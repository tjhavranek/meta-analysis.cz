REPLICATION PACKAGE
Paper: Meta-Analysis of Field Studies on Beauty and Professional Success
Authors: Z. Irsova, T. Havranek, K. Bortnikova, F. Bartoš

------------------------------------------------------------
1. CONTENTS
------------------------------------------------------------
/data/
    beauty.xlsx        (input dataset, sheet "data")

/code/
    beauty.do
    beauty.R

README.txt

------------------------------------------------------------
2. SOFTWARE REQUIREMENTS
------------------------------------------------------------
Stata 15 or higher.
R version 4.x 

------------------------------------------------------------
3. REPLICATION STEPS
------------------------------------------------------------
STEP 1 — STATA ANALYSES
Run:
    do code/beauty.do

This script reproduces all Stata-based analyses reported in the paper. In particular, it:

  - imports beauty.xlsx (sheet "data") and constructs all analysis variables,
    including winsorized effects and standard errors;
  - produces descriptive statistics, correlations, and multicollinearity diagnostics;
  - generates all Stata graphs used in the paper:
        * histogram of the beauty effect
        * time trend of study-level median estimates
        * box plots by study and by country
        * funnel plots (full sample and highlighting sex workers)
        * caliper-plot histogram with kernel density;
  - runs publication-bias procedures:
        * FAT–PET regressions (clustered by study and by database)
        * PET–PEESE meta-regression
        * WAAP (Ioannidis et al., 2017)
        * endogenous-kink model (Bom & Rachinger, 2020)
        * caliper tests around 0, 1.96, and 2.58 (Gerber & Malhotra, 2008),
  - performs heterogeneity and “best-practice” frequentist analyses, including
    fitted effects for subgroups;
  - exports the R-ready dataset:
        beauty_R.xlsx
    into the /data/ folder.


STEP 2 — R ANALYSES
Run:
    source("code/beauty.R")

The R script automatically performs:

A) Publication-bias corrections (on beauty_R.xlsx)
   - Right-Truncated Meta-Analysis (Mathur)
   - STEM-based method (Furukawa)
   - Andrews & Kasy selection model

B) RoBMA analyses (on beauty.xlsx)
   - Full-sample and 3-level RoBMA models
   - NoBMA models for comparison
   - Subgroup models (industry, occupation, gender,
     customer contact, output measurability, interpersonal intensity,
     cognition, salary, penalties, prostitutes)
   - Adjusted models with covariates

C) Bayesian Model Averaging (on beauty_R.xlsx)
   - Three BMS specifications
   - Standard BMS outputs saved to /output/

D) Best-Practice Predictions
   - Posterior-based estimates for a best-practice design
   - Subgroup-specific BP predictions

E) Occupation-Weighted Representative Estimate
   - Employment-share weighting
   - Corrected pooled estimate with simulation-based CI

All R outputs (tables, figures, RDS files) are saved in /output/.

------------------------------------------------------------
4. RUNTIME
------------------------------------------------------------
Stata analyses: minutes
Publication-bias methods in R: tens of minutes
BMS in R: minutes
RoBMA + adjusted models: ~24 hours (parallel)

------------------------------------------------------------
5. CONTACT
------------------------------------------------------------
zuzana.irsova@fsv.cuni.cz
f.bartos96@gmail.com (for RoBMA)
