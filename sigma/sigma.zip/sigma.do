******************************************************************************
******************************************************************************
*Elasticity of subtitution between capital and labor - Meta-analysis
******************************************************************************
******************************************************************************

clear all
log using sigma.log, replace
import excel sigma.xlsx, firstrow clear
xtset idstudy
*use "sigma.dta", clear

*net install winsor2 
*ssc install ivreg2
*ssc install estout
*ssc install winsor2
*ssc install ranktest
*ssc install outreg2
*ssc install boottest

******************************************************************************
*DATA PREPARATION: generate additional variables
******************************************************************************

replace se=0.001 if se==0
gen prec = 1/se
gen prec2 = 1/(se*se)
gen tstat = sigma/se
gen lnobs=ln(nobs)
gen lnpubyear=ln(pubyear)
gen lnmidpoint = ln(midpoint)
replace midpoint = ln(midpoint - 1850+1)
gen pubyear2 = pubyear
replace pubyear = ln(pubyear - 1961+1)
gen lntimespan = ln(time_span)
gen lncrossunits = ln(cross_units)
gen lnyearcits = ln(citations+1)
gen invsqrtnobs = 1/sqrt(nobs)
gen sqrtnobs = sqrt(nobs)
bysort idstudy: egen idmax = max(idcoeff)
gen last=0
replace last = 1 if idmax==idcoeff
bysort idstudy: egen sigmamed = median(sigma)
bysort idstudy: egen precmed = median(prec)
bysort idstudy: egen tmed = median(tstat)
bysort idstudy: egen semed = median(se)
bysort idstudy: egen perstudy = count(sigma)
gen invperstudy = 1/perstudy
egen sigmamedfull = median(sigma)
gen developing = 0
replace developing = 1 if develop ==2
gen net = 0
replace net =1 if grosssigma == -1
gen stacoudata = stadata + coudata
label var formula "Functional form of sigma actually estimated; f(sig)"
label var limit_val "Value of sigma corresponding to a small (noisy) estimate of f(sigma); f(sig)=0; biased value"
label var viadelta "SE calculated via delta method by us"
gen formula_code=0
label var formula_code "Numeric values for functional forms"
order sigma formula formula_code viadelta limit_val
replace formula_code=1 if formula==" -1/sig"
replace formula_code=1 if formula=="1/sig"
replace formula_code=2 if formula=="1-sig"
replace formula_code=2 if formula=="sig-1"
replace formula_code=3 if formula=="(1-sig)/sig"
replace formula_code=3 if formula=="(sig-1)/sig"
replace formula_code=4 if formula=="sig/(1+sig)"
replace formula_code=4 if formula=="sig/(1-sig)"
replace formula_code=5 if formula=="Kmenta"
replace formula_code=5 if formula=="taylor"
replace formula_code=6 if formula=="translog"
replace formula_code=7 if formula=="CES-translog" // or separately??
replace formula_code=8 if formula=="xx"
gen limitval_code=0
label var limitval_code "Numeric values for limit values"
replace limitval_code=1 if limit_val=="1"
replace limitval_code=2 if limit_val==" +-inf"

**********************************************************************************************************
*DATA PREPARATION: winsorize, generate p-value and variance
**********************************************************************************************************

winsor2 sigma se invsqrtnobs, suffix(_win5) cuts(5 95) label
gen prec_win5= 1/se_win5
gen prec_win5_sq= 1/(se_win5*se_win5)
gen tstat_win5 = sigma_win5/se_win5

bysort idstudy: egen sigmamed5 = median(sigma_win5)
bysort idstudy: egen precmed5 = median(prec_win5)
bysort idstudy: egen tmed5 = median(tstat_win5)
bysort idstudy: egen semed5 = median(se_win5)

gen pval = (2 * ttail(nobs, abs(tstat)))
centile pval, centile(5(5)95)
gen pval_win5 = (2 * ttail(nobs, abs(tstat_win5)))
centile pval_win5, centile(5(5)95)
gen variance = se*se
gen variance_win5 = se_win5*se_win5


sum sigma
sum sigma [aweight=invperstudy]

*  Variable |   Obs   Weight    Mean  Std. Dev.    Min    Max
*-------------+-----------------------------------------------------------------
*    sigma |  3,186 121.000002  .8670149  3.908022  -85.981    200

******************************************************************************
*DATA ANALYSIS - summary statistics
******************************************************************************
sum sigma_win5 [aweight=invperstudy] if e_sys_2foc==1
sum sigma_win5 [aweight=invperstudy] if e_cesnonlin==1
sum sigma_win5 [aweight=invperstudy] if e_ceslinapprox==1
sum sigma_win5 [aweight=invperstudy] if e_foc_k_r==1
sum sigma_win5 [aweight=invperstudy] if e_foc_l_w==1 
sum sigma_win5 [aweight=invperstudy] if e_foc_kl_rw==1
sum sigma_win5 [aweight=invperstudy] if e_foc_k_share==1
sum sigma_win5 [aweight=invperstudy] if e_foc_l_share==1
sum sigma_win5 [aweight=invperstudy] if inddata ==1
sum sigma_win5 [aweight=invperstudy] if stacoudata ==1
sum sigma_win5 [aweight=invperstudy] if firmdata ==1
sum sigma_win5 [aweight=invperstudy] if timeser ==1
sum sigma_win5 [aweight=invperstudy] if crosssec ==1
sum sigma_win5 [aweight=invperstudy] if panel ==1
sum sigma_win5 [aweight=invperstudy] if ind_disagg ==1
sum sigma_win5 [aweight=invperstudy] if ind_disagg ==0

sum sigma_win5  if e_sys_2foc==1
sum sigma_win5  if e_cesnonlin==1
sum sigma_win5  if e_ceslinapprox==1
sum sigma_win5  if e_foc_k_r==1
sum sigma_win5  if e_foc_l_w==1 
sum sigma_win5  if e_foc_kl_rw==1
sum sigma_win5  if e_foc_k_share==1
sum sigma_win5  if e_foc_l_share==1
sum sigma_win5  if inddata ==1
sum sigma_win5  if stacoudata ==1
sum sigma_win5  if firmdata ==1
sum sigma_win5  if timeser ==1
sum sigma_win5  if crosssec ==1
sum sigma_win5  if panel ==1
sum sigma_win5  if ind_disagg ==1
sum sigma_win5  if ind_disagg ==0

sum sigma_win5 if formula_code==0 //pure sigma
sum sigma_win5 [aweight=invperstudy] if formula_code==0
sum sigma_win5 if formula_code==1 //limit_val +-inf [(1/sig) and (-1/sig)]
sum sigma_win5 [aweight=invperstudy] if formula_code==1
sum sigma_win5 if formula_code==2 //limit_val 1 [(1-sig) and (sig-1)]
sum sigma_win5 [aweight=invperstudy] if formula_code==2
sum sigma_win5 if formula_code==3 //limit_val 1 [(sig-1)/sig and (1-sig)/sig]
sum sigma_win5 [aweight=invperstudy] if formula_code==3
sum sigma_win5 if formula_code==4 //limit_val 0 [sig/(1+sig) and sig/(1-sig)]
sum sigma_win5 [aweight=invperstudy] if formula_code==4
sum sigma_win5 if formula_code==5 //limit_val 1 [Taylor and Kmenta]
sum sigma_win5 [aweight=invperstudy] if formula_code==5
sum sigma_win5 if formula_code==6 //limit val 1 [translog]
sum sigma_win5 [aweight=invperstudy] if formula_code==6
sum sigma_win5 if formula_code==7 //no limit_val [CES-translog]
sum sigma_win5 [aweight=invperstudy] if formula_code==7
sum sigma_win5 if formula_code==8 //xx
sum sigma_win5 [aweight=invperstudy] if formula_code==8
sum sigma_win5 if limit_val=="0" | limit_val==""
sum sigma_win5 [aweight=invperstudy] if limit_val=="0" | limit_val==""
sum sigma_win5 if limit_val=="1"
sum sigma_win5 [aweight=invperstudy] if limit_val=="1"
sum sigma_win5 if limit_val==" +-inf"
sum sigma_win5 [aweight=invperstudy] if limit_val==" +-inf"

******************************************************************************
*DATA ANALYSIS - histograms
******************************************************************************

*boxplot of all studies
graph hbox sigma if sigma<3 & sigma>-1 , over(study, sort(avyear)) xsize(13) ysize(18) scale(0.35) saving(box, replace)

*histogram
hist sigma if sigma >-1 & sigma<3 , width(0.1) xlabel(-1(0.5)3) start(-1) frequency bcolor(edkbg) 

*stylized facts
twoway (hist sigma if e_foc_k_r==1 & sigma<3 & sigma>-1, freq lcolor(gs12) fcolor(gs12) legend(label(1 "FOC_K_r"))) (hist sigma if e_foc_l_w==1 & sigma<3 & sigma>-1, freq fcolor(cranberry) lcolor(cranberry) legend(label(2 "FOC_L_w")))
twoway (hist sigma if ind_disagg==1 & sigma<3 & sigma>-1, freq lcolor(gs12) fcolor(gs12) legend(label(1 "Industry-level"))) (hist sigma_win5 if ind_disagg==0 & sigma_win5<3 , freq fcolor(cranberry) lcolor(cranberry) legend(label(2 "Whole economy")))
twoway (hist sigma if stacoudata==1 & sigma<3 & sigma>-1, freq lcolor(gs12) fcolor(gs12) legend(label(1 "Country data"))) (hist sigma if inddata==1 & sigma <3 & sigma>-1, freq fcolor(cranberry) lcolor(cranberry) legend(label(2 "Industry data"))) (hist   sigma if firmdata==1 & sigma <3 & sigma>-1,  freq lcolor(navy) fcolor(navy) legend(label(3 "Firm data"))) 
twoway (hist sigma if timeser==1  & sigma<3 & sigma>-1, freq lcolor(gs12) fcolor(gs12) legend(label(1 "Time series"))) (hist sigma if crosssec==1 & sigma<3 & sigma>-1, freq fcolor(cranberry) lcolor(cranberry) legend(label(2 "Cross section")))  (hist sigma if panel==1 & sigma<3 & sigma>-1, freq fcolor(navy) lcolor(navy) legend(label(3 "Panel")))

******************************************************************************
*PUBLICATION BIAS - Funnel plot (Egger et al., 1997)
******************************************************************************

scatter prec sigma if sigma<4 & sigma>-2 & prec<100 , msize(*.5) msymbol(Oh) saving(funnel_all, replace) xlabel(-2(1)4) 
scatter precmed sigmamed , msize(*1) msymbol(O) saving(funnel_perstudy, replace)

*tstat
hist tstat if tstat <15 & tstat>-5, width(1) xlabel(-5(5)15) xtitle("Reported t-statistics") normal saving(hist_tstat, replace)

******************************************************************************
*PUBLICATION BIAS - FAT-PET (Stanley, 2005)
******************************************************************************

*full sample
xtset idstudy
eststo: ivreg2 sigma_win5 se_win5, cluster (idstudy idcountry)
boottest se_win5, nograph
boottest _cons, nograph
eststo: xtreg sigma_win5 se_win5, fe cluster (idstudy)
eststo: xtreg sigma_win5 se_win5, be 
eststo: ivreg2 sigma_win5 se_win5 [pweight=prec_win5_sq], cluster (idstudy idcountry)
boottest se_win5, nograph
boottest _cons, nograph
eststo: ivreg2 sigma_win5 se_win5 [pweight=invperstudy], cluster (idstudy idcountry)
boottest se_win5, nograph
boottest _cons, nograph
esttab using "fatpet.tex", se booktabs replace compress title(Funnel asymmetry test\label{tab:fat}) mtitles("OLS" "FE" "BE" "PREC2" "STUDY") addnote("Standard errors are clustered at the study and country level.") star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) label nonumber nogaps width(1\hsize)
eststo clear

******************************************************************************
* REVISION --- PUBLICATION BIAS - subsample using no formula constraints 
******************************************************************************

*only "pure sigma" estimates
eststo: ivreg2 sigma_win5 se_win5 if formula_code==0, cluster (idstudy idcountry)
boottest se_win5, nograph
boottest _cons, nograph
eststo: xtreg sigma_win5 se_win5 if formula_code==0, fe cluster (idstudy)
eststo: xtreg sigma_win5 se_win5 if formula_code==0, be 
eststo: ivreg2 sigma_win5 se_win5 [pweight=prec_win5_sq] if formula_code==0, cluster (idstudy idcountry)
boottest se_win5, nograph
boottest _cons, nograph
eststo: ivreg2 sigma_win5 se_win5 [pweight=invperstudy] if formula_code==0, cluster (idstudy idcountry)
boottest se_win5, nograph
boottest _cons, nograph
esttab using "fatpet_pure.tex", se booktabs replace compress title(Funnel asymmetry test\label{tab:fat}) mtitles("OLS" "FE" "BE" "PREC2" "STUDY") addnote("Standard errors are clustered at the study and country level.") star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) label nonumber nogaps width(1\hsize)
eststo clear

******************************************************************************
* REVISION --- PUBLICATION BIAS - checking dependence on study design
******************************************************************************

*identification
gen se_identif = se_win5 * identif
*aggregated data (input) 
gen se_stacoudata = se_win5 * stacoudata
*disaggregation on the industry/sector level (output)
gen se_ind_disagg = se_win5 * ind_disagg
*inventory dummy
gen se_k_perpet = se_win5 * k_perpet
*translog
gen translog =0
replace translog=1 if formula_code==6 | formula_code==7
gen se_translog = se_win5*translog
*short-run dummy
gen se_short = se_win5 * shortrun_expl

xtset idstudy
xtreg sigma_win5 se_win5, fe cluster (idstudy)
eststo: xtreg sigma_win5 se_win5 se_identif identif, fe cluster (idstudy)
eststo: xtreg sigma_win5 se_win5 se_stacoudata stacoudata, fe cluster (idstudy)
eststo: xtreg sigma_win5 se_win5 se_ind_disagg ind_disagg, fe cluster (idstudy)
eststo: xtreg sigma_win5 se_win5 se_k_perpet k_perpet, fe cluster (idstudy)
eststo: xtreg sigma_win5 se_win5 se_translog translog, fe cluster (idstudy)
eststo: xtreg sigma_win5 se_win5 se_short shortrun_expl, fe cluster (idstudy)
eststo: xtreg sigma_win5 se_win5 se_identif identif se_stacoudata stacoudata se_ind_disagg ind_disagg se_k_perpet k_perpet se_translog translog se_short shortrun_expl, fe cluster (idstudy)
esttab using "dependence.tex", se booktabs replace compress title(Funnel asymmetry test\label{tab:fat}) mtitles("ident" "aggreg_inp" "aggreg_out" "inventory" "tlog" "short" "all") addnote("Standard errors are clustered at the study and country level.") star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) label nonumber nogaps width(1\hsize)
eststo clear

******************************************************************************
* PUBLICATION BIAS - WAAP (Ioannidis et al., 2017) 
******************************************************************************

reg tstat_win5 prec_win5, noconstant
reg tstat_win5 prec_win5 if se<0.5059035/2.8, noconstant cluster(idstudy)

******************************************************************************
* PUBLICATION BIAS - TOP10 method (Stanley et al., 2010)
******************************************************************************
sum sigma if se<= .022

*Andrews & Kasy and Furukawa - in their web applications

******************************************************************************
* REVISION --- PUBLICATION BIAS 
* using Caliper test (Gerber & Malhotra, 2008) 
******************************************************************************

sum tstat
histogram tstat if tstat<30, bin(70) fcolor(gs14) lstyle(thin) frequency normal xtitle("t-statistics of sigma") xlabel(-5 -1.96 0 1.96 5 10 15 20 25) xline(0 1.96 , lcolor(red)) ylabel( ,glcolor(ltbluishgray)) graphregion(color(ltbluishgray)) saving(caliper, replace)
* weighted by number of estimates per study
generate significant = 0
replace significant = 1 if tstat > 1.96
reg significant if tstat > 1.91 & tstat < 2.01 [aweight=invperstudy]
 lincom _cons - 0.5
reg significant if tstat > 1.86 & tstat < 2.06 [aweight=invperstudy]
 lincom _cons - 0.5
reg significant if tstat > 1.81 & tstat < 2.11 [aweight=invperstudy]
 lincom _cons - 0.5
reg significant if tstat > 1.76 & tstat < 2.16 [aweight=invperstudy]
 lincom _cons - 0.5
reg significant if tstat > 1.71 & tstat < 2.21 [aweight=invperstudy]
 lincom _cons - 0.5
reg significant if tstat > 1.66 & tstat < 2.26 [aweight=invperstudy]
 lincom _cons - 0.5
reg significant if tstat > 1.61 & tstat < 2.31 [aweight=invperstudy]
 lincom _cons - 0.5
reg significant if tstat > 1.56 & tstat < 2.36 [aweight=invperstudy]
 lincom _cons - 0.5
reg significant if tstat > 1.51 & tstat < 2.41 [aweight=invperstudy]
 lincom _cons - 0.5
reg significant if tstat > 1.46 & tstat < 2.46 [aweight=invperstudy]
 lincom _cons - 0.5
reg significant if tstat > 1.36 & tstat < 2.56 [aweight=invperstudy]
 lincom _cons - 0.5
reg significant if tstat > 1.26 & tstat < 2.66 [aweight=invperstudy]
 lincom _cons - 0.5
reg significant if tstat > 1.16 & tstat < 2.76 [aweight=invperstudy]
 lincom _cons - 0.5
reg significant if tstat > 1.06 & tstat < 2.86 [aweight=invperstudy]
 lincom _cons - 0.5
drop significant

******************************************************************************
* testing for selection towards 1.3 in labor-share estimates (only 123 obs)
gen tstat_13 = (sigma - 1.3)/se
sum tstat_13
gen significant = 0
replace significant = 1 if tstat_13 > -1.96 // to get interpretation of the coeff as the share of estimates "above" caliper minus 0.5
histogram tstat_13 if tstat_13>-5 & tstat_13<0 & (e_foc_l_share==1 | e_focrev_l_share==1), bin(30) fcolor(gs14) lstyle(thin) frequency normal xtitle("t-statistics of sigma (1.3)") xlabel(-5 -3 -1.96 -1 0 ) xline(0 -1.96 , lcolor(red)) ylabel( ,glcolor(ltbluishgray)) graphregion(color(ltbluishgray))
* weighted by no. of estimates per study (labor-share estimates)
*reg significant if tstat_13 > -2.01 & tstat_13 < -1.91 & (e_foc_l_share==1 | e_focrev_l_share==1) [aweight=invperstudy]
* lincom _cons - 0.5 
reg significant if tstat_13 > -2.06 & tstat_13 < -1.86 & (e_foc_l_share==1 | e_focrev_l_share==1) [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.11 & tstat_13 < -1.81 & (e_foc_l_share==1 | e_focrev_l_share==1) [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.16 & tstat_13 < -1.76 & (e_foc_l_share==1 | e_focrev_l_share==1) [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.21 & tstat_13 < -1.71 & (e_foc_l_share==1 | e_focrev_l_share==1) [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.26 & tstat_13 < -1.66 & (e_foc_l_share==1 | e_focrev_l_share==1) [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.31 & tstat_13 < -1.61 & (e_foc_l_share==1 | e_focrev_l_share==1) [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.36 & tstat_13 < -1.56 & (e_foc_l_share==1 | e_focrev_l_share==1) [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.41 & tstat_13 < -1.51 & (e_foc_l_share==1 | e_focrev_l_share==1) [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.46 & tstat_13 < -1.46 & (e_foc_l_share==1 | e_focrev_l_share==1) [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.56 & tstat_13 < -1.36 & (e_foc_l_share==1 | e_focrev_l_share==1) [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.66 & tstat_13 < -1.26 & (e_foc_l_share==1 | e_focrev_l_share==1) [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.76 & tstat_13 < -1.16 & (e_foc_l_share==1 | e_focrev_l_share==1) [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.86 & tstat_13 < -1.06 & (e_foc_l_share==1 | e_focrev_l_share==1) [aweight=invperstudy]
 lincom _cons - 0.5  

 
 sum tstat_13 if pubyear2>2012
 histogram tstat_13 if tstat_13>-5 & pubyear2>2012, bin(40) fcolor(gs14) lstyle(thin) frequency normal xtitle("t-statistics of sigma (1.3)") xlabel(-5 -3 -1.96 -1 0 1) xline(0 -1.96 , lcolor(red)) ylabel( ,glcolor(ltbluishgray)) graphregion(color(ltbluishgray))
* weighted by no. of estimates per study (estimates published since 2013)
reg significant if tstat_13 > -2.01 & tstat_13 < -1.91 & pubyear2>2012 [aweight=invperstudy]
 lincom _cons - 0.5  
reg significant if tstat_13 > -2.06 & tstat_13 < -1.86 & pubyear2>2012 [aweight=invperstudy]
 lincom _cons - 0.5  
reg significant if tstat_13 > -2.11 & tstat_13 < -1.81 & pubyear2>2012 [aweight=invperstudy]
 lincom _cons - 0.5  
reg significant if tstat_13 > -2.16 & tstat_13 < -1.76 & pubyear2>2012 [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.21 & tstat_13 < -1.71 & pubyear2>2012 [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.26 & tstat_13 < -1.66 & pubyear2>2012 [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.31 & tstat_13 < -1.61 & pubyear2>2012 [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.36 & tstat_13 < -1.56 & pubyear2>2012 [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.41 & tstat_13 < -1.51 & pubyear2>2012 [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.46 & tstat_13 < -1.46 & pubyear2>2012 [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.56 & tstat_13 < -1.36 & pubyear2>2012 [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.66 & tstat_13 < -1.26 & pubyear2>2012 [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.76 & tstat_13 < -1.16 & pubyear2>2012 [aweight=invperstudy]
 lincom _cons - 0.5 
reg significant if tstat_13 > -2.86 & tstat_13 < -1.06 & pubyear2>2012 [aweight=invperstudy]
 lincom _cons - 0.5  
drop significant 
drop tstat_13

******************************************************************************
* testing for selection towards unity in unity-constrained estimates 
gen tstat_10 = (sigma - 1.0)/se
sum tstat_10 if (formula_code==2 | formula_code==3)
gen significant = 0
replace significant = 1 if tstat_10 > -1.96 // to get interpretation of the coeff as the share of estimates "above" caliper minus 0.5
histogram tstat_10 if tstat_10>-5 & tstat_10<0 & (formula_code==2 | formula_code==3), bin(30) fcolor(gs14) lstyle(thin) frequency normal xtitle("t-statistics of sigma (1)") xlabel(-5 -3 -1.96 -1 0 ) xline(0 -1.96 , lcolor(red)) ylabel( ,glcolor(ltbluishgray)) graphregion(color(ltbluishgray))

*reg significant if tstat_10 > -2.01 & tstat_10 < -1.91 & (formula_code==2 | formula_code==3) [aweight=invperstudy]
* lincom _cons - 0.5  
*reg significant if tstat_10 > -2.06 & tstat_10 < -1.86 & (formula_code==2 | formula_code==3) [aweight=invperstudy]
* lincom _cons - 0.5  
*reg significant if tstat_10 > -2.11 & tstat_10 < -1.81 & (formula_code==2 | formula_code==3) [aweight=invperstudy]
* lincom _cons - 0.5  
*reg significant if tstat_10 > -2.16 & tstat_10 < -1.76 & (formula_code==2 | formula_code==3) [aweight=invperstudy]
* lincom _cons - 0.5  
reg significant if tstat_10 > -2.21 & tstat_10 < -1.71 & (formula_code==2 | formula_code==3) [aweight=invperstudy]
 lincom _cons - 0.5  
reg significant if tstat_10 > -2.26 & tstat_10 < -1.66 & (formula_code==2 | formula_code==3) [aweight=invperstudy]
 lincom _cons - 0.5  
reg significant if tstat_10 > -2.31 & tstat_10 < -1.61 & (formula_code==2 | formula_code==3) [aweight=invperstudy]
 lincom _cons - 0.5  
reg significant if tstat_10 > -2.36 & tstat_10 < -1.56 & (formula_code==2 | formula_code==3) [aweight=invperstudy]
 lincom _cons - 0.5  
reg significant if tstat_10 > -2.41 & tstat_10 < -1.51 & (formula_code==2 | formula_code==3) [aweight=invperstudy]
 lincom _cons - 0.5  
reg significant if tstat_10 > -2.46 & tstat_10 < -1.46 & (formula_code==2 | formula_code==3) [aweight=invperstudy]
 lincom _cons - 0.5  
reg significant if tstat_10 > -2.56 & tstat_10 < -1.36 & (formula_code==2 | formula_code==3) [aweight=invperstudy]
 lincom _cons - 0.5  
reg significant if tstat_10 > -2.66 & tstat_10 < -1.26 & (formula_code==2 | formula_code==3) [aweight=invperstudy]
 lincom _cons - 0.5  
reg significant if tstat_10 > -2.76 & tstat_10 < -1.16 & (formula_code==2 | formula_code==3) [aweight=invperstudy]
 lincom _cons - 0.5  
reg significant if tstat_10 > -2.86 & tstat_10 < -1.06 & (formula_code==2 | formula_code==3) [aweight=invperstudy]
 lincom _cons - 0.5  
 drop significant 
 drop tstat_10

******************************************************************************
* REVISION --- PUBLICATION BIAS 
* using IV and p-uniform* (van Aert & van Assen, 2019) - code for Stata & R
******************************************************************************

*instrumental variable
ivreg2 sigma_win5 (se_win5=invsqrtnobs), cluster(idstudy idcountry)
boottest se_win5, nograph
boottest _cons, nograph

*generate data for p-uniform*
preserve
sort idcoeff
collapse (lastnm) idcoeff_med=idcoeff sigma_med=sigmamed sigma5_med=sigmamed5 se_med=semed se5_med=semed5 tstat_med=tmed tstat5_med=tmed5 (p50) nobs_med=nobs, by(idstudy)
save "pcurve.dta", replace
restore

/* code for R
library(installr)
library(puniform)
library(metafor)
library(dmetar)
library(haven)
library(tidyverse)
library(meta)

data <- read_dta("pcurve.dta")
puni_star(tobs = data$tstat_med, ni = data$nobs_med, alpha = 0.05, side = "right", method = "ML", control=list(stval.tau=0.5, max.iter=10000,tol=0.1,reps=10000, int=c(0,2), verbose=TRUE))
*/

******************************************************************************
* HETEROGENEITY - data preparation for BMA and FMA
******************************************************************************

replace e_foc_k_r = e_foc_k_r + e_focrev_k_r
replace e_foc_l_w = e_foc_l_w + e_focrev_l_w
replace e_foc_kl_rw = e_foc_kl_rw + e_focrev_kl_rw
replace e_foc_k_share = e_foc_k_share + e_focrev_k_share + e_foc_kl_share + e_focrev_kl_share
replace e_foc_l_share = e_foc_l_share + e_focrev_l_share
replace pfoth = pfoth + pfhum
drop  e_focrev_k_r  e_focrev_l_w e_focrev_kl_rw e_focrev_k_share e_foc_kl_share e_focrev_kl_share e_focrev_l_share pfhum ind_services est_nonlin 

*baseline
preserve
order sigma_win5 se_win5 preferred byproduct crosssec panel lnobs midpoint quart firmdata inddata /*stadata*/ country_US country_Eur develop ind_primary ind_disagg ind_second ind_tertiary ind_materials ind_industrials ind_consumer database_ASM_CM database_OECD database_jorgenson e_sys_cesfoc e_sys_2foc e_cesnonlin e_ceslinapprox e_foc_l_w e_foc_kl_rw e_foc_kl_rw e_foc_k_share e_foc_l_share cerest2 norm twolevel partialsig UCE est_dynamic     est_sur identif diff timefe unitfe shortrun_expl longrun_unadj pfoth pfcatc pflatc pfskill tcconst tcother nocrs  nofullcomp k_it k_equip k_struct qualadjust selfempl net capacadj top impact pubyear lnyearcits 
drop nobs time_span lntimespan lncrossunits cross_units developing grosssigma citations lnpubyear lnmidpoint A idstudy study idcoeff sigma se t viadelta prec prec2 tstat invsqrtnobs sqrtnobs idmax last sigmamed precmed tmed perstudy invperstudy sigmamedfull  //drop the rest
drop w_nominal w_direct l_hours l_years l_numwork l_numwork_fte l_force r_ucc r_ucctax r_quasi r_other r_nom r_gross k_it k_equip k_struct k_resincl k_service k_perpet k_index y_index y_other 
drop label country idcountry VES invsqrtnobs_win5 prec_win5 tstat_win5 
drop ind_primary ind_second ind_tertiary ind_materials ind_industrials ind_consumer stacoudata
drop country_Eur_noUK cerest country_UK
drop selfempl capacadj qualadj sigmamed5 impact
drop timeser annual e_foc_k_r coudata longrun_expl pftfp stadata //drop baseline
saveold "bma", version(12) replace
restore

*weighted by sqrt(invperstudy)
preserve
local rhsvars sigma_win5 se_win5 preferred byproduct crosssec panel lnobs midpoint  quart firmdata inddata /*stadata*/ country_US country_Eur  develop ind_primary ind_disagg ind_second ind_tertiary ind_materials ind_industrials ind_consumer  database_ASM_CM database_OECD database_jorgenson  e_sys_cesfoc e_sys_2foc e_cesnonlin e_ceslinapprox  e_foc_l_w e_foc_kl_rw  e_foc_kl_rw e_foc_k_share e_foc_l_share    cerest2 norm twolevel partialsig UCE est_dynamic     est_sur identif diff timefe unitfe shortrun_expl longrun_unadj pfoth pfcatc pflatc  pfskill  tcconst tcother               nocrs  nofullcomp k_it k_equip k_struct qualadjust selfempl net capacadj top impact pubyear lnyearcits 
foreach x of varlist `rhsvars' {
  replace `x' = `x' * sqrt(invperstudy)
}
order sigma_win5 se_win5 preferred byproduct crosssec panel lnobs midpoint  quart firmdata inddata /*stadata*/ country_US country_Eur  develop ind_primary ind_disagg ind_second ind_tertiary ind_materials ind_industrials ind_consumer  database_ASM_CM database_OECD database_jorgenson  e_sys_cesfoc e_sys_2foc e_cesnonlin e_ceslinapprox  e_foc_l_w e_foc_kl_rw  e_foc_kl_rw e_foc_k_share e_foc_l_share    cerest2 norm twolevel partialsig UCE est_dynamic     est_sur identif diff timefe unitfe shortrun_expl longrun_unadj pfoth pfcatc pflatc  pfskill  tcconst tcother               nocrs  nofullcomp k_it k_equip k_struct qualadjust selfempl net capacadj top impact pubyear lnyearcits 
drop nobs time_span lntimespan lncrossunits cross_units developing grosssigma citations lnpubyear lnmidpoint A idstudy study idcoeff sigma se t viadelta prec prec2 tstat invsqrtnobs sqrtnobs idmax last sigmamed precmed tmed perstudy invperstudy sigmamedfull  //drop the rest
drop w_nominal w_direct l_hours l_years l_numwork l_numwork_fte l_force r_ucc r_ucctax r_quasi r_other r_nom r_gross k_it k_equip k_struct k_resincl k_service k_perpet k_index y_index y_other 
drop label country idcountry VES invsqrtnobs_win5 prec_win5 tstat_win5 
drop ind_primary ind_second ind_tertiary ind_materials ind_industrials ind_consumer stacoudata
drop country_Eur_noUK cerest country_UK
drop selfempl capacadj qualadj sigmamed5 impact
drop timeser annual e_foc_k_r coudata longrun_expl pftfp stadata //drop baseline
saveold "bma_invper", version(12) replace
restore

*weighted by 1/SE
preserve
local rhsvars sigma_win5 preferred byproduct crosssec panel lnobs midpoint  quart firmdata inddata /*stadata*/ country_US country_Eur  develop ind_primary ind_disagg ind_second ind_tertiary ind_materials ind_industrials ind_consumer  database_ASM_CM database_OECD database_jorgenson  e_sys_cesfoc e_sys_2foc e_cesnonlin e_ceslinapprox  e_foc_l_w e_foc_kl_rw  e_foc_kl_rw e_foc_k_share e_foc_l_share    cerest2 norm twolevel partialsig UCE est_dynamic     est_sur identif diff timefe unitfe shortrun_expl longrun_unadj pfoth pfcatc pflatc  pfskill  tcconst tcother               nocrs  nofullcomp k_it k_equip k_struct qualadjust selfempl net capacadj top impact pubyear lnyearcits 
foreach aa in `rhsvars' {
  replace `aa' = (`aa'/se_win5)
}
order sigma_win5 se_win5 preferred byproduct crosssec panel lnobs midpoint  quart firmdata inddata /*stadata*/ country_US country_Eur  develop ind_primary ind_disagg ind_second ind_tertiary ind_materials ind_industrials ind_consumer  database_ASM_CM database_OECD database_jorgenson  e_sys_cesfoc e_sys_2foc e_cesnonlin e_ceslinapprox  e_foc_l_w e_foc_kl_rw  e_foc_kl_rw e_foc_k_share e_foc_l_share    cerest2 norm twolevel partialsig UCE est_dynamic     est_sur identif diff timefe unitfe shortrun_expl longrun_unadj pfoth pfcatc pflatc  pfskill  tcconst tcother               nocrs  nofullcomp k_it k_equip k_struct qualadjust selfempl net capacadj top impact pubyear lnyearcits 
drop nobs time_span lntimespan lncrossunits cross_units developing grosssigma citations lnpubyear lnmidpoint A idstudy study idcoeff sigma se t viadelta prec prec2 tstat invsqrtnobs sqrtnobs idmax last sigmamed precmed tmed perstudy invperstudy sigmamedfull  //drop the rest
drop w_nominal w_direct l_hours l_years l_numwork l_numwork_fte l_force r_ucc r_ucctax r_quasi r_other r_nom r_gross k_it k_equip k_struct k_resincl k_service k_perpet k_index y_index y_other 
drop label country idcountry VES invsqrtnobs_win5 prec_win5 tstat_win5 
drop ind_primary ind_second ind_tertiary ind_materials ind_industrials ind_consumer stacoudata
drop country_Eur_noUK cerest country_UK
drop selfempl capacadj qualadj sigmamed5 impact
drop se_win5 //intercept
drop timeser annual e_foc_k_r coudata longrun_expl pftfp stadata //drop baseline
saveold "bma_se", version(12) replace
restore

*estimation with labor measurement variables only
*check correlations
corr se_win5 preferred byproduct crosssec panel lnobs midpoint quart firmdata inddata country_US country_Eur developing ind_disagg database_ASM_CM database_OECD database_jorgenson e_sys_cesfoc e_sys_2foc e_ceslinapprox e_foc_l_w e_foc_l_share cerest2 norm twolevel est_dynamic est_sur identif diff timefe unitfe shortrun_expl longrun_unadj pfoth pflatc pfskill tcconst tcother nocrs nofullcomp qualadjust selfempl net capacadj top impact pubyear lnyearcits w_nominal w_direct l_hours l_years l_numwork l_numwork_fte l_force y_index y_other
return list
matrix list r(C)
putexcel A1=matrix(r(C), names) using "corr_L.xlsx"

preserve
order sigma_win5 se_win5 preferred byproduct crosssec panel lnobs midpoint  quart firmdata inddata /*stadata*/ country_US country_Eur developing ind_primary ind_disagg ind_second ind_tertiary ind_materials ind_industrials ind_consumer  database_ASM_CM database_OECD database_jorgenson  e_sys_cesfoc e_sys_2foc e_cesnonlin e_ceslinapprox  e_foc_l_w e_foc_kl_rw  e_foc_kl_rw e_foc_k_share e_foc_l_share    cerest2 norm twolevel partialsig UCE est_dynamic     est_sur identif diff timefe unitfe shortrun_expl longrun_unadj pfoth pfcatc pflatc  pfskill  tcconst tcother               nocrs  nofullcomp k_it k_equip k_struct qualadjust selfempl net capacadj top impact pubyear lnyearcits 
drop nobs time_span lntimespan lncrossunits cross_units develop grosssigma citations lnpubyear lnmidpoint A idstudy study idcoeff sigma se t viadelta prec prec2 tstat invsqrtnobs sqrtnobs idmax last sigmamed precmed tmed perstudy invperstudy sigmamedfull  //drop the rest
drop r_ucc r_ucctax r_quasi r_other r_nom r_gross k_it k_equip k_struct k_resincl k_service k_perpet k_index 
drop label country idcountry VES invsqrtnobs_win5 prec_win5 tstat_win5 
drop ind_primary ind_second ind_tertiary ind_materials ind_industrials ind_consumer stacoudata
drop country_Eur_noUK cerest country_UK
drop if e_foc_l_w ==0 & e_foc_l_share ==0
drop if e_foc_k_share ==1
drop if e_foc_kl_rw ==1
drop e_foc_k_r e_foc_k_share e_foc_kl_rw
drop pfcatc e_cesnonlin partialsig 
drop UCE l_numwork e_foc_l_w
drop capacadj sigmamed5 impact
drop timeser annual coudata longrun_expl pftfp stadata //drop baseline
saveold "bma_labor", version(12) replace
restore

*estimation with capital measurement variables only
preserve
order sigma_win5 se_win5 preferred byproduct crosssec panel lnobs midpoint  quart firmdata inddata /*stadata*/ country_US country_Eur developing ind_primary ind_disagg ind_second ind_tertiary ind_materials ind_industrials ind_consumer  database_ASM_CM database_OECD database_jorgenson  e_sys_cesfoc e_sys_2foc e_cesnonlin e_ceslinapprox  e_foc_l_w e_foc_kl_rw  e_foc_kl_rw e_foc_k_share e_foc_l_share    cerest2 norm twolevel partialsig UCE est_dynamic     est_sur identif diff timefe unitfe shortrun_expl longrun_unadj pfoth pfcatc pflatc  pfskill  tcconst tcother               nocrs  nofullcomp k_it k_equip k_struct qualadjust selfempl net capacadj top impact pubyear lnyearcits 
drop nobs time_span lntimespan lncrossunits cross_units develop grosssigma citations lnpubyear lnmidpoint A idstudy study idcoeff sigma se t viadelta prec prec2 tstat invsqrtnobs sqrtnobs idmax last sigmamed precmed tmed perstudy invperstudy sigmamedfull  //drop the rest
drop w_nominal w_direct l_hours l_years l_numwork l_numwork_fte l_force 
drop label country idcountry VES invsqrtnobs_win5 prec_win5 tstat_win5 
drop ind_primary ind_second ind_tertiary ind_materials ind_industrials ind_consumer stacoudata
drop country_Eur_noUK cerest country_UK
drop if e_foc_k_r ==0 & e_foc_k_share ==0
drop if e_foc_l_share ==1
drop if e_foc_kl_rw ==1
drop e_foc_l_w e_foc_l_share e_foc_kl_rw
drop pflatc 
drop partialsig y_index tcother qualadjust
drop r_gross
drop e_cesnonlin
drop selfempl sigmamed5 impact
drop timeser annual e_foc_k_r coudata longrun_expl pftfp stadata //drop baseline
saveold "bma_capital", version(12) replace
restore

*industry-level estimates
preserve
drop if ind_disagg==0
order sigma_win5 se_win5 preferred byproduct crosssec panel lnobs midpoint  quart firmdata inddata /*stadata*/ country_US country_Eur  develop ind_primary ind_disagg ind_second ind_tertiary ind_materials ind_industrials ind_consumer  database_ASM_CM database_OECD database_jorgenson  e_sys_cesfoc e_sys_2foc e_cesnonlin e_ceslinapprox  e_foc_l_w e_foc_kl_rw  e_foc_kl_rw e_foc_k_share e_foc_l_share    cerest2 norm twolevel partialsig UCE est_dynamic     est_sur identif diff timefe unitfe shortrun_expl longrun_unadj pfoth pfcatc pflatc  pfskill  tcconst tcother               nocrs  nofullcomp k_it k_equip k_struct qualadjust selfempl net capacadj top impact pubyear lnyearcits 
drop nobs time_span lntimespan lncrossunits cross_units developing grosssigma citations lnpubyear lnmidpoint A idstudy study idcoeff sigma se t viadelta prec prec2 tstat invsqrtnobs sqrtnobs idmax last sigmamed precmed tmed perstudy invperstudy sigmamedfull  //drop the rest
drop w_nominal w_direct l_hours l_years l_numwork l_numwork_fte l_force r_ucc r_ucctax r_quasi r_other r_nom r_gross k_it k_equip k_struct k_resincl k_service k_perpet k_index y_index y_other 
drop label country idcountry VES invsqrtnobs_win5 prec_win5 tstat_win5 
*drop ind_primary ind_second ind_tertiary ind_materials ind_industrials ind_consumer stacoudata
drop country_Eur_noUK cerest country_UK
drop selfempl capacadj qualadj sigmamed5 impact
drop  stacoudata ind_disagg ind_second quart
drop net unitfe UCE e_cesnonlin database_OECD ind_primary preferred
drop timeser annual e_foc_k_r coudata longrun_expl pftfp stadata //drop baseline
saveold "bma_ind", version(12) replace
restore

******************************************************************************
*BMA: now run the R code
*FMA: now run the R code
******************************************************************************

******************************************************************************
* HETEROGENEITY - frequentist check 
******************************************************************************

*full BMA-model OLS and FE check
ivreg2 sigma_win5 se_win5 lnobs midpoint crosssec panel quart firmdata inddata country_US country_Eur develop database_ASM_CM database_OECD database_jorgenson ind_disagg e_sys_cesfoc e_sys_2foc e_cesnonlin e_ceslinapprox e_foc_l_w e_foc_kl_rw e_foc_k_share e_foc_l_share cerest2 norm twolevel partialsig UCE est_dynamic est_sur identif diff timefe unitfe shortrun_expl longrun_unadj pfoth pfcatc pflatc pfskill tcconst tcother nocrs nofullcomp net top pubyear lnyearcits preferred byproduct, cluster (idstudy idcountry)
xtreg sigma_win5 se_win5 lnobs midpoint crosssec panel quart firmdata inddata country_US country_Eur develop database_ASM_CM database_OECD database_jorgenson ind_disagg e_sys_cesfoc e_sys_2foc e_cesnonlin e_ceslinapprox e_foc_l_w e_foc_kl_rw e_foc_k_share e_foc_l_share cerest2 norm twolevel partialsig UCE est_dynamic est_sur identif diff timefe unitfe shortrun_expl longrun_unadj pfoth pfcatc pflatc pfskill tcconst tcother nocrs nofullcomp net top pubyear lnyearcits preferred byproduct, fe cluster (idstudy)
*frequentist check
ivreg2 sigma_win5 se_win5 midpoint panel inddata country_Eur database_OECD e_ceslinapprox e_foc_l_w e_foc_k_share e_foc_l_share norm UCE diff shortrun_expl pfoth tcconst net top lnyearcits byproduct, cluster (idstudy idcountry)

******************************************************************************
* HETEROGENEITY - best-practice estimate
******************************************************************************

ivreg2 sigma_win5 se_win5 lnobs midpoint crosssec panel quart firmdata inddata country_US country_Eur develop ind_disagg database_ASM_CM database_OECD database_jorgenson e_sys_cesfoc e_sys_2foc e_ceslinapprox e_foc_l_w e_foc_kl_rw e_foc_k_share e_foc_l_share cerest2 norm twolevel partialsig UCE est_dynamic est_sur identif diff timefe unitfe shortrun_expl longrun_unadj pfoth pflatc pfcatc pfskill tcconst tcother nocrs nofullcomp net top pubyear lnyearcits preferred byproduct , cluster (idstudy idcountry)


*base
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +1*inddata +0*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*US
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +1*inddata +1*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*EUR
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +1*inddata +0*country_US +1*country_Eur +0*develop +0*ind_disagg +0*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct

*base SR
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +1*inddata +0*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +1*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*US SR
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +1*inddata +1*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +1*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*EUR SR
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +1*inddata +0*country_US +1*country_Eur +0*develop +0*ind_disagg +0*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +1*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct

*base net
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +1*inddata +0*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +1*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*US net
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +1*inddata +1*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +1*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*EUR net
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +1*inddata +0*country_US +1*country_Eur +0*develop +0*ind_disagg +0*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +1*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct

*base country level data
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +0*inddata +0*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*US country level data
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +0*inddata +1*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*EUR country level data
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +0*inddata +0*country_US +1*country_Eur +0*develop +0*ind_disagg +0*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct

*base quartertly
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 1*quart + 0*firmdata +1*inddata +0*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*US quartertly
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 1*quart + 0*firmdata +1*inddata +1*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*EUR quartertly
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 1*quart + 0*firmdata +1*inddata +0*country_US +1*country_Eur +0*develop +0*ind_disagg +0*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct

*base time series
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0*crosssec + 0*panel + 0.11*quart + 0*firmdata +1*inddata +0*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*US time series
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0*crosssec + 0*panel + 0.11*quart + 0*firmdata +1*inddata +1*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*EUR time series
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0*crosssec + 0*panel + 0.11*quart + 0*firmdata +1*inddata +0*country_US +1*country_Eur +0*develop +0*ind_disagg +0*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct

*base cross-sectional data
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 1*crosssec + 0*panel + 0.11*quart + 0*firmdata +1*inddata +0*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*US cross-sectional data
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 1*crosssec + 0*panel + 0.11*quart + 0*firmdata +1*inddata +1*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*EUR cross-sectional data
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 1*crosssec + 0*panel + 0.11*quart + 0*firmdata +1*inddata +0*country_US +1*country_Eur +0*develop +0*ind_disagg +0*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +1*e_sys_cesfoc +0*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct

*system 2FOC
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +1*inddata +0*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +0*e_sys_cesfoc +1*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*US SR
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +1*inddata +1*country_US +0*country_Eur +0*develop +0*ind_disagg +0.14*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +0*e_sys_cesfoc +1*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct
*EUR SR
lincom _cons + 0*se_win5 + 10.2*lnobs + 5.04*midpoint + 0.33*crosssec + 0.14*panel + 0.11*quart + 0*firmdata +1*inddata +0*country_US +1*country_Eur +0*develop +0*ind_disagg +0*database_ASM_CM +0.065*database_OECD +0.15*database_jorgenson +0*e_sys_cesfoc +1*e_sys_2foc +0*e_ceslinapprox +1*e_foc_l_w +0*e_foc_kl_rw +0*e_foc_k_share +0*e_foc_l_share +1*cerest2 +1*norm +0*twolevel +0*partialsig +0*UCE +0*est_dynamic +1*est_sur +0.13*identif +0.23*diff +0*timefe +0*unitfe +0*shortrun_expl +0*longrun_unadj +0*pfoth +1*pflatc +1*pfcatc +0*pfskill +0.3*tcconst +0.1*tcother +0*nocrs +0*nofullcomp +0*net +1*top +4.04*pubyear +1.47*lnyearcits +0*preferred +0*byproduct

