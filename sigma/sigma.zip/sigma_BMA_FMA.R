rm(list=ls())
###################
# loading library #
###################
library(BMS)
library(foreign)

###################
# set directory   #
###################
setwd("D:/IES_Phd/Capital_labor/SIGMA")

# BMA #################################
#######################################
# Parameters for in-sample estimation #
#######################################
#burn_       = 0.5e8
#iter_       = 1e8
burn_       = 1e6
iter_       = 3e6
gprior      = "UIP"
modelprior  = "uniform"
order_PIP   = F
separator   = ","

################
# loading data #
################

data_nw         = read.dta("bma.dta")
data_se         = read.dta("bma_se.dta")
data_ps         = read.dta("bma_invper.dta")
data_nwL        = read.dta("bma_labor.dta")
data_nwK        = read.dta("bma_capital.dta")
data_nw_ind     = read.dta("bma_ind.dta")

data_nw <- data_nw[complete.cases(data_nw), ]
data_se <- data_se[complete.cases(data_se), ]
data_ps <- data_ps[complete.cases(data_ps), ]
data_nwL <- data_nwL[complete.cases(data_nwL), ]
data_nwK <- data_nwK[complete.cases(data_nwK), ]
data_nw_ind <- data_nw_ind[complete.cases(data_nw_ind), ]

colnames(data_nw)  <- c("Sigma", "St. error", "Preferred","Byproduct","Cross-sec.","Panel","No. of obs.","Midpoint","Quarterly","Firm data","Industry data","Country: US","Country: Eur","Developing", "Ind. disaggregated","Database: ASM,CM","Database: OECD","Database: KLEM","System PF+FOC","System FOCs","Nonlinear","Linear approx.","FOC_L_w","FOC_KL_rw","FOC_K_share","FOC_L_share","Cross-eq. restr.","Normalized","Two-level PF","Partial sigma","User cost. elast.","Dynamic est.","SUR, 2SLS","Identification","Differenced", "Time FE", "Unit FE", "Short-run", "Long-run unadj.","Other inputs in PF", "CATC", "LATC", "Skilled L", "Constant TC growth", "Other TC growth","No CRS", "No full comp.",  "Net sigma", "Top journal",  "Pub. year", "Citations")
colnames(data_se)  <- c("Sigma",             "Preferred","Byproduct","Cross-sec.","Panel","No. of obs.","Midpoint","Quarterly","Firm data","Industry data","Country: US","Country: Eur","Developing", "Ind. disaggregated","Database: ASM,CM","Database: OECD","Database: KLEM","System PF+FOC","System FOCs","Nonlinear","Linear approx.","FOC_L_w","FOC_KL_rw","FOC_K_share","FOC_L_share","Cross-eq. restr.","Normalized","Two-level PF","Partial sigma","User cost. elast.","Dynamic est.","SUR, 2SLS","Identification","Differenced", "Time FE", "Unit FE", "Short-run", "Long-run unadj.","Other inputs in PF", "CATC", "LATC", "Skilled L", "Constant TC growth", "Other TC growth","No CRS", "No full comp.",  "Net sigma", "Top journal",  "Pub. year", "Citations")
colnames(data_ps)  <- c("Sigma", "St. error", "Preferred","Byproduct","Cross-sec.","Panel","No. of obs.","Midpoint","Quarterly","Firm data","Industry data","Country: US","Country: Eur","Developing", "Ind. disaggregated","Database: ASM,CM","Database: OECD","Database: KLEM","System PF+FOC","System FOCs","Nonlinear","Linear approx.","FOC_L_w","FOC_KL_rw","FOC_K_share","FOC_L_share","Cross-eq. restr.","Normalized","Two-level PF","Partial sigma","User cost. elast.","Dynamic est.","SUR, 2SLS","Identification","Differenced", "Time FE", "Unit FE", "Short-run", "Long-run unadj.","Other inputs in PF", "CATC", "LATC", "Skilled L", "Constant TC growth", "Other TC growth","No CRS", "No full comp.",  "Net sigma", "Top journal",  "Pub. year", "Citations")
colnames(data_nwL) <- c("Sigma", "St. error", "Preferred","Byproduct","Cross-sec.","Panel","No. of obs.","Midpoint","Quarterly","Firm data","Industry data","Country: US","Country: Eur","Developing", "Ind. disaggregated","Database: ASM,CM","Database: OECD","Database: KLEM","System PF+FOC","System FOCs",            "Linear approx."                                    ,"FOC_L_share","Cross-eq. restr.","Normalized","Two-level PF"                                    ,"Dynamic est.","SUR, 2SLS","Identification","Differenced", "Time FE", "Unit FE", "Short-run", "Long-run unadj.","Other inputs in PF",         "LATC", "Skilled L", "Constant TC growth", "Other TC growth","No CRS", "No full comp.", "Quality adj.", "Self empl.", "Net sigma",     "Top journal", "Pub. year", "Citations", "W nominal", "W direct", "L hours", "L years",  "L FTE workers", "L force", "Y index", "Y other")
colnames(data_nwK) <- c("Sigma", "St. error", "Preferred","Byproduct","Cross-sec.","Panel","No. of obs.","Midpoint","Quarterly","Firm data","Industry data","Country: US","Country: Eur","Developing", "Ind. disaggregated","Database: ASM,CM","Database: OECD","Database: KLEM","System PF+FOC","System FOCs",            "Linear approx."                      ,"FOC_K_share",              "Cross-eq. restr.","Normalized","Two-level PF",                "User cost. elast.","Dynamic est.","SUR, 2SLS","Identification","Differenced", "Time FE", "Unit FE", "Short-run", "Long-run unadj.","Other inputs in PF", "CATC",         "Skilled L", "Constant TC growth",                  "No CRS", "No full comp.", "K: IT", "K: equipment", "K: structures",        "Net sigma", "Capacity adj.", "Top journal",     "Pub. year", "Citations", "r: UCC", "r: UCC tax", "r: quasi", "r: other", "r: nominal", "K: residential", "K: services", "K: perpetual", "K: index","Y: other")
colnames(data_nw_ind)  <- c("Sigma", "St. error","Byproduct","Cross-sec.","Panel","No. of obs.","Midpoint", "Firm data","Industry data","Country: US","Country: Eur","Developing", "Tertiary ind.", "Ind.: Materials", "Ind.: Industrials", "Ind.: Consumer goods", "Database: ASM,CM","Database: KLEM","System PF+FOC","System FOCs","Linear approx.","FOC_L_w","FOC_KL_rw","FOC_K_share","FOC_L_share","Cross-eq. restr.","Normalized","Two-level PF","Partial sigma","Dynamic est.","SUR, 2SLS","Identification","Differenced", "Time FE", "Short-run", "Long-run unadj.","Other inputs in PF", "CATC", "LATC", "Skilled L", "Constant TC growth", "Other TC growth","No CRS", "No full comp.",   "Top journal",  "Pub. year", "Citations")

##############
# Estimation #
##############
BMA_nw  = bms(data_nw, burn=burn_,iter=iter_, g=gprior, mprior=modelprior, nmodel=10000, mcmc="bd", user.int=FALSE)
BMA_nw_res<-coef(BMA_nw,std.coefs=F, order.by.pip = order_PIP, exact=T,include.constant = T)
write.table(BMA_nw_res,"BMA_baseline.csv",sep=separator)
image(BMA_nw, cex=0.7, xlab="", main="")
summary(BMA_nw)
plot(BMA_nw)


BMAse  = bms(data_se, burn=burn_,iter=iter_, g=gprior, mprior=modelprior, nmodel=5000, mcmc="bd", user.int=FALSE)
BMAse_res<-coef(BMAse,std.coefs=F, order.by.pip = order_PIP, exact=T,include.constant = T)
write.table(BMAse_res,"BMA_se.csv",sep=separator)
image(BMAse, cex=0.7, xlab="", main="")
summary(BMAse)
plot(BMAse)


BMAps  = bms(data_ps, burn=burn_,iter=iter_, g=gprior, mprior=modelprior, nmodel=5000, mcmc="bd", user.int=FALSE)
BMAps_res<-coef(BMAps,std.coefs=F, order.by.pip = order_PIP, exact=T,include.constant = T)
write.table(BMAps_res,"BMA_ps.csv",sep=separator)
image(BMAps, cex=0.7, xlab="", main="")
summary(BMAps)
plot(BMAps)


BMA_nwL  = bms(data_nwL, burn=burn_, iter=iter_, g=gprior, mprior=modelprior, nmodel=5000, mcmc="bd", user.int=FALSE)
BMA_nwL_res<-coef(BMA_nwL,std.coefs=F, order.by.pip = order_PIP, exact=T,include.constant = T)
write.table(BMA_nwL_res,"BMA_L.csv",sep=separator)
image(BMA_nwL, cex=0.7, xlab="", main="")
summary(BMA_nwL)
plot(BMA_nwL)


BMA_nwK  = bms(data_nwK, burn=burn_, iter=iter_, g=gprior, mprior=modelprior, nmodel=5000, mcmc="bd", user.int=FALSE)
BMA_nwK_res<-coef(BMA_nwK,std.coefs=F, order.by.pip = order_PIP, exact=T,include.constant = T)
write.table(BMA_nwK_res,"BMA_K.csv",sep=separator)
image(BMA_nwK, cex=0.7, xlab="", main="")
summary(BMA_nwK)
plot(BMA_nwK)


BMA_nw_ind  = bms(data_nw_ind, burn=burn_,iter=iter_, g=gprior, mprior=modelprior, nmodel=5000, mcmc="bd", user.int=FALSE)
BMA_nw_ind_res<-coef(BMA_nw_ind,std.coefs=F, order.by.pip = order_PIP, exact=T,include.constant = T)
write.table(BMA_nw_ind_res,"BMA_ind.csv",sep=separator)
image(BMA_nw_ind, cex=0.7, xlab="", main="")
summary(BMA_nw_ind)
plot(BMA_nw_ind)



#Prior sensitivity
#BMA_ps1  = bms(data_nw, burn=burn_,iter=iter_, g="UIP", mprior="uniform", nmodel=5000, mcmc="bd", user.int=FALSE)
BMA_nw2  = bms(data_nw, burn=burn_,iter=iter_, g="BRIC", mprior="random", nmodel=5000, mcmc="bd", user.int=FALSE)
BMA_nw3  = bms(data_nw, burn=burn_,iter=iter_, g="HQ", mprior="random", nmodel=5000, mcmc="bd", user.int=FALSE)

plotComp("UIP and Uniform"=BMA_nw,"BRIC and Random"=BMA_ps2,"HQ and Random"=BMA_ps3,  add.grid=F,cex.xaxis=0.7)


######################
# Save the workspace #
######################
par(mfrow=c(3,2))
density(BMA_nw, reg="Industry data")
density(BMA_nw, reg="FOC_L_w")
density(BMA_nw, reg="Linear approx.")
density(BMA_nw, reg="Normalized")
density(BMA_nw, reg="Short-run")
density(BMA_nw, reg="Top journal")

save.image("results_sigma.Rdata")

 
#  FMA  ###################################################################

#================================
# Mallows Model Averaging Program 
#================================

# Loading libraries
library(foreign)
library(xtable)
library(LowRankQP)
#==================================================

setwd("D:/IES_Phd/Capital_labor/SIGMA")
rm(list=ls())

mydata <- read.dta("bma.dta", convert.dates=TRUE, convert.factors=TRUE, 
                   missing.type=TRUE, convert.underscore=TRUE, warn.missing.labels=TRUE)

colnames(mydata)  <- c("Sigma", "St. error", "Preferred","Byproduct","Cross-sec.","Panel","No. of obs.","Midpoint","Quarterly","Firm data","Industry data","Country: US","Country: Eur","Developing", "Ind. disaggregated","Database: ASM,CM","Database: OECD","Database: KLEM","System PF+FOC","System FOCs","Nonlinear","Linear approx.","FOC_L_w","FOC_KL_rw","FOC_K_share","FOC_L_share","Cross-eq. restr.","Normalized","Two-level PF","Partial sigma","User cost. elast.","Dynamic est.","SUR, 2SLS","Identification","Differenced", "Time FE", "Unit FE", "Short-run", "Long-run unadj.","Other inputs in PF", "CATC", "LATC", "Skilled L", "Constant TC growth", "Other TC growth","No CRS", "No full comp.",  "Net sigma", "Top journal",  "Pub. year", "Citations")

#deleting missing observations
mydata <-na.omit(mydata)
x.data <- mydata[,-1]

#adding constant
const_<-c(1)
x.data <-cbind(const_,x.data)


x <- sapply(1:ncol(x.data),function(i){x.data[,i]/max(x.data[,i])})   
scale.vector <- as.matrix(sapply(1:ncol(x.data),function(i){max(x.data[,i])}))        
Y <- as.matrix(mydata[,1])
output.colnames <- colnames(x.data)
full.fit <- lm(Y~x-1)
beta.full <- as.matrix(coef(full.fit))
M <- k <- ncol(x)
n <- nrow(x)
beta <- matrix(0,k,M)
e <- matrix(0,n,M)
K_vector <- matrix(c(1:M))
var.matrix <- matrix(0,k,M)
bias.sq <- matrix(0,k,M)             


# MMA Estimator using orthogonalization 
for(i in 1:M)
{
  X <- as.matrix(x[,1:i])
  ortho <- eigen(t(X)%*%X)
  Q <- ortho$vectors ; lambda <- ortho$values 
  x.tilda <- X%*%Q%*%(diag(lambda^-0.5,i,i))
  beta.star <- t(x.tilda)%*%Y
  beta.hat <- Q%*%diag(lambda^-0.5,i,i)%*%beta.star
  beta[1:i,i] <- beta.hat
  e[,i] <- Y-x.tilda%*%as.matrix(beta.star)
  bias.sq[,i] <- (beta[,i]-beta.full)^2
  var.matrix.star <- diag(as.numeric(((t(e[,i])%*%e[,i])/(n-i))),i,i)
  var.matrix.hat <- var.matrix.star%*%(Q%*%diag(lambda^-1,i,i)%*%t(Q))
  var.matrix[1:i,i] <- diag(var.matrix.hat)
  var.matrix[,i] <- var.matrix[,i]+ bias.sq[,i]
} # End loop over i

e_k <- e[,M]
sigma_hat <- as.numeric((t(e_k)%*%e_k)/(n-M))
G <- t(e)%*%e
a <- ((sigma_hat)^2)*K_vector
A <- matrix(1,1,M)
b <- matrix(1,1,1)
u <- matrix(1,M,1)
optim <- LowRankQP(Vmat=G,dvec=a,Amat=A,bvec=b,uvec=u,method="LU",verbose=FALSE)
weights <- as.matrix(optim$alpha)
beta.scaled <- beta%*%weights
final.beta <- beta.scaled/scale.vector
std.scaled <- sqrt(var.matrix)%*%weights
final.std <- std.scaled/scale.vector
results.reduced <- as.matrix(cbind(final.beta,final.std))
rownames(results.reduced) <- output.colnames; colnames(results.reduced) <- c("Coefficient", "Sd. Err")
#MMA.fls <- round(results.reduced,4)[-1,]
MMA.fls <- round(results.reduced,4)
list(MMA.fls)


MMA.fls <- data.frame(MMA.fls)
t <- as.data.frame(MMA.fls$Coefficient/MMA.fls$Sd..Err)
MMA.fls$pv <-round( (1-apply(as.data.frame(apply(t,1,abs)), 1, pnorm))*2,3)
MMA.fls$names <- rownames(MMA.fls)
names <- c(colnames(mydata))
names <- c(names,"const_")
MMA.fls <- MMA.fls[match(names, MMA.fls$names),]
MMA.fls$names <- NULL
MMA.fls


library(xtable)
xtable(MMA.fls,digits=c(0,3,3,3))

separator   = ";"
write.table(MMA.fls,"FMA_results.csv",sep=separator)


#================================ End of code =================================


