This is the analysis script for reproducing findings reported in:
Adjusting for Publication Bias Reveals Evidence Against Social Comparison As a Behaviour Change Technique Across the Behavioural Sciences
Author: Frantisek Bartos
Contact: f.bartos96@gmail.com

Note that the code requires:
JAGS (https://sourceforge.net/projects/mcmc-jags/)
and the following R packages: RoBMA, metafor, readxl

Data & code for reproducing the original analyses was accessed from https://osf.io/uwtbx/

The runtime of the code is approximately 30 minutes to 2 hours depending on the number of CPUs
> sessionInfo()
R version 4.5.1 (2025-06-13 ucrt)
Platform: x86_64-w64-mingw32/x64
Running under: Windows 11 x64 (build 26100)

Matrix products: default
LAPACK version 3.12.1

locale:
  [1] LC_COLLATE=English_United States.utf8  LC_CTYPE=English_United States.utf8    LC_MONETARY=English_United States.utf8
[4] LC_NUMERIC=C                           LC_TIME=English_United States.utf8

time zone: Europe/Amsterdam
tzcode source: internal

attached base packages:
  [1] stats     graphics  grDevices utils     datasets  methods   base

other attached packages:
  [1] metafor_4.8-0       numDeriv_2016.8-1.1 metadat_1.4-0       Matrix_1.7-3        RoBMA_3.5.0

loaded via a namespace (and not attached):
  [1] vctrs_0.6.5            nlme_3.1-168           cli_3.6.5              rlang_1.1.6            stringi_1.8.7
[6] bridgesampling_1.1-2   Brobdingnag_1.2-9      glue_1.8.0             rjags_4-17             readxl_1.4.5
[11] grid_4.5.1             cellranger_1.1.0       tibble_3.3.0           mvtnorm_1.3-3          lifecycle_1.0.4
[16] BayesTools_0.2.19      stringr_1.5.1          compiler_4.5.1         mathjaxr_1.8-0         coda_0.19-4.1
[21] pkgconfig_2.0.3        rstudioapi_0.17.1.9000 runjags_2.2.2-5        lattice_0.22-7         digest_0.6.37
[26] pillar_1.10.2          Rdpack_2.6.4           parallel_4.5.1         rbibutils_2.3          magrittr_2.0.3
[31] tools_4.5.1
