### This is the analysis script for reproducing findings reported in:
# Adjusting for Publication Bias Reveals Evidence Against Social Comparison As a Behaviour Change Technique Across the Behavioural Sciences
# Author: Frantisek Bartos
# Contact: f.bartos96@gmail.com
#
# Note that the code requires:
# JAGS (https://sourceforge.net/projects/mcmc-jags/)
# and the following R packages: RoBMA, metafor, readxl
#
# Data & code for reproducing the original analyses was accessed from https://osf.io/uwtbx/
#
# The runtime of the code is approximately 30 minutes to 2 hours depending on the number of CPUs
# > sessionInfo()
# R version 4.5.1 (2025-06-13 ucrt)
# Platform: x86_64-w64-mingw32/x64
# Running under: Windows 11 x64 (build 26100)
#
# Matrix products: default
# LAPACK version 3.12.1
#
# locale:
#   [1] LC_COLLATE=English_United States.utf8  LC_CTYPE=English_United States.utf8    LC_MONETARY=English_United States.utf8
# [4] LC_NUMERIC=C                           LC_TIME=English_United States.utf8
#
# time zone: Europe/Amsterdam
# tzcode source: internal
#
# attached base packages:
#   [1] stats     graphics  grDevices utils     datasets  methods   base
#
# other attached packages:
#   [1] metafor_4.8-0       numDeriv_2016.8-1.1 metadat_1.4-0       Matrix_1.7-3        RoBMA_3.5.0
#
# loaded via a namespace (and not attached):
#   [1] vctrs_0.6.5            nlme_3.1-168           cli_3.6.5              rlang_1.1.6            stringi_1.8.7
# [6] bridgesampling_1.1-2   Brobdingnag_1.2-9      glue_1.8.0             rjags_4-17             readxl_1.4.5
# [11] grid_4.5.1             cellranger_1.1.0       tibble_3.3.0           mvtnorm_1.3-3          lifecycle_1.0.4
# [16] BayesTools_0.2.19      stringr_1.5.1          compiler_4.5.1         mathjaxr_1.8-0         coda_0.19-4.1
# [21] pkgconfig_2.0.3        rstudioapi_0.17.1.9000 runjags_2.2.2-5        lattice_0.22-7         digest_0.6.37
# [26] pillar_1.10.2          Rdpack_2.6.4           parallel_4.5.1         rbibutils_2.3          magrittr_2.0.3
# [31] tools_4.5.1

library(RoBMA)
library(metafor)
sc <- readxl::read_excel(path = "Dataset SC-BCT OSF.xlsx")

# reporting functions
effect_ci.selmod   <- function(fit) {
  return(sprintf("%1.2f [%2.2f, %3.2f] p = %4.3f", fit$b, fit$ci.lb[1], fit$ci.ub[1], fit$pval))
}
effect_ci.PETPEESE <- function(fit.PET, fit.PEESE) {

  tempSummary <- data.frame(summary(fit.PET)[["coefficients"]])
  if(tempSummary[1,"Pr...t.."] < 0.10) {
    tempSummary <- data.frame(summary(fit.PET)[["coefficients"]])
  } else {
    tempSummary <- data.frame(summary(fit.PEESE)[["coefficients"]])
  }

  tempSummary$lCI <- tempSummary[, "Estimate"] - 1.96 * tempSummary[, "Std..Error"]
  tempSummary$uCI <- tempSummary[, "Estimate"] + 1.96 * tempSummary[, "Std..Error"]
  return(sprintf("%1.2f [%2.2f, %3.2f] p = %4.3f", tempSummary$Estimate[1], tempSummary$lCI[1], tempSummary$uCI[1], tempSummary[1,"Pr...t.."]))
}

# row 1 (abstract #1)
scBCT <- subset(sc, analysis_grouping_merged=="SC BCT main")
scBCTpost <- subset(scBCT, time.point=="Post")
scBCTpostPCC <- subset(scBCTpost, comp=="exp_vs_PCC")
scBCTpostPCCoverarching <- subset(scBCTpostPCC, overarching==1)
postPCCoverarching <- rma(yi=yi, vi=vi, data=scBCTpostPCCoverarching, slab = paste(reference))
postPCCoverarching
funnel(postPCCoverarching)

fit1.sm1   <- selmodel(postPCCoverarching, type = "step", steps = c(0.025))      # selection model 1
fit1.sm2   <- selmodel(postPCCoverarching, type = "step", steps = c(0.025, 0.5)) # selection model 2
fit1.PET   <- lm(yi ~ sqrt(vi), weights = 1/vi, data = scBCTpostPCCoverarching)  # PET model
fit1.PEESE <- lm(yi ~ vi, weights = 1/vi, data = scBCTpostPCCoverarching)        # PEESE model

effect_ci.selmod(fit1.sm1)
# "0.20 [0.10, 0.29] p = 0.000"
effect_ci.selmod(fit1.sm2)
# "-0.05 [-0.37, 0.28] p = 0.778"
effect_ci.PETPEESE(fit1.PET, fit1.PEESE)
# "0.21 [0.14, 0.28] p = 0.000"

# reporting RoBMA from the JASP summary (with small differences due to MCMC sampling between bridge-sampling and spike-and-slab)
fit1.RoBMA <- RoBMA(d = scBCTpostPCCoverarching$yi, se = sqrt(scBCTpostPCCoverarching$vi), parallel = TRUE, seed = 1)
summary(fit1.RoBMA)
# Call:
#   RoBMA(d = scBCTpostPCCoverarching$yi, se = sqrt(scBCTpostPCCoverarching$vi),
#         parallel = TRUE, seed = 1)
#
# Robust Bayesian meta-analysis
# Components summary:
#   Models Prior prob. Post. prob.  Inclusion BF
# Effect         18/36       0.500       0.103  1.150000e-01
# Heterogeneity  18/36       0.500       1.000 2.724396e+288
# Bias           32/36       0.500       0.998  5.086550e+02
#
# Model-averaged estimates:
#   Mean Median  0.025 0.975
# mu                -0.006  0.000 -0.143 0.036
# tau                0.200  0.195  0.134 0.293
# omega[0,0.025]     1.000  1.000  1.000 1.000
# omega[0.025,0.05]  0.945  1.000  0.631 1.000
# omega[0.05,0.5]    0.678  0.683  0.326 0.983
# omega[0.5,0.95]    0.077  0.061  0.012 0.203
# omega[0.95,0.975]  0.077  0.061  0.012 0.203
# omega[0.975,1]     0.077  0.061  0.012 0.203
# PET                0.002  0.000  0.000 0.000
# PEESE              0.003  0.000  0.000 0.000
# The estimates are summarized on the Cohen's d scale (priors were specified on the Cohen's d scale).
# (Estimated publication weights omega correspond to one-sided p-values.)

# row 2
postPCCoverarchingOUTLIER <- subset(scBCTpostPCCoverarching, yi<= 0.1696 + (3.3* (0.0320 * sqrt(37))) & yi >= 0.1696 - (3.3* (0.0320 * sqrt(37))))
postPCCoverarchingOUTLIERout <- rma(yi=yi, vi=vi, data=postPCCoverarchingOUTLIER, slab = paste(reference))
postPCCoverarchingOUTLIERout
funnel(postPCCoverarchingOUTLIERout)

fit2.sm1   <- selmodel(postPCCoverarchingOUTLIERout, type = "step", steps = c(0.025))
fit2.sm2   <- selmodel(postPCCoverarchingOUTLIERout, type = "step", steps = c(0.025, 0.5))
fit2.PET   <- (lm(yi ~ sqrt(vi), weights = 1/vi, data = postPCCoverarchingOUTLIER))
fit2.PEESE <- (lm(yi ~ vi, weights = 1/vi, data = postPCCoverarchingOUTLIER))

effect_ci.selmod(fit2.sm1)
effect_ci.selmod(fit2.sm2)
effect_ci.PETPEESE(fit2.PET, fit2.PEESE)

fit2.RoBMA <- RoBMA(d = postPCCoverarchingOUTLIERout$yi, se = sqrt(postPCCoverarchingOUTLIERout$vi), parallel = TRUE, seed = 1)
summary(fit2.RoBMA)

# row 3 (abstract #2)
scBCTpostACC <- subset(scBCTpost, comp=="exp_vs_ACC")
scBCTpostACCoverarching <- subset(scBCTpostACC, overarching==1)
postACCoverarching <- rma(yi=yi, vi=vi, data=scBCTpostACCoverarching, slab = paste(reference))
postACCoverarching
funnel(postACCoverarching)

fit3.sm1   <- selmodel(postACCoverarching, type = "step", steps = c(0.025))
fit3.sm2   <- selmodel(postACCoverarching, type = "step", steps = c(0.025, 0.5))
fit3.PET   <- (lm(yi ~ sqrt(vi), weights = 1/vi, data = scBCTpostACCoverarching))
fit3.PEESE <- (lm(yi ~ vi, weights = 1/vi, data = scBCTpostACCoverarching))

effect_ci.selmod(fit3.sm1)
effect_ci.selmod(fit3.sm2)
effect_ci.PETPEESE(fit3.PET, fit3.PEESE)

fit3.RoBMA <- RoBMA(d = scBCTpostACCoverarching$yi, se = sqrt(scBCTpostACCoverarching$vi), parallel = TRUE, seed = 1)
summary(fit3.RoBMA)

# row 4 = adjusted row 3

# row 5
scBCTpostACCoverarchingOUTLIER <- subset(scBCTpostACCoverarching, yi<= 0.2315 + (3.3* (0.0396 * sqrt(42))) & yi >= 0.2315 - (3.3* (0.0396 * sqrt(42))))
postACCoverarchingOUTLIERout <- rma(yi=yi, vi=vi, data=scBCTpostACCoverarchingOUTLIER, slab = paste(reference))
postACCoverarchingOUTLIERout
funnel(postACCoverarchingOUTLIERout)

fit4.sm1   <- selmodel(postACCoverarchingOUTLIERout, type = "step", steps = c(0.025))
fit4.sm2   <- selmodel(postACCoverarchingOUTLIERout, type = "step", steps = c(0.025, 0.5))
fit4.PET   <- (lm(yi ~ sqrt(vi), weights = 1/vi, data = scBCTpostACCoverarchingOUTLIER))
fit4.PEESE <- (lm(yi ~ vi, weights = 1/vi, data = scBCTpostACCoverarchingOUTLIER))

effect_ci.selmod(fit4.sm1)
effect_ci.selmod(fit4.sm2)
effect_ci.PETPEESE(fit4.PET, fit4.PEESE)

fit4.RoBMA <- RoBMA(d = postACCoverarchingOUTLIERout$yi, se = sqrt(postACCoverarchingOUTLIERout$vi), parallel = TRUE, seed = 1)
summary(fit4.RoBMA)

# row 6
scBCT <- subset(sc, analysis_grouping_merged=="SC BCT main")
scBCTfu <- subset(scBCT, time.point=="FU1")
scBCTfuPCC <- subset(scBCTfu, comp=="exp_vs_PCC")
scBCTfuPCCoverarching <- subset(scBCTfuPCC, overarching==2)
fuPCCoverarching <- rma(yi=yi, vi=vi, data=scBCTfuPCCoverarching, slab = paste(reference))
fuPCCoverarching
funnel(fuPCCoverarching)

fit5.sm1   <- selmodel(fuPCCoverarching, type = "step", steps = c(0.025))
fit5.sm2   <- selmodel(fuPCCoverarching, type = "step", steps = c(0.025, 0.5))
fit5.PET   <- (lm(yi ~ sqrt(vi), weights = 1/vi, data = scBCTfuPCCoverarching))
fit5.PEESE <- (lm(yi ~ vi, weights = 1/vi, data = scBCTfuPCCoverarching))

effect_ci.selmod(fit5.sm1)
effect_ci.selmod(fit5.sm2)
effect_ci.PETPEESE(fit5.PET, fit5.PEESE)

fit5.RoBMA <- RoBMA(d = scBCTfuPCCoverarching$yi, se = sqrt(scBCTfuPCCoverarching$vi), parallel = TRUE, seed = 1)
summary(fit5.RoBMA)

# row 7
scBCTfuPCCoverarchingOUTLIER <- subset(scBCTfuPCCoverarching, yi<= 0.0967 + (3.3* (0.0173 * sqrt(13))) & yi >= 0.0967 - (3.3* (0.0173 * sqrt(13))))
fuPCCoverarchingOUTLIER <- rma(yi=yi, vi=vi, data=scBCTfuPCCoverarchingOUTLIER, slab = paste(reference))
fuPCCoverarchingOUTLIER
funnel(fuPCCoverarchingOUTLIER)

fit6.sm1   <- selmodel(fuPCCoverarchingOUTLIER, type = "step", steps = c(0.025))
fit6.sm2   <- selmodel(fuPCCoverarchingOUTLIER, type = "step", steps = c(0.025, 0.5))
fit6.PET   <- (lm(yi ~ sqrt(vi), weights = 1/vi, data = scBCTfuPCCoverarchingOUTLIER))
fit6.PEESE <- (lm(yi ~ vi, weights = 1/vi, data = scBCTfuPCCoverarchingOUTLIER))

effect_ci.selmod(fit6.sm1)
effect_ci.selmod(fit6.sm2)
effect_ci.PETPEESE(fit6.PET, fit6.PEESE)

fit6.RoBMA <- RoBMA(d = fuPCCoverarchingOUTLIER$yi, se = sqrt(fuPCCoverarchingOUTLIER$vi), parallel = TRUE, seed = 1)
summary(fit6.RoBMA)

# row 8
scBCTfuACC <- subset(scBCTfu, comp=="exp_vs_ACC")
scBCTfuACCoverarching <- subset(scBCTfuACC, overarching==2)
fuACCoverarching <- rma(yi=yi, vi=vi, data=scBCTfuACCoverarching, slab = paste(reference))
fuACCoverarching
funnel(fuACCoverarching)

fit7.sm1   <- selmodel(fuACCoverarching, type = "step", steps = c(0.025))
fit7.sm2   <- selmodel(fuACCoverarching, type = "step", steps = c(0.025, 0.5))
fit7.PET   <- (lm(yi ~ sqrt(vi), weights = 1/vi, data = scBCTfuACCoverarching))
fit7.PEESE <- (lm(yi ~ vi, weights = 1/vi, data = scBCTfuACCoverarching))

effect_ci.selmod(fit7.sm1)
effect_ci.selmod(fit7.sm2)
effect_ci.PETPEESE(fit7.PET, fit7.PEESE)

fit7.RoBMA <- RoBMA(d = scBCTfuACCoverarching$yi, se = sqrt(scBCTfuACCoverarching$vi), parallel = TRUE, seed = 1)
summary(fit7.RoBMA)

# create an overall data set (for exporting to JASP)
# Post-intervention results: short-term efficacy
scBCTpostPCCoverarching$dataset        <- "SC-BCTs versus passive control conditions"
postPCCoverarchingOUTLIER$dataset      <- "SC-BCTs versus passive control conditions (outlier-adjusted)"
scBCTpostACCoverarching$dataset        <- "SC-BCTs versus active control conditions"
scBCTpostACCoverarchingOUTLIER$dataset <- "SC-BCTs versus active control conditions (outlier-adjusted)"
# Follow-up results: long-term efficacy
scBCTfuPCCoverarching$dataset        <- "SC-BCTs versus passive control conditions (follow-up)"
scBCTfuPCCoverarchingOUTLIER$dataset <- "SC-BCTs versus passive control conditions (follow-up, outlier-adjusted)"
scBCTfuACCoverarching$dataset        <- "SC-BCTs versus active control conditions (follow-up)"

# combine all data sets
df <- rbind(
  scBCTpostPCCoverarching[,c("yi", "vi", "dataset", "reference")],
  postPCCoverarchingOUTLIER[,c("yi", "vi", "dataset", "reference")],
  scBCTpostACCoverarching[,c("yi", "vi", "dataset", "reference")],
  scBCTpostACCoverarchingOUTLIER[,c("yi", "vi", "dataset", "reference")],
  scBCTfuPCCoverarching[,c("yi", "vi", "dataset", "reference")],
  scBCTfuPCCoverarchingOUTLIER[,c("yi", "vi", "dataset", "reference")],
  scBCTfuACCoverarching[,c("yi", "vi", "dataset", "reference")]
)
df$sei <- sqrt(df$vi)
write.csv(df, file = "scBCT.csv", row.names = FALSE)
