rm(list=ls())
###################
# loading library #
###################

library(BMS)
library(foreign)
library(xtable)

###################
# set directory   #
###################


setwd("C:\\Users\\asokolova\\Dropbox\\Habit formation\\Habits_EER_revision\\data_codes")


#######################################
# Parameters for in-sample estimation #
#######################################
burn_       = 1e6
iter_       = 3e6
gprior      = "UIP"
modelprior  = "uniform"
order_PIP   = F
separator   = ";"

################
# loading data #
################


data_se         = read.dta("habit_for_BMA_se.dta")
data_se <- na.omit(data_se)
data_nw         = read.dta("habit_for_BMA_notweighted.dta")
data_us         = read.dta("habit_for_BMA_US.dta")

colnames(data_se) <- c("habit", "precision","no_of_obs.","average_year","micro","monthly","annual","US","EU","Japan","external","deep","durable","food","asset_returns","GMM","TSLS","panel","second_order_approx.","DSGE","bayes","mininum_distance","ML","open_economy_DSGE","matching_IR_to_mon._policy","no_of_observables_in_DSGE","seven_observables_from_SW","no_consumption","no_wage","publication_year","citations","top_journal","impact")




###################################################
# Estimation BMA with  fixed data characteristics #
###################################################


BMA_se_ff  = bms(data_se  , burn=burn_,iter=iter_, g=gprior, mprior=modelprior, fixed.reg=c("average_year","no_of_obs.","US","EU","Japan", "monthly", "annual", "micro"),  nmodel=5000, mcmc="bd", user.int=FALSE)
BMA_se_res_ff<-coef(BMA_se_ff,std.coefs=F, order.by.pip = order_PIP, exact=T,include.constant = T)
write.table(BMA_se_res_ff,"BMA_se_ff.csv",sep=separator)
#### save image as pdf
pdf(width=8, height=5, file = "BMA_se_ff.pdf")
par(bty="l",las=1,lwd=1,cex=0.7,oma = c(1, 1, 0, 1), mar = c(3, 4, 3.5, 5))
image(BMA_se_ff)
dev.off()
summary(BMA_se_ff)
BMA_nw1 <- BMA_se_res_ff[,c(2,3,1)]
xtable(BMA_nw1,digits=c(0,3,3,3))


pdf(width=8, height=5, file = "d_observations.pdf")
par(bty="l",las=1,lwd=1,cex=1.2,oma = c(1, 1, 0, 1), mar = c(3, 4, 3.5, 1))
density(BMA_se_ff, reg="no_of_obs.")
dev.off()


pdf(width=8, height=5, file = "d_avg_year.pdf")
par(bty="l",las=1,lwd=1,cex=1.2,oma = c(1, 1, 0, 1), mar = c(3, 4, 3.5, 1))
density(BMA_se_ff, reg="average_year")
dev.off()



pdf(width=8, height=5, file = "d_micro.pdf")
par(bty="l",las=1,lwd=1,cex=1.2,oma = c(1, 1, 0, 1), mar = c(3, 4, 3.5, 1))
density(BMA_se_ff, reg="micro")
dev.off()

pdf(width=8, height=5, file = "d_monthly.pdf")
par(bty="l",las=1,lwd=1,cex=1.2,oma = c(1, 1, 0, 1), mar = c(3, 4, 3.5, 1))
density(BMA_se_ff, reg="monthly")
dev.off()

pdf(width=8, height=5, file = "d_annual.pdf")
par(bty="l",las=1,lwd=1,cex=1.2,oma = c(1, 1, 0, 1), mar = c(3, 4, 3.5, 1))
density(BMA_se_ff, reg="annual")
dev.off()

pdf(width=8, height=5, file = "d_US.pdf")
par(bty="l",las=1,lwd=1,cex=1.2,oma = c(1, 1, 0, 1), mar = c(3, 4, 3.5, 1))
density(BMA_se_ff, reg="US")
dev.off()

pdf(width=8, height=5, file = "d_EU.pdf")
par(bty="l",las=1,lwd=1,cex=1.2,oma = c(1, 1, 0, 1), mar = c(3, 4, 3.5, 1))
density(BMA_se_ff, reg="EU")
dev.off()

pdf(width=8, height=5, file = "d_Japan.pdf")
par(bty="l",las=1,lwd=1,cex=1.2,oma = c(1, 1, 0, 1), mar = c(3, 4, 3.5, 1))
density(BMA_se_ff, reg="Japan")
dev.off()



#########################################
# Robustness check: alternative priors  #
#########################################

BMA_ps2_ff  = bms(data_se, burn=burn_,iter=iter_, g="BRIC", mprior="random", fixed.reg=c("average_year","no_of_obs.","US","EU","Japan", "monthly", "annual", "micro"), nmodel=5000, mcmc="bd", user.int=FALSE)
BMA_ps2_res_ff<-coef(BMA_ps2_ff,std.coefs=F, order.by.pip = order_PIP, exact=T,include.constant = T)
write.table(BMA_ps2_res_ff,"BMA_ps2_ff.csv",sep=separator)






####################
# Correlation plot #
####################



library(corrplot)
M_nw=cor(data_nw)
corrplot(M_nw,type="upper",tl.pos="tp",tl.col="black", tl.cex=1.2, tl.srt=45,  mar = c(0, 0, 0, 0))
corrplot(M_nw,add=TRUE, type="lower", method="number",diag=FALSE,tl.pos="n", cl.pos="n",number.digits = 1,number.cex=0.8)







