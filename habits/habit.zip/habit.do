clear
clear mata
set more off


*cd "C:\Users\asokolova\Dropbox\Habit formation\Habits_EER_revision\data_codes"
use "habit_rev.dta", clear

************************************
* VARIABLES DEFINITIONS AND LABELS *
************************************

drop if missing(se)


replace avg_year               = avg_year - 1932
replace no_year                = ln(no_year)
replace no_cross               = ln(no_cross)
replace citations              = ln(1+citations)/(2015-pub_year) 
replace pub_year               = pub_year-1991
gen invsqrtn 				   = 1/(sqrt(observations))
replace observations           = ln(observations)
bysort idstudy: egen habit_med = median(habit)


* Generating country dummies
egen idcountry = group(country)
gen US = 0
replace US = 1 if country=="US"
gen EU = 0
replace EU = 1 if country=="Belgium" ||  country=="Denmark" || country=="EA" || country=="Finland" || /*
              */country=="France" ||  country=="Germany" || country=="Italy" || country=="Netherlands" ||/*
			  */country=="Spain" || country=="Sweden" ||  country=="UK" 
gen Japan=0
replace Japan=1 if country=="Japan"
gen Other=1
replace Other=0 if US==1 
replace Other=0 if EU==1 
replace Other=0 if Japan==1

* Number of estimates in a given study
bysort idstudy: egen no_est = max(id)
gen inv_no_est              = 1/no_est



****************************
* GENERATING TABS, FIGURES *
****************************
* Tab 1: Summary statistics from subgroups
sum habit, detail 
sum habit if micro==1, detail 
sum habit if micro==0, detail 
sum habit if external==0, detail 
sum habit if external==1, detail
sum habit if asset_returns==1, detail 
sum habit if micro==1 & external == 0, detail 
sum habit if micro==1 & external == 1, detail 
sum habit if micro==0 & external == 0, detail 
sum habit if micro==0 & external == 1, detail 
sum habit if dsge==0 & micro==0, detail 
sum habit if dsge==1, detail 
 


sum habit [aweight=inv_no_est], detail 
sum habit if micro==1 [aweight=inv_no_est], detail 
sum habit if micro==0 [aweight=inv_no_est], detail 
sum habit if external==0 [aweight=inv_no_est], detail 
sum habit if external==1 [aweight=inv_no_est], detail 
sum habit if asset_returns==1 [aweight=inv_no_est], detail
sum habit if micro==1 & external == 0 [aweight=inv_no_est], detail 
sum habit if micro==1 & external == 1 [aweight=inv_no_est], detail 
sum habit if micro==0 & external == 0 [aweight=inv_no_est], detail 
sum habit if micro==0 & external == 1 [aweight=inv_no_est], detail 
sum habit if dsge==0 & micro==0 [aweight=inv_no_est], detail
sum habit if dsge==1 [aweight=inv_no_est], detail 


********* additional statistics
sum habit if monthly==1 & external == 1, detail 
sum habit if monthly==1 & external == 0, detail 
sum habit if secord==1 & external == 0, detail 

sum impact, detail
sum habit if monthly==1 & top == 1 , detail 
sum habit if   top == 1 & external==1, detail 
sum top, detail


* Fig: Boxplot
graph hbox habit, over(study, sort(pub_year)) xsize(6.3) ysize(8) scale(0.5)  saving(habit_box, replace)

* Fig: Histogram
sum habit ,detail
local m_all =r(p50)
sum habit if top==1 , detail
local m_top =r(p50)
sum habit_med , detail
local mm_all=r(p50)
histogram habit, bin(50) addplot(pci 0 `m_all' 2 `m_all' ,lcolor(gs0) || pci 0 `m_top' 2 `m_top', lp(dash) lcolor(gs0)) legend(off) saving(histogram, replace)

	   

* Tab 2: country averages
sum habit if US==1, detail 
sum habit if EU==1, detail 
sum habit if Japan==1, detail 
sum habit if Other==1, detail 
sum habit if US==1 [aweight=inv_no_est], detail 
sum habit if EU==1 [aweight=inv_no_est], detail 
sum habit if Japan==1 [aweight=inv_no_est], detail 
sum habit if Other==1 [aweight=inv_no_est], detail 

* Tab 2: micro
sum habit if US==1 & micro==1, detail 
sum habit if EU==1 & micro==1, detail 
sum habit if Japan==1 & micro==1, detail 
sum habit if Other==1 & micro==1, detail 
sum habit if US==1 & micro==1 [aweight=inv_no_est], detail 
sum habit if EU==1 & micro==1 [aweight=inv_no_est], detail 
sum habit if Japan==1 & micro==1 [aweight=inv_no_est], detail 
sum habit if Other==1 & micro==1 [aweight=inv_no_est], detail 

* Tab 2: macro
sum habit if US==1 & micro==0, detail 
sum habit if EU==1 & micro==0, detail 
sum habit if Japan==1 & micro==0, detail 
sum habit if Other==1 & micro==0, detail 
sum habit if US==1 & micro==0 [aweight=inv_no_est], detail 
sum habit if EU==1 & micro==0 [aweight=inv_no_est], detail 
sum habit if Japan==1 & micro==0 [aweight=inv_no_est], detail 
sum habit if Other==1 & micro==0 	[aweight=inv_no_est], detail 

* Tab 3: Summary statistics
sum habit se observations avg_year micro  monthly annual US EU Japan external deep durable_other food  asset_returns GMM TSLS panel secord dsge bayes min_distance ML   open   mp_match n_observables seven_observ no_cons no_wage pub_year citations top impact , detail
sum habit se  observations avg_year micro  monthly annual US EU Japan external deep durable_other food  asset_returns GMM TSLS panel secord dsge bayes min_distance ML   open   mp_match n_observables seven_observ no_cons no_wage pub_year citations top impact  [aweight=inv_no_est], detail

*********************************************************************
*

gen prec_nw = 1/se
gen tstat_nw = habit/se
gen invvar_nw = 1/(se*se)
bysort idstudy: egen prec_med_nw = median(prec_nw)



******************************
* Winsorizing outliers in SE *
******************************
sum se, detail
*winsorizing data, 0.05 from each tail
winsor se, gen(se_win) p(0.05)
replace se=se_win

************************
* Generating precision *++++++
************************
gen prec = 1/se
gen tstat = habit/se
gen invvar = 1/(se*se)
bysort idstudy: egen prec_med = median(prec)
bysort idstudy: egen se_med = median(se)
bysort idstudy: egen tstat_med = median(tstat)
bysort idstudy: egen invvar_med = median(invvar)




drop if missing(se)

********************************
* TESTING FOR PUBLICATION BIAS *
********************************
label variable habit_med "Estimate of the habit persistence parameter"
label variable prec_nw "Precision of the estimate (1/SE)"
label variable prec_med_nw "Precision of the estimate (1/SE)"

sum habit if  dsge==0,detail
local m_all =r(p50)
scatter prec_nw habit if prec_nw<200 & dsge==0, msize(*1) msymbol(Oh)  xline(`m_all', lp(dash) lcolor(gs0)) 

sum habit_med if dsge==0, detail
local med_all =r(p50)
scatter prec_med_nw habit_med if prec_med_nw<200  & dsge==0,  msize(*1.5) msymbol(Oh) xline(`med_all', lp(dash) lcolor(gs0)) 



*Funnel asymmetry tests
xtset idstudy
* Clustered at study level
eststo: xtreg habit se if dsge==0 , fe cluster (idstudy)
* Standard error instrumented by no of observations
eststo: xtivreg habit (se=invsqrtn)  if dsge==0 , fe
* Weighted by no. of. estimates
eststo: xtreg habit se  if dsge==0  [pweight=inv_no_est], fe cluster (idstudy)
* Precision weighted
eststo: xtreg habit se if dsge==0  [pweight=invvar_med], fe cluster (idstudy)
xtivreg2 habit (se=invsqrtn) if dsge==0  [pweight=invvar_med], fe cluster (idstudy)
* Median regression
eststo: ivreg2 habit_med se_med if id==1  & dsge==0 


esttab using fat_test.rtf, se compress replace
esttab using fat_test.tex, se booktabs replace compress title(Funnel asymmetry test for non-DSGE\label{tab:fat}) /*
                      */addnote("Standard errors are clustered at the study level.")/*
					 */star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) label nonumber nogaps width(1\hsize)
eststo clear






************************************
* Generating data for weighed BMA  *
************************************
local rhsvars  observations avg_year micro  monthly annual US EU Japan external deep durable_other food  asset_returns GMM TSLS panel secord dsge bayes min_distance ML   open   mp_match n_observables seven_observ no_cons no_wage pub_year citations top impact 

foreach x of varlist habit `rhsvars' {					 
gen `x'_se = `x' / se	 
}


preserve	

sum se, detail

local rhsvars_se habit_se  prec  observations_se avg_year_se micro_se  monthly_se annual_se US_se EU_se Japan_se external_se deep_se durable_other_se food_se  asset_returns_se GMM_se TSLS_se panel_se secord_se dsge_se bayes_se min_distance_se ML_se   open_se   mp_match_se n_observables_se seven_observ_se no_cons_se no_wage_se pub_year_se citations_se top_se impact_se 
keep `rhsvars_se'
order habit_se  prec  observations_se avg_year_se micro_se  monthly_se annual_se US_se EU_se Japan_se external_se deep_se durable_other_se food_se  asset_returns_se GMM_se TSLS_se panel_se secord_se dsge_se bayes_se min_distance_se ML_se   open_se   mp_match_se n_observables_se seven_observ_se no_cons_se no_wage_se pub_year_se citations_se top_se impact_se
saveold "habit_for_BMA_se", replace
restore







***********************
* Frequentist check 1 * WLS baseline
***********************
eststo: ivreg2 habit_se prec observations_se avg_year_se micro_se  monthly_se annual_se US_se EU_se Japan_se external_se  panel_se secord_se   open_se  top_se impact_se, cluster(idstudy) 
esttab using check.csv, se  compress replace wide 
esttab using check_p.csv, p compress replace wide 
eststo clear

***********************
* Frequentist check 2 * WLS for alternative prior setting, appendix 
***********************
eststo: ivreg2 habit_se prec observations_se avg_year_se micro_se  monthly_se annual_se US_se EU_se Japan_se  panel_se secord_se   open_se  top_se impact_se, cluster(idstudy) 
esttab using check2.csv, se  compress replace wide 
esttab using check_p2.csv, p compress replace wide 
eststo clear


***********************
* Frequentist check 3 * WLS for FMA, appendix
***********************
eststo: ivreg2 habit_se prec  micro_se  annual_se US_se   panel_se    open_se  top_se, cluster(idstudy) 
esttab using check3.csv, se  compress replace wide 
esttab using check_p3.csv, p compress replace wide 
eststo clear















