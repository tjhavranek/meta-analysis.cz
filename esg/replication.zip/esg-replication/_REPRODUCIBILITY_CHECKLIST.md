# Replication package — reproducibility checklist (for the authors, before public release)

This is an **internal** checklist (do **not** ship it in the public zip). The package is
cleaned and documented (README, MANIFEST, RUN_ORDER, REQUIREMENTS, CODEBOOK, CHANGELOG).
The items below are the few things that still need a human decision or a small edit
before the package runs end-to-end on a fresh machine. None of them affects the numbers
in the paper.

### Done (no action needed)
- **Dataset**: `esg_clean.xlsx` ships only the `Data` sheet (533 × 65); the internal
  Notes/Questions sheets are gone, their content absorbed into `CODEBOOK.md` and
  `CHANGELOG.md`. `esg_clean.csv` regenerated as comma-delimited UTF-8 (was
  semicolon + BOM), values identical to the xlsx.
- **One naming scheme end to end** (the old checklist's main item): the do-file's
  embedded R blocks are canonical, and the six `Code/R-code/` scripts are byte-identical
  extracts — filenames referenced in code match the files on disk everywhere (verified
  mechanically).
- **Seeds**: Stata re-seeds at every bootstrap block (`set seed 20241215`), so all
  wild-bootstrap intervals reproduce even from standalone block runs; BMA seeds fixed in
  `5.het_bma.R`.
- **Engines bundled**: `maivefunction.r` (MAIVE) and `metastudiesfunctions.r`/
  `metastudiesplots.r` (MetaStudies, not on CRAN) are shipped next to their inputs.
- **No macOS-only graphics**: all plotting uses `png()`; the old `quartz()` calls are
  gone.
- **Dead code removed**: the unreported PIP>0.5 restricted FMA (and its orphan exports),
  the legacy `puniform()` call, the never-existing `data_full_nest_excl_me.xlsx`
  reference (now points to the real robustness export).
- **Documented quirks**: no folder "5." under `Publication bias/` (kink is Stata-only);
  `7. Caliper/` intentionally empty; `maive.r` marked legacy; header-name oddities
  (`ln_data firms`, `data_cross-section`, `non-financial`) noted in the codebook.

### Decisions / small edits still needed
1. **Absolute paths in the six R scripts.** Every script opens with
   `setwd("/Users/karolina/IES/PhD/...")` (and `6.het_fcheck.R` reads via `~/IES/...`).
   Documented in RUN_ORDER/REQUIREMENTS as "edit the root part of the one setwd line",
   which is acceptable — but consider replacing with a single `PROJECT_ROOT` variable at
   the top of each script (or `here::here()`) so the edit is one obvious line per script,
   incl. the fcheck read path.
2. **Excel lock files**: delete `Data/~$esg1.xlsx`, `Data/~$esg_clean.xlsx`, and
   `Output/Publication bias/6. MAIVE/~$inputdata.xlsx` before zipping (they exist right
   now).
3. **`maive.r` legacy driver**: keep for provenance (as the MANIFEST currently says) or
   drop from the public zip — decide.
4. **`dilutBMS2` install**: verify `devtools::install_git("https://gitlab.com/matmosr/dilutbms2")`
   still resolves on a clean machine (REQUIREMENTS quotes it from the earlier package
   notes; the locally installed copy is v0.3.3 from a git source).
5. **Vestigial `library()` calls** (cosmetic): `4.pubbias-puniform.R` loads
   `metafor`/`meta` and `2.pubbias-selection.R`/`3.pubbias-stem.R` load `ggplot2`
   without strictly needing them for the reported numbers — trim or leave (REQUIREMENTS
   currently lists them as required, which is the safe choice).
6. **LICENSE file** before public release (README suggests CC BY 4.0 data / MIT code);
   also re-add the journal to the README citation once acceptance is confirmed.
7. **Final clean-machine run**: after the last data/code change, one top-to-bottom
   replication on a machine that isn't the author's — regenerating all figures (funnel,
   t-statistic histogram, BMA heatmaps/posteriors were last regenerated after the
   July 2026 t-imputation correction) — and diff the printed numbers against the paper.
8. **Exclusions from the zip**: `Primary studies/` (copyright), the tracked-changes
   manuscript files, and this checklist.
