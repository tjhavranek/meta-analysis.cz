# Software requirements

## Stata (17 or newer)

The master script `Code/esg_code_v5.do` declares `version 17.0`. It uses the following
**user-written commands** (install once via `ssc install <name>`):

| Command | Purpose |
|---------|---------|
| `winsor` | winsorize estimates/SEs at the 1st/99th percentile |
| `univar` | summary statistics (Section A) |
| `ivreg2` | FAT-PET regressions with cluster-robust inference |
| `boottest` | wild cluster bootstrap p-values and confidence intervals (Roodman et al., 2019) |
| `estout` (`esttab`, `eststo`) | exporting the `.tex` regression tables |

`ranktest` installs automatically as a dependency of `ivreg2`. Built-in commands used:
`xtset`/`xtreg`, `regress`, `lincom`, `collapse`, `stepwise`, `preserve`/`restore`.

*(The old `weakiv`/Anderson–Rubin step is no longer needed: the ad-hoc IV specification
was replaced by the MAIVE estimator, which computes its own AR confidence interval in R.)*

## R (4.x recommended)

Six scripts in `Code/R-code/` (verbatim extracts of the R blocks embedded in the
do-file). Each except `6.het_fcheck.R` (absolute `read_excel()` path) begins with a `setwd()` into its output folder — **adjust the root part of
that one line to your location**; inputs are then read by bare filename. All graphics use
portable devices (`png()`); nothing is macOS-specific.

Required packages by script:

**`1.pubbias-maive.R`** — `readxl`; the MAIVE engine is bundled as
`Output/Publication bias/6. MAIVE/maivefunction.r` (Irsova, Bom, Havranek & Rachinger)
and itself requires `varhandle`, `pracma`, `sandwich`.

**`2.pubbias-selection.R`** — `readr` and **`MetaStudies`** (Andrews–Kasy
selection model; Kranz & Putz implementation). `MetaStudies` is **not on CRAN**: install
with `remotes::install_github("skranz/MetaStudies")` (install `remotes` first if
missing). The scripts call `library(MetaStudies)`; no local copy is required.

**`3.pubbias-stem.R`** — `readxl`, `ggplot2`; the STEM algorithm (Furukawa, 2019) is
defined inline. (`data.table` is needed only if the optional `data_median()` helper is
used; the shipped pipeline collapses to study medians in Stata instead.)

**`4.pubbias-puniform.R`** — `puniform`, `haven`, `metafor`, `meta` (all CRAN).

**`5.het_bma.R`** — `readxl`, `BMS`, `corrplot`, and **`dilutBMS2`** (the
Feldkircher–Zeugner `BMS` extended with the dilution model prior by Hofmarcher & Moser).
`dilutBMS2` is **not on CRAN**; install from GitLab:

```r
install.packages("devtools")  # if missing
devtools::install_git("https://gitlab.com/matmosr/dilutbms2")
```

Loading order matters: `dilutBMS2` is loaded **after** `BMS` so that its `bms()` masks
`BMS::bms` (see the comment in the script).

**`6.het_fcheck.R`** — `readxl`, `foreign`, `xtable`, `LowRankQP` (all CRAN; the script
installs missing ones via `if (!require(...)) install.packages(...)`).

## Python (optional)

No Python is needed to reproduce the paper. The plain-text dataset `Data/esg_clean.csv`
(comma-delimited UTF-8) is provided for users outside the Stata/R ecosystem.
