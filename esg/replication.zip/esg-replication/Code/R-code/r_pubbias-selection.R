library(ggplot)
library(MetaStudies)
library(readr)
data_full <- read_csv("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Publication bias/2. Selection Model/data_full.csv", 
                      col_names = FALSE)

colnames(data_full) = c("X","sigma")
ms = metastudies_estimation(X=data_full$X,sigma=data_full$sigma,model = "t",cutoffs = c(1.96),symmetric = TRUE)
ms$est_tab
metastudy_X_sigma_cors(ms)

data_direct_est <- read_csv("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Publication bias/2. Selection Model/data_direct_est.csv",
                            col_names = FALSE)

colnames(data_direct_est) = c("X","sigma")
ms = metastudies_estimation(X=data_direct_est$X,sigma=data_direct_est$sigma,model = "t",cutoffs = c(1.96),symmetric = TRUE)
ms$est_tab
metastudy_X_sigma_cors(ms)

data_excl_ME <- read_csv("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Publication bias/2. Selection Model/data_excl_ME.csv",
                         col_names = FALSE)

colnames(data_excl_ME) = c("X","sigma")
ms = metastudies_estimation(X=data_excl_ME$X,sigma=data_excl_ME$sigma,model = "t",cutoffs = c(1.96),symmetric = TRUE)
ms$est_tab
metastudy_X_sigma_cors(ms)

data_unwinsorised <- read_csv("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Publication bias/2. Selection Model/data_unwinsorised.csv",
                              col_names = FALSE)

colnames(data_unwinsorised) = c("X","sigma")
ms = metastudies_estimation(X=data_unwinsorised$X,sigma=data_unwinsorised$sigma,model = "t",cutoffs = c(1.96),symmetric = TRUE)
ms$est_tab
metastudy_X_sigma_cors(ms)

