# ========================= p-uniform* in R (van Aert & van Assen 2026) =========================
# install once if needed:
# install.packages(c('puniform','metafor','dmetar','haven','tidyverse','meta'))
library(puniform); library(metafor); library(haven); library(meta)
setwd("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Publication bias/4. p-uniform")

run_puni <- function(file, yi, vi){            # file names match the Stata saves above
  d <- read_dta(file)
  print(puni_star(yi = d[[yi]], vi = d[[vi]], side="right", method="ML", alpha = 0.05))
  # (legacy original-p-uniform call removed: never reported, and errors under side="right")
}

run_puni("puniform_full.dta",       "estimate_medw", "variance_medw")   # B7.1 full
run_puni("puniform_direct_est.dta", "estimate_medw", "variance_medw")   # B7.2 direct only
run_puni("puniform_excl_me.dta",    "estimate_medw", "variance_medw")   # B7.3 excluding Middle East
run_puni("puniform_full.dta",       "estimate_med",  "variance_med")    # B7.4 unwinsorised (raw medians)
