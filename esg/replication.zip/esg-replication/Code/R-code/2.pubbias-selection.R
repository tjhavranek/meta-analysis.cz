# ============== Selection model in R (Andrews & Kasy 2019; Kranz & Putz 2021) ==============
library(MetaStudies)
library(readr)
setwd("PATH/TO/esg-replication/Output/Publication bias/2. Selection Model")

run_ak <- function(file){                       # file names match the Stata exports above
  d <- read_csv(file, col_names = FALSE)
  colnames(d) <- c("X","sigma")
  ms <- metastudies_estimation(X=d$X, sigma=d$sigma, model="t", cutoffs=c(1.96), symmetric=TRUE)
  print(ms$est_tab)
  metastudy_X_sigma_cors(ms)
}

run_ak("data_full.csv")           # B4.1 full sample
run_ak("data_direct_est.csv")     # B4.2 direct estimates only
run_ak("data_excl_ME.csv")        # B4.3 excluding Middle East
run_ak("data_unwinsorised.csv")   # B4.4 unwinsorised
