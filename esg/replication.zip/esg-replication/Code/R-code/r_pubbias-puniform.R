install.packages('puniform')
install.packages('metafor')
install.packages('dmetar')
install.packages('haven')
install.packages('tidyverse')
install.packages('meta')

library(puniform)
library(metafor)
library(dmetar)
library(haven)
library(tidyverse)
library(meta)

data <- read_dta("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Publication bias/4. p-uniform/puniform_full.dta")
puni_star(yi = data$estimate_medw, vi = data$variance_medw, side="left", method="ML", alpha = 0.05)
puniform(yi = data$estimate_medw, vi = data$variance_medw, side="left", method="ML",alpha = 0.05)


data <- read_dta("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Publication bias/4. p-uniform/puniform_direct_est.dta")
puni_star(yi = data$estimate_medw, vi = data$variance_medw, side="left", method="ML", alpha = 0.05)
puniform(yi = data$estimate_medw, vi = data$variance_medw, side="left", method="ML",alpha = 0.05)

data <- read_dta("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Publication bias/4. p-uniform/puniform_excl_me.dta")
puni_star(yi = data$estimate_medw, vi = data$variance_medw, side="left", method="ML", alpha = 0.05)
puniform(yi = data$estimate_medw, vi = data$variance_medw, side="left", method="ML",alpha = 0.05)

data <- read_dta("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Publication bias/4. p-uniform/puniform_full.dta")
puni_star(yi = data$estimate_med, vi = data$variance_med, side="left", method="ML", alpha = 0.05)
puniform(yi = data$estimate_med, vi = data$variance_med, side="left", method="ML",alpha = 0.05)
