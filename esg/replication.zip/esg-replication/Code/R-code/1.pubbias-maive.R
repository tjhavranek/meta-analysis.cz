# ========================= MAIVE in R =========================

# If your earlier run failed, the usual reasons are:
#   - setwd(dirname(getActiveDocumentContext()$path)) only works when the script
#     is open in the RStudio editor and run via "Source"; set the path explicitly.
#   - source("maivefunction.R") is case-sensitive on some systems; the file here
#     is maivefunction.r (lower-case .r).
if (!require('readxl')) install.packages('readxl'); library('readxl')

setwd("PATH/TO/esg-replication/Output/Publication bias/6. MAIVE")
source("maivefunction.r")     # ships with the MAIVE replication code; must be in this folder

# Options (Irsova et al. defaults): MAIVE-PET-PEESE, unweighted, instrumented,
# study-level clustering, Anderson-Rubin CI for weak instruments.
method <- 3; weight <- 0; instrument <- 1; studylevel <- 2; AR <- 1

run_maive <- function(file){
  dat <- as.data.frame(read_excel(file))      # columns in order: effect, SE, N, study_id
  m <- maive(dat=dat, method=method, weight=weight,
             instrument=instrument, studylevel=studylevel, AR=AR)
  data.frame(quantity = c("MAIVE coef","MAIVE SE","F-test 1st stage",
                          "Hausman","Chi2(1) crit","AR CI"),
             value    = c(m$beta, m$SE, m$`F-test`, m$Hausman, m$Chi2,
                          paste(m$AR_CI, collapse=" ")))
}

run_maive("maive_full.xlsx")           # B2.5.1 full sample
run_maive("maive_direct.xlsx")         # B2.5.2 direct estimates only
run_maive("maive_excl_me.xlsx")        # B2.5.3 excluding Middle East
run_maive("maive_unwinsorised.xlsx")   # B2.5.4 unwinsorised (conventional MAIVE input)
