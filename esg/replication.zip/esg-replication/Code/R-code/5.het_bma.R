# ============================================================================
# BMA HETEROGENEITY ANALYSIS  —  BGD -> ESG meta-analysis
# ----------------------------------------------------------------------------
# Reported specifications:
#   (1) BASELINE        dilution + UIP , full sample      , 1,000,000 draws
#   (2) SUBSAMPLE       dilution + UIP , excl. Middle East , 1,000,000 draws
#   (3) PRIOR ROBUSTNESS random   + BRIC, full sample      ,   300,000 draws
# Convergence diagnostics:
#   - Corr PMP (analytic vs MCMC PMP)      [within-chain stationarity]
#   - unique models visited & % of 2^K     [model-space exploration]
#   - models needed to reach 90% PMP        [effective concentration / ESS proxy]
#   - PIP agreement 1M vs 300k (same seed)  [draw-length sensitivity]
#   - PIP agreement seed1 vs seed2 (300k)   [independent-chain agreement = Gelman-Rubin analogue]
# ============================================================================

library(readxl)
library(BMS)          # S3 methods for class "bma" (coef/summary/image/pmp.bma)
library(dilutBMS2)    # adds the dilution prior; load AFTER BMS so its bms() masks BMS::bms
library(corrplot)

setwd("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Heterogeneity/")

## ---- constants --------------------------------------------------------------
LABELS <- c(
  estimate_w         = "Effect",
  se_estimate_w      = "Standard error",
  ln_sample_size     = "Sample size",
  data_panel         = "Data: panel",
  eikon              = "Data: LSEG",
  ln_avg_year        = "Average data year",
  ln_bgd_mean        = "Average board gender diversity",
  published_study    = "Published",
  ln_citations       = "Number of citations",
  method_linear      = "Method: linear",
  method_panel       = "Method: panel",
  method_iv          = "Method: IV",
  method_gmm         = "Method: GMM",
  poor_endog_control = "Endogeneity control: poor",
  ln_data_variables  = "Number of variables",
  global             = "Region: global",
  europe             = "Region: Europe",
  us                 = "Region: USA",
  asia               = "Region: Asia",
  middle_east        = "Region: Middle East",
  emerging           = "Market: emerging",
  financial          = "Sector: financial",
  control_firm_size  = "Control: firm size",
  control_board_ind  = "Control: board independence",
  control_csr_com    = "Control: CSR committee"
)

load_design <- function(file) {
  d <- as.data.frame(readxl::read_excel(file))
  stopifnot(setequal(colnames(d), names(LABELS)))   # fails loudly if a var is missing/extra
  stopifnot(colnames(d)[1] == "estimate_w")          # bms needs the dependent var first
  colnames(d) <- LABELS[colnames(d)]                 # rename by match, order-proof
  d
}

BURN_1M  <- 3e5;  ITER_1M  <- 1e6
BURN_3e5 <- 1e5;  ITER_3e5 <- 3e5
NMODEL   <- 1e5
SEED1 <- 20241215
SEED2 <- 99999
ME_COL <- "Region: Middle East"

## ---- helpers ----------------------------------------------------------------
# drop zero-variance columns (keep 'Effect' first); returns cleaned df
drop_constant <- function(df) {
  keep <- vapply(df, function(x) length(unique(x)) > 1, logical(1))
  keep["Effect"] <- TRUE
  if (any(!keep)) message("Dropped constant column(s): ",
                          paste(names(keep)[!keep], collapse = ", "))
  df[, keep, drop = FALSE]
}

run_bma <- function(dat, seed, burn, iter, g, mprior, label) {
  set.seed(seed)
  m <- dilutBMS2::bms(dat, burn = burn, iter = iter, g = g, mprior = mprior,
                      nmodel = NMODEL, mcmc = "bd", user.int = FALSE)
  cat("\n================  ", label, "  ================\n"); print(summary(m))
  m
}

# MCMC-frequency PIPs (these reflect sampler behaviour -> used for convergence)
pip_of    <- function(m) { cf <- coef(m, order.by.pip = FALSE, exact = FALSE)
setNames(cf[, "PIP"], rownames(cf)) }
models_to <- function(m, thr = 0.90) min(which(cumsum(pmp.bma(m)[, 1]) >= thr))
summ_num  <- function(m, field) as.numeric(gsub("[^0-9eE.+-]", "", summary(m)[field]))

diag_row  <- function(m, label, draws, k) data.frame(
  Specification   = label,
  Draws           = draws,
  Unique_models   = summ_num(m, "No. models visited"),
  Pct_of_2K       = round(summ_num(m, "No. models visited") / (2^k) * 100, 4),
  Models_to_90PMP = models_to(m, 0.90),
  Corr_PMP        = round(summ_num(m, "Corr PMP"), 4),
  row.names = NULL)

## ---- data -------------------------------------------------------------------
dat_full <- load_design("data_full_nest.xlsx")          # weighted design matrix
K <- ncol(dat_full) - 1L                                  # = 24

# Excl-Middle-East subsample, derived to match Stata's `if middle_east==0`:
# in the weighted data the ME column is 0 for non-ME obs and >0 for ME obs.
dat_excl_me <- dat_full[dat_full[[ME_COL]] == 0, ]
dat_excl_me[[ME_COL]] <- NULL
dat_excl_me <- drop_constant(dat_excl_me)                 # safety net
K_me <- ncol(dat_excl_me) - 1L
cat("Full sample N =", nrow(dat_full), " | Excl-ME N =", nrow(dat_excl_me),
    " | K(full)=", K, " K(excl-ME)=", K_me, "\n")
# (If you'd rather use the Stata export (section C1.3), note it omits the middle_east
#  column, so load_design()'s strict column check would stop; read it without the
#  check — replace the 3 lines above with:
#   d <- as.data.frame(readxl::read_excel("data_full_nest_robustness.xlsx"))
#   colnames(d) <- LABELS[colnames(d)]
#   dat_excl_me <- drop_constant(d) )

# ============================================================================
# (1) BASELINE : dilution + UIP, full sample, 1M
# ============================================================================
baseline <- run_bma(dat_full, SEED1, BURN_1M, ITER_1M, "UIP", "dilut",
                    "BASELINE  dilut+UIP  full  1M")

ctab_base <- coef(baseline, order.by.pip = TRUE, exact = TRUE, include.constant = TRUE)
print(ctab_base)
write.csv(ctab_base, "bma_baseline_coef.csv")

b0_bma <- coef(baseline, order.by.pip = FALSE, exact = TRUE,
               include.constant = TRUE)["(Intercept)", "Post Mean"]
cat("\n=== COPY INTO Stata BPE SECTION ===\nscalar b0_bma =", round(b0_bma, 6), "\n")

png("bma_baseline.png", width = 7, height = 6, units = "in", res = 150)
image(baseline, yprop2pip = FALSE, order.by.pip = TRUE, do.grid = TRUE, cex.axis = 0.7)
dev.off()
png("posterior_baseline.png", width = 7, height = 6, units = "in", res = 150)
plot(baseline); dev.off()

# cumulative PMP (effective-concentration / ESS proxy)
png("bma_baseline_pmp_cumulative.png", width = 8, height = 5, units = "in", res = 150)
plot(cumsum(pmp.bma(baseline)[, 1]), type = "l", lwd = 2,
     xlab = "Model rank", ylab = "Cumulative posterior model prob.",
     main = "Cumulative PMP — baseline (1M draws)")
abline(h = 0.90, lty = 2, col = "red")
legend("bottomright", "90% PMP", lty = 2, col = "red", bty = "n")
dev.off()

# ============================================================================
# CONVERGENCE CHAINS (full sample) — diagnostics only, not reported as columns
#   conv_len : 300k, SEED1  -> isolates DRAW LENGTH  (vs 1M baseline)
#   conv_seed: 300k, SEED2  -> isolates SEED         (vs conv_len)
# ============================================================================
conv_len  <- run_bma(dat_full, SEED1, BURN_3e5, ITER_3e5, "UIP", "dilut",
                     "CONV 300k seed1")
conv_seed <- run_bma(dat_full, SEED2, BURN_3e5, ITER_3e5, "UIP", "dilut",
                     "CONV 300k seed2")

p_base <- pip_of(baseline); p_len <- pip_of(conv_len); p_seed <- pip_of(conv_seed)
cmp <- function(a, b) c(cor = cor(a, b[names(a)]),
                        max_abs_diff = max(abs(a - b[names(a)])))
len_check  <- cmp(p_base, p_len)    # 1M vs 300k (same seed)
seed_check <- cmp(p_len, p_seed)    # 300k seed1 vs seed2

# per-variable PIP across the three full-sample chains, sorted by disagreement
conv_tab <- data.frame(Variable = names(p_base),
                       PIP_1M         = round(p_base, 4),
                       PIP_300k_s1    = round(p_len[names(p_base)], 4),
                       PIP_300k_s2    = round(p_seed[names(p_base)], 4),
                       row.names = NULL)
conv_tab$Spread <- round(apply(conv_tab[, 2:4], 1, function(x) max(x) - min(x)), 4)
conv_tab <- conv_tab[order(-conv_tab$Spread), ]
write.csv(conv_tab, "bma_convergence_pip_table.csv", row.names = FALSE)

# ============================================================================
# (2) SUBSAMPLE ROBUSTNESS : dilution + UIP, excl Middle East, 1M
# ============================================================================
subsample <- run_bma(dat_excl_me, SEED1, BURN_1M, ITER_1M, "UIP", "dilut",
                     "SUBSAMPLE  dilut+UIP  excl-ME  1M")
ctab_sub <- coef(subsample, order.by.pip = TRUE, exact = TRUE, include.constant = TRUE)
print(ctab_sub); write.csv(ctab_sub, "bma_excl_me_coef.csv")
png("bma_excl_me.png", width = 7, height = 6, units = "in", res = 150)
image(subsample, yprop2pip = FALSE, order.by.pip = TRUE, do.grid = TRUE, cex.axis = 0.7)
dev.off()

# ============================================================================
# (3) PRIOR ROBUSTNESS : random + BRIC, full sample, 300k
#   (if dilutBMS2 lacks mprior="random", use BMS::bms here instead)
# ============================================================================
prior_rob <- run_bma(dat_full, SEED1, BURN_3e5, ITER_3e5, "BRIC", "random",
                     "PRIOR ROB  random+BRIC  full  300k")
ctab_pr <- coef(prior_rob, order.by.pip = TRUE, exact = TRUE, include.constant = TRUE)
print(ctab_pr); write.csv(ctab_pr, "bma_prior_random_bric_coef.csv")
png("bma_prior_random_bric.png", width = 7, height = 6, units = "in", res = 150)
image(prior_rob, yprop2pip = FALSE, order.by.pip = TRUE, do.grid = TRUE, cex.axis = 0.7)
dev.off()

# ============================================================================
# CONSOLIDATED CONVERGENCE REPORT
# ============================================================================
conv_summary <- rbind(
  diag_row(baseline,  "Baseline (dilut+UIP, full, 1M)",        ITER_1M,  K),
  diag_row(subsample, "Subsample (dilut+UIP, excl-ME, 1M)",    ITER_1M,  K_me),
  diag_row(prior_rob, "Prior rob. (random+BRIC, full, 300k)",  ITER_3e5, K))
write.csv(conv_summary, "bma_convergence_summary.csv", row.names = FALSE)

cat("\n\n=========================  CONVERGENCE  =========================\n")
print(conv_summary, row.names = FALSE)
cat("\nFull-sample cross-chain PIP agreement (MCMC PIPs):\n")
cat(sprintf("  Draw length  (1M vs 300k, same seed) : cor = %.4f , max |dPIP| = %.4f\n",
            len_check["cor"],  len_check["max_abs_diff"]))
cat(sprintf("  Independent seed (300k s1 vs s2)     : cor = %.4f , max |dPIP| = %.4f\n",
            seed_check["cor"], seed_check["max_abs_diff"]))
cat("  Rule of thumb: cor > 0.99 and max |dPIP| < 0.05 = adequate convergence.\n")
cat("  NB: <1% coverage of 2^K is expected for MCMC BMA — the chain concentrates\n",
    "     posterior mass on high-likelihood models; Corr PMP ~ 1 is the validity test.\n")
cat("=======================================================================\n")

# ============================================================================
# FIGURE : correlation matrix on the UNWEIGHTED data (interpretable one)
# ============================================================================
M <- cor(load_design("data_full.xlsx"))
png("correlation.png", width = 12, height = 10, units = "in", res = 150)
col <- colorRampPalette(c("red", "white", "blue"))
corrplot.mixed(M, lower = "number", upper = "circle",
               lower.col = col(200), upper.col = col(200),
               tl.pos = "lt", diag = "u", tl.col = "black", tl.srt = 45,
               tl.cex = 0.5, number.cex = 0.5, cl.cex = 0.5, cl.ratio = 0.1)
dev.off()

# ============================================================================
# OPTIONAL (DISABLED — not used in the paper; uncomment to run):
#   posterior densities of selected high-interest coefficients
#   (names must match labels; pick by PIP after seeing ctab_base)
# ============================================================================
# png("posterior_densities.png", width = 9, height = 7, units = "in", res = 150)
# par(mfrow = c(3, 2))
# for (v in c("Standard error", "Average board gender diversity",
#             "Number of citations", "Published",
#             "Market: emerging", "Data: panel"))
#   density(baseline, reg = v)
# dev.off()
