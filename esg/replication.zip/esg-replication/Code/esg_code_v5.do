*============================================================================
* Female Leadership and ESG Performance: A Meta-Analysis
* Code version: v5  (MAIVE estimator replaces the ad-hoc IV; amended June 2026)
* Author: Hozova, Havranek, Irsova
*
* ── TABLE OF CONTENTS ──────────────────────────────────────────────────────
*
*  A.  DATA PREPARATION & SUMMARY STATISTICS
*      A1   Replication setup (version, seed, global paths)
*      A2   Winsorisation — two thresholds (baseline 1/99 & raw)
*      A3   Descriptive summary statistics
*        A3.1  Unweighted subgroup means (estimate_w)
*        A3.2  Study-weighted subgroup means [aweight=inv_nest]
*        A3.3  SE distributions by subgroup (unweighted and study-weighted)
*        A3.4  Provider comparison: SE distributions and KS test
*        A3.5  Distributions - unweighted and weighted
* 		 A3.6  Figures: histogram, box plots by study / country / sector, scatter trends
*
*  B.  PUBLICATION BIAS
*     B1   Funnel plot (Egger et al., 1997)
*        B1.1  Full sample
*        B1.2  Robustness check: Direct estimates only
*      B2   FAT-PET (Stanley, 2005)
*        B2.1  Full sample
*        B2.2  Robustness check: Direct estimates only
*        B2.3  Robustness check: Excluding Middle East
*        B2.4  Robustness check: Unwinsorised data
*        B2.5  MAIVE estimator (Irsova et al., 2025) — R  [replaces the IV]
*               B2.5.1 full / B2.5.2 direct / B2.5.3 excl. ME / B2.5.4 unwinsorised
*        B2.6  Provider invariance: interaction FAT-PET
*      B3   WAAP (Ioannidis et al., 2017)
*        B3.1  Full sample
*        B3.2  Robustness check: Direct estimates only
*        B3.3  Robustness check: Excluding Middle East
*        B3.4  Robustness check: Unwinsorised data
*        B3.5  Sensitivity: half / double PET power assumption
*      B4   Selection model (Andrews & Kasy, 2019; Kranz & Putz, 2021) — R
*        B4.1  Full sample
*        B4.2  Robustness check: Direct estimates only
*        B4.3  Robustness check: Excluding Middle East
*        B4.4  Robustness check: Unwinsorised data
*      B5   STEM method (Furukawa, 2019) — R
*        B5.1  Full sample
*        B5.2  Robustness check: Direct estimates only
*        B5.3  Robustness check: Excluding Middle East
*        B5.4  Robustness check: Unwinsorised data
*      B6   Endogenous Kink (Bom & Rachinger, 2020)
*        B6.1  Full sample
*        B6.2  Robustness check: Direct estimates only
*        B6.3  Robustness check: Excluding Middle East
*        B6.4  Robustness check: Unwinsorised data
*      B7   p-uniform* (van Aert & van Assen, 2026) — R
*        B7.1  Full sample
*        B7.2  Robustness check: Direct estimates only
*        B7.3  Robustness check: Excluding Middle East
*        B7.4  Robustness check: Unwinsorised data
*      B8   Caliper test (Gerber & Malhotra, 2008)
*        B8.1  Full sample
*        B8.2  Robustness check: Direct estimates only
*        B8.3  Robustness check: Excluding Middle East
*        B8.4  Robustness check: Unwinsorised data
*
*  C.  HETEROGENEITY
*      C1   Data export and preparation for BMA / FMA
*        C1.1  Full unweighted dataset
*        C1.2  Study-weighted dataset (sqrt(inv_nest) pre-scaling)
*        C1.3  Middle East exclusion robustness dataset
*      C2   OLS meta-regression (full 24-moderator set)
*      C3   Bayesian Model Averaging — R (BMS / dilutBMS2 package)
*        C3.1  Baseline: UIP g-prior + dilution model prior
*        C3.2  Convergence diagnostics: unique models, two chains, 1M draws [NEW]
*        C3.3  Robustness: BRIC g-prior + random model prior
*        C3.4  Middle East exclusion robustness
*      C4   Frequentist Model Averaging — R (Mallows criterion, full moderator set)
*
*  D.  BEST-PRACTICE ESTIMATE (BPE)
*      D1   Setup — PIP>0.5 variable selection and BMA posterior means
*      D2   Frequentist check regression (PIP>0.5, collinearity-fixed spec)
*      D3   BPE — All excl. Middle East  (middle_east = 0)
*      D4   BPE — Middle East only       (middle_east = 1)
*
* ── HOW TO REPLICATE ────────────────────────────────────────────────────────
*  1. Open this file in Stata 17+.
*  2. Set global root in section A1 to your local project folder — the only
*     change needed in the Stata code.
*  3. Run Stata sections A–D end-to-end.
*  4. For each R block (inside /* ... */), open RStudio, set the working
*     directory to $het (Heterogeneity folder), and run the block.
*     First edit the setwd() path at the top of the block (and the read_excel()
*     path in the C4 block) to your own $root/Output subfolder.
*============================================================================

*============================================================================
* A.  DATA PREPARATION & SUMMARY STATISTICS
*============================================================================

*----------------------------------------------------------------------------
* A1. REPLICATION SETUP
*   Edit ONLY the $root (and, if needed, $data) line below if you move the
*   project folder. Every path in the file derives from these macros.
*
*   OUTPUT LAYOUT — all results are written under a single Output/ tree, with
*   one subfolder per part of the analysis. Each section cd's into its folder,
*   so every figure / table / export it produces lands in the right place:
*       $root/Output/Data overview     <- Section A  (descriptive figures)
*       $root/Output/Publication bias  <- Section B  (funnels, FAT-PET, WAAP, ...)
*       $root/Output/Heterogeneity     <- Section C  (BMA / FMA export & results)
*----------------------------------------------------------------------------
version 17.0
set more off
set seed 20241215

global root  "/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg"
global data  "$root/Data"

* Output tree — one subfolder per section (created below if missing)
global out    "$root/Output"
global dataov "$out/Data overview"        
global pub    "$out/Publication bias"     
global het    "$out/Heterogeneity"        

cap mkdir "$out"
cap mkdir "$dataov"
cap mkdir "$pub"
cap mkdir "$het"
* R-input subfolders used by the publication-bias exports (one per R-based method)
cap mkdir "$pub/2. Selection Model"
cap mkdir "$pub/3. STEM Method"
cap mkdir "$pub/4. p-uniform"
cap mkdir "$pub/6. MAIVE"

clear
import excel "$data/esg_clean.xlsx", sheet("Data") firstrow

*----------------------------------------------------------------------------
* A2. WINSORISATION — three thresholds (A12 compares them at end of file)
*
*  (i)  1st/99th percentile — BASELINE used in all main tables
*  (ii) No winsorisation   — raw data (sensitivity)
*  
*  Note: winsorisation direction is symmetric; both tails are trimmed.
*  The raw range is approximately -0.33 to 5.9; the main tables use (i).
*----------------------------------------------------------------------------
* (i) BASELINE: 1st/99th
winsor estimate,    generate(estimate_w)    p(0.01)
winsor se_estimate, generate(se_estimate_w) p(0.01)
winsor sample_size, generate(sample_size_w) p(0.01)

gen tstat_w    = estimate_w / se_estimate_w
gen tstat      = estimate / se_estimate
* (raw tstat helper: B3.4 unwinsorised WAAP and B8.4 unwinsorised caliper reference `tstat`; without this line Stata silently abbreviation-expands `tstat` to `tstat_w`)
gen precision_w = 1 / se_estimate_w
gen precision   = 1 / se_estimate

*number of estimates per study
bysort id_study: egen nest = count(estimate_w)
gen inv_nest = 1/nest

*number of observations used
gen double nobs = sqrt(sample_size_w)
gen inv_nobs = 1/nobs

*quick summary
sum estimate, detail
sum se_estimate, detail

univar estimate estimate_w se_estimate se_estimate_w

sum estimate_w, detail
sum se_estimate_w, detail

*----------------------------------------------------------------------------
* A3. Descriptive summary statistics
*----------------------------------------------------------------------------

*----------------------------------------------------------------------------
* A3.1  Unweighted subgroup means (estimate_w)
*----------------------------------------------------------------------------
mean estimate_w
mean estimate_w if direct_est==1
mean estimate_w if direct_est==0
mean estimate_w if data_panel==1
mean estimate_w if data_crosssection==1
mean estimate_w if eikon==1
mean estimate_w if bloomberg==1
mean estimate_w if published_study==1
mean estimate_w if unpublished_study==1
mean estimate_w if poor_endog_control==1
mean estimate_w if proper_endog_control==1
mean estimate_w if control_firm_size==1
mean estimate_w if control_firm_size==0
mean estimate_w if control_board_ind==1
mean estimate_w if control_board_ind==0
mean estimate_w if control_csr_com==1
mean estimate_w if control_csr_com==0
mean estimate_w if global==1
mean estimate_w if europe==1
mean estimate_w if us==1
mean estimate_w if asia==1
mean estimate_w if middle_east==1
mean estimate_w if other==1
mean estimate_w if developed==1
mean estimate_w if emerging==1
mean estimate_w if developed==0 & emerging==0
mean estimate_w if financial==1
mean estimate_w if nonfinancial==1
mean estimate_w if cross_sector==1
mean estimate_w if method_linear==1
mean estimate_w if method_panel==1
mean estimate_w if method_iv==1
mean estimate_w if method_gmm==1
mean estimate_w if method_other==1

*----------------------------------------------------------------------------
* A3.2  Study-weighted subgroup means [aweight=inv_nest]
*        Each study receives equal total weight regardless of estimate count
*----------------------------------------------------------------------------
mean estimate_w [aweight=inv_nest]
mean estimate_w [aweight=inv_nest] if direct_est==1
mean estimate_w [aweight=inv_nest] if direct_est==0
mean estimate_w [aweight=inv_nest] if data_panel==1
mean estimate_w [aweight=inv_nest] if data_crosssection==1
mean estimate_w [aweight=inv_nest] if eikon==1
mean estimate_w [aweight=inv_nest] if bloomberg==1
mean estimate_w [aweight=inv_nest] if published_study==1
mean estimate_w [aweight=inv_nest] if unpublished_study==1
mean estimate_w [aweight=inv_nest] if poor_endog_control==1
mean estimate_w [aweight=inv_nest] if proper_endog_control==1
mean estimate_w [aweight=inv_nest] if control_firm_size==1
mean estimate_w [aweight=inv_nest] if control_firm_size==0
mean estimate_w [aweight=inv_nest] if control_board_ind==1
mean estimate_w [aweight=inv_nest] if control_board_ind==0
mean estimate_w [aweight=inv_nest] if control_csr_com==1
mean estimate_w [aweight=inv_nest] if control_csr_com==0
mean estimate_w [aweight=inv_nest] if global==1
mean estimate_w [aweight=inv_nest] if europe==1
mean estimate_w [aweight=inv_nest] if us==1
mean estimate_w [aweight=inv_nest] if asia==1
mean estimate_w [aweight=inv_nest] if middle_east==1
mean estimate_w [aweight=inv_nest] if other==1
mean estimate_w [aweight=inv_nest] if developed==1
mean estimate_w [aweight=inv_nest] if emerging==1
mean estimate_w [aweight=inv_nest] if developed==0 & emerging==0
mean estimate_w [aweight=inv_nest] if financial==1
mean estimate_w [aweight=inv_nest] if nonfinancial==1
mean estimate_w [aweight=inv_nest] if cross_sector==1
mean estimate_w [aweight=inv_nest] if method_linear==1
mean estimate_w [aweight=inv_nest] if method_panel==1
mean estimate_w [aweight=inv_nest] if method_iv==1
mean estimate_w [aweight=inv_nest] if method_gmm==1
mean estimate_w [aweight=inv_nest] if method_other==1

*----------------------------------------------------------------------------
* A3.3  SE distributions by subgroup (unweighted and study-weighted)
*----------------------------------------------------------------------------
mean se_estimate_w
mean se_estimate_w if direct_est==1
mean se_estimate_w if direct_est==0
mean se_estimate_w if data_panel==1
mean se_estimate_w if data_crosssection==1
mean se_estimate_w if eikon==1
mean se_estimate_w if bloomberg==1
mean se_estimate_w if published_study==1
mean se_estimate_w if unpublished_study==1
mean se_estimate_w if poor_endog_control==1
mean se_estimate_w if proper_endog_control==1
mean se_estimate_w if control_firm_size==1
mean se_estimate_w if control_firm_size==0
mean se_estimate_w if control_board_ind==1
mean se_estimate_w if control_board_ind==0
mean se_estimate_w if control_csr_com==1
mean se_estimate_w if control_csr_com==0
mean se_estimate_w if global==1
mean se_estimate_w if europe==1
mean se_estimate_w if us==1
mean se_estimate_w if asia==1
mean se_estimate_w if middle_east==1
mean se_estimate_w if other==1
mean se_estimate_w if developed==1
mean se_estimate_w if emerging==1
mean se_estimate_w if developed==0 & emerging==0
mean se_estimate_w if financial==1
mean se_estimate_w if nonfinancial==1
mean se_estimate_w if cross_sector==1
mean se_estimate_w if method_linear==1
mean se_estimate_w if method_panel==1
mean se_estimate_w if method_iv==1
mean se_estimate_w if method_gmm==1
mean se_estimate_w if method_other==1

mean se_estimate_w [aweight=inv_nest]
mean se_estimate_w [aweight=inv_nest] if direct_est==1
mean se_estimate_w [aweight=inv_nest] if direct_est==0
mean se_estimate_w [aweight=inv_nest] if data_panel==1
mean se_estimate_w [aweight=inv_nest] if data_crosssection==1
mean se_estimate_w [aweight=inv_nest] if eikon==1
mean se_estimate_w [aweight=inv_nest] if bloomberg==1
mean se_estimate_w [aweight=inv_nest] if published_study==1
mean se_estimate_w [aweight=inv_nest] if unpublished_study==1
mean se_estimate_w [aweight=inv_nest] if poor_endog_control==1
mean se_estimate_w [aweight=inv_nest] if proper_endog_control==1
mean se_estimate_w [aweight=inv_nest] if control_firm_size==1
mean se_estimate_w [aweight=inv_nest] if control_firm_size==0
mean se_estimate_w [aweight=inv_nest] if control_board_ind==1
mean se_estimate_w [aweight=inv_nest] if control_board_ind==0
mean se_estimate_w [aweight=inv_nest] if control_csr_com==1
mean se_estimate_w [aweight=inv_nest] if control_csr_com==0
mean se_estimate_w [aweight=inv_nest] if global==1
mean se_estimate_w [aweight=inv_nest] if europe==1
mean se_estimate_w [aweight=inv_nest] if us==1
mean se_estimate_w [aweight=inv_nest] if asia==1
mean se_estimate_w [aweight=inv_nest] if middle_east==1
mean se_estimate_w [aweight=inv_nest] if other==1
mean se_estimate_w [aweight=inv_nest] if developed==1
mean se_estimate_w [aweight=inv_nest] if emerging==1
mean se_estimate_w [aweight=inv_nest] if developed==0 & emerging==0
mean se_estimate_w [aweight=inv_nest] if financial==1
mean se_estimate_w [aweight=inv_nest] if nonfinancial==1
mean se_estimate_w [aweight=inv_nest] if cross_sector==1
mean se_estimate_w [aweight=inv_nest] if method_linear==1
mean se_estimate_w [aweight=inv_nest] if method_panel==1
mean se_estimate_w [aweight=inv_nest] if method_iv==1
mean se_estimate_w [aweight=inv_nest] if method_gmm==1
mean se_estimate_w [aweight=inv_nest] if method_other==1

*----------------------------------------------------------------------------
* A3.4  Provider comparison: SE distributions and KS test
*----------------------------------------------------------------------------

di "=== SE distribution: Bloomberg (bloomberg==1) ==="
sum se_estimate_w if bloomberg==1, detail

di "=== SE distribution: LSEG/Eikon (eikon==1) ==="
sum se_estimate_w if eikon==1, detail

* Two-sample test: are the SE distributions statistically different?
ttest se_estimate_w, by(bloomberg)
* Kolmogorov-Smirnov non-parametric test
ksmirnov se_estimate_w, by(bloomberg)

*----------------------------------------------------------------------------
* A3.5  Distributions - unweighted and weighted
*----------------------------------------------------------------------------

sum estimate_w se_estimate_w ln_sample_size data_panel data_crosssection eikon bloomberg ln_avg_year ln_bgd_mean published_study unpublished_study ln_citations proper_endog_control poor_endog_control ln_data_variables control_firm_size control_board_ind control_csr_com global europe us asia middle_east other emerging financial method_linear method_panel method_iv method_gmm method_other 

sum estimate_w se_estimate_w ln_sample_size data_panel data_crosssection eikon bloomberg ln_avg_year ln_bgd_mean published_study unpublished_study ln_citations proper_endog_control poor_endog_control ln_data_variables control_firm_size control_board_ind control_csr_com global europe us asia middle_east other emerging financial method_linear method_panel method_iv method_gmm method_other [aweight=inv_nest]


*----------------------------------------------------------------------------
* A3.6  Figures: histogram, box plots by study / country / sector, scatter trends
*----------------------------------------------------------------------------
* Route all data-overview figures to $root/Output/Data overview
cd "$dataov"

*histogram: estimates vs frequency — all estimates vs direct estimates, side by side
* Panel (a): all estimates
histogram estimate if estimate >-0.321 & estimate<2.73, bin(50) fcolor(gs14) lstyle(thin) frequency xtitle("Estimated effect") xline(.278, lpattern(solid) lcolor(red)) xline(.170, lpattern(dash) lcolor(navy)) xlabel(0 0.5 1 1.5) xlabel(.278 "0.278", add custom labcolor(red) tlcolor(red) labsize(small)) ylabel( ,glcolor(ltbluishgray)) graphregion(color(none)) title("(a) All estimates", size(medium)) name(hist_all, replace)

* Panel (b): direct estimates only
histogram estimate if estimate >-0.321 & estimate<2.73 & direct_est==1, bin(50) fcolor(gs14) lstyle(thin) frequency xtitle("Estimated effect") xline(.247, lpattern(solid) lcolor(red)) xline(.163, lpattern(dash) lcolor(navy)) xlabel(0 0.5 1 1.5) xlabel(.247 "0.247", add custom labcolor(red) tlcolor(red) labsize(small)) ylabel( ,glcolor(ltbluishgray)) graphregion(color(none)) title("(b) Direct estimates", size(medium)) name(hist_direct, replace)

* Combine the two panels into one figure (side by side)
graph combine hist_all hist_direct, rows(1) graphregion(color(none)) saving(histogram_combined, replace)

*hboxes
graph hbox estimate if estimate >-0.321 & estimate<2.73, over(study, label(grid)) xsize(3) ysize(4) scale(0.5) yline(0, lcolor (red))  box(1,lcolor(black) fcolor(none)) marker(1,msymbol(circle_hollow)  mcolor(gs13)) ytitle("Estimated effect") ylabel(, nogrid) saving(hbox_studies, replace) 

graph hbox estimate if estimate >-0.321 & estimate<2.73, over(country_cat, label(grid)) xsize(3) ysize(2) scale(1.05) yline(0, lcolor (red))  box(1,lcolor(black) fcolor(none)) marker(1,msymbol(circle_hollow)  mcolor(gs12)) ytitle("Estimated effect") ylabel(, nogrid) saving(hbox_countries, replace) 

bysort id_study: egen estimate_w_med = median(estimate_w)
bysort id_study: egen mid_year_med = median(data_mid_year)
bysort id_study: egen bgd_mean_med = median(bgd_mean)

graph twoway (scatter estimate_w_med  bgd_mean_med, msize(*1) msymbol(Oh) ylabel( ,glcolor(ltbluishgray)) graphregion(color(ltbluishgray))) (lfit estimate_w_med  bgd_mean_med, lcolor(black)),  xtitle("Median BGD mean") ytitle("Median estimate of the effect") legend(off) saving(trend_bgd_mean, replace)

graph twoway (scatter estimate_w_med  mid_year_med, msize(*1) msymbol(Oh) ylabel( ,glcolor(ltbluishgray)) graphregion(color(ltbluishgray))) (lfit estimate_w_med  mid_year_med, lcolor(black)), yline(0.278, lcolor(red) lpattern(dash)) xtitle("Median data year") ytitle("Median estimate of the effect") legend(off) saving(trend_mid_year, replace)

* (a) ESG data provider: Bloomberg vs LSEG
twoway (histogram estimate if eikon==1 & estimate >-0.321 & estimate<2.73, bin(30) fcolor(gs12) lcolor(gs10) lwidth(vvthin) frequency) (histogram estimate if bloomberg==1 & estimate >-0.321 & estimate<2.73, bin(30) fcolor("67 107 161") lcolor("67 107 161") lwidth(vvthin) frequency), xlabel(0 0.5 1 1.5) ylabel(, glcolor(ltbluishgray)) xtitle("Estimated effect") ytitle("Frequency") legend(order(2 "Bloomberg" 1 "LSEG") position(1) ring(0) cols(1)) graphregion(color(white)) plotregion(color(white)) saving(hist_provider, replace)

* (b) CSR committee control: Yes vs No
twoway (histogram estimate if control_csr_com==0 & estimate >-0.321 & estimate<2.73, bin(30) fcolor(gs12) lcolor(gs10) lwidth(vvthin) frequency) (histogram estimate if control_csr_com==1 & estimate >-0.321 & estimate<2.73, bin(30) fcolor("67 107 161") lcolor("67 107 161") lwidth(vvthin) frequency), xlabel(0 0.5 1 1.5) ylabel(, glcolor(ltbluishgray)) xtitle("Estimated effect") ytitle("Frequency") legend(order(2 "CSR committee: Yes" 1 "CSR committee: No") position(1) ring(0) cols(1)) graphregion(color(white)) plotregion(color(white)) saving(hist_csr, replace)

* Combined two-panel figure (like Figure 4 layout)
graph combine hist_provider.gph hist_csr.gph, col(2) xsize(7) ysize(3.5) graphregion(color(white))
graph export hist_provider_csr.png, replace width(2400)


*============================================================================
* B.  PUBLICATION BIAS
*============================================================================
* Route all publication-bias output (figures, .tex tables, R-input exports,
* intermediate .dta files) to $root/Output/Publication bias
cd "$pub"

*----------------------------------------------------------------------------
* B1.  Funnel plot (Egger et al., 1997)
*----------------------------------------------------------------------------
* B1.1  Full sample
quietly sum estimate, detail 
local m = r(mean)
local median = r(p50)
twoway scatter precision estimate if (estimate >-0.321 & estimate<2.73) & (precision<400), xlabel(-0.5 0 0.5 1) ytitle("Precision of the estimate (1/SE)") ylabel(, glcolor(none)) xtitle("Estimated effect") xline(`median', lpattern(dash) lcolor(black)) xline(`m', lpattern(dot) lcolor(black)) msymbol(smcircle_hollow) graphregion(color(ltbluishgray)) title("(a) All estimates", size(medium)) name(funnel_all, replace) saving(funnel, replace)

* B1.2  Robustness check: Direct estimates (Excluding interaction-derived 
*			   marginal effects and estimates with back-computed SE) 
quietly sum estimate if direct_est==1, detail
local m = r(mean)
local median = r(p50)
twoway scatter precision estimate if (estimate >-0.321 & estimate<2.73) & (precision<400) & direct_est==1, xlabel(-0.5 0 0.5 1) ytitle("Precision of the estimate (1/SE)") ylabel(, glcolor(none)) xtitle("Estimated effect") xline(`median', lpattern(dash) lcolor(black)) xline(`m', lpattern(dot) lcolor(black)) msymbol(smcircle_hollow) graphregion(color(ltbluishgray)) title("(b) Direct estimates", size(medium)) name(funnel_direct, replace) saving(funnel_direct_est, replace)

* Combine full-sample (a) and direct-estimate (b) funnels side by side (one figure)
graph combine funnel_all funnel_direct, rows(1) graphregion(color(ltbluishgray)) saving(funnel_combined, replace)

*----------------------------------------------------------------------------
* B2.  FAT-PET — Funnel Asymmetry / Precision Effect Test (Stanley, 2005)
*       Four specifications per sample: OLS / Between-study / Study-weighted /
*       Precision-weighted.  Wild bootstrap SEs (Gechert et al., 2019).
*       The old IV spec (SE instrumented with 1/sqrt(N)) is replaced by the
*       MAIVE estimator in B2.5.
*----------------------------------------------------------------------------
* B2.1  Full sample
* reseed at the start of EACH boottest block: the top-of-file seed only pins full runs; this makes brackets reproducible when a block is run standalone
set seed 20241215
*OLS
eststo: ivreg2 estimate_w se_estimate_w, cluster(id_study)
local pet_full = _b[_cons]    
boottest se_estimate_w, nograph
boottest _cons, nograph
*Between-study variation
xtset id_study
eststo: xtreg estimate_w se_estimate_w, be 
*Study-weighted
eststo: ivreg2 estimate_w se_estimate_w [pweight=inv_nobs], cluster (id_study)
boottest se_estimate_w, nograph
boottest _cons, nograph
*Precision-weighted
eststo: ivreg2 estimate_w se_estimate_w [pweight=precision_w], cluster (id_study)
boottest se_estimate_w, nograph
boottest _cons, nograph
* (IV/inv_nobs instrument removed — replaced by the MAIVE estimator, section B2.5)

esttab using table_bias_full.tex, se booktabs replace compress title(FAT-PET all\label{tab:fatpet}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01)
eststo clear

* B2.2  Robustness check: Direct estimates (Excluding interaction-derived
*			   marginal effects and estimates with back-computed SE)
set seed 20241215
*OLS
eststo: ivreg2 estimate_w se_estimate_w if direct_est==1, cluster(id_study)
boottest se_estimate_w, nograph
boottest _cons, nograph
*Between-study variation
xtset id_study
eststo: xtreg estimate_w se_estimate_w if direct_est==1, be
*Study-weighted
eststo: ivreg2 estimate_w se_estimate_w [pweight=inv_nobs] if direct_est==1, cluster(id_study)
boottest se_estimate_w, nograph
boottest _cons, nograph
*Precision-weighted
eststo: ivreg2 estimate_w se_estimate_w [pweight=precision_w] if direct_est==1, cluster(id_study)
boottest se_estimate_w, nograph
boottest _cons, nograph
* (IV/inv_nobs instrument removed — replaced by the MAIVE estimator, section B2.5)

esttab using table_bias_direct_est.tex, se booktabs replace compress title(FAT-PET Direct estimates\label{tab:fatpet_direct_est}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01)
eststo clear

* B2.3  Robustness check: Excluding Middle East
set seed 20241215
*OLS
eststo: ivreg2 estimate_w se_estimate_w if middle_east==0, cluster(id_study)
local pet_excl_me = _b[_cons]    
boottest se_estimate_w, nograph
boottest _cons, nograph
*Between-study variation
xtset id_study
eststo: xtreg estimate_w se_estimate_w if middle_east==0, be 
*Study-weighted
eststo: ivreg2 estimate_w se_estimate_w [pweight=inv_nobs] if middle_east==0, cluster (id_study)
boottest se_estimate_w, nograph
boottest _cons, nograph
*Precision-weighted
eststo: ivreg2 estimate_w se_estimate_w [pweight=precision_w] if middle_east==0, cluster (id_study)
boottest se_estimate_w, nograph
boottest _cons, nograph
* (IV/inv_nobs instrument removed — replaced by the MAIVE estimator, section B2.5)

esttab using table_bias_excl_me.tex, se booktabs replace compress title(FAT-PET excluding Middle East\label{tab:fatpet_excl_me}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01)
eststo clear

* B2.4  Robustness check: Unwinsorised data (raw estimate / se_estimate)
set seed 20241215
*OLS
eststo: ivreg2 estimate se_estimate, cluster(id_study)
local pet_unw = _b[_cons]
boottest se_estimate, nograph
boottest _cons, nograph
*Between-study variation
xtset id_study
eststo: xtreg estimate se_estimate, be
*Study-weighted
eststo: ivreg2 estimate se_estimate [pweight=inv_nobs], cluster (id_study)
boottest se_estimate, nograph
boottest _cons, nograph
*Precision-weighted
eststo: ivreg2 estimate se_estimate [pweight=precision], cluster (id_study)
boottest se_estimate, nograph
boottest _cons, nograph
* (IV/inv_nobs instrument removed — replaced by the MAIVE estimator, section B2.5)

esttab using table_bias_unwinsorised.tex, se booktabs replace compress title(FAT-PET unwinsorised\label{tab:fatpet_unwinsorised}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01)
eststo clear


*----------------------------------------------------------------------------
* B2.5  MAIVE — Meta-Analysis Instrumental Variable Estimator
*       (Irsova, Bom, Havranek & Rachinger, 2025) — R
*
*   Replaces the ad-hoc IV that instrumented the SE with 1/sqrt(N). MAIVE
*   instruments the reported VARIANCE with sample size, so it is robust to
*   spurious precision / p-hacking in the reported SEs — directly relevant to
*   the precise-but-tiny-SE studies flagged in the data audit (e.g. Dang, Bruna).
*
*   Input file column ORDER must be: (1) effect  (2) SE  (3) N  (4) study_id.
*   maive() reads by position, so variable names do not matter. maivefunction.r
*   must sit in "$pub/6. MAIVE" (it ships with the MAIVE replication code).
*   Same four robustness subsamples as the FAT-PET table above.
*----------------------------------------------------------------------------
* B2.5.1  Full sample (winsorised effect & SE, raw N)
preserve
keep if !missing(estimate_w, se_estimate_w, sample_size)
keep estimate_w se_estimate_w sample_size id_study
order estimate_w se_estimate_w sample_size id_study
export excel using "$pub/6. MAIVE/maive_full.xlsx", firstrow(variables) replace
restore

* B2.5.2  Direct estimates only
preserve
keep if direct_est==1 & !missing(estimate_w, se_estimate_w, sample_size)
keep estimate_w se_estimate_w sample_size id_study
order estimate_w se_estimate_w sample_size id_study
export excel using "$pub/6. MAIVE/maive_direct.xlsx", firstrow(variables) replace
restore

* B2.5.3  Excluding Middle East
preserve
keep if middle_east==0 & !missing(estimate_w, se_estimate_w, sample_size)
keep estimate_w se_estimate_w sample_size id_study
order estimate_w se_estimate_w sample_size id_study
export excel using "$pub/6. MAIVE/maive_excl_me.xlsx", firstrow(variables) replace
restore

* B2.5.4  Unwinsorised (raw effect & SE) — the conventional MAIVE input
preserve
keep if !missing(estimate, se_estimate, sample_size)
keep estimate se_estimate sample_size id_study
order estimate se_estimate sample_size id_study
export excel using "$pub/6. MAIVE/maive_unwinsorised.xlsx", firstrow(variables) replace
restore

/*
# ========================= MAIVE in R =========================

# If your earlier run failed, the usual reasons are:
#   - setwd(dirname(getActiveDocumentContext()$path)) only works when the script
#     is open in the RStudio editor and run via "Source"; set the path explicitly.
#   - source("maivefunction.R") is case-sensitive on some systems; the file here
#     is maivefunction.r (lower-case .r).
if (!require('readxl')) install.packages('readxl'); library('readxl')

setwd("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Publication bias/6. MAIVE")
source("maivefunction.r")     # ships with the MAIVE replication code; must be in this folder

# Options (Irsova et al. defaults): MAIVE-PET-PEESE, unweighted, instrumented,
# study-level clustering, Anderson-Rubin CI for weak instruments.
method <- 3; weight <- 0; instrument <- 1; studylevel <- 2; AR <- 1

run_maive <- function(file){
  dat <- as.data.frame(read_excel(file))      # columns in order: effect, SE, N, study_id
  m <- maive(dat=dat, method=method, weight=weight,
             instrument=instrument, studylevel=studylevel, AR=AR)
  data.frame(quantity = c("MAIVE coef","MAIVE SE","F-test 1st stage",
                          "Hausman","Chi2(1) crit","AR CI"),
             value    = c(m$beta, m$SE, m$`F-test`, m$Hausman, m$Chi2,
                          paste(m$AR_CI, collapse=" ")))
}

run_maive("maive_full.xlsx")           # B2.5.1 full sample
run_maive("maive_direct.xlsx")         # B2.5.2 direct estimates only
run_maive("maive_excl_me.xlsx")        # B2.5.3 excluding Middle East
run_maive("maive_unwinsorised.xlsx")   # B2.5.4 unwinsorised (conventional MAIVE input)
*/

*----------------------------------------------------------------------------
* B2.6  Provider invariance: interaction FAT-PET (formal test of the difference)
*       estimate_w = b0 + b1*SE + b2*bloomberg + b3*(SE x bloomberg)
*       b3 (se_x_bb)  : difference in FAT slope  (publication bias) across providers
*       b2 (bloomberg): difference in PET intercept (corrected mean) across providers
*       Two separately significant subsamples do NOT establish a difference; this
*       interaction provides a direct test of provider invariance.

set seed 20241215
cap drop se_x_bb
gen se_x_bb = se_estimate_w * bloomberg
*OLS
eststo: ivreg2 estimate_w se_estimate_w bloomberg se_x_bb, cluster(id_study)
*H0: equal FAT slope (publication bias) across providers
boottest se_x_bb, nograph     
*H0: equal PET intercept (corrected mean) across providers
boottest bloomberg, nograph    
*Precision-weighted
eststo: ivreg2 estimate_w se_estimate_w bloomberg se_x_bb [pweight=precision_w], cluster(id_study)
boottest se_x_bb, nograph
boottest bloomberg, nograph

esttab using table_bias_provider_interaction.tex, se booktabs replace compress title(FAT-PET provider invariance (interaction test)\label{tab:fatpet_provider_int}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01)
eststo clear

*-------------------------------------------------------------------------------
* B3.  WAAP — Weighted Average of Adequately Powered estimates (Ioannidis et al., 2017)
*
* METHOD NOTE:
*   WAAP retains only estimates with 80% power to detect the "true" effect.
*   The power threshold is SE < |θ̂_PET| / 2.8, where θ̂_PET is the
*   FAT-PET OLS intercept (bias-corrected mean). Because θ̂_PET is itself
*   estimated from the full sample including potentially biased observations,
*   the power screen is circular: biased estimates influence θ̂_PET, which
*   determines which estimates pass the screen. We report the standard WAAP
*   and two sensitivity checks (half / double θ̂_PET) to bracket the range.
*   Readers should interpret WAAP estimates with this caveat in mind.
*-------------------------------------------------------------------------------

* B3.1  Full sample
summarize estimate_w [aweight=precision_w*precision_w]
gen waapbound = abs(r(mean))/2.8
reg tstat_w precision_w if se_estimate_w < waapbound, noconstant

* B3.2  Robustness check: Direct estimates only (Excluding interaction-derived
*			   marginal effects and estimates with back-computed SE)
summarize estimate_w [aweight=precision_w*precision_w] if direct_est==1
gen waapbound_direct_est = abs(r(mean))/2.8
reg tstat_w precision_w if se_estimate_w < waapbound_direct_est & direct_est==1, noconstant

* B3.3  Robustness check: Excluding Middle East
summarize estimate_w [aweight=precision_w*precision_w] if middle_east==0
gen waapbound_int = abs(r(mean))/2.8
reg tstat_w precision_w if se_estimate_w < waapbound_int & middle_east==0, noconstant

* B3.4  Robustness check: Unwinsorised data (raw estimate / se_estimate / precision)
summarize estimate [aweight=precision*precision]
gen waapbound_nw = abs(r(mean))/2.8
reg tstat precision if se_estimate < waapbound_nw, noconstant

* B3.5  Sensitivity: half / double PET power assumption
* Using the FAT-PET OLS intercept (pet_full) stored earlier as the "true effect"
* rather than the WLS mean. This avoids the circularity partially.
*
* `pet_full' is set in B2.1, but Stata locals live only within a single run, so
* it is empty if B3 is executed on its own. Recompute it here when missing, so
* this block is self-contained.
if "`pet_full'" == "" {
    quietly ivreg2 estimate_w se_estimate_w, cluster(id_study)
    local pet_full = _b[_cons]
    di "NOTE: pet_full not in memory (B2 not run this session) — recomputed = " %6.4f `pet_full'
}
*
* Half PET (conservative — assumes true effect is smaller; more obs pass screen)
local waapbound_half = abs(`pet_full') / 2 / 2.8
di "--- WAAP sensitivity: half PET bound = " %6.4f `waapbound_half' " ---"
count if se_estimate_w < `waapbound_half'
reg tstat_w precision_w if se_estimate_w < `waapbound_half', noconstant

* Double PET (liberal — assumes true effect is larger; fewer obs pass screen)
local waapbound_double = abs(`pet_full') * 2 / 2.8
di "--- WAAP sensitivity: double PET bound = " %6.4f `waapbound_double' " ---"
count if se_estimate_w < `waapbound_double'
reg tstat_w precision_w if se_estimate_w < `waapbound_double', noconstant

* Summary
di ""
di "=== WAAP SENSITIVITY SUMMARY (full sample) ==="
di "  Power assumption       SE threshold    N in screen"
di "  Baseline (WLS mean)    " %6.4f waapbound  "            [see output above]"
di "  Half PET               " %6.4f `waapbound_half'
di "  Double PET             " %6.4f `waapbound_double'
di "  NOTE: If estimates diverge across rows, interpret WAAP with caution."


***************************************************************************************
*----------------------------------------------------------------------------
* B4.  Selection model (Andrews & Kasy, 2019; Kranz & Putz, 2021) — R
*----------------------------------------------------------------------------
***************************************************************************************
* --- Stata: export Selection-Model input data (col order: effect, SE) ---
* B4.1  Full sample
export delimited estimate_w se_estimate_w using "$pub/2. Selection Model/data_full.csv", novarnames
* B4.2  Direct estimates only (excl. interaction-derived & back-computed-SE estimates)
export delimited estimate_w se_estimate_w if direct_est==1 using "$pub/2. Selection Model/data_direct_est.csv", novarnames
* B4.3  Excluding Middle East
export delimited estimate_w se_estimate_w if middle_east==0 using "$pub/2. Selection Model/data_excl_ME.csv", novarnames
* B4.4  Unwinsorised data (raw estimate / se_estimate)
export delimited estimate se_estimate using "$pub/2. Selection Model/data_unwinsorised.csv", novarnames

/*
# ============== Selection model in R (Andrews & Kasy 2019; Kranz & Putz 2021) ==============
# MetaStudies is NOT on CRAN: install once with remotes::install_github("skranz/MetaStudies"),
# or source the bundled copies shipped in this folder instead of library():
#   source("metastudiesfunctions.r"); source("metastudiesplots.r")
library(MetaStudies)
library(readr)
setwd("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Publication bias/2. Selection Model")

run_ak <- function(file){                       # file names match the Stata exports above
  d <- read_csv(file, col_names = FALSE)
  colnames(d) <- c("X","sigma")
  ms <- metastudies_estimation(X=d$X, sigma=d$sigma, model="t", cutoffs=c(1.96), symmetric=TRUE)
  print(ms$est_tab)
  metastudy_X_sigma_cors(ms)
}

run_ak("data_full.csv")           # B4.1 full sample
run_ak("data_direct_est.csv")     # B4.2 direct estimates only
run_ak("data_excl_ME.csv")        # B4.3 excluding Middle East
run_ak("data_unwinsorised.csv")   # B4.4 unwinsorised
*/


***************************************************************************************
*----------------------------------------------------------------------------
* B5.  STEM method (Furukawa, 2019) — R
*----------------------------------------------------------------------------
***************************************************************************************
* STEM assumes INDEPENDENT studies, so it runs on study-level medians (one row per
* study). Two Stata exports first (full + direct subsamples), then a single R block
* that defines the STEM functions once and runs all four robustness checks.
* Files land in "$pub/3. STEM Method" and the R block reads them by bare name.
*----------------------------------------------------------------------------
* --- Stata: export study-level input files ---
* B5.1 data (full sample): per-study medians, winsorised (_medw) + raw (_med), with middle_east
preserve
bysort id_study: egen estimate_medw = median(estimate_w)
bysort id_study: egen se_medw       = median(se_estimate_w)
bysort id_study: egen estimate_med  = median(estimate)
bysort id_study: egen se_med        = median(se_estimate)
collapse (firstnm) study middle_east estimate_medw se_medw estimate_med se_med, by(id_study)
export excel id_study study middle_east estimate_medw se_medw estimate_med se_med using "$pub/3. STEM Method/esg_r_study.xlsx", firstrow(variables) replace
restore

* B5.2 data (direct estimates only): per-study medians over direct_est==1
preserve
keep if direct_est==1
bysort id_study: egen estimate_medw = median(estimate_w)
bysort id_study: egen se_medw       = median(se_estimate_w)
collapse (firstnm) study estimate_medw se_medw, by(id_study)
export excel id_study study estimate_medw se_medw using "$pub/3. STEM Method/esg_r_study_direct.xlsx", firstrow(variables) replace
restore

/*
# ============================ STEM in R (Furukawa 2019) ============================
library(readxl)
setwd("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Publication bias/3. STEM Method")

##0 set stem parameter
tolerance = 10^(-4) #set level of sufficiently small stem to determine convergence
max_N_count = 10^3 #set maximum number of iteration before termination
param <- c(tolerance, max_N_count)

##1 outer algorithm
stem <- function(beta, se, param){
  #Initial Values
  N_study <- length(beta)
  
  # sending sigma0->infinity implies equal weights to all studies
  beta_equal <- mean(beta)
  max_sigma_squared <- variance_0(N_study, beta, se, beta_equal)
  max_sigma = sqrt(max_sigma_squared)
  min_sigma = 0
  tolerance = param[1]
  
  #Sorting data by ascending order of standard error
  data1 <- cbind(beta,se)
  data_sorted <- data1[order(data1[,2]),]
  beta_sorted <- data_sorted[,1]
  se_sorted <- data_sorted[,2]
  
  #Compute stem based estimates until convergence from max and min of sigma
  output_max <- stem_converge(max_sigma, beta_sorted, se_sorted, param)
  output_min <- stem_converge(min_sigma, beta_sorted, se_sorted, param)
  Y_max <- output_max$estimates
  Y_min <- output_min$estimates
  
  
  #Check whether max and min agree
  diff_sigma <- abs(Y_max[3] -  Y_min[3])
  if (diff_sigma > (2*tolerance)){
    multiple = 1
  }
  else{
    multiple = 0
  }
  
  #information in sample
  n_stem <- Y_max[4]
  sigma0 <- Y_max[3]
  inv_var <- 1/(se_sorted^2+sigma0^2)
  info_in_sample = sum(inv_var[1:n_stem])/sum(inv_var)
  
  #Return
  Y1 = c(Y_max, multiple, info_in_sample)
  Y2 <- t(Y1)
  Z1 <- output_max$MSE
  Z2 <- t(Z1)
  
  colnames(Y2) <- c("estimate","se", "sd of total heterogeneity", "n_stem", "n_iteration", "multiple", "% info used")
  colnames(Z2) <- c("MSE", "variance", "bias_squared")
  output <- list("estimates" = Y2, "MSE" = Z2)
  return(output)
}

stem_converge <- function(initial_sigma, beta_sorted, se_sorted, param){
  converged = 0
  N_count = 0
  tolerance = param[1]
  max_N_count = param[2]
  sigma0 = initial_sigma
  
  while (converged == 0){
    output <- stem_compute(beta_sorted, se_sorted, sigma0)
    Y_stem <- output$estimates
    sigma = Y_stem[3]
    evolution = abs(sigma0 - sigma)
    N_count = N_count + 1
    
    if (evolution<tolerance){
      converged = 1
    }
    else if (N_count > max_N_count){
      converged = 1
    }
    else{
      sigma0 = sigma
    }
  }
  Y <- c(Y_stem, N_count)
  Z <- output$MSE
  output <- list("estimates" = Y, "MSE" = Z)
  return(output)
}


##2 inner algorithm
stem_compute <- function(beta, se, sigma0){
  
  N_study = length(beta)
  
  # relevant bias squared
  Eb_all = weighted_mean(beta, se, sigma0)
  Eb_leave_top_out = weighted_mean(beta[2:N_study], se[2:N_study], sigma0)
  Eb_squared = weighted_mean_squared(beta[2:N_study], se[2:N_study], sigma0)
  MSE_original = Eb_squared - 2*beta[1]*Eb_leave_top_out
  # since Eb_squared[1] cannot be computed without bias
  
  # variance
  Var_all = variance_b(se, sigma0)
  
  # minimize MSE
  n_stem_min = 3
  MSE = MSE_original[(n_stem_min-1):(N_study-1)]
  Bias = MSE - Var_all[n_stem_min:N_study]
  index <- which.min(MSE)
  n_stem = index+(n_stem_min-1)
  
  # assign values
  beta_stem = Eb_all[n_stem]
  se_stem = Var_all[n_stem]^(0.5)
  var_stem = variance_0(N_study, beta, se, beta_stem)
  sigma_stem = sqrt(var_stem)
  
  # stack outputs
  Y = cbind(beta_stem,se_stem,sigma_stem,n_stem)
  Z = rbind(MSE, Var_all[n_stem_min:N_study], Bias[(n_stem_min-1):(N_study-1)])
  output <- list("estimates" = Y, "MSE" = Z)
  return(output)
}

variance_b <- function(se, sigma){
  N_study <- length(se)
  Y <- vector(mode = 'numeric', length = N_study)
  proportional_weights = 1/(se^2 + sigma^2)
  
  for (i in 1:N_study){
    Y[i] <- 1/sum(proportional_weights[1:i])
  }
  return(Y)
}


variance_0 <- function(n_stem, beta, se, beta_mean){
  # formula adopted from DerSimonian and Laird (1996)
  weights <- 1/(se[1:n_stem]^2)
  total_weight = sum(weights)
  
  Y1 <- (t(weights) %*% (beta[1:n_stem] - beta_mean)^2) - (n_stem - 1)
  Y2 <- total_weight - (t(weights) %*% weights)/total_weight
  var = pmax(0, Y1/Y2)
  
  Y <- var
  return(Y)
}

weighted_mean <- function(beta, se, sigma){
  N_study <- length(beta)
  Y <- vector(mode = 'numeric', length = N_study)
  
  proportional_weights <- 1/(se^2 + sigma^2)
  
  for (i in 1:N_study){
    Y[i] <- beta[1:i] %*% proportional_weights[1:i]/sum(proportional_weights[1:i])
  }
  return(Y)
}

weighted_mean_squared <- function(beta, se, sigma){
  N <- length(beta)
  Y <- vector(mode = 'numeric', length = N)
  
  weights <- 1/(se^2 + sigma^2)
  weights_beta <- weights*beta
  
  W <- weights %o% weights
  WB <- weights_beta %o% weights_beta
  
  for (i in 2:N){
    Y1 <- sum(WB[1:i,1:i]) - sum(weights_beta[1:i]^2)
    Y2 <- sum(W[1:i,1:i]) - sum(weights[1:i]^2)
    Y[i] <- Y1/Y2
  }
  return(Y)
}

##3. figures
#install.packages("ggplot2")
#library(ggplot2)

se_rescale <- function(se){
  Y <- -log10(se)
  return(Y)
}

stem_funnel <- function(beta_input, se_input, stem_estimates){
  #take stem estimates
  b_stem <- stem_estimates[1]
  SE_b_stem <- stem_estimates[2]
  sigma0 <- stem_estimates[3]
  n_stem <- stem_estimates[4]
  
  #cumulative estimates
  data_input <- cbind(beta_input,se_input)
  data_sorted <- data_input[order(data_input[,2]),]
  beta_sorted <- data_sorted[,1]
  se_sorted <- data_sorted[,2]
  cumulative_estimates = weighted_mean(beta_sorted, se_sorted, sigma0)
  
  #set values for figures
  t_stat <- 1.96
  lineswidth<-2.5
  filled_diamond <- 18
  points_size <-2
  se_axis_min <- 0
  beta_axis_min <- 0.6
  beta_axis_max <- 1.2
  labNames <- c('Coefficient ','Precision ')
  
  # rescale SE for ease of visual interpretation
  se_axis <- se_rescale(se_sorted)
  
  #--------------
  # plot
  #--------------
  
  plot.new()
  # adjust margin
  par(mar=c(4.1,4.1,1,1))
  # plot studies
  plot(beta_sorted, se_axis, 
       col=rgb(102, 102, 255, maxColorValue = 255), pch = 1, lwd = 2.5,
       xlim=c(beta_axis_min, beta_axis_max),
       xlab=substitute(paste(name, beta), list(name=labNames[1])),
       ylab=substitute(paste(name, -log(SE)), list(name=labNames[2]))) #@@@@@@ modify this line if rescaling with a different function    
  #stem (cumulative estimates)
  lines(cumulative_estimates, se_axis, col=rgb(96, 96, 96, maxColorValue = 255), lwd=lineswidth)
  #augment stem
  points(b_stem, se_axis[n_stem], pch=filled_diamond ,col=rgb(0, 0, 153, maxColorValue = 255), cex = points_size)
  segments(b_stem, se_axis[1], b_stem, se_axis_min,col=rgb(0, 0, 153, maxColorValue = 255), lwd=lineswidth)
  #stem-based estimate
  points(b_stem, se_axis[1], pch=filled_diamond ,col=rgb(255, 128, 0, maxColorValue = 255), cex = points_size)
  segments(b_stem-t_stat*SE_b_stem, se_axis[1], b_stem+t_stat*SE_b_stem, se_axis[1],col=rgb(255, 128, 0, maxColorValue = 255), lwd=lineswidth)
  #zero line
  abline(v=0, col=rgb(192, 192, 192, maxColorValue = 255), lty=2, lwd=lineswidth)
  
  #legend
  legend("topleft", #@@@@@@ modify this line if want to put legend in a different location
         legend = c("stem-based estimate","95 confidence interval","cumulative estimate", "minimal precision", "study") , 
         col = c(rgb(255, 128, 0, maxColorValue = 255) , 
                 rgb(255, 128, 0, maxColorValue = 255) ,
                 rgb(96, 96, 96, maxColorValue = 255) ,
                 rgb(0, 0, 153, maxColorValue = 255) ,  
                 rgb(102, 102, 255, maxColorValue = 255)) , 
         bty = "n", 
         lty = c(NA, 1, 1, NA, NA), lwd = c(NA, 2, 2, NA, 2.5),
         pch= c(18, NA, NA, 18, 1), 
         pt.cex = 1.8, cex = 0.8, horiz = FALSE, inset = c(0, 0),
         y.intersp=1.5)
  
}

stem_MSE <- function(V){
  MSE = V[,1]
  bias_squared = V[,3]
  variance = V[,2]
  N_study = dim(V)[1]
  
  #figure input
  N_min = 2
  lineset <- 2.5
  num_study <- (N_min+1):(N_study+1)
  
  layout(matrix(c(1,2,3,3), 2, 2, byrow = TRUE))
  plot(num_study,bias_squared[N_min:N_study],type='l',  col="blue", lwd = lineset, xlab = 'Num of included studies i', ylab='', main= expression(Bias^2 - b[0]^2))
  plot(num_study,variance[N_min:N_study],type='l',  col="blue", lwd = lineset, xlab = 'Num of included studies i', ylab='', main = expression(Variance))
  plot(num_study,MSE[N_min:N_study],type='l',  col="blue", lwd = lineset, xlab = 'Num of included studies i', ylab='', main = expression(MSE - b[0]^2))
  
  }



#4. auxiliary function
#install.packages("data.table")
#library("data.table")

data_median <- function(data, id_var, main_var, additional_var){
  
  #1. drop rows with any NA
  complete_data <- na.omit(data)
  
  #2. rename columns
  column_id <- eval((substitute(complete_data[a], list(a = id_var))))
  colnames(column_id)[1] <- "id"
  column_main <- eval((substitute(complete_data[a], list(a = main_var))))
  colnames(column_main)[1] <- "main"
  column_additional <- eval((substitute(complete_data[a], list(a = additional_var))))
  colnames(column_additional)[1] <- "additional"
  
  columns_main_merged <- merge(column_id, column_main, by=0, all=TRUE) 
  columns_additional_merged <- merge(column_id, column_additional, by=0, all=TRUE) 
  
  #3. choose median of main_var along with id
  median_only <- aggregate(main~id,columns_main_merged,median)
  
  #4. merge with complete data
  median_together <- merge(median_only, columns_main_merged, by.x="id", by.y="id")
  median_all <- merge(median_together, columns_additional_merged, by.x="Row.names", by.y="Row.names")
  
  #5. choose data closest to the computed median
  median_all$diff_squared <- (median_all$main.x - median_all$main.y)^2
  table_form <- data.table(median_all)
  median_combined <- table_form[ , .SD[which.min(diff_squared)], by = id.x]
  
  #6. clean before output
  median_combined2 <- median_combined[order(median_combined$id.x),]
  median_combined3 <- median_combined2[, c("id.x", "main.x", "additional")]
  colnames(median_combined3)[1] <- "ID"
  colnames(median_combined3)[2] <- "coefficient"
  colnames(median_combined3)[3] <- "standard_error"
  Y <- median_combined3
  
  return(Y)
}

esg_r <- read_excel("esg_r_study.xlsx")   # cols: estimate_medw, se_medw, estimate_med, se_med, middle_east

# ----- B5.1  Full sample (winsorised study medians) -----
stem_results = stem(esg_r$estimate_medw, esg_r$se_medw, param)
print(stem_results[["estimates"]], digits = 6)
# QUALITY DIAGNOSTIC: if n_stem equals the floor n_stem_min (3 in stem_compute()),
# the MSE minimum is a boundary solution, not a genuine optimum -> inspect stem_MSE.
stem_MSE(stem_results[["MSE"]])
stem_funnel(esg_r$estimate_medw, esg_r$se_medw, stem_results[["estimates"]])

# ----- B5.2  Direct estimates only -----
esg_r_direct_est <- read_excel("esg_r_study_direct.xlsx")
stem_results = stem(esg_r_direct_est$estimate_medw, esg_r_direct_est$se_medw, param)
stem_results[["estimates"]]

# ----- B5.3  Excluding Middle East (subset the full study-level file) -----
esg_excl_me <- subset(esg_r, esg_r$middle_east==0)
stem_results = stem(esg_excl_me$estimate_medw, esg_excl_me$se_medw, param)
stem_results[["estimates"]]

# ----- B5.4  Unwinsorised (raw study medians estimate_med / se_med) -----
stem_results = stem(esg_r$estimate_med, esg_r$se_med, param)
stem_results[["estimates"]]
*/

* B6.  Endogenous Kink (Bom & Rachinger, 2020)
*----------------------------------------------------------------------------
*      code downloaded from https://sites.google.com/site/heikorachinger/codes 
***************************************************************************************
* NOTE: each subsample is wrapped in preserve/restore. The EK routine renames
*       the effect/SE variables (estimate_w -> bs, etc.); restore rolls those
*       renames back so every check starts from the full dataset and the data
*       are left intact for the sections that follow.

* B6.1  Full sample
preserve
quietly{
rename estimate_w bs
rename se_estimate_w sebs
gen ones=1
sum
local M=r(N)
sum sebs
local sebs_min=r(min)
local sebs_max=r(max)
gen sebs2=sebs^2
gen wis=ones/sebs2
gen bs_sebs=bs/sebs
gen ones_sebs=ones/sebs
gen bswis=bs*wis
sum wis
local wis_sum=r(sum)

regress bs_sebs ones_sebs ones,noc
local pet=_b[ones_sebs]
local t1_linreg = (_b[ones_sebs]/_se[ones_sebs])
local b_lin=_b[ones_sebs]
local Q1_lin = e(rss)
di `t1_linreg'
local abs_t1_linreg = abs(`t1_linreg')
di `abs_t1_linreg'

regress bs_sebs ones_sebs sebs,noc
local peese=_b[ones_sebs]
local b_sq=_b[ones_sebs]
local Q1_sq = e(rss)
di `Q1_sq'

if `abs_t1_linreg' > invt(`M-2', 0.975) {
    local combreg=`b_sq'
	local Q1=`Q1_sq'
	}
else {
    local combreg=`b_lin'
	local Q1=`Q1_lin'
}

local sigh2hat=max(0,`M'*((`Q1'/(`M'-e(df_m)-1))-1)/`wis_sum')
local sighhat=sqrt(`sigh2hat')

if `combreg'>1.96*`sighhat' {
    local a1=(`combreg'-1.96*`sighhat')*(`combreg'+1.96*`sighhat')/(2*1.96*`combreg')
}
else {
	local a1=0
	}
	rename bs bs_original
	rename bs_sebs bs
	rename ones_sebs constant
	rename ones pub_bias
    noisily: display "EK regression (Full sample): "
if `a1'>`sebs_min' & `a1'<`sebs_max' {
    gen sebs_a1=sebs-`a1' if sebs>`a1'
	replace sebs_a1=0 if sebs<=`a1'
	gen pubbias=sebs_a1/sebs
	noisily regress bs constant pubbias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pubbias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pubbias]
}
else if `a1'<`sebs_min' {
    noisily regress bs constant pub_bias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pub_bias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pub_bias]
}
else if `a1'>`sebs_max' {
    noisily regress bs constant, noc
	local b0_ek=_b[constant]
	local sd0_ek=_se[constant]
}
noisily: display "EK's mean effect estimate (alpha1) and standard error:"
noisily: di `b0_ek'
noisily: di `sd0_ek'
noisily: display "EK's publication bias estimate (delta) and standard error:"
noisily: di `b1_ek'
noisily: di `sd1_ek'
}
restore

* B6.2  Robustness check: Direct estimates only (Excluding interaction-derived
*			   marginal effects and estimates with back-computed SE)
preserve
keep if direct_est==1
quietly{
rename estimate_w bs
rename se_estimate_w sebs
gen ones=1
sum
local M=r(N)
sum sebs
local sebs_min=r(min)
local sebs_max=r(max)
gen sebs2=sebs^2
gen wis=ones/sebs2
gen bs_sebs=bs/sebs
gen ones_sebs=ones/sebs
gen bswis=bs*wis
sum wis
local wis_sum=r(sum)

regress bs_sebs ones_sebs ones,noc
local pet=_b[ones_sebs]
local t1_linreg = (_b[ones_sebs]/_se[ones_sebs])
local b_lin=_b[ones_sebs]
local Q1_lin = e(rss)
di `t1_linreg'
local abs_t1_linreg = abs(`t1_linreg')
di `abs_t1_linreg'

regress bs_sebs ones_sebs sebs,noc
local peese=_b[ones_sebs]
local b_sq=_b[ones_sebs]
local Q1_sq = e(rss)
di `Q1_sq'

if `abs_t1_linreg' > invt(`M-2', 0.975) {
    local combreg=`b_sq'
	local Q1=`Q1_sq'
	}
else {
    local combreg=`b_lin'
	local Q1=`Q1_lin'
}

local sigh2hat=max(0,`M'*((`Q1'/(`M'-e(df_m)-1))-1)/`wis_sum')
local sighhat=sqrt(`sigh2hat')

if `combreg'>1.96*`sighhat' {
    local a1=(`combreg'-1.96*`sighhat')*(`combreg'+1.96*`sighhat')/(2*1.96*`combreg')
}
else {
	local a1=0
	}
	rename bs bs_original
	rename bs_sebs bs
	rename ones_sebs constant
	rename ones pub_bias
    noisily: display "EK regression (Direct estimates): "
if `a1'>`sebs_min' & `a1'<`sebs_max' {
    gen sebs_a1=sebs-`a1' if sebs>`a1'
	replace sebs_a1=0 if sebs<=`a1'
	gen pubbias=sebs_a1/sebs
	noisily regress bs constant pubbias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pubbias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pubbias]
}
else if `a1'<`sebs_min' {
    noisily regress bs constant pub_bias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pub_bias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pub_bias]
}
else if `a1'>`sebs_max' {
    noisily regress bs constant, noc
	local b0_ek=_b[constant]
	local sd0_ek=_se[constant]
}
noisily: display "EK's mean effect estimate (alpha1) and standard error:"
noisily: di `b0_ek'
noisily: di `sd0_ek'
noisily: display "EK's publication bias estimate (delta) and standard error:"
noisily: di `b1_ek'
noisily: di `sd1_ek'
}
restore

* B6.3  Robustness check: Excluding Middle East
preserve
keep if middle_east==0
quietly{
rename estimate_w bs
rename se_estimate_w sebs
gen ones=1
sum
local M=r(N)
sum sebs
local sebs_min=r(min)
local sebs_max=r(max)
gen sebs2=sebs^2
gen wis=ones/sebs2
gen bs_sebs=bs/sebs
gen ones_sebs=ones/sebs
gen bswis=bs*wis
sum wis
local wis_sum=r(sum)

regress bs_sebs ones_sebs ones,noc
local pet=_b[ones_sebs]
local t1_linreg = (_b[ones_sebs]/_se[ones_sebs])
local b_lin=_b[ones_sebs]
local Q1_lin = e(rss)
di `t1_linreg'
local abs_t1_linreg = abs(`t1_linreg')
di `abs_t1_linreg'

regress bs_sebs ones_sebs sebs,noc
local peese=_b[ones_sebs]
local b_sq=_b[ones_sebs]
local Q1_sq = e(rss)
di `Q1_sq'

if `abs_t1_linreg' > invt(`M-2', 0.975) {
    local combreg=`b_sq'
	local Q1=`Q1_sq'
	}
else {
    local combreg=`b_lin'
	local Q1=`Q1_lin'
}

local sigh2hat=max(0,`M'*((`Q1'/(`M'-e(df_m)-1))-1)/`wis_sum')
local sighhat=sqrt(`sigh2hat')

if `combreg'>1.96*`sighhat' {
    local a1=(`combreg'-1.96*`sighhat')*(`combreg'+1.96*`sighhat')/(2*1.96*`combreg')
}
else {
	local a1=0
	}
	rename bs bs_original
	rename bs_sebs bs
	rename ones_sebs constant
	rename ones pub_bias
    noisily: display "EK regression (Excluding Middle East): "
if `a1'>`sebs_min' & `a1'<`sebs_max' {
    gen sebs_a1=sebs-`a1' if sebs>`a1'
	replace sebs_a1=0 if sebs<=`a1'
	gen pubbias=sebs_a1/sebs
	noisily regress bs constant pubbias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pubbias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pubbias]
}
else if `a1'<`sebs_min' {
    noisily regress bs constant pub_bias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pub_bias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pub_bias]
}
else if `a1'>`sebs_max' {
    noisily regress bs constant, noc
	local b0_ek=_b[constant]
	local sd0_ek=_se[constant]
}
noisily: display "EK's mean effect estimate (alpha1) and standard error:"
noisily: di `b0_ek'
noisily: di `sd0_ek'
noisily: display "EK's publication bias estimate (delta) and standard error:"
noisily: di `b1_ek'
noisily: di `sd1_ek'
}
restore

* B6.4  Robustness check: Unwinsorised data (raw estimate / se_estimate)
preserve
quietly{
rename estimate bs
rename se_estimate sebs
gen ones=1
sum
local M=r(N)
sum sebs
local sebs_min=r(min)
local sebs_max=r(max)
gen sebs2=sebs^2
gen wis=ones/sebs2
gen bs_sebs=bs/sebs
gen ones_sebs=ones/sebs
gen bswis=bs*wis
sum wis
local wis_sum=r(sum)

regress bs_sebs ones_sebs ones,noc
local pet=_b[ones_sebs]
local t1_linreg = (_b[ones_sebs]/_se[ones_sebs])
local b_lin=_b[ones_sebs]
local Q1_lin = e(rss)
di `t1_linreg'
local abs_t1_linreg = abs(`t1_linreg')
di `abs_t1_linreg'

regress bs_sebs ones_sebs sebs,noc
local peese=_b[ones_sebs]
local b_sq=_b[ones_sebs]
local Q1_sq = e(rss)
di `Q1_sq'

if `abs_t1_linreg' > invt(`M-2', 0.975) {
    local combreg=`b_sq'
	local Q1=`Q1_sq'
	}
else {
    local combreg=`b_lin'
	local Q1=`Q1_lin'
}

local sigh2hat=max(0,`M'*((`Q1'/(`M'-e(df_m)-1))-1)/`wis_sum')
local sighhat=sqrt(`sigh2hat')

if `combreg'>1.96*`sighhat' {
    local a1=(`combreg'-1.96*`sighhat')*(`combreg'+1.96*`sighhat')/(2*1.96*`combreg')
}
else {
	local a1=0
	}
	rename bs bs_original
	rename bs_sebs bs
	rename ones_sebs constant
	rename ones pub_bias
    noisily: display "EK regression (Unwinsorised): "
if `a1'>`sebs_min' & `a1'<`sebs_max' {
    gen sebs_a1=sebs-`a1' if sebs>`a1'
	replace sebs_a1=0 if sebs<=`a1'
	gen pubbias=sebs_a1/sebs
	noisily regress bs constant pubbias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pubbias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pubbias]
}
else if `a1'<`sebs_min' {
    noisily regress bs constant pub_bias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pub_bias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pub_bias]
}
else if `a1'>`sebs_max' {
    noisily regress bs constant, noc
	local b0_ek=_b[constant]
	local sd0_ek=_se[constant]
}
noisily: display "EK's mean effect estimate (alpha1) and standard error:"
noisily: di `b0_ek'
noisily: di `sd0_ek'
noisily: display "EK's publication bias estimate (delta) and standard error:"
noisily: di `b1_ek'
noisily: di `sd1_ek'
}
restore

********************************************************************************
*----------------------------------------------------------------------------
* B7.  p-uniform* (van Aert & van Assen, 2026) — R  [study-level medians]
*----------------------------------------------------------------------------
***************************************************************************************
* Two-step layout (like MAIVE): first Stata collapses each subsample to study-level
* medians and saves one .dta to "$pub/4. p-uniform"; then a single R block setwd's
* there and runs p-uniform* on each. Each file keeps BOTH winsorised (_medw) and raw
* (_med) medians, so the unwinsorised check (B7.4) re-reads the full file's raw cols.
* preserve/restore keeps the estimate-level master data intact for later sections.
*----------------------------------------------------------------------------
* --- Stata: study-level median datasets ---
* B7.1  Full sample
preserve
bysort id_study: egen estimate_med  = median(estimate)
bysort id_study: egen estimate_medw = median(estimate_w)
bysort id_study: egen se_med  = median(se_estimate)
bysort id_study: egen se_medw = median(se_estimate_w)
bysort id_study: egen t_med  = median(t_stat)
bysort id_study: egen t_medw = median(tstat_w)
gen variance_med  = se_med*se_med
gen variance_medw = se_medw*se_medw
collapse (lastnm) estimate_med estimate_medw se_med se_medw variance_med variance_medw t_med t_medw (p50) nobs_med=sample_size_w, by(id_study)
save "$pub/4. p-uniform/puniform_full.dta", replace
restore

* B7.2  Direct estimates only (excl. interaction-derived & back-computed-SE)
preserve
keep if direct_est==1
bysort id_study: egen estimate_med  = median(estimate)
bysort id_study: egen estimate_medw = median(estimate_w)
bysort id_study: egen se_med  = median(se_estimate)
bysort id_study: egen se_medw = median(se_estimate_w)
bysort id_study: egen t_med  = median(t_stat)
bysort id_study: egen t_medw = median(tstat_w)
gen variance_med  = se_med*se_med
gen variance_medw = se_medw*se_medw
collapse (lastnm) estimate_med estimate_medw se_med se_medw variance_med variance_medw t_med t_medw (p50) nobs_med=sample_size_w, by(id_study)
save "$pub/4. p-uniform/puniform_direct_est.dta", replace
restore

* B7.3  Excluding Middle East
preserve
keep if middle_east==0
bysort id_study: egen estimate_med  = median(estimate)
bysort id_study: egen estimate_medw = median(estimate_w)
bysort id_study: egen se_med  = median(se_estimate)
bysort id_study: egen se_medw = median(se_estimate_w)
bysort id_study: egen t_med  = median(t_stat)
bysort id_study: egen t_medw = median(tstat_w)
gen variance_med  = se_med*se_med
gen variance_medw = se_medw*se_medw
collapse (lastnm) estimate_med estimate_medw se_med se_medw variance_med variance_medw t_med t_medw (p50) nobs_med=sample_size_w, by(id_study)
save "$pub/4. p-uniform/puniform_excl_me.dta", replace
restore

/*
# ========================= p-uniform* in R (van Aert & van Assen 2026) =========================
# install once if needed:
# install.packages(c('puniform','metafor','dmetar','haven','tidyverse','meta'))
library(puniform); library(metafor); library(haven); library(meta)
setwd("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Publication bias/4. p-uniform")

run_puni <- function(file, yi, vi){            # file names match the Stata saves above
  d <- read_dta(file)
  print(puni_star(yi = d[[yi]], vi = d[[vi]], side="right", method="ML", alpha = 0.05))
  # (legacy original-p-uniform call removed: never reported, and errors under side="right")
}

run_puni("puniform_full.dta",       "estimate_medw", "variance_medw")   # B7.1 full
run_puni("puniform_direct_est.dta", "estimate_medw", "variance_medw")   # B7.2 direct only
run_puni("puniform_excl_me.dta",    "estimate_medw", "variance_medw")   # B7.3 excluding Middle East
run_puni("puniform_full.dta",       "estimate_med",  "variance_med")    # B7.4 unwinsorised (raw medians)
*/

* B8.  Caliper test (Gerber & Malhotra, 2008)
*----------------------------------------------------------------------------
***************************************************************************************

histogram tstat_w if 20>tstat_w & tstat_w>-6, bin(40) fcolor(gs14) lstyle(thin) frequency normal xtitle("t-statistics of the elasticity estimates") xlabel(-5 0 1.96 5 10 15 20) xline(0 1.96 , lcolor(red)) ylabel( ,glcolor(ltbluishgray)) graphregion(color(ltbluishgray)) saving(caliper_direct, replace)

* NOTE: each subsample is wrapped in preserve/restore. The caliper test generates
*       a `significant` indicator and drops observations; restore returns the full
*       estimate-level data so each check starts clean and the data are intact for
*       the sections that follow.

* B8.1  Full sample
preserve
generate significant = 0
replace significant = 1 if tstat_w > 0


reg significant if tstat_w > -0.35 & tstat_w < 0.35
 lincom _cons - 0.5
reg significant if tstat_w > -0.4 & tstat_w < 0.4
 lincom _cons - 0.5
reg significant if tstat_w > -0.45 & tstat_w < 0.45
 lincom _cons - 0.5
reg significant if tstat_w > -0.5 & tstat_w < 0.5
 lincom _cons - 0.5

replace significant = 0
replace significant = 1 if tstat_w > 1.96

reg significant if tstat_w > 1.61 & tstat_w < 2.31
 lincom _cons - 0.5
reg significant if tstat_w > 1.56 & tstat_w < 2.36
 lincom _cons - 0.5
reg significant if tstat_w > 1.51 & tstat_w < 2.41
 lincom _cons - 0.5
reg significant if tstat_w > 1.46 & tstat_w < 2.46
 lincom _cons - 0.5
restore

* B8.2  Robustness check: Direct estimates only (Excluding interaction-derived
*			   marginal effects and estimates with back-computed SE)
preserve
keep if direct_est==1

generate significant = 0
replace significant = 1 if tstat_w > 0

reg significant if tstat_w > -0.35 & tstat_w < 0.35
 lincom _cons - 0.5
reg significant if tstat_w > -0.4 & tstat_w < 0.4
 lincom _cons - 0.5
reg significant if tstat_w > -0.45 & tstat_w < 0.45
 lincom _cons - 0.5
reg significant if tstat_w > -0.5 & tstat_w < 0.5
 lincom _cons - 0.5

replace significant = 0
replace significant = 1 if tstat_w > 1.96

reg significant if tstat_w > 1.61 & tstat_w < 2.31
 lincom _cons - 0.5
reg significant if tstat_w > 1.56 & tstat_w < 2.36
 lincom _cons - 0.5
reg significant if tstat_w > 1.51 & tstat_w < 2.41
 lincom _cons - 0.5
reg significant if tstat_w > 1.46 & tstat_w < 2.46
 lincom _cons - 0.5
restore

* B8.3  Robustness check: Excluding Middle East
preserve
keep if middle_east==0

generate significant = 0
replace significant = 1 if tstat_w > 0


reg significant if tstat_w > -0.35 & tstat_w < 0.35
 lincom _cons - 0.5
reg significant if tstat_w > -0.4 & tstat_w < 0.4
 lincom _cons - 0.5
reg significant if tstat_w > -0.45 & tstat_w < 0.45
 lincom _cons - 0.5
reg significant if tstat_w > -0.5 & tstat_w < 0.5
 lincom _cons - 0.5

replace significant = 0
replace significant = 1 if tstat_w > 1.96

reg significant if tstat_w > 1.61 & tstat_w < 2.31
 lincom _cons - 0.5
reg significant if tstat_w > 1.56 & tstat_w < 2.36
 lincom _cons - 0.5
reg significant if tstat_w > 1.51 & tstat_w < 2.41
 lincom _cons - 0.5
reg significant if tstat_w > 1.46 & tstat_w < 2.46
 lincom _cons - 0.5
restore

* B8.4  Robustness check: Unwinsorised data (raw tstat = estimate / se_estimate)
preserve

generate significant = 0
replace significant = 1 if tstat > 0

reg significant if tstat > -0.35 & tstat < 0.35
 lincom _cons - 0.5
reg significant if tstat > -0.4 & tstat < 0.4
 lincom _cons - 0.5
reg significant if tstat > -0.45 & tstat < 0.45
 lincom _cons - 0.5
reg significant if tstat > -0.5 & tstat < 0.5
 lincom _cons - 0.5

replace significant = 0
replace significant = 1 if tstat > 1.96

reg significant if tstat > 1.61 & tstat < 2.31
 lincom _cons - 0.5
reg significant if tstat > 1.56 & tstat < 2.36
 lincom _cons - 0.5
reg significant if tstat > 1.51 & tstat < 2.41
 lincom _cons - 0.5
reg significant if tstat > 1.46 & tstat < 2.46
 lincom _cons - 0.5
restore

*==============================================================================================
*==============================================================================================
*
*  C.  HETEROGENEITY
*
*==============================================================================================
*==============================================================================================

***************************************************************************************
*----------------------------------------------------------------------------
* C1.  Data export and preparation for BMA / FMA
*----------------------------------------------------------------------------
***************************************************************************************
* HETEROGENEITY - Exporting data
*   All intermediate files (data_all.xlsx, data_full_nest.xlsx, etc.) are
*   written to $het so Stata and R both point to the same folder.
***************************************************************************************
cd "$het"

***************************************************************************************
export excel using "data_all.xlsx", sheet("unweighted") firstrow(variables) replace
clear

*all unweighted (full sample)
import excel data_all.xlsx, sheet("unweighted") firstrow

correlate estimate_w se_estimate_w ln_sample_size data_panel eikon ln_avg_year ln_bgd_mean published_study ln_citations method_linear method_panel method_iv method_gmm poor_endog_control ln_data_variables global europe us asia middle_east emerging financial control_firm_size control_board_ind control_csr_com     

keep estimate_w se_estimate_w ln_sample_size data_panel eikon ln_avg_year ln_bgd_mean published_study ln_citations method_linear method_panel method_iv method_gmm poor_endog_control ln_data_variables global europe us asia middle_east emerging financial control_firm_size control_board_ind control_csr_com 

order estimate_w se_estimate_w ln_sample_size data_panel eikon ln_avg_year ln_bgd_mean published_study ln_citations method_linear method_panel method_iv method_gmm poor_endog_control ln_data_variables global europe us asia middle_east emerging financial control_firm_size control_board_ind control_csr_com

export excel using "data_full.xlsx", sheet("unweighted") firstrow(variables) replace
clear

**************************************************************************************
*all weighted by sqrt(inv_nest) (full sample)

import excel data_all.xlsx, sheet("unweighted") firstrow
local data_nest "estimate_w se_estimate_w ln_sample_size data_panel eikon ln_avg_year ln_bgd_mean published_study ln_citations method_linear method_panel method_iv method_gmm poor_endog_control ln_data_variables global europe us asia middle_east emerging financial control_firm_size control_board_ind control_csr_com" 
foreach var of varlist `data_nest' {
				replace `var' = `var' * sqrt(inv_nest)
}

correlate estimate_w se_estimate_w ln_sample_size data_panel eikon ln_avg_year ln_bgd_mean published_study  ln_citations method_linear method_panel method_iv method_gmm poor_endog_control ln_data_variables global europe us asia middle_east emerging financial control_firm_size control_board_ind control_csr_com 

keep estimate_w se_estimate_w ln_sample_size data_panel eikon ln_avg_year ln_bgd_mean published_study ln_citations method_linear method_panel method_iv method_gmm poor_endog_control ln_data_variables global europe us asia middle_east emerging financial control_firm_size control_board_ind control_csr_com

order estimate_w se_estimate_w ln_sample_size data_panel eikon ln_avg_year ln_bgd_mean published_study ln_citations method_linear method_panel method_iv method_gmm poor_endog_control ln_data_variables global europe us asia middle_east emerging financial control_firm_size control_board_ind control_csr_com 

export excel using "data_full_nest.xlsx", sheet("weighted_n") firstrow(variables) replace
clear


**************************************************************************************
*ROBUSTNESS CHECK
import excel data_full_nest.xlsx, sheet("weighted_n") firstrow

keep if middle_east==0           


* excl-ME: middle_east dropped (constant = 0 after keep if middle_east==0)
correlate estimate_w se_estimate_w ln_sample_size data_panel eikon ln_avg_year ln_bgd_mean published_study  ln_citations method_linear method_panel method_iv method_gmm poor_endog_control ln_data_variables global europe us asia emerging financial control_firm_size control_board_ind control_csr_com 

keep estimate_w se_estimate_w ln_sample_size data_panel eikon ln_avg_year ln_bgd_mean published_study  ln_citations method_linear method_panel method_iv method_gmm poor_endog_control ln_data_variables global europe us asia emerging financial control_firm_size control_board_ind control_csr_com 

order estimate_w se_estimate_w ln_sample_size data_panel eikon ln_avg_year ln_bgd_mean published_study  ln_citations method_linear method_panel method_iv method_gmm poor_endog_control ln_data_variables global europe us asia emerging financial control_firm_size control_board_ind control_csr_com 

export excel using "data_full_nest_robustness.xlsx", sheet("weighted_n") firstrow(variables) replace

clear
***************************************************************************************
*----------------------------------------------------------------------------
* C2.  OLS meta-regression (full 24-moderator set)
*----------------------------------------------------------------------------
***************************************************************************************
import excel data_all.xlsx, sheet("unweighted") firstrow
ivreg2 estimate_w se_estimate_w ln_sample_size data_panel eikon ln_avg_year ln_bgd_mean published_study ln_citations method_linear method_panel method_iv method_gmm poor_endog_control global europe us asia middle_east emerging financial ln_data_variables control_firm_size control_board_ind control_csr_com, cluster(id_study)

stepwise, pr(.05): regress estimate_w se_estimate_w ln_sample_size data_panel eikon ln_avg_year ln_bgd_mean published_study ln_citations method_linear method_panel method_iv method_gmm poor_endog_control global europe us asia middle_east emerging financial ln_data_variables control_firm_size control_board_ind control_csr_com, cluster(id_study)

***************************************************************************************
*----------------------------------------------------------------------------
* C3.  Bayesian Model Averaging (BMA) — R (dilutBMS2 package)
*----------------------------------------------------------------------------
***************************************************************************************
/*
# ============================================================================
# BMA HETEROGENEITY ANALYSIS  —  BGD -> ESG meta-analysis
# ----------------------------------------------------------------------------
# Reported specifications:
#   (1) BASELINE        dilution + UIP , full sample      , 1,000,000 draws
#   (2) SUBSAMPLE       dilution + UIP , excl. Middle East , 1,000,000 draws
#   (3) PRIOR ROBUSTNESS random   + BRIC, full sample      ,   300,000 draws
# Convergence diagnostics (closes audit F2-001):
#   - Corr PMP (analytic vs MCMC PMP)      [within-chain stationarity]
#   - unique models visited & % of 2^K     [model-space exploration]
#   - models needed to reach 90% PMP        [effective concentration / ESS proxy]
#   - PIP agreement 1M vs 300k (same seed)  [draw-length sensitivity, audit asks 1M+]
#   - PIP agreement seed1 vs seed2 (300k)   [independent-chain agreement = Gelman-Rubin analogue]
# ============================================================================

library(readxl)
library(BMS)          # S3 methods for class "bma" (coef/summary/image/pmp.bma)
library(dilutBMS2)    # adds the dilution prior; load AFTER BMS so its bms() masks BMS::bms
library(corrplot)

setwd("/Users/karolina/IES/PhD/Meta-Analysis/bgd-esg/Output/Heterogeneity/")

## ---- constants --------------------------------------------------------------
LABELS <- c(
  estimate_w         = "Effect",
  se_estimate_w      = "Standard error",
  ln_sample_size     = "Sample size",
  data_panel         = "Data: panel",
  eikon              = "Data: LSEG",
  ln_avg_year        = "Average data year",
  ln_bgd_mean        = "Average board gender diversity",
  published_study    = "Published",
  ln_citations       = "Number of citations",
  method_linear      = "Method: linear",
  method_panel       = "Method: panel",
  method_iv          = "Method: IV",
  method_gmm         = "Method: GMM",
  poor_endog_control = "Endogeneity control: poor",
  ln_data_variables  = "Number of variables",
  global             = "Region: global",
  europe             = "Region: Europe",
  us                 = "Region: USA",
  asia               = "Region: Asia",
  middle_east        = "Region: Middle East",
  emerging           = "Market: emerging",
  financial          = "Sector: financial",
  control_firm_size  = "Control: firm size",
  control_board_ind  = "Control: board independence",
  control_csr_com    = "Control: CSR committee"
)

load_design <- function(file) {
  d <- as.data.frame(readxl::read_excel(file))
  stopifnot(setequal(colnames(d), names(LABELS)))   # fails loudly if a var is missing/extra
  stopifnot(colnames(d)[1] == "estimate_w")          # bms needs the dependent var first
  colnames(d) <- LABELS[colnames(d)]                 # rename by match, order-proof
  d
}

BURN_1M  <- 3e5;  ITER_1M  <- 1e6
BURN_3e5 <- 1e5;  ITER_3e5 <- 3e5
NMODEL   <- 1e5
SEED1 <- 20241215
SEED2 <- 99999
ME_COL <- "Region: Middle East"

## ---- helpers ----------------------------------------------------------------
# drop zero-variance columns (keep 'Effect' first); returns cleaned df
drop_constant <- function(df) {
  keep <- vapply(df, function(x) length(unique(x)) > 1, logical(1))
  keep["Effect"] <- TRUE
  if (any(!keep)) message("Dropped constant column(s): ",
                          paste(names(keep)[!keep], collapse = ", "))
  df[, keep, drop = FALSE]
}

run_bma <- function(dat, seed, burn, iter, g, mprior, label) {
  set.seed(seed)
  m <- dilutBMS2::bms(dat, burn = burn, iter = iter, g = g, mprior = mprior,
                      nmodel = NMODEL, mcmc = "bd", user.int = FALSE)
  cat("\n================  ", label, "  ================\n"); print(summary(m))
  m
}

# MCMC-frequency PIPs (these reflect sampler behaviour -> used for convergence)
pip_of    <- function(m) { cf <- coef(m, order.by.pip = FALSE, exact = FALSE)
setNames(cf[, "PIP"], rownames(cf)) }
models_to <- function(m, thr = 0.90) min(which(cumsum(pmp.bma(m)[, 1]) >= thr))
summ_num  <- function(m, field) as.numeric(gsub("[^0-9eE.+-]", "", summary(m)[field]))

diag_row  <- function(m, label, draws, k) data.frame(
  Specification   = label,
  Draws           = draws,
  Unique_models   = summ_num(m, "No. models visited"),
  Pct_of_2K       = round(summ_num(m, "No. models visited") / (2^k) * 100, 4),
  Models_to_90PMP = models_to(m, 0.90),
  Corr_PMP        = round(summ_num(m, "Corr PMP"), 4),
  row.names = NULL)

## ---- data -------------------------------------------------------------------
dat_full <- load_design("data_full_nest.xlsx")          # weighted design matrix
K <- ncol(dat_full) - 1L                                  # = 25

# Excl-Middle-East subsample, derived to match Stata's `if middle_east==0`:
# in the weighted data the ME column is 0 for non-ME obs and >0 for ME obs.
dat_excl_me <- dat_full[dat_full[[ME_COL]] == 0, ]
dat_excl_me[[ME_COL]] <- NULL
dat_excl_me <- drop_constant(dat_excl_me)                 # safety net
K_me <- ncol(dat_excl_me) - 1L
cat("Full sample N =", nrow(dat_full), " | Excl-ME N =", nrow(dat_excl_me),
    " | K(full)=", K, " K(excl-ME)=", K_me, "\n")
# (If you'd rather use the Stata export (section C1.3), note it omits the middle_east
#  column, so load_design()'s strict column check would stop; read it without the
#  check — replace the 3 lines above with:
#   d <- as.data.frame(readxl::read_excel("data_full_nest_robustness.xlsx"))
#   colnames(d) <- LABELS[colnames(d)]
#   dat_excl_me <- drop_constant(d) )

# ============================================================================
# (1) BASELINE : dilution + UIP, full sample, 1M
# ============================================================================
baseline <- run_bma(dat_full, SEED1, BURN_1M, ITER_1M, "UIP", "dilut",
                    "BASELINE  dilut+UIP  full  1M")

ctab_base <- coef(baseline, order.by.pip = TRUE, exact = TRUE, include.constant = TRUE)
print(ctab_base)
write.csv(ctab_base, "bma_baseline_coef.csv")

b0_bma <- coef(baseline, order.by.pip = FALSE, exact = TRUE,
               include.constant = TRUE)["(Intercept)", "Post Mean"]
cat("\n=== COPY INTO Stata BPE SECTION ===\nscalar b0_bma =", round(b0_bma, 6), "\n")

png("bma_baseline.png", width = 7, height = 6, units = "in", res = 150)
image(baseline, yprop2pip = FALSE, order.by.pip = TRUE, do.grid = TRUE, cex.axis = 0.7)
dev.off()
png("posterior_baseline.png", width = 7, height = 6, units = "in", res = 150)
plot(baseline); dev.off()

# cumulative PMP (effective-concentration / ESS proxy for F2-001)
png("bma_baseline_pmp_cumulative.png", width = 8, height = 5, units = "in", res = 150)
plot(cumsum(pmp.bma(baseline)[, 1]), type = "l", lwd = 2,
     xlab = "Model rank", ylab = "Cumulative posterior model prob.",
     main = "Cumulative PMP — baseline (1M draws)")
abline(h = 0.90, lty = 2, col = "red")
legend("bottomright", "90% PMP", lty = 2, col = "red", bty = "n")
dev.off()

# ============================================================================
# CONVERGENCE CHAINS (full sample) — for F2-001 only, not reported as columns
#   conv_len : 300k, SEED1  -> isolates DRAW LENGTH  (vs 1M baseline)
#   conv_seed: 300k, SEED2  -> isolates SEED         (vs conv_len)
# ============================================================================
conv_len  <- run_bma(dat_full, SEED1, BURN_3e5, ITER_3e5, "UIP", "dilut",
                     "CONV 300k seed1")
conv_seed <- run_bma(dat_full, SEED2, BURN_3e5, ITER_3e5, "UIP", "dilut",
                     "CONV 300k seed2")

p_base <- pip_of(baseline); p_len <- pip_of(conv_len); p_seed <- pip_of(conv_seed)
cmp <- function(a, b) c(cor = cor(a, b[names(a)]),
                        max_abs_diff = max(abs(a - b[names(a)])))
len_check  <- cmp(p_base, p_len)    # 1M vs 300k (same seed)
seed_check <- cmp(p_len, p_seed)    # 300k seed1 vs seed2

# per-variable PIP across the three full-sample chains, sorted by disagreement
conv_tab <- data.frame(Variable = names(p_base),
                       PIP_1M         = round(p_base, 4),
                       PIP_300k_s1    = round(p_len[names(p_base)], 4),
                       PIP_300k_s2    = round(p_seed[names(p_base)], 4),
                       row.names = NULL)
conv_tab$Spread <- round(apply(conv_tab[, 2:4], 1, function(x) max(x) - min(x)), 4)
conv_tab <- conv_tab[order(-conv_tab$Spread), ]
write.csv(conv_tab, "bma_convergence_pip_table.csv", row.names = FALSE)

# ============================================================================
# (2) SUBSAMPLE ROBUSTNESS : dilution + UIP, excl Middle East, 1M
# ============================================================================
subsample <- run_bma(dat_excl_me, SEED1, BURN_1M, ITER_1M, "UIP", "dilut",
                     "SUBSAMPLE  dilut+UIP  excl-ME  1M")
ctab_sub <- coef(subsample, order.by.pip = TRUE, exact = TRUE, include.constant = TRUE)
print(ctab_sub); write.csv(ctab_sub, "bma_excl_me_coef.csv")
png("bma_excl_me.png", width = 7, height = 6, units = "in", res = 150)
image(subsample, yprop2pip = FALSE, order.by.pip = TRUE, do.grid = TRUE, cex.axis = 0.7)
dev.off()

# ============================================================================
# (3) PRIOR ROBUSTNESS : random + BRIC, full sample, 300k
#   (if dilutBMS2 lacks mprior="random", use BMS::bms here instead)
# ============================================================================
prior_rob <- run_bma(dat_full, SEED1, BURN_3e5, ITER_3e5, "BRIC", "random",
                     "PRIOR ROB  random+BRIC  full  300k")
ctab_pr <- coef(prior_rob, order.by.pip = TRUE, exact = TRUE, include.constant = TRUE)
print(ctab_pr); write.csv(ctab_pr, "bma_prior_random_bric_coef.csv")
png("bma_prior_random_bric.png", width = 7, height = 6, units = "in", res = 150)
image(prior_rob, yprop2pip = FALSE, order.by.pip = TRUE, do.grid = TRUE, cex.axis = 0.7)
dev.off()

# ============================================================================
# CONSOLIDATED CONVERGENCE REPORT
# ============================================================================
conv_summary <- rbind(
  diag_row(baseline,  "Baseline (dilut+UIP, full, 1M)",        ITER_1M,  K),
  diag_row(subsample, "Subsample (dilut+UIP, excl-ME, 1M)",    ITER_1M,  K_me),
  diag_row(prior_rob, "Prior rob. (random+BRIC, full, 300k)",  ITER_3e5, K))
write.csv(conv_summary, "bma_convergence_summary.csv", row.names = FALSE)

cat("\n\n=========================  F2-001 CONVERGENCE  =========================\n")
print(conv_summary, row.names = FALSE)
cat("\nFull-sample cross-chain PIP agreement (MCMC PIPs):\n")
cat(sprintf("  Draw length  (1M vs 300k, same seed) : cor = %.4f , max |dPIP| = %.4f\n",
            len_check["cor"],  len_check["max_abs_diff"]))
cat(sprintf("  Independent seed (300k s1 vs s2)     : cor = %.4f , max |dPIP| = %.4f\n",
            seed_check["cor"], seed_check["max_abs_diff"]))
cat("  Rule of thumb: cor > 0.99 and max |dPIP| < 0.05 = adequate convergence.\n")
cat("  NB: <1% coverage of 2^K is expected for MCMC BMA — the chain concentrates\n",
    "     posterior mass on high-likelihood models; Corr PMP ~ 1 is the validity test.\n")
cat("=======================================================================\n")

# ============================================================================
# FIGURE : correlation matrix on the UNWEIGHTED data (interpretable one)
# ============================================================================
M <- cor(load_design("data_full.xlsx"))
png("correlation.png", width = 12, height = 10, units = "in", res = 150)
col <- colorRampPalette(c("red", "white", "blue"))
corrplot.mixed(M, lower = "number", upper = "circle",
               lower.col = col(200), upper.col = col(200),
               tl.pos = "lt", diag = "u", tl.col = "black", tl.srt = 45,
               tl.cex = 0.5, number.cex = 0.5, cl.cex = 0.5, cl.ratio = 0.1)
dev.off()

# ============================================================================
# OPTIONAL (DISABLED — not used in the paper; uncomment to run):
#   posterior densities of selected high-interest coefficients
#   (names must match labels; pick by PIP after seeing ctab_base)
# ============================================================================
# png("posterior_densities.png", width = 9, height = 7, units = "in", res = 150)
# par(mfrow = c(3, 2))
# for (v in c("Standard error", "Average board gender diversity",
#             "Number of citations", "Published",
#             "Market: emerging", "Data: panel"))
#   density(baseline, reg = v)
# dev.off()
*/

***************************************************************************************
*----------------------------------------------------------------------------
* C4.  Frequentist Model Averaging — Mallows criterion (FMA) — R
*----------------------------------------------------------------------------
***************************************************************************************
/*
# Frequentist Model Averaging (Mallows / FLS) -- frequentist check for the BMA.
# Reads the weighted design matrix exported in Section C1; the full specification
# populates the frequentist column of Table tab:bma1.
if (!require('readxl'))    install.packages('readxl');    library(readxl)
if (!require('foreign'))   install.packages('foreign');   library(foreign)
if (!require('xtable'))    install.packages('xtable');    library(xtable)
if (!require('LowRankQP')) install.packages('LowRankQP'); library(LowRankQP)

##Estimation1 full
dataesg=read_excel("~/IES/PhD/Meta-Analysis/bgd-esg/Output/Heterogeneity/data_full_nest.xlsx")
dataesg <-na.omit(dataesg)


x.data <- dataesg[,-1]
const_<-c(1)
x.data <-cbind(const_,x.data)

x <- sapply(1:ncol(x.data),function(i){x.data[,i]/max(x.data[,i])})   
scale.vector <- as.matrix(sapply(1:ncol(x.data),function(i){max(x.data[,i])}))        
Y <- as.matrix(dataesg[,1])
output.colnames <- colnames(x.data)
full.fit <- lm(Y~x-1)

beta.full <- as.matrix(coef(full.fit))
M <- k <- ncol(x)
n <- nrow(x)
beta <- matrix(0,k,M)
e <- matrix(0,n,M)
K_vector <- matrix(c(1:M))
var.matrix <- matrix(0,k,M)
bias.sq <- matrix(0,k,M) 

for(i in 1:M)
{
  X <- as.matrix(x[,1:i])
  ortho <- eigen(t(X)%*%X)
  Q <- ortho$vectors ; lambda <- ortho$values 
  x.tilda <- X%*%Q%*%(diag(lambda^-0.5,i,i))
  beta.star <- t(x.tilda)%*%Y
  beta.hat <- Q%*%diag(lambda^-0.5,i,i)%*%beta.star
  beta[1:i,i] <- beta.hat
  e[,i] <- Y-x.tilda%*%as.matrix(beta.star)
  bias.sq[,i] <- (beta[,i]-beta.full)^2
  var.matrix.star <- diag(as.numeric(((t(e[,i])%*%e[,i])/(n-i))),i,i)
  var.matrix.hat <- var.matrix.star%*%(Q%*%diag(lambda^-1,i,i)%*%t(Q))
  var.matrix[1:i,i] <- diag(var.matrix.hat)
  var.matrix[,i] <- var.matrix[,i]+ bias.sq[,i]
} 

e_k <- e[,M]
sigma_hat <- as.numeric((t(e_k)%*%e_k)/(n-M))
G <- t(e)%*%e
a <- ((sigma_hat)^2)*K_vector
A <- matrix(1,1,M)
b <- matrix(1,1,1)
u <- matrix(1,M,1)
optim <- LowRankQP(Vmat=G,dvec=a,Amat=A,bvec=b,uvec=u,method="LU",verbose=FALSE)
weights <- as.matrix(optim$alpha)
beta.scaled <- beta%*%weights
final.beta <- beta.scaled/scale.vector
std.scaled <- sqrt(var.matrix)%*%weights
final.std <- std.scaled/scale.vector
results.reduced <- as.matrix(cbind(final.beta,final.std))
rownames(results.reduced) <- output.colnames; colnames(results.reduced) <- c("Coefficient", "Sd. Err")
MMA.fls <- round(results.reduced,4)
MMA.fls <- data.frame(MMA.fls)
t <- as.data.frame(MMA.fls$Coefficient/MMA.fls$Sd..Err)
MMA.fls$pv <-round( (1-apply(as.data.frame(apply(t,1,abs)), 1, pnorm))*2,3)
MMA.fls$names <- rownames(MMA.fls)
names <- c(colnames(dataesg))
names <- c(names,"const_")
MMA.fls <- MMA.fls[match(names, MMA.fls$names),]
MMA.fls$names <- NULL
MMA.fls

*/

*==============================================================================================
*==============================================================================================
*
*  D.  BEST-PRACTICE ESTIMATE (BPE)
*
*==============================================================================================
*==============================================================================================

*==============================================================================================
* D1.  Setup — PIP>0.5 variable selection and BMA posterior means
*==============================================================================================
* CONSERVATIVE BEST-PRACTICE ESTIMATE (BPE) -- current specification
*   PIP>0.5 set: se_estimate_w ln_sample_size data_panel published_study
*                ln_citations asia middle_east method_iv  (+ intercept)
*
* X vector : SE=0 (no publication bias), data_panel=1 (panel design), published_study=1
*            (a published, best-practice study); ln_sample_size, ln_citations and
*            method_iv at their SAMPLE MEANS (not unambiguously "best"). Reported for
*            three mutually-exclusive regions via the asia / middle_east dummies:
*              Rest of world (ref) : asia=0, middle_east=0
*              Middle East         : asia=0, middle_east=1
*              Asia                : asia=1, middle_east=0
* Weighting: D2 uses [aw=inv_nest] (each study equal weight), matching the BMA and the
*            FMA frequentist check -> the point (FMA) and SE are internally consistent.
* Estimate : reported as the consistent FMA (point and SE from the same check). The
*            BMA-posterior-mean combination is printed as a cross-check; it coincides
*            with the FMA, so a separate BMA-hybrid CI is no longer needed.
*
* WORKFLOW: run the BMA in R (Section C3 / r_het_bma.R) first; copy the intercept
* printed as "scalar b0_bma = ..." into STEP 2 before running this block.

clear
import excel "$data/esg_clean.xlsx", sheet("Data") firstrow

* Recreate the variables used below (mirrors the top of the file)
winsor estimate,    generate(estimate_w)    p(0.01)
winsor se_estimate, generate(se_estimate_w) p(0.01)
* Study weight: inv_nest gives each study equal total weight (1/#estimates),
* matching the sqrt(inv_nest) pre-scaling used by the BMA and the FMA frequentist check.
bysort id_study: egen nest = count(estimate_w)
gen inv_nest = 1/nest

*----------------------------------------------------------------------------
* D2.  Frequentist-check OLS -- supplies the FMA point and clustered VCV
*----------------------------------------------------------------------------
reg estimate_w se_estimate_w ln_sample_size data_panel published_study ln_citations asia middle_east method_iv [aw=inv_nest], vce(cluster id_study)
estimates store freq_check

*--- STEP 1: X VECTOR (conservative best practice; region set per block below) ---
quietly sum ln_sample_size
scalar x_size = r(mean)
quietly sum ln_citations
scalar x_cit = r(mean)
quietly sum method_iv
scalar x_iv = r(mean)
scalar x_se  = 0
scalar x_pan = 1
scalar x_pub = 1

*--- STEP 2: BMA POSTERIOR MEANS (current baseline, Table tab:bma1) ---
* REPLACE b0_bma with the intercept printed by R: "scalar b0_bma = X.XXXXXX"
* (updated 2026-07-09 from the post-correction baseline run, corr PMP 0.9996;
*  Method: linear crosses 0.5 in the baseline only -> excluded, spec unchanged)
scalar b0_bma = -0.020742
scalar b_se   =  2.134
scalar b_size =  0.027
scalar b_pan  = -0.134
scalar b_pub  =  0.160
scalar b_cit  = -0.033
scalar b_asia = -0.235
scalar b_me   =  0.151
scalar b_iv   =  0.244

*============================  Rest of world  (asia=0, middle_east=0)  =======
estimates restore freq_check
lincom _b[_cons] + _b[se_estimate_w]*x_se + _b[ln_sample_size]*x_size + _b[data_panel]*x_pan + _b[published_study]*x_pub + _b[ln_citations]*x_cit + _b[asia]*0 + _b[middle_east]*0 + _b[method_iv]*x_iv
scalar fma_ref = r(estimate)
scalar se_ref  = r(se)
scalar bma_ref = b0_bma + b_se*x_se + b_size*x_size + b_pan*x_pan + b_pub*x_pub + b_cit*x_cit + b_asia*0 + b_me*0 + b_iv*x_iv
scalar ref_lo  = fma_ref - 1.96*se_ref
scalar ref_hi  = fma_ref + 1.96*se_ref

*============================  Middle East  (asia=0, middle_east=1)  =========
estimates restore freq_check
lincom _b[_cons] + _b[se_estimate_w]*x_se + _b[ln_sample_size]*x_size + _b[data_panel]*x_pan + _b[published_study]*x_pub + _b[ln_citations]*x_cit + _b[asia]*0 + _b[middle_east]*1 + _b[method_iv]*x_iv
scalar fma_me = r(estimate)
scalar se_me  = r(se)
scalar bma_me = b0_bma + b_se*x_se + b_size*x_size + b_pan*x_pan + b_pub*x_pub + b_cit*x_cit + b_asia*0 + b_me*1 + b_iv*x_iv
scalar me_lo  = fma_me - 1.96*se_me
scalar me_hi  = fma_me + 1.96*se_me

*============================  Asia  (asia=1, middle_east=0)  ================
estimates restore freq_check
lincom _b[_cons] + _b[se_estimate_w]*x_se + _b[ln_sample_size]*x_size + _b[data_panel]*x_pan + _b[published_study]*x_pub + _b[ln_citations]*x_cit + _b[asia]*1 + _b[middle_east]*0 + _b[method_iv]*x_iv
scalar fma_asia = r(estimate)
scalar se_asia  = r(se)
scalar bma_asia = b0_bma + b_se*x_se + b_size*x_size + b_pan*x_pan + b_pub*x_pub + b_cit*x_cit + b_asia*1 + b_me*0 + b_iv*x_iv
scalar asia_lo  = fma_asia - 1.96*se_asia
scalar asia_hi  = fma_asia + 1.96*se_asia

*============================  SUMMARY  ======================================
di ""
di "=================================================================================="
di " CONSERVATIVE BEST-PRACTICE ESTIMATES (SE=0, panel=1, pub=1; sample/cit/IV at mean)"
di "=================================================================================="
di " Region                  Estimate   95% CI lower   95% CI upper"
di "----------------------------------------------------------------------------------"
di " Rest of world (ref)   " %8.3f fma_ref  "    " %8.3f ref_lo  "    " %8.3f ref_hi
di " Middle East           " %8.3f fma_me   "    " %8.3f me_lo   "    " %8.3f me_hi
di " Asia                  " %8.3f fma_asia "    " %8.3f asia_lo "    " %8.3f asia_hi
di "=================================================================================="
di " Estimates: consistent FMA (point + SE from the inv_nest-weighted frequentist check)."
di " BMA-means cross-check (points): ref=" %5.3f bma_ref " ME=" %5.3f bma_me " Asia=" %5.3f bma_asia
di "=================================================================================="
