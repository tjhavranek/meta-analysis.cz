# Use of artificial intelligence

Disclosure for *Do Female Directors Raise ESG Ratings? A Meta-Analysis*
(Hozová, Havránek & Iršová), following the reporting guidelines for meta-analysis in
economics updated for AI (Cook et al. 2026, *Journal of Economic Surveys*,
doi:10.1111/joes.70116) and the guiding principles that accompany them
(Cook et al. 2026, doi:10.1111/joes.70105).

Appendix D of the paper carries the same information in short form. This file adds the tool
versions and dates that the guidelines ask replication materials to record.

## Summary

**No search, screening, or coding decision was delegated to AI.** The literature search, the
inclusion and exclusion decisions, and the coding of all 533 estimates and their moderators
were carried out by the authors. The share of estimates coded by AI is zero, so the audit
share and the inter-rater statistics that the guidelines require for AI-assisted screening and
coding do not arise here. Every estimate, table, and figure in the paper comes from the
authors' own Stata and R code in this package; no figure or table was produced by AI. AI did
not influence any analytical choice — no specification, weighting scheme, prior, or bandwidth.

## Where AI was used

| Stage | Used | What it did |
|---|---|---|
| Research question, hypotheses | No | Formulated by the authors. |
| Literature search | No | Google Scholar and backward snowballing, run by the authors in May and December 2024 (Appendix A of the paper). |
| Screening, inclusion decisions | No | All decisions by the authors. |
| Coding of estimates and moderators | No | All 533 estimates coded by the first author. |
| Checking of the coded data | **Yes** | A random sample of coded estimates was re-checked against the primary studies with AI assistance. Every discrepancy was resolved by the authors against the primary study; the resulting corrections are logged cell by cell in `Data/CHANGELOG.md`. |
| Checking of reported numbers | **Yes** | Numbers printed in the paper were cross-checked against this dataset and against the code output. |
| Estimation, tables, figures | No | Authors' Stata and R code (`Code/`). |
| Replication package, online appendix | **Yes** | Assembled and documented with AI assistance, then checked by the authors. |
| Language editing | **Yes** | Editing of text written by the authors. |

## Tools, versions, dates

| Tool | Version | Interface | Period of use |
|---|---|---|---|
| Claude | Opus 4.8 | Claude Code | June–July 2026 |
| Claude | Fable 5 | Claude Code | July 2026 |
| Claude | Sonnet 5 | Claude Code | July 2026 |
| GPT | 5.6 Sol | Codex CLI | July 2026 |

Earlier data-checking work by the first author used Claude through the Claude web interface
(June 2026).

## Prompts and settings

The AI assistance took the form of interactive sessions rather than a fixed prompt template,
so there is no single reusable prompt to publish. The instructions given were of three kinds:
(i) re-check these coded estimates against the primary study and report any disagreement;
(ii) verify that a number printed in the paper matches the dataset or the code output; and
(iii) edit this author-written passage for language without changing its content. Because AI
was not used for screening, coding, or analysis, no prompt materially influenced the evidence
base or the estimates.

## Accountability

The authors are responsible for the whole of the paper, including everything checked or
edited with AI assistance. AI is not an author.
