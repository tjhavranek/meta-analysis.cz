# Codebook — `esg_clean.xlsx` (sheet `Data`)

Dataset of **533 estimates** hand-collected from **106 primary studies** of the effect of
board gender diversity (BGD) on corporate ESG ratings. One row = one estimate.
`esg_clean.xlsx` (sheet `Data`, 65 columns) is the file read by the Stata master script
`esg_code_v5.do` (`import excel ... sheet("Data") firstrow`).

The moderators used in the meta-regression are described in Table 4 of the paper; this
codebook documents every column in the file, including raw and log-transformed versions,
identifiers, and provenance flags. All cell-level revisions made during data validation
are documented in `CHANGELOG.md` (same folder); a condensed history is at the end of this
file.

## Variables

Columns are listed in file order.

| # | Variable | Type | Description |
|---|----------|------|-------------|
| **Identifiers** | | | |
| 1 | `id_study` | int | Study identifier (1–106, contiguous). |
| 2 | `study` | text | Study citation (author–year). |
| 3 | `id_estimate` | int | Within-study estimate counter (1 up to 28). |
| **Effect size** | | | |
| 4 | `estimate` | num | Reported effect of a one-percentage-point increase in BGD on the ESG score (0–100 scale), linearized/re-scaled to the common metric (paper, Section 2). |
| 5 | `se_estimate` | num | Standard error of `estimate`. |
| 6 | `t_stat` | num | t-statistic (= `estimate`/`se_estimate`; verified consistent for all 533 rows). |
| **Provenance flags** | | | (see notes below the table) |
| 7 | `se_imputed` | 0/1 | Standard error not read directly from the primary table: derived from reported t/z/p-values or confidence intervals, imputed at a significance threshold, or produced by the standardized-to-raw conversion (n = 40). |
| 8 | `interaction_term` | 0/1 | Estimate obtained by linearizing an interaction or quadratic specification via the delta method (n = 77). |
| 9 | `direct_est` | 0/1 | Estimate and standard error taken directly from the primary study, without transformation or imputation (n = 426). Equals 1 exactly when columns 7 and 8 are both 0. |
| **Sample size** | | | |
| 10 | `sample_size` | int | Number of observations behind the estimate. |
| 11 | `ln_sample_size` | num | Natural log of `sample_size`. |
| 12 | `data_firms` | int | Number of firms in the sample. |
| 13 | `ln_data firms` | num | Natural log of `data_firms`. *(Note the space in the header — preserved as in the source file; the Stata script strips it on import.)* |
| **Board gender diversity level** | | | |
| 14 | `bgd_mean` | num | Average board gender diversity in the study sample (% women on boards, 0–100). |
| 15 | `ln_bgd_mean` | num | Natural log of `bgd_mean`. |
| **Estimation technique** | | | (dummies; `method_other` is the reference category) |
| 16 | `method_linear` | 0/1 | OLS or GLS. |
| 17 | `method_panel` | 0/1 | Fixed- or random-effects panel estimator. |
| 18 | `method_iv` | 0/1 | Instrumental variables (2SLS, control function, LIML). |
| 19 | `method_gmm` | 0/1 | GMM or an extension. |
| 20 | `method_tobit` | 0/1 | Tobit estimator. Sub-flag: these rows also have `method_other = 1`. |
| 21 | `method_quantile` | 0/1 | Quantile regression. Sub-flag: these rows also have `method_other = 1`. |
| 22 | `method_other` | 0/1 | Other estimator (reference; includes tobit and quantile rows). |
| **Data type** | | | |
| 23 | `data_panel` | 0/1 | Panel data (n = 512). |
| 24 | `data_cross-section` | 0/1 | Cross-sectional data (n = 21). *(Hyphen in header preserved; stripped on import.)* |
| **Endogeneity treatment** | | | (complementary pair) |
| 25 | `proper_endog_control` | 0/1 | Study controls for at least two types of endogeneity (n = 98). Reference category in Table 5. |
| 26 | `poor_endog_control` | 0/1 | Study controls for at most one type of endogeneity (n = 435). Shown as *Endogeneity control: poor* in Table 5. |
| **Control variables in the primary study** | | | |
| 27 | `control_firm_lev` | 0/1 | Controls for firm leverage. |
| 28 | `control_firm_size` | 0/1 | Controls for firm size. |
| 29 | `control_board_ind` | 0/1 | Controls for board independence. |
| 30 | `control_board_size` | 0/1 | Controls for board size. |
| 31 | `control_csr_com` | 0/1 | Controls for the existence of a CSR committee. |
| **ESG data provider** | | | (exactly one = 1) |
| 32 | `bloomberg` | 0/1 | ESG rated by Bloomberg (n = 204). |
| 33 | `eikon` | 0/1 | ESG rated by LSEG/Refinitiv (Eikon) (n = 329). |
| **Region** | | | (dummies; `other` is the reference region) |
| 34 | `global` | 0/1 | Global/multi-region sample. |
| 35 | `europe` | 0/1 | European firms. |
| 36 | `us` | 0/1 | US firms. |
| 37 | `asia` | 0/1 | Asian firms. |
| 38 | `middle_east` | 0/1 | Middle Eastern firms. |
| 39 | `other` | 0/1 | Other region (reference). |
| **Economic development** | | | (both 0 = mixed, the reference) |
| 40 | `developed` | 0/1 | Developed markets. |
| 41 | `emerging` | 0/1 | Emerging markets. |
| **Sector** | | | |
| 42 | `financial` | 0/1 | Financial-sector firms. |
| 43 | `non-financial` | 0/1 | Non-financial firms. *(Hyphen preserved; stripped on import.)* |
| 44 | `cross_sector` | 0/1 | Mixed sectors (reference). |
| 45 | `sector` | text | Sector label as reported by the primary study. |
| 46 | `sector_cat` | text | Harmonized sector category (e.g. "Financial Services", "Cross-sector"). |
| 47 | `country` | text | Country/region label (used for Figure A.2). |
| 48 | `country_cat` | text | Harmonized country/region category. |
| **Publication characteristics** | | | |
| 49 | `published_study` | 0/1 | Published in a peer-reviewed journal (n = 506). |
| 50 | `unpublished_study` | 0/1 | Working paper, thesis, or other unpublished form (n = 27). |
| 51 | `pub_year` | int | Year of publication. |
| 52 | `ln_publication_year` | num | Natural log of `pub_year`. |
| 53 | `citations` | int | Google Scholar citation count. |
| 54 | `ln_citations` | num | Natural log of `citations`. |
| 55 | `impact_factor` | num | Journal impact factor (0 for unpublished). Retained in the file but **not used** in the reported meta-regressions (dropped for collinearity with `published_study`/`citations`). |
| 56 | `ln_impact_factor` | num | Natural log of `impact_factor`. Not used (see above). |
| **Data period** | | | |
| 57 | `data_start` | int | First year of the sample. |
| 58 | `data_end` | int | Last year of the sample. |
| 59 | `data_mid_year` | num | Midpoint year of the sample. |
| 60 | `ln_avg_year` | num | Natural log of `data_mid_year`. Shown as *Average data year* in Table 5. |
| 61 | `data_length` | int | Number of years spanned. |
| 62 | `ln_data_length` | num | Natural log of `data_length`. |
| **Model size** | | | |
| 63 | `data_variables` | int | Number of explanatory variables in the primary regression. |
| 64 | `ln_data_variables` | num | Natural log of `data_variables`. |
| **Reference** | | | |
| 65 | `Reference` | text | Full bibliographic reference of the primary study. |

### Notes on the provenance flags (columns 7–9)

`direct_est = 1` defines the *direct estimates* robustness subsample used throughout the
paper (Block 2 of the publication-bias tables, the direct funnel, MAIVE B2.5.2, and the
STEM/p-uniform* direct runs). `se_imputed` and `interaction_term` may overlap: ten
estimates in Martínez et al. (2022) are interaction-derived **and** rest on imputed
p-values, so both flags equal 1. `direct_est` equals 1 exactly when both are 0.

## Data-construction decisions

These rules were applied during coding and validation:

1. **Subsample means.** When a primary study reports a subsample estimate but not that
   subsample's mean BGD, the whole-sample mean BGD is used.
2. **Linearization.** Quadratic and interaction specifications are converted to a single
   average marginal effect via the delta method (paper, Section 2); the corresponding
   standard error is derived with the delta method. Such rows carry
   `interaction_term = 1`.
3. **Standardized coefficients.** Standardized (beta) coefficients are converted to raw
   slopes as `raw = β · SD_ESG / SD_BGD`, with both standard deviations expressed on
   comparable scales (exact formula and per-study numbers in `CHANGELOG.md`); the
   standard error is scaled by the same factor, preserving the t-statistic. Applied to
   Dakhli (2021), Dang et al. (2023a) (Dang, Hikkerova, Simioni & Sahut; labeled `Dang et al. (2023b)` in the dataset's `study` column), Kamran et al. (2023), and Khemakhem et al. (2023,
   SEM path estimate). Such rows carry `se_imputed = 1`.
4. **Instrument.** Where a lagged instrument is referenced, BGD(t−1) is used (following
   Wu et al.).
5. **Sample size.** When a subsample's sample size is unavailable, the whole-sample size
   is used; when no sample size is reported at all, it is approximated as
   `data_length × data_firms` (balanced-panel assumption).
6. **Imputation of uncertainty statistics** (all such rows carry `se_imputed = 1`):
   - standard errors printed as 0.000 are replaced with 0.0004, a rounding bound
     (Bruna 2021; Gerged et al. 2023);
   - p-values printed as 0.000, and significance reported only at the 1% level, are
     replaced with p = 0.0001 and the standard error derived as |estimate|/3.8906
     (Bhatia & Marwaha 2022; Martínez et al. 2022; Nadeem et al. 2017; Setiani 2024;
     Miranda et al. 2023);
   - estimates reported only as *significant at the 5% level* are assigned t = 1.96, the
     two-tailed 5% critical value — the largest standard error consistent with the
     reported significance (Fahad & Rahman 2020; Kamaludin et al. 2022).
7. **Winsorization.** Estimates and standard errors are winsorized at the 1st/99th
   percentiles in the baseline (`estimate_w`, `se_estimate_w`, created by the Stata
   script); every publication-bias test is replayed on the raw, unwinsorized data as a
   sensitivity check.

## Studies excluded after retrieval (and why)

- **Cambrea et al. (2023)** — estimates executive vs. independent (non-executive) female
  directors separately, which is not comparable to the board-share measure used here.
- **Dang et al. (2023b)** (Dang, Houanti, Simioni & Sahut) — 13 estimates removed during validation: the coefficients are
  standardized betas, and the descriptive-statistics table needed for the conversion is
  corrupted in the published paper (the standard-deviation column duplicates the median),
  so the standardized-to-raw conversion could not be performed.
- **Nuhu and Alam (2024)** — standardized beta; the standard deviations required for
  conversion appear only in image-based tables and could not be recovered (the author did
  not respond). Dropped for consistency with Dang et al. (2023b).
- **Trireksani et al. (2024)** — several interaction-term estimates could not be
  linearized from the reported statistics; the two usable estimates are included.

*Note: Giannarakis (2013), listed as excluded in earlier working notes, is **included** —
its single estimate is retained after a decimal-shift correction (see `CHANGELOG.md`).*

## Revision history (condensed; full cell-level detail in `CHANGELOG.md`)

The dataset was audited against the primary-study PDFs in June 2026. Net effect:
**547 → 533 estimates, 108 → 106 studies.**

- **Removals:** Dang et al. (2023b), 13 estimates; Nuhu and Alam (2024), 1 estimate (reasons
  above).
- **Scale corrections** (×100/÷100 after re-verification against the primary tables):
  de Klerk & Singh (2023); Al-Shaer et al. (2024); Bruna et al. (2021, quantile block);
  Giannarakis (2013, decimal shift).
- **Statistic-type corrections:** standard errors and t-statistics swapped in the source
  (Marrone et al. 2023; Waterstraat et al. 2022); p-values mis-recorded as standard
  errors, re-derived from the reported p (Arayssi et al. 2018; Nicolò et al. 2024);
  zero-printed standard errors re-imputed (Gerged et al. 2023).
- **Standardized-to-raw conversions** applied per rule 3 above; Kamran et al. (2023)
  rebuilt to 8 estimates from Tables 3, 4, and 15; Aliani et al. (2024) `bgd_mean` typo
  corrected (48.694 → 28.48).
- **Imputation-convention change (July 2026):** the 5%-significance imputation moved from
  the midpoint t = 2.27 to the conservative boundary t = 1.96 (Fahad & Rahman 2020;
  Kamaludin et al. 2022; two estimates).
- **Structural changes:** the earlier three-level endogeneity judgment scheme was replaced
  by the binary `proper_endog_control`/`poor_endog_control` pair; the `quotas`/`noquota`
  columns (row alignment corrupted by a partial sort in the source file) were removed;
  the `preferred_est` column was dropped.
