# esg_clean.xlsx — Change Log

_Generated 2026-06-28._

**Baselines.** Original file = `esg.xlsx`. Current = `Data/esg_clean.xlsx`.

Convention: BGD & ESG both on 0–100; standardized→raw `raw = β·SD_ESG(0–100)/SD_BGD(0–1)/100` (est & SE scaled, t-stat preserved).

**Net: 547 → 533 estimates**; 108 → 106 studies; 69 → 65 columns (66 → 65 in the July 2026 addendum below).


## 1. Estimates removed

**Total removed: 14 estimates — Dang et al. (2023a) (13) and Nuhu et al. (2023) (1)**

> Labels in this log are the dataset's `study` values. The paper's bibliography renders the
> two Dang (2023) studies with the opposite letters, so the study removed here appears as
> Dang et al. (2023b) in the paper. See the July 2026 addendum at the end of this file.

_Dang et al. (2023a) excluded: Table 3 Std-dev column was corrupted (duplicated the median), so its standardized betas could not be converted._

| study | id_estimate | estimate (orig) | se (orig) |
|---|---|---|---|
| Dang et al. (2023a) | 1 | 0.00521 | 0.00017 |
| Dang et al. (2023a) | 2 | 0.00186 | 0.00017 |
| Dang et al. (2023a) | 3 | 0.00647 | 0.00964 |
| Dang et al. (2023a) | 4 | 0.00495 | 0.00017 |
| Dang et al. (2023a) | 5 | 0.01728 | 0.00114 |
| Dang et al. (2023a) | 6 | 0.00082 | 1e-05 |
| Dang et al. (2023a) | 7 | 0.00109 | 0.00014 |
| Dang et al. (2023a) | 8 | 0.00107 | 0.00015 |
| Dang et al. (2023a) | 9 | 0.00081 | 9e-05 |
| Dang et al. (2023a) | 10 | 0.00205 | 0.00061 |
| Dang et al. (2023a) | 11 | 0.00107 | 0.00018 |
| Dang et al. (2023a) | 12 | 0.0007 | 0.0002 |
| Dang et al. (2023a) | 13 | 0.00087 | 0.00023 |

_Nuhu et al. (2023) excluded: coefficient is a standardized β (paper interprets it as "1 SD BGD → 7.3% ESG"), but the descriptive SDs needed for the standardized→raw conversion are only in image-based tables and could not be obtained (author did not reply). Dropped for consistency with Dang 2023a._

| study | id_estimate | estimate (orig) | se (orig) |
|---|---|---|---|
| Nuhu et al. (2023) | 1 | 0.073 | 0.018703 |


## 2. Validation edits 

### Giannarakis (2013)
_est1 10x too large (decimal shift) _

| id_estimate | change |
|---|---|
| 1 | estimate 0.00956→0.000956 |

### Makeeva et al. (2022)
_id_est incorrectly marked_

| id_estimate | change |
|---|---|
| 2 | id_est 1→2 |

### Marrone et al. (2023)
_SE and t-stat swapped_

| id_estimate | change |
|---|---|
| 1 | se_estimate 1.887→0.291, t_stat 0.291→1.887 |

### Waterstraat et al. (2022)
_SE and t-stat swapped_

| id_estimate | change |
|---|---|
| 1 | se_estimate 1.0→0.163, t_stat 0.163→1.0 |

### Arayssi et al. (2018)
_p-value and SE swapped -> new SE (and t_stat) recomputed from p-values_

| id_estimate | change |
|---|---|
| 1 | se_estimate 0.087→0.016; t_stat →1.75 |
| 2 | se_estimate 0.091→0.015; t_stat →1.667 |
| 3 | se_estimate 0.056→1.519; t_stat →1.909 |

### Arayssi et al. (2024)
_p-value and SE swapped -> new SE (and t_stat) recomputed from p-values_

| id_estimate | change |
|---|---|
| 1 | se_estimate 0.576→0.272; t_stat →0.559 |
| 2 | se_estimate 0.520→0.262; t_stat →0.6491 |
| 3 | se_estimate 0.580→0.267; t_stat →0.551 |
| 4 | se_estimate 0.532→0.270; t_stat →0.630 |
| 5 | se_estimate 0.603→0.269; t_stat →0.520 |
| 6 | se_estimate 0.525→0.266; t_stat →0.639 |
| 7 | se_estimate 0.591→0.267; t_stat →0.539 |
| 8 | se_estimate 0.146→0.996; t_stat →1.450 |
| 9 | se_estimate 0.001→0.360; t_stat →3.292 |
| 10 | se_estimate 0.472→0.142; t_stat →0.718 |
| 11 | se_estimate 0.576→0.145; t_stat →0.559 |

### de Klerk & Singh (2023)
_estimates 100x too small (decimal shift) _

| id_estimate | change |
|---|---|
| 1 | estimate 0.00173→0.173; se_estimate 0.000611307→0.0611307 |
| 2 | estimate 0.00151→0.151; se_estimate 0.000634454→0.0634454 |
| 3 | estimate 0.00149→0.149; se_estimate 0.00062605→0.062605 |
| 4 | estimate 0.00147→0.147; se_estimate 0.000335616→0.0335616 |
| 5 | estimate 0.00186→0.186; se_estimate 0.0004→0.04 |

### Paolone et al. (2024a)
_Typo in SE_

| id_estimate | change |
|---|---|
| 1 | se_estimate 0.0539→0.0576; t_stat 1→0.935764 |

### Gerged et al. (2023)
_SEs printed as 0.000 → imputed 0.0004 (se_imputed=1)._

| id_estimate | change |
|---|---|
| 11 | se_estimate 0.00015→0.0004; t_stat 1113.33→417.5 |
| 13 | se_estimate 7.4e-05→0.0004; t_stat 1810.81→335 |

### Martinez et al. (2022)
_Imputed SEs re-derived from p-value =0.0001; affects all 12 estimates._

| id_estimate | change |
|---|---|
| 1 | se_estimate 0.0310884→0.04644; t_stat 5.81186→3.8906 |
| 2 | se_estimate 0.119→0.123901; t_stat 1.47597→1.41759 |
| 3 | se_estimate 0.122106→0.126886; t_stat 1.49294→1.43669 |
| 4 | se_estimate 0.0905446→0.096895; t_stat 1.92202→1.79606 |
| 5 | se_estimate 0.0425136→0.0554; t_stat 5.06989→3.8906 |
| 6 | se_estimate 0.189867→0.193161; t_stat 2.03666→2.00193 |
| 7 | se_estimate 0.155054→0.159071; t_stat 2.45373→2.39177 |
| 8 | se_estimate 0.228154→0.230903; t_stat 1.96917→1.94573 |
| 9 | se_estimate 0.195238→0.198263; t_stat 0.901164→0.887416 |
| 10 | se_estimate 0.191846→0.194923; t_stat 0.880369→0.86647 |
| 11 | se_estimate 0.678249→0.679178; t_stat 0.541489→0.540748 |
| 12 | se_estimate 0.79024→0.791038; t_stat 0.563572→0.563003 |

### Bruna et al. (2021)
_IV-QRPD quantile models (id4–8): per the table note the brackets are p-values, so SE = |coef|/z(p): Q10 p=0.008→SE 0.0117, Q50 p=0.001→SE 0.0021, Q75 p=0.005→SE 0.0018, Q90 p=0.143→SE 0.199; id5/Q25 printed as [0.000] → SE imputed 0.0004)_

| id_estimate | change |
|---|---|
| 4 | estimate -0.00031→-0.031; se_estimate 8e-05→0.011689; t_stat -3.875→-2.6521 |
| 5 | estimate -1e-05→-0.001; se_estimate 1e-06→0.0004; t_stat -10→-2.5 |
| 6 | estimate -7e-05→-0.007; se_estimate 1e-05→0.002127; t_stat -7→-3.2905 |
| 7 | estimate 5e-05→0.005; se_estimate 5e-05→0.001781; t_stat 1→2.807 |
| 8 | estimate 0.00291→0.291; se_estimate 0.00143→0.198674; t_stat 2.03497→1.4647 |

### Nicolo et al. (2024)
_p-values mis-recorded as SE → SE re-derived from p._

| id_estimate | change |
|---|---|
| 1 | se_estimate 0.069→0.034645; t_stat 0.913043→1.81842 |
| 2 | se_estimate 0.003→0.037065; t_stat 36.6667→2.96774 |

### Adiasih & Lianawati (2018)
_id2 t_stat corrected to estimate/se (−3.395→−3.327): the SE (9.92745 ÷100 = 0.099275) is the reported Random-effects-model SE, so the stored t was an internal-inconsistency error._

| id_estimate | change |
|---|---|
| 2 | t_stat -3.3954→-3.3271 |

### Ali & Firmansyah (2023)
_Paper reports only coefficient + p-value (0.000 ***), no SE/t printed (HPCSE). id2’s derived SE/t were internally inconsistent → re-derived consistently with id1: SE = |coef|/z(p=0.0001) = 0.2683/3.8906 = 0.068961, t = 3.8906 (option c)._

| id_estimate | change |
|---|---|
| 1 | se_estimate 0.078→0.07844; t_stat 3.897→3.891 |
| 2 | se_estimate 0.062→0.068961; t_stat 4.274→3.8906 |

### Al-Shaer et al. (2024)
_Raw coefficient on 0–1 ESG; ÷100 wrongly applied → corrected ×100._

| id_estimate | change |
|---|---|
| 1 | estimate 0.007953→0.7953; se_estimate 0.00171401→0.171401 |
| 2 | estimate 0.004475→0.4475; se_estimate 0.00142063→0.142063 |
| 3 | estimate 0.005281→0.5281; se_estimate 0.00114804→0.114804 |
| 4 | estimate 0.005564→0.5564; se_estimate 0.00358968→0.358968 |
| 5 | estimate 0.007953→0.7953; se_estimate 0.00171401→0.171401 |
| 6 | estimate 0.004475→0.4475; se_estimate 0.00142063→0.142063 |
| 7 | estimate 0.004799→0.4799; se_estimate 0.00192731→0.192731 |
| 8 | estimate 0.006423→0.6423; se_estimate 0.00124718→0.124718 |
| 9 | estimate 0.004858→0.4858; se_estimate 0.0014811→0.14811 |
| 10 | estimate 0.00568→0.568; se_estimate 0.00142714→0.142714 |

### Dakhli (2021)
_Standardized β → raw via SD ratio R=1.331; recoded direct_est=0/se_imputed=1._

| id_estimate | change |
|---|---|
| 1 | estimate 0.00159→0.211604; se_estimate 0.000787129→0.104755 |
| 2 | estimate 0.00118→0.15704; se_estimate 0.000210339→0.027993 |

### Dang et al. (2023b)
_Standardized β → raw via SD ratio R=1.621; recoded direct_est=0/se_imputed=1._

| id_estimate | change |
|---|---|
| 1 | estimate 0.00794→1.28674; se_estimate 0.00198→0.320874 |

### Kamran et al. (2023)
_Rebuilt to 8 estimates. Paper standardizes all variables → raw via SD ratio R=SD_ESG/SD_BGD=12.974/12.6=1.030 (estimate & SE scaled, t-stat preserved); all se_imputed=1. The 8 = BGD M2/M3/M4 from Table 3 (HMR) and Table 4 (bootstrap), plus the 2 BGD→CSR 2SLS estimates from Table 15 (M1, M4; method_iv=1). M4's 0.076 is the effect at MAS=mean (MAS is standardized, so the reported coef already is the mean effect). The previous MAS=0 extrapolations (orig id3, id6 = −2.3558) and the −29.73595 outlier (orig id8) were dropped and replaced. Instead, 2 more estimates are added from table 15_

| id_estimate | source | estimate | se_estimate | t_stat |
|---|---|---|---|---|
| 1 | Table 3 (HMR) M2 | 0.12→0.123562 | 0.012→0.012356 | 10.00 (unch.) |
| 2 | Table 3 (HMR) M3 | 0.089→0.091642 | 0.012→0.012356 | 7.42 (unch.) |
| 3 | Table 3 (HMR) M4 | −2.3558→0.078256 | 0.743164→0.013386 | −3.170→5.846 |
| 4 | Table 4 (boot) M2 | 0.12→0.123562 | 0.013010→0.013397 | 9.22 (unch.) |
| 5 | Table 4 (boot) M3 | 0.089→0.091642 | 0.013265→0.013659 | 6.71 (unch.) |
| 6 | Table 4 (boot) M4 | −2.3558→0.078256 | 0.844479→0.013659 | −2.790→5.729 |
| 7 | Table 15 (2SLS) M1 | 3.117→3.209520 | 1.085→1.117206 | 2.87 (unch.) |
| 8 | Table 15 (2SLS) M4 | −29.73595→0.613691 | 4.86431→0.085464 | −6.113→7.181 |

### Khemakhem et al. (2023)
_id2 standardized SEM path → raw via SD ratio R=2.577. id1 (2.730) raw 2SLS, unchanged._

| id_estimate | change |
|---|---|
| 2 | estimate 0.131→0.337532; se_estimate 0.05413→0.13947 |

### Aliani et al. (2024)
_bgd_mean data-entry typo 48.694 → 28.48 (ln updated)._

| id_estimate | change |
|---|---|
| 1 | bgd_mean 48.694→28.48 |
| 2 | bgd_mean 48.694→28.48 |
| 3 | bgd_mean 48.694→28.48 |
| 4 | bgd_mean 48.694→28.48 |
| 5 | bgd_mean 48.694→28.48 |
| 6 | bgd_mean 48.694→28.48 |
| 7 | bgd_mean 48.694→28.48 |
| 8 | bgd_mean 48.694→28.48 |
| 9 | bgd_mean 48.694→28.48 |
| 10 | bgd_mean 48.694→28.48 |
| 11 | bgd_mean 48.694→28.48 |
| 12 | bgd_mean 48.694→28.48 |
| 13 | bgd_mean 48.694→28.48 |


## 3. Structural & metadata changes
- **Endogeneity columns:** 5 → 2 (`no/end/low/moderate/high_endog_control` → `proper_endog_control` is basically when study controls for all 3 types of endogeneity, `poor_endog_control`when study controls for at least one; 98 proper / 435 poor). Header comment + description added.
- **direct_est / se_imputed:** SD-converted rows (Dakhli ×2, Dang 2023b ×1, Kamran ×8, Khemakhem ×2) recoded `direct_est=1→0`, `se_imputed=1`.
- **country_cat:** recoded to drop uninformative categories.
- **id_study:** renumbered to contiguous 1–106 (closing the gaps left by dropping Dang 2023a, study #35, and Nuhu).
- Initial clean-copy work: columns reordered, green ESG styling, frozen panes; original `Notes`/`Questions` sheets dropped.

## 4. Addendum (July 2026, after the log above)

- **Columns 66 → 65**: the `preferred_est` column was dropped (see `CODEBOOK.md`).
- **5%-significance imputation moved from the midpoint t = 2.27 to the conservative boundary
  t = 1.96** (se = |estimate| / 1.96), affecting two estimates:
  Fahad & Rahman (2020): se 0.069163 → 0.080102; Kamaludin et al. (2022): se 0.170264 → 0.197194.
- **Dang labels**: the paper's rendered bibliography and this data file use opposite a/b letters.
  The retained semiparametric study (Dang, Hikkerova, Simioni & Sahut) is `Dang et al. (2023b)` in
  the dataset's `study` column but renders as Dang et al. (2023a) in the paper; the removed
  control-function study (Dang, Houanti, Simioni & Sahut) renders as Dang et al. (2023b).
  Nuhu is cited in the paper as Nuhu and Alam (2024).
- **Endogeneity dummies**: the definitions in the log above are the June wording;
  `CODEBOOK.md` carries the operative definitions.
