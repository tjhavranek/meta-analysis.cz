Replication package -- Do Female Directors Enhance ESG Performance? A Meta-Analysis
Karolina Hozova, Tomas Havranek, Zuzana Irsova (Charles University, Prague).
Online appendix: meta-analysis.cz/esg

Reproduces the analysis in the paper: 533 estimates from 106 primary studies of the effect of
board gender diversity on firms' ESG ratings (Bloomberg / LSEG).

Contents
--------
  Data/esg_clean.xlsx   hand-collected dataset (533 estimates; sheet 'Data')
  Data/CHANGELOG.md     dataset construction / cleaning log
  Code/esg_code_v5.do   Stata master script (data prep, summary statistics, funnel/FAT-PET and
                        non-linear publication-bias tests, model-averaging setup)
  Code/R-code/*.R       the R steps the Stata script hands off to: selection model, STEM,
                        p-uniform*, MAIVE, Bayesian model averaging, heterogeneity F-checks

To run: install the required Stata/R packages, set the data path at the top of esg_code_v5.do,
run it, and let it call the R-code/ scripts for the non-linear and model-averaging steps; figures
and tables are written out by the code.

This is the current working replication set matching the submitted manuscript. A few code-side
housekeeping items (intermediate-file naming, some macOS-only graphics calls) may need adjustment
on a fresh machine; they do not affect any number in the paper.
