# Manifest

Annotated list of files in this replication package. Tables are reproduced as `.tex`
fragments exported by `esttab`; figures as Stata `.gph` and rendered `.png`. Replication
instructions (run order, the one path to change) are in the header of the master script
`Code/esg_code_v5.do`.

## Data/
| File | Description |
|------|-------------|
| `esg_clean.xlsx` | Main dataset, sheet `Data` (533 estimates × 65 columns). The file read by the Stata master script. |
| `esg_clean.csv` | Same data as comma-delimited UTF-8 text (identical values), for non-Stata users. |
| `CODEBOOK.md` | Variable definitions, provenance flags, data-construction rules, exclusions, and condensed revision history. |
| `CHANGELOG.md` | Full cell-level audit trail of every revision made during data validation (before → after per estimate). |

## Code/
| File | Description |
|------|-------------|
| `esg_code_v5.do` | **Master script.** Sections A (data overview), B (publication bias), C (heterogeneity: BMA/FMA), D (best-practice estimates). Seeded throughout (`set seed 20241215`, re-seeded at each bootstrap block) so all wild-bootstrap intervals are reproducible. The R steps are embedded as commented `/* ... */` blocks at the point in the pipeline where they run. |
| `R-code/1.pubbias-maive.R` | MAIVE estimator (Irsová et al. 2025) — Table 3 / Table B.1 MAIVE columns. |
| `R-code/2.pubbias-selection.R` | Andrews–Kasy selection model — Panel B "Selection Model" columns. |
| `R-code/3.pubbias-stem.R` | Furukawa STEM method (engine included in the script) — Panel B "STEM" columns. |
| `R-code/4.pubbias-puniform.R` | p-uniform* (van Aert & van Assen; CRAN package `puniform`) — Panel B "p-uniform*" columns. |
| `R-code/5.het_bma.R` | Bayesian model averaging: baseline (UIP + dilution, 1M draws), convergence checks, BRIC+random prior robustness, excl-Middle-East subsample → Tables 5, C.1, C.2 and the BMA figures. |
| `R-code/6.het_fcheck.R` | Frequentist (Mallows) model averaging, full moderator set → frequentist columns of Table 5. |

The six numbered R scripts are verbatim extracts of the do-file's embedded R blocks
(the do-file is canonical; run them in numeric order at the points marked in the
do-file). Each script `setwd()`s into its own output folder and reads inputs by bare
filename.

## Output/Data overview/
Rendered summary figures in `.gph`/`.png`: combined estimates histogram
(`histogram_combined`), country and study box plots (`hbox_countries`, `hbox_studies`),
provider/CSR histograms (`hist_provider`, `hist_csr`, `hist_provider_csr`), and the
trend plots against mean BGD and sample mid-year (`trend_bgd_mean`, `trend_mid_year`).

## Output/Publication bias/
| Path | Description |
|------|-------------|
| `1. FAT-PET/funnel*.gph/.png` | Funnel plots: full sample, direct estimates, combined panel. |
| `1. FAT-PET/table_bias_*.tex` | Exported FAT-PET table fragments: full, direct estimates, excl. Middle East, unwinsorised, and the provider-invariance interaction test. |
| `2. Selection Model/data_*.csv` | Inputs (effect, SE) for the selection model: full, direct, excl-ME, unwinsorised. |
| `2. Selection Model/metastudiesfunctions.r`, `metastudiesplots.r` | Bundled source of the `MetaStudies` package (not on CRAN; alternatively `remotes::install_github("skranz/MetaStudies")`). |
| `3. STEM Method/esg_r_study*.xlsx` | Study-level median inputs (full and direct) for the STEM method. |
| `4. p-uniform/puniform_*.dta` | Study-level median inputs for p-uniform* (full, direct, excl-ME; the unwinsorised run reads the raw-median columns of the full file). |
| `6. MAIVE/maivefunction.r` | MAIVE engine (ships with the Irsová et al. replication code; must sit in this folder). |
| `6. MAIVE/maive_*.xlsx` | MAIVE inputs (effect, SE, N, study id): full, direct, excl-ME, unwinsorised. |
| `7. Caliper/` | Caliper-section figures from the producing run (`caliper_direct.gph`, `histogram_tstat.gph/.png`); the caliper test statistics themselves (B8) print to the Stata log only. |

*(There is no folder “5.”: the Endogenous Kink estimator (B6) runs entirely in Stata and
exports no files.)*

## Output/Heterogeneity/
| File | Description |
|------|-------------|
| `data_all.xlsx`, `data_full.xlsx` | Intermediate exports from the do-file (unweighted design matrices). |
| `data_full_nest.xlsx` | Study-weighted (√inv_nest-scaled) design matrix — input to the BMA and the FMA check. |
| `data_full_nest_robustness.xlsx` | Excl-Middle-East variant of the weighted design matrix (the BMA script derives the subsample internally; this export omits the `middle_east` column — see the comment in `5.het_bma.R` for how to load it). |
| `bma_baseline_coef.csv`, `bma_excl_me_coef.csv`, `bma_prior_random_bric_coef.csv` | Posterior means / SDs / PIPs for the three BMA specifications (populate Tables 5 and C.2). Written by `5.het_bma.R` when it is run; not shipped (the rendered figures are). |
| `bma_convergence_pip_table.csv`, `bma_convergence_summary.csv` | Convergence diagnostics: per-variable PIP agreement across chains and the summary comparison (1M vs 300k, seed 1 vs seed 2). Written by `5.het_bma.R` when it is run; not shipped. |
| `bma_baseline.png`, `bma_excl_me.png`, `bma_prior_random_bric.png` | BMA inclusion heatmaps. |
| `posterior_baseline.png`, `bma_baseline_pmp_cumulative.png` | Posterior model-size distribution and cumulative posterior model probability (Figure C.1). |
| `correlation.png` | Moderator correlation matrix. |

## Software requirements
- **Stata 17+** with community packages: `ivreg2`, `boottest`, `winsor`, `estout`
  (`esttab`).
- **R (≥ 4.x)** with packages: `readxl`, `readr`, `haven`, `puniform`, `BMS`,
  `dilutBMS2` (dilution model prior; loaded after `BMS` so its `bms()` masks
  `BMS::bms` — see the comment in `5.het_bma.R`), `LowRankQP`, `foreign`, `xtable`,
  `varhandle`, `pracma`, `sandwich`, `data.table`, `corrplot`, and `MetaStudies`
  (bundled; see above). `dilutBMS2` and `MetaStudies` are not on CRAN.

## Not distributed
`Primary studies/` (the collected PDFs of the 106 primary studies) is not part of the
public package for copyright reasons; the full reference list is in the `Reference`
column of the dataset and the paper's bibliography.

## Housekeeping notes
- Excel lock files (`~$*.xlsx`) may appear next to the data files while a workbook is
  open; they are artifacts and should be deleted before zipping the package.
- The manuscript sources with tracked changes (`bgd_esg_tracked.txt` and `bgd_esg_tracked_karolina.txt`) are
  working files, not part of the replication package.
