# Replication package

### Do Female Directors Raise ESG Ratings? A Meta-Analysis
Karolina Hozova, Tomas Havranek, and Zuzana Irsova

This package reproduces every table and figure in the paper, which synthesizes **533
estimates from 106 primary studies** of the effect of board gender diversity on corporate
ESG ratings. Online appendix, data, and code: **meta-analysis.cz/esg**.

Corresponding author: Karolina Hozova (karolina.hozova@fsv.cuni.cz).

---

## What is here

| Folder / file | Contents |
|---------------|----------|
| `Data/` | The hand-collected dataset (`esg_clean.xlsx`, `esg_clean.csv`), its `CODEBOOK.md`, and the cell-level revision log `CHANGELOG.md`. |
| `Code/` | The Stata master script `esg_code_v5.do`, which orchestrates the full analysis, and `Code/R-code/` with the six numbered R scripts for the steps Stata hands off to R. |
| `Output/` | Everything the pipeline writes: rendered figures and exported table fragments, plus the intermediate datasets passed between Stata and R (`Data overview/`, `Publication bias/`, `Heterogeneity/`). |
| `RUN_ORDER.md` | The end-to-end run order and the Stata↔R hand-offs. |
| `REQUIREMENTS.md` | Software, user-written Stata commands, and R packages (incl. the two non-CRAN ones). |
| `MANIFEST.md` | An annotated list of every file. |

A full description of every variable is in [`Data/CODEBOOK.md`](Data/CODEBOOK.md); every
revision made during data validation is documented in
[`Data/CHANGELOG.md`](Data/CHANGELOG.md).

## Data

The dataset is hand-collected from the primary literature (study list in Table 1; search
and screening in Appendix A / the PRISMA diagram). The sample is restricted to studies
that rate ESG performance with **Bloomberg** or **LSEG (Refinitiv/Eikon)** and measure
board gender diversity as the **share of women on the board**, so effect sizes are
comparable on a common 0.01–100 ESG scale.

- `Data/esg_clean.xlsx` — sheet `Data`, 533 rows × 65 columns; this is the file the Stata
  script imports.
- `Data/esg_clean.csv` — the same data as comma-delimited UTF-8 text (identical values),
  for users who prefer a non-proprietary format.

## How to reproduce

1. Install the software and packages listed in [`REQUIREMENTS.md`](REQUIREMENTS.md).
   Note that two R packages are not on CRAN: `MetaStudies` (bundled) and `dilutBMS2`.
2. Open `Code/esg_code_v5.do` in Stata 17+. Set the single `global root` path (Section
   A1) to wherever you placed this package — that is the only line you need to change.
3. Run the Stata sections **A–D** top to bottom. Stata alone produces the summary
   statistics, funnel plots, FAT-PET (incl. the provider-invariance test), WAAP,
   endogenous-kink and caliper results, the OLS meta-regression, and the best-practice
   estimates.
4. Five steps run in **R**. Each is embedded in the do-file as a commented `/* ... */`
   block at the exact point in the pipeline where it runs, and shipped as an identical
   standalone script in `Code/R-code/` — run the numbered script when you reach the
   corresponding block, then continue in Stata:
   - `1.pubbias-maive.R` — MAIVE (after the Section B2.5 exports)
   - `2.pubbias-selection.R` — Andrews–Kasy selection model (after B4)
   - `3.pubbias-stem.R` — Furukawa STEM (after B5)
   - `4.pubbias-puniform.R` — p-uniform* (after B7)
   - `5.het_bma.R` — Bayesian model averaging (after the Section C1 exports), then
     `6.het_fcheck.R` — frequentist (Mallows) model averaging
5. One manual hand-off: `5.het_bma.R` prints the BMA intercept as
   `scalar b0_bma = ...` — paste it into STEP 2 of Section D (the do-file comment marks
   the spot) before running the best-practice block. The remaining BMA posterior means in
   STEP 2 mirror Table 5 and are updated the same way after any re-run.

Each R script `setwd()`s into its own folder under `Output/` and reads its inputs by
bare filename, so no paths need editing there. [`RUN_ORDER.md`](RUN_ORDER.md) lists the
full step-by-step sequence and which intermediate files pass between Stata and R.

Random seeds are fixed throughout (Stata: `set seed 20241215`, re-seeded at the start of
every bootstrap block so each block is reproducible even when run standalone; R model
averaging: seeds set inside `5.het_bma.R`), so all results — including wild-bootstrap
confidence intervals — reproduce exactly.

## Citation

> Hozova, K., Havranek, T., & Irsova, Z. (2026). *Do Female Directors Raise ESG
> Ratings? A Meta-Analysis.*

## License

Suggested: data under **CC BY 4.0**, code under the **MIT License**. Add a `LICENSE` file
before public release.

## Acknowledgments

Hozova acknowledges support from the European Union's Horizon 2020 research and innovation
programme under the Marie Skłodowska-Curie grant agreement No. 870245.
