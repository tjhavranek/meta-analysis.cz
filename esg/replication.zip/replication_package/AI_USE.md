# Use of artificial intelligence

Disclosure for *Do Female Directors Raise ESG Ratings? A Meta-Analysis*
(Hozová, Havránek & Iršová), following the reporting guidelines for meta-analysis in
economics updated for AI (Cook et al. 2026, *Journal of Economic Surveys*,
doi:10.1111/joes.70116) and the guiding principles that accompany them
(Cook et al. 2026, doi:10.1111/joes.70105).

Appendix D of the paper carries the same information in short form. This file adds the detail
the guidelines ask replication materials to record: the period of use for each tool and the
kinds of instruction given.

## Summary

**No search, screening, or coding decision was delegated to AI.** The literature search, the
inclusion and exclusion decisions, and the coding of all 533 estimates and their moderators
were carried out by the authors. The share of estimates coded by AI is zero, so the
false-negative rate that the guidelines attach to AI-assisted screening does not arise here.

**On the two-reviewer recommendation.** The coding was done by one author. Rather than have a
second reviewer code independently, a random sample of coded estimates was re-checked against
the primary studies with AI assistance, and the authors adjudicated every case the check raised
against the primary study; those corrections are logged cell by cell in `Data/CHANGELOG.md`.
Because the AI acted as a checker against the sources rather than as an independent coder, we
report no formal inter-rater statistic (Cohen's kappa or similar). We record this as a
deviation, for the reason just given, not as a requirement that does not apply.

Every estimate, table, and figure in the paper comes from the authors' own Stata and R code in
this package; no figure or table was produced by AI. AI did not influence any analytical
choice — no specification, weighting scheme, prior, or bandwidth.

## Where AI was used

| Stage | AI used | Detail |
|---|---|---|
| Research question, hypotheses | No | Formulated by the authors. |
| Literature search | No | Google Scholar and backward snowballing, run by the authors in May and December 2024 (Appendix A of the paper). |
| Screening, inclusion decisions | No | All decisions by the authors. |
| Coding of estimates and moderators | No | All 533 estimates coded by the first author. |
| Checking of the coded data | **Yes** | A random sample of coded estimates was re-checked against the primary studies with AI assistance. Every discrepancy was resolved by the authors against the primary study; the resulting corrections are logged cell by cell in `Data/CHANGELOG.md`. |
| Checking of reported numbers | **Yes** | Numbers printed in the paper were cross-checked against this dataset and against the code output, and reported results were re-derived from the shipped data as a check. The checks led to corrections in the paper. |
| Estimation, tables, figures | No | Authors' Stata and R code (`Code/`). |
| Replication package, online appendix | **Yes** | Assembled and documented with AI assistance, then checked by the authors. |
| Language editing | **Yes** | Editing of text written by the authors. |

## Tools, versions, dates

| Tool | Version | Interface | Period of use |
|---|---|---|---|
| Claude | Opus 4.8 | Claude Code | June–July 2026 |
| Claude | Fable 5 | Claude Code | July 2026 |
| Claude | Sonnet 5 | Claude Code | July 2026 |
| GPT | 5.6 Sol | Codex CLI | July 2026 |

Earlier data-checking work by the first author used Claude through the Claude web interface
(June 2026); the specific model version was not recorded at the time, and that work used
default settings. The later command-line work was run at a raised reasoning-effort setting.

## Prompts and settings

The AI assistance took the form of interactive sessions rather than a fixed prompt template,
so there is no single reusable prompt to publish. The instructions given were of four kinds:
(i) re-check these coded estimates against the primary study and report any disagreement;
(ii) verify that a number printed in the paper matches the dataset or the code output;
(iii) edit this author-written passage for language without changing its content; and
(iv) assemble and document the replication package. No prompt
selected a study, coded a value, or chose a specification; every discrepancy the checks raised
was adjudicated by the authors.

## Accountability

The authors are responsible for the whole of the paper, including everything checked or
edited with AI assistance. AI is not an author.
