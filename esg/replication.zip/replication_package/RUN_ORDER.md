# Run order

The analysis runs mostly in **Stata** (`Code/esg_code_v5.do`), which exports a few
intermediate datasets that four publication-bias methods and the model-averaging step
consume in **R**. Run the steps in the order below. The six R scripts in `Code/R-code/`
are verbatim extracts of the R blocks embedded (as `/* ... */` comments) in the do-file
at the exact points where they run.

## 0. Setup
- Install the software and packages in [`REQUIREMENTS.md`](REQUIREMENTS.md).
- In `Code/esg_code_v5.do`, Section A1, set `global root` to this package's location.
  Every other Stata path derives from it.
- Each R script except `6.het_fcheck.R` (which reads its input by a full path) begins with a `setwd()` into its own folder under `Output/` — adjust the
  root part of that one line to your location; inputs are then read by bare filename.
- Seeds are fixed: Stata sets `set seed 20241215` globally **and re-seeds at the start of
  every bootstrap block**, so each block reproduces even when run standalone; the R
  model-averaging seeds are set inside `5.het_bma.R` (`SEED1 = 20241215`,
  `SEED2 = 99999` for the convergence check).

## 1. Stata — Sections A–B (data prep, summary statistics, publication bias)

> Note: Section B `cd`s into `Output/Publication bias` and saves the FAT-PET and caliper
> outputs there under bare file names, so a rerun writes them to that folder rather than
> into `1. FAT-PET/` and `7. Caliper/`, where the shipped copies are filed. Compare the
> new files against the shipped ones; nothing is overwritten.
Run `esg_code_v5.do` from the top. These sections produce:
- **A** — import, winsorization, helper variables, subgroup means → **Table 2**; the A3.5 summary block → **Table 4**; the
  data-overview figures (histograms, box plots, trend plots).
- **B1** — funnel plots (full sample and direct estimates).
- **B2** — FAT-PET linear tests (OLS, between effects, study and precision weights) with
  wild-cluster-bootstrap CIs for all four samples → Panel A of **Table 3** and
  **Table B.1**; **B2.5** exports the MAIVE inputs; **B2.6** the provider-invariance
  interaction test → **Table B.2**.
- **B3** — WAAP; **B6** — endogenous kink → the corresponding Panel B cells of
  Tables 3 / B.1; **B8** — caliper tests (console output; a robustness check not
  reported in the paper's tables).
- **B4 / B5 / B7** export the datasets the selection-model, STEM, and p-uniform* scripts
  read (hand-off table below).

Sections B6–B8 are wrapped in `preserve`/`restore`, so Section B runs safely end-to-end
and leaves the dataset intact for Section C; individual blocks can also be re-run out of
order.

## 2. R — publication-bias methods
Run each script after the corresponding Stata export (or run all of Stata first — every
export block precedes its consumer):

| Script | Reads from | Produces |
|--------|------------|----------|
| `1.pubbias-maive.R` | `Output/Publication bias/6. MAIVE/` | MAIVE column of **Tables 3 / B.1** (coef, SE, first-stage F, Anderson–Rubin interval) |
| `2.pubbias-selection.R` | `Output/Publication bias/2. Selection Model/` | Selection-model cells of Panel B |
| `3.pubbias-stem.R` | `Output/Publication bias/3. STEM Method/` | STEM cells of Panel B |
| `4.pubbias-puniform.R` | `Output/Publication bias/4. p-uniform/` | p-uniform* cells of Panel B |

Transcribe the printed estimates into the corresponding table cells.

## 3. Stata — Sections C1–C2 (heterogeneity: data export, OLS)
Continue in `esg_code_v5.do`:
- **C1** exports the model-averaging design matrices to `Output/Heterogeneity/`.
- **C2** runs the OLS / stepwise meta-regression.

## 4. R — model averaging → Tables 5, C.1, C.2
Run, in order:
- `5.het_bma.R` — Bayesian model averaging: baseline (UIP + dilution, 1M draws),
  convergence diagnostics (chain-length and seed checks), BRIC+random prior robustness,
  and the excl-Middle-East subsample (derived internally) → **Table 5** (BMA columns),
  **Tables C.1–C.2**, the inclusion heatmaps and posterior figures. It also **prints the
  BMA intercept as `scalar b0_bma = ...`** — used only by the optional cross-check in step 5.
- `6.het_fcheck.R` — frequentist (Mallows) model averaging, full moderator set →
  frequentist columns of **Table 5**.

## 5. Stata — Section D: best-practice estimates → Table 6
Run Section D. The best-practice estimates reported in **Table 6** come from `lincom` on the
Section D2 OLS regression (the `_b[]` coefficients), so they need nothing pasted in.
STEP 2 additionally holds the BMA posterior means and intercept: pasting the
`scalar b0_bma = ...` line printed by `5.het_bma.R` at the marked spot, and updating the
other scalars after a BMA re-run, refreshes the optional BMA-implied cross-check that the
section prints alongside Table 6. It does not change any reported number.

## Stata → R hand-off files

| Exported by Stata | Read by |
|-------------------|---------|
| `6. MAIVE/maive_{full,direct,excl_me,unwinsorised}.xlsx` | `1.pubbias-maive.R` |
| `2. Selection Model/data_{full,direct_est,excl_ME,unwinsorised}.csv` | `2.pubbias-selection.R` |
| `3. STEM Method/esg_r_study.xlsx`, `esg_r_study_direct.xlsx` | `3.pubbias-stem.R` |
| `4. p-uniform/puniform_{full,direct_est,excl_me}.dta` (the unwinsorised run uses the raw-median columns of the full file) | `4.pubbias-puniform.R` |
| `Heterogeneity/data_full_nest.xlsx` (and `data_full_nest_robustness.xlsx` as the documented alternative for the excl-ME subsample) | `5.het_bma.R`, `6.het_fcheck.R` |

> The rendered intermediate files and figures already in `Output/` let you inspect the
> expected outputs without a full re-run.
