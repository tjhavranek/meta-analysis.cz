#!/usr/bin/env Rscript

# Install only packages that are not already available.  Keeping dependency
# installation separate makes the computational part of the replication easy
# to rerun offline after the first successful setup.
# Pick a CRAN mirror.  A vanilla R session leaves the placeholder "@CRAN@"
# here, which install.packages() cannot resolve non-interactively, so a
# cold-start replicator needs an explicit fallback.
cran_mirror <- function() {
  cran <- getOption("repos")["CRAN"]
  if (is.na(cran) || identical(unname(cran), "@CRAN@")) "https://cloud.r-project.org" else unname(cran)
}

cran_packages <- c(
  "BMS", "clubSandwich", "dplyr", "dqrng", "ggplot2", "lmtest",
  "remotes", "sandwich", "scales", "tidyr"
)

missing_packages <- cran_packages[
  !vapply(cran_packages, requireNamespace, logical(1), quietly = TRUE)
]

if (length(missing_packages)) {
  message("Installing missing packages: ", paste(missing_packages, collapse = ", "))
  install.packages(missing_packages, repos = cran_mirror())
}

still_missing <- cran_packages[
  !vapply(cran_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(still_missing)) {
  stop("Dependency installation failed for: ", paste(still_missing, collapse = ", "))
}

# fwildclusterboot is distributed from its official GitHub repository rather
# than CRAN. Pin the exact release commit used for Table 8 so later upstream
# changes cannot silently alter the reported bootstrap inference.
fwildclusterboot_version <- "0.14.0"
fwildclusterboot_commit <- "add82ae02090937dc2baf716a30e4209e4119d01"
summclust_commit <- "a6c773fa20ccd9cb63444dfac48f437fd3db1600"

github_commit_installed <- function(package, commit) {
  if (!requireNamespace(package, quietly = TRUE)) return(FALSE)
  remote_sha <- utils::packageDescription(package, fields = "RemoteSha")
  !is.na(remote_sha) && identical(unname(remote_sha), commit)
}

if (!github_commit_installed("summclust", summclust_commit)) {
  message("Installing pinned summclust dependency ...")
  remotes::install_github(
    paste0("s3alfisc/summclust@", summclust_commit),
    dependencies = NA,
    upgrade = "never"
  )
}

fwildclusterboot_ok <- requireNamespace("fwildclusterboot", quietly = TRUE) &&
  identical(as.character(utils::packageVersion("fwildclusterboot")), fwildclusterboot_version) &&
  github_commit_installed("fwildclusterboot", fwildclusterboot_commit)

if (!fwildclusterboot_ok) {
  message("Installing pinned fwildclusterboot ", fwildclusterboot_version, " ...")
  remotes::install_github(
    paste0("s3alfisc/fwildclusterboot@", fwildclusterboot_commit),
    dependencies = NA,
    upgrade = "never"
  )
}

if (!requireNamespace("fwildclusterboot", quietly = TRUE) ||
    !identical(as.character(utils::packageVersion("fwildclusterboot")), fwildclusterboot_version) ||
    !github_commit_installed("fwildclusterboot", fwildclusterboot_commit)) {
  stop("Dependency installation failed for pinned fwildclusterboot ", fwildclusterboot_version)
}

message("All R dependencies are available.")
