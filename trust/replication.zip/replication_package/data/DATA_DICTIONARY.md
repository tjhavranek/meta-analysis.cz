# Data dictionary and provenance

`analysis_ready.rds` is the frozen, pre-analysis estimate-level dataset used to
construct the finalized timing-matched model frame. `analysis_ready_persistent_trust.rds`
is the corresponding frozen input for the persistent-country-trust diagnostic in
Table 5. Neither file contains raw survey microdata.

The inputs combine reported size-slope estimates and study-design variables from
the Astakhov et al. archive with country-period EVS/WVS trust summaries, Worldwide
Governance Indicators, and linked macro-financial controls. The package begins at
this matched-data stage; it does not recreate source acquisition or matching.

The authoritative prose descriptions of the moderators are manuscript Tables 9 and 10
(the two variable dictionaries). The frozen RDS files also carry staging columns that
the analysis does not use. One of them is an empty merge artifact literally named `NA`: it is
missing in every row and nothing reads it. `R/01_data.R` selects and transforms only the fields listed
below before estimation. Every column the workflow actually consumes is documented here,
with the exact transformation from `R/01_data.R` and the display label from the
`coefficient_labels` map in `R/03_bma.R`.

## Identifiers and outcome

| Column | Meaning | Notes |
|---|---|---|
| `cn_id` | Country identifier | Grouped pseudo-country codes matching `^GR[0-9]+$` are dropped before analysis. `US` carries 1,115 of the 1,613 estimates. |
| `idstudy` | Source-study identifier | 105 studies in the complete-case sample. |
| `size` | Reported size slope (dependent variable) | Winsorized at 1/99 *after* the complete-case frame is fixed; `size_unwinsorized` keeps the raw value. More negative values imply a stronger conventional size premium. |
| `se` | Reported standard error of the size slope | Winsorized at 1/99 after the frame is fixed; `se_unwinsorized` keeps the raw value. Also enters the meta-regression as the precision moderator. |

## Institutional variables

| Column | Label (`03_bma.R`) | Construction (`01_data.R`) |
|---|---|---|
| `trust_index` | Generalized trust | Row mean of the seven standardized EVS/WVS trust components below; set to `NA` if all seven are missing. |
| `rule_of_law` | Rule of law | Worldwide Governance Indicators rule-of-law score; used as supplied. |
| `trust_rule_of_law` | Generalized trust x Rule of law | `trust_index * rule_of_law`, formed after winsorization. |

Generalized-trust components (each already standardized, `z_`-prefixed):
`z_mean_g007_18_b`, `z_mean_g007_33_b`, `z_mean_g007_34_b`, `z_mean_g007_35_b`,
`z_mean_g007_36_b`, `z_mean_g007_01`, `z_share_6_a165`.

Family-trust placebo (`placebo_index`, summarized in Table 2 and used in the Table 5 diagnostic): row mean of
`z_mean_d001` and `z_mean_d001_b`.

Other WGI measures retained for the alternative-governance robustness checks, used as
supplied: `regulatory_quality`, `government_effectiveness`, `control_of_corruption`.

## Controls (moderators)

Labels are the `coefficient_labels` entries in `R/03_bma.R`; transformations are from
`R/01_data.R`. A dash means the column enters as supplied.

| Column | Label | Transformation |
|---|---|---|
| `rel_size` | Relative-size coding | — |
| `avg_year` | Sample midyear | centered: `avg_year - 1983.301` |
| `num_years` | Log sample length | `log(num_years)` |
| `any_trim` | Any trimming | — |
| `OLS` | OLS estimator | — |
| `FM` | Fama-MacBeth estimator | — |
| `excess` | Excess-return specification | — |
| `indstock` | Individual-stock sample | — |
| `jan` | January-return specification | — |
| `impact` | Journal impact | — |
| `cits` | Log citations | `log(cits)` |
| `indep_demean` | Demeaned size variable | — |
| `value` | Value controls | — |
| `syst_risk` | Systematic-risk controls | — |
| `momentum` | Momentum controls | — |
| `leverage_group` | Leverage controls | — |
| `profitability` | Profitability controls | — |
| `liquidity` | Liquidity controls | — |
| `volatility` | Volatility controls | — |
| `price_group` | Price controls | — |
| `mkt_char` | Market-characteristic controls | — |
| `mkt_state` | Market-state controls | — |
| `information` | Information controls | — |
| `ownership` | Ownership controls | — |
| `growth` | Growth controls | — |
| `distress_group` | Distress controls | — |
| `size_group` | Additional size controls | — |
| `bond_yield` | Bond yield | — |
| `mkt_return_vol` | Market-return volatility | `100 * mkt_return_vol` |
| `credit_gdp` | Private credit to GDP | `credit_gdp / 100` |
| `gdp_pc` | Log GDP per capita | `log(gdp_pc)` |
| `gdp_growth` | GDP growth | `100 * gdp_growth` |

## Sample construction

`R/01_data.R` drops grouped pseudo-country identifiers (`^GR[0-9]+$`), applies the
transformations above, constructs the generalized- and family-trust indices, selects the
model frame, drops incomplete rows to form the complete-case sample, and only then
winsorizes `size` and `se` at 1/99. The resulting frame holds 1,613 estimates from 105
studies and 31 countries (1,115 U.S.). These counts are enforced at run time by
`validate_baseline_data()` in `R/01_data.R` and recorded in
`outputs/data_validation.csv`.
