# Replication package: Trust, Rule of Law, and the Size Premium

## Citation

Schwarz, Jiří, Tomáš Havránek, Zuzana Iršová, and Jiří Novák. 2026. “Trust,
Rule of Law, and the Size Premium: Evidence from a Meta-Analysis.” Manuscript.

This replication package is archived at <https://doi.org/10.5281/zenodo.22212719> (version 1.1.0)
and mirrored at <https://meta-analysis.cz/trust>. The concept DOI
<https://doi.org/10.5281/zenodo.21486176> always resolves to the latest version.

## Purpose

This directory reproduces the statistical tables and figures used in the finalized
manuscript from frozen analysis-ready data. It is standalone: after copying this
directory elsewhere, no path to the parent research repository is required.

### Scope: what this package does and does not rebuild

**Replication starts from frozen, analysis-ready inputs.** `data/analysis_ready.rds` contains the
reported size-slope estimates and study-design codings from the Astakhov et al. archive, matched to
country-period EVS/WVS trust summaries, Worldwide Governance Indicators, and macro-financial
controls. It is the input for the baseline and for every table and figure except one: the
persistent-country-trust diagnostic in Table 5 is estimated from the companion frozen file
`data/analysis_ready_persistent_trust.rds`, which replaces the nearest-survey-year trust match with a
time-invariant country trust measure.

The package does **not** rebuild the upstream acquisition and matching: the EVS/WVS survey
aggregation, the nearest-survey-year matching of trust to each estimate, the WGI merge, and the
pre-1960 sample-midpoint filter were applied before this frozen file was written, and the raw
survey microdata cannot be redistributed here. `data/DATA_DICTIONARY.md` documents every column the
analysis consumes, with the exact transformation applied to it. Users who need the pre-frozen build
should contact the corresponding author (j.schwarz.sbu@aauni.edu).

## Quick start

Install R (version 4.2 or newer is recommended), open a terminal, and run:

    cd replication_package
    Rscript run_all.R

On a first run, installing the pinned GitHub sources for `fwildclusterboot` and its `summclust`
dependency may require the usual package-development toolchain (Rtools on Windows, Xcode Command
Line Tools on macOS, or a C++ compiler on Linux). Subsequent runs reuse the verified commits.

`run_all.R` is the only required entry point. It installs missing CRAN packages and
the pinned official `fwildclusterboot` and `summclust` releases,
validates the inputs, estimates all models, exports the tables and figures, and
checks the results against manuscript values. Existing CRAN package installations are
left unchanged; the two pinned GitHub dependencies are replaced only if their recorded
commit differs. Internet access is required only if packages are missing or mismatched.

The full BMA uses 100,000 burn-in and 200,000 retained MCMC iterations. Runtime depends on the
machine, installed numerical libraries, and whether dependencies must be installed; the full run
normally takes a few minutes. For a non-publication smoke test, open `run_all.R` and change the
clearly marked switch near the top from `QUICK_BMA <- FALSE` to
`QUICK_BMA <- TRUE`. Change it back to `FALSE` for all reportable or submission
runs. Quick-mode BMA results must not be reported or submitted.

## Directory map

- `data/`: frozen analysis-ready RDS inputs and their data dictionary.
- `R/`: extensively commented preparation, estimation, graphics, and verification scripts.
- `vendor/BMS/`: upstream BMS source plus the documented local covariance extension.
- `tables/`: manuscript-numbered CSV deliverables.
- `figures/png/` and `figures/pdf/`: identical figures in raster and vector formats.
- `outputs/`: intermediate model objects, plot data, validation files, run log, manifest, and session information.

The `outputs/economic_effects_calculation.csv` file explicitly reconstructs the
illustrative calculation described in the Discussion. It records the country-level
trust and rule-of-law quantiles, the trust interquartile change, baseline OLS
coefficients, fitted slope movements at lower and higher rule of law, the implied
reported-slope percentile, the number and share of estimates spanned by that
movement, and the country-weighted mean slope. These are point-estimate illustrations
in reported-slope space, not structural counterfactual effects.

## Reproduced manuscript outputs

The package creates Tables 2, 3, 4, 5, 7, 8, and 11. The numbering gaps are
deliberate: Table 1 is the data-source overview, Table 6 lists included papers, and
Tables 9--10 are variable dictionaries rather than requested statistical outputs.

It creates Figure 1; separate panels Figure 2a and 2b; Figure 3; separate panels
Figure 4a and 4b; and Figure 5.
Figures 1--4 are exported to PNG (300 dpi) and PDF from the same ggplot object; Figure 5 is
drawn twice with the native BMS image method, to PNG at 220 dpi and to an 11x8 inch PDF.

## Computational sequence

1. `R/01_data.R` applies transformations, constructs trust indices, fixes the
   complete-case sample, and then applies the specified tail treatment.
2. `R/02_ols_and_figures.R` generates descriptive statistics, baseline OLS with
   study/country clustered inference, marginal effects, the institutional surface,
   Figures 1--3, Table 7, and the Discussion's illustrative economic-effects CSV.
3. `R/03_bma.R` runs the adjusted BMS estimator, posterior marginal effects,
   Figures 4--5, and the OLS/BMA tables.
4. `R/04_diagnostics.R` reconstructs Table 5 and implements CR1, CR2/Satterthwaite,
   and null-imposed WCR11 wild-cluster-bootstrap inference for Table 8 via
   `fwildclusterboot`.
5. `R/05_verify.R` checks the output inventory and manuscript-facing values and
   writes checksums, dimensions, timestamps, package versions, and pass/fail files.

## Adjusted BMS code

The vendored source is based on upstream BMS commit `cd115f0`. The additive local
change accumulates posterior coefficient cross-moments during MCMC. Standard BMS
reports marginal posterior standard deviations but not the cross-coefficient
covariances needed for interaction marginal effects. The adjustment supplies those
covariances without replacing the upstream functions. See
`vendor/BMS/LOCAL_MODIFICATIONS.md` and the extension file `R/bms_mcmc_extensions.R`.

The manuscript run fixes seed 20260607 and uses the BRIC g-prior, random model-size
prior, birth-death sampler, 5,000 stored models, 100,000 burn-in iterations, and
200,000 retained iterations. Native BMS marginal summaries are checked against the
extended moment reconstruction.

## Expected checks

The preferred sample must contain 1,613 estimates, 105 studies, 31 countries, and
1,115 U.S. estimates. Verification also checks finite model matrices, expected
files, nonempty outputs, headline manuscript numbers, and CSV row counts, then records output
hashes in the manifest. The manifest records the exact bytes produced by the archived run. Numerical results reproduce at manuscript
precision across supported platforms, but byte-level hashes may differ across platforms because
CSV line endings, graphics devices, compression, and PDF creation metadata are platform-dependent.

## Two implementation details a replicator should know

**The vendored BMS copy is the complete upstream tree with the documented local modifications.**
`vendor/BMS/` carries the whole upstream package (including its manual, vignettes, and build
auxiliaries) so that the exact sources behind the reported BMA results travel with the package. Two
changes are ours, and both are recorded in `vendor/BMS/LOCAL_MODIFICATIONS.md`: the added posterior
cross-moment extension, and the removal of the samplers' internal `set.seed(as.numeric(Sys.time()))`
calls, so that the caller's explicit seed (20260607) is the one that governs. Nothing else in the
tree was edited. Some upstream files still contain the original maintainer's own absolute build
paths; they are inert, nothing this package runs reads them, and they are left as they are rather
than tidied, so the rest of the tree stays faithful to its BSD-3-licensed source.

**The wild-cluster bootstrap in `R/04_diagnostics.R`.** Table 8 uses the
`fwildclusterboot` v0.14 release (package version 0.14.0, commit
`add82ae02090937dc2baf716a30e4209e4119d01`). This replaced the package's earlier hand-coded,
4,999-replication procedure. The current call performs a null-imposed WCR11 test with the native R
`fnw11` algorithm, Rademacher weights, two-tailed inference, `dqrng` sampling, one thread, and the
explicit small-sample settings `adj = TRUE`, `fixef.K = "none"`, `cluster.adj = TRUE`, and
`cluster.df = "conventional"`. It requests 99,999 bootstrap replications for each of the three
institutional terms and uses term-specific seeds 20260607, 20260608, and 20260609, set for both base
R and `dqrng`, so results do not depend on evaluation order. The installer also pins `summclust`
v0.5 (commit `a6c773fa20ccd9cb63444dfac48f437fd3db1600`), because exact replication requires these source
versions even when other releases are available from CRAN.

If execution fails, inspect `outputs/run.log`. Dependency failures normally indicate
missing compilation tools or blocked CRAN access. A data-validation failure means
that an input was altered. A numerical-verification failure means that the model,
software behavior, or random state no longer matches the finalized analysis and
should not be ignored.

## License

The Bayesian model averaging code under `vendor/BMS/` is derived from the upstream BMS
package and remains under its upstream BSD 3-clause license (see `vendor/BMS/DESCRIPTION`
and `vendor/BMS/LICENSE`); any redistribution of this directory should respect it, along
with the documented local changes in `vendor/BMS/LOCAL_MODIFICATIONS.md`.

See `LICENSE` for the full terms. The package is licensed by component: the authors' code
(`run_all.R`, `00_install_dependencies.R`, `R/`) under the MIT License; the frozen data and
the derived deliverables (`data/`, `tables/`, `outputs/`, `figures/`) under CC BY 4.0, subject
to the upstream terms of the Astakhov et al. archive, EVS/WVS, and the Worldwide Governance
Indicators; and `vendor/BMS/` under its upstream BSD 3-clause license.
