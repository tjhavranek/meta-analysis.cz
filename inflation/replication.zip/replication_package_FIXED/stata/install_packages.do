********************************************************************************
** User-package installer for the Stata side of the replication package.
** Run once before `do Inflation_v34.do`.
**
**   stata -b do install_packages.do
**
** Tested with Stata 17 and Stata 18 on Windows 11.
********************************************************************************
ssc install metan,    replace
ssc install psacalc,  replace
ssc install weakivtest, replace
ssc install estout,   replace
* The following are used by some robustness branches; install if Stata reports
* "command unrecognized" while running Inflation_v34.do:
* ssc install ftools,  replace
* ssc install reghdfe, replace

display "Stata user packages installed."
