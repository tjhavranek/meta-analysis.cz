********************************************************************************
** Optimal Inflation Rate: Meta-Analysis (v3.3 dataset (v34 cleaning + Lipinski))
** Main Stata do-file -- MAER-Net pipeline
**
** Author: Matej Opatrny (2026)
** Data  : inflation_v34.dta  (885 obs x 180 vars; 130 unique Idstudy;
**         116 studies contribute >=1 quantitative estimate;
**         777 analysis rows after dropping rows with missing Estimate_win)
** Built by: python/phase2_build_analysis_dataset.py
**
** To run:  cd to the stata/ folder of this package, then `do Inflation_v34.do`
**         (no `cd` inside the do-file; we use a relative working directory).
**
** Pipeline:
**   01. Load & summary statistics
**   02. Histograms (overall, Sticky vs Flex, ExogInfl, by-year boxplots)
**   03. Funnel plot (publication bias)
**   04. Caliper test at pi=0 and pi=2 (widths 0.5/1.0/1.5/2.0)
**   05. FAT-PET and PEESE (Stanley 2005, 2008)
**   06. WAAP (Ioannidis et al. 2017)
**   07. TOP10 (Stanley et al. 2010)
**   08. Andrews-Kasy export
**   09. Endogenous kink (Bom & Rachinger 2020)
**   10. Export data for p-uniform* (Stata + R)
**   11. Heterogeneity regressions (OLS, clustered by Idstudy)
**   12. Best-practice lincom
**   13. Robustness: Preferred==1 and se_is_genuine==1 subsamples
********************************************************************************

clear all
set more off
set seed 1234
capture log close
capture mkdir Graphs
log using Inflation_v34_run.log, replace

use inflation_v34.dta, clear

* housekeeping
drop if missing(Estimate_win)           // keep rows with usable effect size
rename Idstudy idstudy                  // lowercase per MAER-Net convention
xtset idstudy

label variable Estimate_win     "Optimal inflation (pp/year)"
label variable SE_win           "SE (bootstrap or reported)"
label variable precision        "Precision (1/SE)"
label variable tstat            "t-stat"
label variable Year             "Year"
label variable LCitations       "Log citations"
label variable LIF              "Log impact factor"

*===============================================================================
* 01. SUMMARY STATISTICS  (class-size-paper convention: two tables)
*   Table A: overall summary (Obs / Mean / SD / Median)
*   Table B: BMA-style grouped with section headers via esttab refcat()
*            - Variable of Interest
*            - Estimation methodology
*            - Model characteristics
*            - Publication characteristics
*===============================================================================
summarize Estimate_win SE_win precision Year LCitations LIF
tabulate SE_source
tabulate Estimator_Type

* --- Table A: overall summary ------------------------------------------------
est clear
eststo: estpost tabstat                                                         ///
    Estimate_win SE_win precision                                               ///
    StickyPrices FlexiblePrices ZLB ExogInfl Ramsey Growth                      ///
    Preferred se_is_genuine                                                     ///
    Year LCitations LIF,                                                        ///
    statistics(count mean sd p50) col(stat)
esttab est1 using o_Desc_stats_v34.tex, replace booktabs ///
    cells("count(fmt(%13.0fc)) mean(fmt(%13.2fc)) sd(fmt(%13.2fc)) p50(fmt(%13.2fc))") ///
    nonumber title("Descriptive statistics\label{tab:v34sumstats}") ///
    collabels("Obs." "Mean" "SD" "Median") label ///
    note("Estimate_win is the winsorized (5\%) annualized optimal inflation in pp/year.")

* --- Table B: class-size-style grouped summary ------------------------------
* Nice human labels for the grouped table
label variable Estimate_win                  "Optimal inflation rate"
label variable SE_win                        "Standard error (bootstrap or CI-derived)"
label variable precision                     "Precision (1/SE)"
label variable EST_Bayesian                  "Bayesian estimator"
label variable EST_GMM                       "GMM estimator"
label variable EST_calibration               "Calibration"
label variable SEN_baseline                  "Baseline specification"
label variable SEN_robustness_parameter      "Robustness: parameter"
label variable SEN_robustness_mechanism      "Robustness: mechanism"
label variable PR_Ramsey                     "Ramsey policy"
label variable PR_Friedman_rule              "Friedman rule"
label variable PR_Taylor_rule                "Taylor rule"
label variable PR_Optimized_Taylor_rule      "Optimized Taylor rule"
label variable PR_Inflation_targeting        "Inflation targeting"
label variable PR_Zero_inflation             "Zero-inflation policy"
label variable NFT_Calvo_prices              "Calvo price friction"
label variable NFT_Calvo_prices_and_wages    "Calvo prices and wages"
label variable NFT_Rotemberg_prices          "Rotemberg prices"
label variable NFT_flexible                  "Flexible prices (no friction)"
label variable WRT_Calvo_wages               "Calvo wage rigidity"
label variable WRT_DNWR                      "Downward nominal wage rigidity"
label variable WRT_sticky_real_wages         "Sticky real wages"
label variable MDT_CIA                       "Cash-in-advance"
label variable MDT_MIU                       "Money in utility"
label variable MDT_cashless                  "Cashless"
label variable IND_past_inflation            "Indexation to past inflation"
label variable IND_trend_inflation           "Indexation to trend inflation"
label variable EXP_rational                  "Rational expectations"
label variable EXP_learning                  "Learning"
label variable EXP_adaptive                  "Adaptive expectations"
label variable WC_unconditional              "Unconditional welfare"
label variable WC_conditional_efficient_SS   "Conditional efficient SS welfare"
label variable SST_deterministic             "Deterministic steady state"
label variable SST_stochastic                "Stochastic steady state"
label variable AUG_ZLB                       "ZLB augmentation"
label variable AUG_financial_frictions       "Financial frictions"
label variable AUG_heterogeneous_agents      "Heterogeneous agents"
label variable AUG_labor_market_frictions    "Labor-market frictions"
label variable AUG_open_economy              "Open-economy"
label variable HZ_long_run                   "Long-run horizon"
label variable HZ_short_run                  "Short-run horizon"
label variable ZLB                           "ZLB binding (legacy)"
label variable Growth                        "Growth included"
label variable Ramsey                        "Ramsey rule (legacy)"
label variable Preferred                     "Preferred estimate (1 per paper)"
label variable se_is_genuine                 "SE is genuine (CI/Bayes/GMM)"
label variable Year                          "Publication year"
label variable LCitations                    "Log(1+citations)"
label variable LIF                           "Log(1+impact factor)"

est clear
eststo: estpost tabstat                                                         ///
    Estimate_win SE_win precision                                               ///
    EST_Bayesian EST_GMM EST_calibration                                        ///
    SEN_baseline SEN_robustness_parameter SEN_robustness_mechanism              ///
    PR_Ramsey PR_Friedman_rule PR_Taylor_rule PR_Optimized_Taylor_rule          ///
    PR_Inflation_targeting PR_Zero_inflation                                    ///
    NFT_Calvo_prices NFT_Calvo_prices_and_wages NFT_Rotemberg_prices NFT_flexible ///
    WRT_Calvo_wages WRT_DNWR WRT_sticky_real_wages                              ///
    MDT_CIA MDT_MIU MDT_cashless                                                ///
    IND_past_inflation IND_trend_inflation                                      ///
    EXP_rational EXP_learning EXP_adaptive                                      ///
    WC_unconditional WC_conditional_efficient_SS                                ///
    SST_deterministic SST_stochastic                                            ///
    AUG_ZLB AUG_financial_frictions AUG_heterogeneous_agents                    ///
    AUG_labor_market_frictions AUG_open_economy                                 ///
    HZ_long_run HZ_short_run                                                    ///
    ZLB Growth Ramsey                                                           ///
    Year LCitations LIF,                                                        ///
    statistics(count mean sd) col(stat)

esttab est1 using BMA_Desc_stats_v34.tex, replace booktabs wrap compress nofloat ///
    cells("count(fmt(%13.0fc)) mean(fmt(%13.2fc)) sd(fmt(%13.2fc))") nonumber   ///
    se label collabels("Obs." "Mean" "SD") width(1\hsize) alignment(rrr)        ///
    varlabels(label)                                                            ///
    refcat(Estimate_win     "\emph{Variable of Interest}"                       ///
           EST_Bayesian     "\vspace{0.1em} \\ \hline\emph{Estimation methodology}" ///
           PR_Ramsey        "\vspace{0.1em} \\ \hline\emph{Policy regime}"      ///
           NFT_Calvo_prices "\vspace{0.1em} \\ \hline\emph{Nominal frictions}"  ///
           WRT_Calvo_wages  "\vspace{0.1em} \\ \hline\emph{Wage rigidity}"      ///
           MDT_CIA          "\vspace{0.1em} \\ \hline\emph{Money demand}"       ///
           IND_past_inflation "\vspace{0.1em} \\ \hline\emph{Indexation}"       ///
           EXP_rational     "\vspace{0.1em} \\ \hline\emph{Expectations}"       ///
           WC_unconditional "\vspace{0.1em} \\ \hline\emph{Welfare criterion}"  ///
           SST_deterministic "\vspace{0.1em} \\ \hline\emph{Steady state}"      ///
           AUG_ZLB          "\vspace{0.1em} \\ \hline\emph{Augmentations}"      ///
           HZ_long_run      "\vspace{0.1em} \\ \hline\emph{Horizon}"            ///
           ZLB              "\vspace{0.1em} \\ \hline\emph{Legacy dummies}"     ///
           Year             "\vspace{0.1em} \\ \hline\emph{Publication characteristics}", ///
           nolabel)

*===============================================================================
* 02. HISTOGRAMS
*===============================================================================
quietly summarize Estimate_win, detail
local m = r(mean)

histogram Estimate_win, bin(60) fcolor(gs14) lstyle(thin) frequency ///
    xtitle("Optimal inflation rate (pp/year)") ///
    xline(0, lcolor(red)) xline(2, lcolor(orange) lpattern(dash)) ///
    xline(`m', lcolor(black) lpattern(dot)) ///
    bgcolor(white) graphregion(color(white)) saving(histogram_v34, replace)
graph export Graphs/v34_Inflation_distribution.pdf, replace

* Sticky vs flexible
twoway (hist Estimate_win if FlexiblePrices==1, bin(50) freq fcolor(gs5) lcolor(gs5)) ///
       (hist Estimate_win if StickyPrices==1,   bin(50) freq fcolor(gs13) lcolor(gs10)), ///
    legend(label(1 "Flexible") label(2 "Sticky") ring(0) pos(11)) ///
    xtitle("Optimal inflation rate") graphregion(color(white))
graph export Graphs/v34_Sticky_vs_Flex.pdf, replace

* Exogenous vs endogenous inflation
twoway (hist Estimate_win if ExogInfl==1, bin(50) freq fcolor(gs5) lcolor(gs5)) ///
       (hist Estimate_win if ExogInfl==0, bin(50) freq fcolor(gs13) lcolor(gs10)), ///
    legend(label(1 "Exogenous") label(2 "Endogenous") ring(0) pos(11)) ///
    xtitle("Optimal inflation rate") graphregion(color(white))
graph export Graphs/v34_Exo_vs_Endo.pdf, replace

* By year (horizontal boxes)
graph hbox Estimate_win, over(Year, sort(Year)) xsize(3) ysize(5) ///
    yline(0, lcolor(red)) yline(2, lcolor(orange) lpattern(dash)) ///
    ytitle("Optimal inflation rate") graphregion(color(white))
graph export Graphs/v34_by_year.pdf, replace

* ---- Per-study horizontal box plot, sorted by publication year -------------
*      (class-size-paper Figure 1 style: one row per primary paper)
preserve
    * Strip a trailing " (YYYY)" tag from Author if present (e.g. "Jung, Y. (2025)")
    gen _au = ustrregexra(Author, " *\([0-9]{4}\) *$", "")

    * --- First-author surname (UTF-8 safe) -----------------------------------
    * The .dta uses three formats for Author:
    *   "Lastname, I., Lastname, I."   (comma list)
    *   "Lastname, I.; Lastname, I."   (semicolon list)
    *   "Lastname1 and Lastname2"      (BibTeX style; surnames or full names)
    *   "Firstname Middle Lastname"    (rare, no commas, e.g. Nlemfu Mukoko)
    * For the first three, the surname is everything up to the first
    * comma / semicolon. We use ustrregex* so multi-byte characters
    * (é, ñ, í, …) are preserved instead of being chopped at the first
    * non-ASCII byte (which is what the previous [A-Za-z\-]+ regex did).
    gen _shortauth = ustrregexs(1) if ustrregexm(_au, "^([^,;]+)")
    * Trim leading/trailing whitespace.
    replace _shortauth = ustrtrim(_shortauth)
    * If the surname token contains spaces and starts with a capital the
    * default is fine ("da Costa", "Di Bartolomeo", "Schmitt-Grohé" all
    * survive). If the field is "Firstname Lastname" with no comma, we
    * keep the whole token; explicit overrides below cover the few cases
    * (Nlemfu Mukoko) where we want a different surname.

    * --- Co-author count -----------------------------------------------------
    gen _nand   = (strlen(_au) - strlen(subinstr(_au, " and ", "", .))) / 5
    gen _ncomma = (strlen(_au) - strlen(subinstr(_au, "., ",   "", .))) / 3
    gen _nsemi  = (strlen(_au) - strlen(subinstr(_au, "; ",    "", .))) / 2
    gen _nauth  = 1 + _nand + cond(_nand>0, 0, _ncomma + _nsemi)

    * --- Second-author surname (for the 2-author "& " label) -----------------
    *     UTF-8 safe.
    gen _secondauth = ""
    replace _secondauth = ustrregexs(1) ///
        if _nauth==2 & _nand==1 & ustrregexm(_au, " and ([^,;()]+)")
    replace _secondauth = ustrregexs(1) ///
        if _nauth==2 & _nand==0 & ustrregexm(_au, "[,;] ?([^,;()]+)[,;]")
    replace _secondauth = ustrtrim(_secondauth)

    * --- APA-style label: 1 author -> "Surname (Y)"; 2 -> "S1 & S2 (Y)";
    *     3+ -> "S1 et al. (Y)" --------------------------------------------
    gen str80 study_lbl = ///
          cond(_nauth==1, _shortauth, ///
          cond(_nauth==2 & _secondauth!="", _shortauth + " & " + _secondauth, ///
                                            _shortauth + " et al.")) ///
        + " (" + string(Year, "%4.0f") + ")"

    * --- Per-study label overrides (cosmetic, do not touch the .dta) --------
    *   Match on the unique Author string rather than Idstudy because the
    *   per-study preserve block does not necessarily carry Idstudy.
    *
    *   9114  Author "Jean Blaise Nlemfu Mukoko" (no comma) -> "Nlemfu Mukoko".
    replace study_lbl = "Nlemfu Mukoko (" + string(Year, "%4.0f") + ")" ///
        if Author == "Jean Blaise Nlemfu Mukoko"
    *   9138  Author "Schmitt-Grohe, S.; Uribe, M. (2010)" -- the lone
    *   un-accented entry in the data; reinstate the é.
    replace study_lbl = "Schmitt-Groh" + uchar(233) + " & Uribe (" ///
        + string(Year, "%4.0f") + ")" ///
        if Author == "Schmitt-Grohe, S.; Uribe, M. (2010)"
    *   9044  Coibion-Gorodnichenko-Wieland: the .dta records the 2010 NBER WP
    *   date; the published Review of Economic Studies version (which the
    *   manuscript cites as "Coibion et al. 2012") is 2012. The .dta is left
    *   untouched; only the forest-plot label is corrected.
    replace study_lbl = "Coibion et al. (2012)" ///
        if Author == "Coibion, O., Gorodnichenko, Y., & Wieland, J. F. (2010)"

    * rank studies by (Year, first-author) so the axis is sorted oldest -> youngest
    egen _pair_id = group(Year study_lbl)
    * attach the string label to the numeric rank via value label
    capture label drop studylab
    levelsof _pair_id, local(_ids)
    local _first = 1
    foreach id of local _ids {
        qui levelsof study_lbl if _pair_id==`id', local(_txt) clean
        if `_first' {
            label define studylab `id' `"`_txt'"'
            local _first = 0
        }
        else {
            label define studylab `id' `"`_txt'"', add
        }
    }
    label values _pair_id studylab

    graph hbox Estimate_win, over(_pair_id, sort(_pair_id) ///
            label(labsize(tiny)) axis(noline)) ///
        yline(0, lcolor(red)) yline(2, lcolor(orange) lpattern(dash)) ///
        ytitle("Optimal inflation rate (pp/year)", size(small)) ///
        ylabel(, labsize(small)) ///
        ysize(14) xsize(6) ///
        graphregion(color(white)) bgcolor(white) ///
        note("Studies sorted by publication year (oldest to youngest)." ///
             " Box = IQR, line = median, whiskers = 1.5 x IQR.", size(vsmall))
    graph export Graphs/v34_by_study.pdf, replace
restore

* Time-series mean ± 95% CI line plot (replaces naive scatter)
preserve
    collapse (mean) mean=Estimate_win (sd) sd=Estimate_win ///
             (count) n=Estimate_win (p50) med=Estimate_win, by(Year)
    gen se_mean  = sd/sqrt(n)
    gen lo95     = mean - 1.96*se_mean
    gen hi95     = mean + 1.96*se_mean
    gen lo1sd    = mean - sd
    gen hi1sd    = mean + sd

    * X-axis range driven by the data so the plot does not pad to 2030
    quietly summarize Year
    local ymin = r(min)
    local ymax = r(max)

    twoway (rarea  lo1sd hi1sd Year, color(navy%10)) ///
           (rarea  lo95  hi95  Year, color(navy%30)) ///
           (line   mean        Year, lcolor(navy) lwidth(medthick)) ///
           (line   med         Year, lcolor(black) lpattern(dash)) ///
           (scatter mean       Year, mcolor(navy) msymbol(O) msize(small)),     ///
        yline(0, lcolor(red)) yline(2, lcolor(orange) lpattern(dash))           ///
        ytitle("Optimal inflation (pp/year)") xtitle("Publication year")        ///
        xscale(range(`ymin' `ymax'))                                            ///
        xlabel(`ymin'(5)`ymax', format(%4.0f))                                  ///
        legend(order(3 "Mean" 4 "Median" 2 "95% CI of mean" 1 "±1 SD")          ///
               ring(0) pos(11) rows(2) region(lstyle(none)))                    ///
        graphregion(color(white)) bgcolor(white) saving(line_year_v34, replace)
    graph export Graphs/v34_Inflation_by_year_line.pdf, replace
restore

*===============================================================================
* 03. FUNNEL PLOT
*===============================================================================
quietly summarize Estimate_win, detail
local m      = r(mean)
local median = r(p50)

twoway scatter precision Estimate_win if precision<100 & SE_source=="bootstrap", ///
       mcolor("black%40") msymbol(smcircle_hollow) msize(small) ///
    || scatter precision Estimate_win if precision<100 & SE_source=="from_CI", ///
       mcolor(red) msymbol(smcircle) msize(small) ///
    , ytitle("Precision (1/SE)") xtitle("Optimal inflation rate") ///
      xline(`median', lpattern(dash) lcolor(black)) ///
      xline(`m',      lpattern(dot)  lcolor(black)) ///
      xline(0, lcolor(red)) xline(2, lcolor(orange) lpattern(dash)) ///
      legend(label(1 "Bootstrap SE") label(2 "Genuine SE")) ///
      graphregion(color(white)) saving(funnel_v34, replace)
graph export Graphs/v34_Funnel.pdf, replace

*===============================================================================
* 04. CALIPER TEST -- Gerber & Malhotra 2008
*  Two thresholds: pi=0 (Friedman rule) and pi=2 (inflation target)
*===============================================================================
capture program drop caliper_block
program define caliper_block
    syntax , JUMP(real) [ IF(string) TAG(string) ]
    if "`tag'"==""  local tag "Full"
    if "`if'"!=""   local cond "& `if'"

    est clear
    foreach w of numlist 0.5 1.0 1.5 2.0 {
        capture drop sig
        gen sig = (Estimate_win > `jump') if !missing(Estimate_win)
        quietly reg sig if Estimate_win >= `jump'-`w' & Estimate_win <= `jump'+`w' `cond'
        local wname = subinstr("`w'", ".", "_", .)
        label variable sig "Caliper `w'"
        eststo Cal_`wname'
        display "`tag' pi=`jump' width=`w': beta=" _b[_cons] " N=" e(N)
        drop sig
    }
    esttab using caliper_v34_`tag'_pi`=string(`jump',"%02.0f")'.tex, ///
        replace booktabs se cells(b(star fmt(3)) se(par fmt(3))) ///
        mtitles("w=0.5" "w=1.0" "w=1.5" "w=2.0")               ///
        title("Caliper test, `tag' (pi=`jump')")
end

caliper_block, jump(0)                                    // full sample, pi=0
caliper_block, jump(2)                                    // full sample, pi=2
caliper_block, jump(2) if("StickyPrices==1") tag("Sticky")
caliper_block, jump(2) if("Year>=2010")      tag("Recent")
caliper_block, jump(2) if("Preferred==1")    tag("Preferred")

*===============================================================================
* 05. FAT-PET / PEESE  (Stanley 2005, 2008)
*===============================================================================
est clear

* FAT-PET (OLS clustered)
eststo fatpet_ols: ///
    ivreg2 Estimate_win SE_win, cluster(idstudy)
* FAT-PET precision-weighted (WLS = regression of t on 1/SE)
eststo fatpet_wls: ///
    reg tstat precision, cluster(idstudy)
* PEESE: regress Estimate on SE^2 (passes through origin in precision-weighted form)
gen SE2_win = SE_win^2
eststo peese: ///
    ivreg2 Estimate_win SE2_win, cluster(idstudy)

esttab fatpet_ols fatpet_wls peese using table_FatPet_v34.tex, ///
    replace booktabs se nofloat ///
    varlabels(SE_win "SE (publication bias)" SE2_win "SE squared" ///
              precision "Precision (effect beyond bias)" ///
              _cons "Effect beyond bias / constant") ///
    mtitles("FAT-PET OLS" "FAT-PET WLS" "PEESE")

*===============================================================================
* 06. WAAP  -- Ioannidis, Stanley, Doucouliagos 2017
*===============================================================================
summarize Estimate_win [aweight=precision*precision]
local waapmean = r(mean)
scalar waapbound = abs(`waapmean')/2.8
di "WAAP bound = " waapbound

est clear
eststo waap: reg tstat precision if SE_win < waapbound, noconstant cluster(idstudy)
esttab waap using table_WAAP_v34.tex, replace booktabs se nofloat ///
    mtitle("WAAP") title("Weighted Average of Adequately-Powered estimates")

*===============================================================================
* 07. TOP10  -- Stanley, Jarrell, Doucouliagos 2010
*===============================================================================
summarize precision, detail
local top10p90 = r(p90)
di "TOP10 precision threshold (p90) = " `top10p90'
summarize Estimate_win if precision > `top10p90'

*===============================================================================
* 08. ANDREWS-KASY 2019  (export for https://maxkasy.github.io/home/metastudy )
*===============================================================================
preserve
    keep Estimate_win SE_win
    drop if missing(SE_win) | SE_win<=0
    outsheet Estimate_win SE_win using Selection_Kasy_v34.csv, comma nonames replace
restore

*===============================================================================
* 09. ENDOGENOUS KINK  (Bom & Rachinger 2020)
*===============================================================================
preserve
    keep if !missing(Estimate_win, SE_win) & SE_win>0
    rename Estimate_win bs
    rename SE_win       sebs
    gen ones = 1
    local M = _N
    quietly summarize sebs
    local sebs_min = r(min)
    local sebs_max = r(max)
    gen sebs2   = sebs^2
    gen wis     = 1/sebs2
    gen bs_sebs = bs/sebs
    gen ones_sebs = ones/sebs
    quietly summarize wis
    local wis_sum = r(sum)

    regress bs_sebs ones_sebs ones, noconstant
    local pet = _b[ones_sebs]
    local t1  = _b[ones_sebs]/_se[ones_sebs]
    local b_lin = _b[ones_sebs]
    local Q1_lin = e(rss)
    local abs_t1 = abs(`t1')

    regress bs_sebs ones_sebs sebs, noconstant
    local b_sq = _b[ones_sebs]
    local Q1_sq = e(rss)

    if `abs_t1' > invt(`M'-2, 0.975) {
        local combreg = `b_sq'
        local Q1      = `Q1_sq'
    }
    else {
        local combreg = `b_lin'
        local Q1      = `Q1_lin'
    }
    local sigh2 = max(0, `M'*((`Q1'/(`M'-e(df_m)-1)) - 1)/`wis_sum')
    local sighhat = sqrt(`sigh2')

    if `combreg' > 1.96*`sighhat' {
        local a1 = (`combreg' - 1.96*`sighhat')*(`combreg' + 1.96*`sighhat')/(2*1.96*`combreg')
    }
    else {
        local a1 = 0
    }

    rename bs       bs_original
    rename bs_sebs  bs
    rename ones_sebs constant
    rename ones     pub_bias

    display "Endogenous kink a1 = " `a1' ", sebs range = [" `sebs_min' ", " `sebs_max' "]"
    if `a1' > `sebs_min' & `a1' < `sebs_max' {
        gen sebs_a1 = sebs - `a1' if sebs > `a1'
        replace sebs_a1 = 0 if sebs <= `a1'
        gen pubbias = sebs_a1/sebs
        regress bs constant pubbias, noconstant
    }
    else if `a1' <= `sebs_min' {
        regress bs constant pub_bias, noconstant
    }
    else {
        regress bs constant, noconstant
    }
restore

*===============================================================================
* 10. EXPORT FOR p-uniform*  (preferred-only sub-sample, median per paper)
*===============================================================================
preserve
    keep if !missing(Estimate_win, SE_win) & SE_win>0
    bysort idstudy: egen est_med = median(Estimate_win)
    bysort idstudy: egen se_med  = median(SE_win)
    gen variance_med = se_med^2
    collapse (lastnm) est_med se_med variance_med, by(idstudy)
    save puniform_v34.dta, replace
    export delimited using puniform_v34.csv, replace
restore

*===============================================================================
* 11. HETEROGENEITY -- OLS clustered by idstudy
*  Using v3.3 dummies (drop one per block to avoid multicollinearity)
*===============================================================================
* Reference categories (implicit - omit these):
*   PR_Ramsey  (most common policy regime)
*   NFT_Calvo_prices
*   WC_unconditional
*   EST_calibration
*   SST_deterministic
*   EXP_rational
*   HZ_long_run
*   PUB_published
est clear
eststo het_full: ///
    reg Estimate_win SE_win ///
        PR_Friedman_rule PR_Inflation_targeting PR_Laissez_faire ///
        PR_Optimized_Taylor_rule PR_Taylor_rule PR_Zero_inflation ///
        PR_Ramsey_discretion PR_Estimated_policy ///
        NFT_Calvo_prices_and_wages NFT_Rotemberg_prices NFT_flexible ///
        NFT_Taylor_contracts NFT_menu_cost NFT_information_friction ///
        WRT_Calvo_wages WRT_DNWR WRT_Rotemberg_wages WRT_sticky_real_wages ///
        WRT_search_and_matching WRT_none ///
        MDT_CIA MDT_MIU MDT_cashless MDT_transactions_technology ///
        IND_past_inflation IND_trend_inflation IND_hybrid ///
        EST_Bayesian EST_GMM ///
        SEN_baseline SEN_comparison SEN_extension SEN_robustness_parameter ///
        EXP_adaptive EXP_learning EXP_heterogeneous ///
        WC_conditional_efficient_SS WC_consumption_equivalent ///
        SST_stochastic SST_transition ///
        ZLB Growth Ramsey ///
        AUG_ZLB AUG_financial_frictions AUG_heterogeneous_agents ///
        AUG_labor_market_frictions AUG_open_economy ///
        HZ_short_run PUB_working_paper PUB_NBER_WP ///
        Year LCitations LIF ///
        , cluster(idstudy)

esttab het_full using table_Heterogeneity_v34.tex, replace booktabs ///
    se compress nofloat label ///
    star(* 0.10 ** 0.05 *** 0.01)                                     ///
    title("Heterogeneity of optimal-inflation estimates (v3.3)")

*===============================================================================
* 12. BEST-PRACTICE estimate (lincom at sample means of methodological dummies,
*     impact factor at 90th pct, latest year, and 'preferred' dummies fixed)
*===============================================================================
foreach v of varlist PR_* NFT_* WRT_* MDT_* IND_* EST_* SEN_* EXP_* ///
                     WC_* SST_* AUG_* HZ_* PUB_* ZLB Growth Ramsey ///
                     Year LCitations LIF {
    quietly summarize `v'
    local m`v' = r(mean)
}
quietly summarize LCitations, detail
local p90LCitations = r(p90)
quietly summarize LIF, detail
local p90LIF        = r(p90)
quietly summarize Year, detail
local maxYear       = r(max)

* Best practice: SE_win=0 (no bias), preferred methodology (NFT Calvo prices,
* rational expectations, Ramsey policy, long horizon, published), latest year,
* top-decile journal quality.
lincom _cons + SE_win*0 ///
    + PR_Friedman_rule*0 + PR_Inflation_targeting*0 + PR_Laissez_faire*0 ///
    + PR_Optimized_Taylor_rule*0 + PR_Taylor_rule*0 + PR_Zero_inflation*0 ///
    + PR_Ramsey_discretion*0 + PR_Estimated_policy*0 ///
    + NFT_Calvo_prices_and_wages*0 + NFT_Rotemberg_prices*0 + NFT_flexible*0 ///
    + NFT_Taylor_contracts*0 + NFT_menu_cost*0 + NFT_information_friction*0 ///
    + WRT_Calvo_wages*0 + WRT_DNWR*0 + WRT_Rotemberg_wages*0 ///
    + WRT_sticky_real_wages*0 + WRT_search_and_matching*0 + WRT_none*0 ///
    + MDT_CIA*0 + MDT_MIU*0 + MDT_cashless*1 + MDT_transactions_technology*0 ///
    + IND_past_inflation*0 + IND_trend_inflation*0 + IND_hybrid*0 ///
    + EST_Bayesian*0 + EST_GMM*0 ///
    + SEN_baseline*1 + SEN_comparison*0 + SEN_extension*0 + SEN_robustness_parameter*0 ///
    + EXP_adaptive*0 + EXP_learning*0 + EXP_heterogeneous*0 ///
    + WC_conditional_efficient_SS*0 + WC_consumption_equivalent*0 ///
    + SST_stochastic*0 + SST_transition*0 ///
    + ZLB*1 + Growth*0 + Ramsey*1 ///
    + AUG_ZLB*1 + AUG_financial_frictions*0 + AUG_heterogeneous_agents*0 ///
    + AUG_labor_market_frictions*0 + AUG_open_economy*0 ///
    + HZ_short_run*0 + PUB_working_paper*0 + PUB_NBER_WP*0 ///
    + Year*`maxYear' + LCitations*`p90LCitations' + LIF*`p90LIF'

*===============================================================================
* 13. ROBUSTNESS SUBSAMPLES
*===============================================================================

* 13a. PREFERRED-ESTIMATE-ONLY (one per paper)
display _n(2) "*** ROBUSTNESS: Preferred==1 subsample ***"
est clear
eststo fatpet_pref: ivreg2 Estimate_win SE_win if Preferred==1, cluster(idstudy)
eststo peese_pref : ivreg2 Estimate_win SE2_win if Preferred==1, cluster(idstudy)
summarize Estimate_win if Preferred==1, detail

* 13b. GENUINE-SE-ONLY  (classical meta-analysis on rows where SE is sampling-based)
display _n(2) "*** ROBUSTNESS: se_is_genuine==1 subsample ***"
count if se_is_genuine==1
if r(N) >= 10 {
    eststo fatpet_gen: ivreg2 Estimate_win SE_win if se_is_genuine==1, cluster(idstudy)
    summarize Estimate_win if se_is_genuine==1, detail
    summarize Estimate_win [aweight=precision*precision] if se_is_genuine==1
    scalar waap_gen = abs(r(mean))/2.8
    di "Genuine-SE WAAP bound = " waap_gen
    reg tstat precision if se_is_genuine==1 & SE_win < waap_gen, noconstant
}
else {
    di "Not enough genuine-SE rows (N=" r(N) ") for classical meta; skip."
}

esttab fatpet_pref peese_pref fatpet_gen using table_Robust_v34.tex, replace ///
    booktabs se nofloat ///
    mtitles("Preferred FAT-PET" "Preferred PEESE" "Genuine-SE FAT-PET")

* Block 1 (k=116 preferred-row sample): FAT-PET + PEESE.
esttab fatpet_pref peese_pref using table_Robust_Block1_v34.tex, replace ///
    booktabs se nofloat ///
    mtitles("Preferred FAT-PET" "Preferred PEESE")

* Block 2 (k=16, 3 paper clusters): genuine-SE FAT-PET, flagged not robust.
esttab fatpet_gen using table_Robust_Block2_v34.tex, replace ///
    booktabs se nofloat ///
    mtitles("Genuine-SE FAT-PET")

summarize Estimate_win SE_win precision

log close
