#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
phase1_normalize.py — free data-quality fixes on v3_0_full/extracted_enriched.xlsx.

Produces:
  AI_dataset/v3_0_full/extracted_enriched_phase1.xlsx
  AI_dataset/v3_0_full/phase1_issues.csv   (rows flagged for manual review)

Additions:
  * Results_Inflation_Annualized_Pct   — all values normalized to annual %.
  * Unit_Mixed_In_Paper                 — 1 if the paper uses >1 unit.
  * Outlier_Flag                        — 'high_inflation_legit' / 'suspicious'.
  * Manual_Review_Required              — reason string or "".
  * Manual fixes applied, each logged in phase1_issues.csv.

No API calls, no cost.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

import argparse

REPO = Path(__file__).resolve().parent.parent
# Default: operate on v3_0_full (v3.3 schema) output.
DEFAULT_DIR = REPO / "AI_dataset" / "v3_0_full"

# Unit -> annual-pct multiplier
UNIT_FACTOR = {
    "annual_pct":        1.0,
    "quarterly_pct":     4.0,
    "monthly_pct":       12.0,
    "decimal_annual":    100.0,
    "decimal_quarterly": 400.0,
}


def coerce_float(x):
    if pd.isna(x) or x in ("NA", "", None):
        return np.nan
    try:
        return float(str(x).replace(",", ""))
    except (TypeError, ValueError):
        return np.nan


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", type=Path, default=DEFAULT_DIR,
                    help="Folder containing extracted_enriched.xlsx")
    args = ap.parse_args()
    SRC = args.dir / "extracted_enriched.xlsx"
    OUT_XLSX = args.dir / "extracted_enriched_phase1.xlsx"
    OUT_ISSUES = args.dir / "phase1_issues.csv"
    df = pd.read_excel(SRC)
    n0 = len(df)
    print(f"Loaded {n0} rows x {len(df.columns)} cols from {SRC.name}")

    issues: list[dict] = []

    # --- 1. Normalize to annual % -----------------------------------------
    inf = df["Results_Inflation"].map(coerce_float)
    factor = df["Inflation_Unit"].map(UNIT_FACTOR).astype(float)
    df["Results_Inflation_Annualized_Pct"] = inf * factor

    unknown_unit = df["Inflation_Unit"].isin(["unknown", "NA", "", None]) | df["Inflation_Unit"].isna()
    df.loc[unknown_unit, "Results_Inflation_Annualized_Pct"] = np.nan

    n_missing_annual = df["Results_Inflation_Annualized_Pct"].isna().sum()
    print(f"  Results_Inflation_Annualized_Pct: {n0 - n_missing_annual} rows filled, {n_missing_annual} NA")

    # --- 2. Mixed unit detection ------------------------------------------
    units_per_paper = (
        df[df["Inflation_Unit"].astype(str).str.match(r"(annual|quarterly|monthly|decimal)_")]
        .groupby("Idstudy")["Inflation_Unit"]
        .nunique()
    )
    mixed_papers = units_per_paper[units_per_paper > 1].index.tolist()
    df["Unit_Mixed_In_Paper"] = df["Idstudy"].isin(mixed_papers).astype(int)
    print(f"  Mixed-unit papers: {mixed_papers}")
    for idst in mixed_papers:
        sub = df[df["Idstudy"] == idst]
        issues.append({
            "Idstudy": idst,
            "IdEstimate": "ALL",
            "Author": sub["Author"].iloc[0],
            "Issue": "Mixed Inflation_Unit within paper",
            "Detail": f"Units used: {sorted(sub['Inflation_Unit'].unique().tolist())}",
            "Action": "Manual review: harmonize units",
        })

    # --- 3. Outlier flags --------------------------------------------------
    df["Outlier_Flag"] = ""
    abs_ann = df["Results_Inflation_Annualized_Pct"].abs()
    mask_big = abs_ann > 20.0
    df.loc[mask_big, "Outlier_Flag"] = "extreme_value"

    # Known-legit high-inflation regimes (manual whitelist from audit)
    legit_extreme = [
        (9045, "Cooley-Hansen 1989 high-inflation steady state"),
        (9130, "Rotemberg-Woodford 1997 minimum-L policy"),
        (9135, "SGU 2005 full-indexation result"),
        (9123, "Paczos 2020 flex-price monetary union"),
        (9154, "Wolman 2001 discretionary equilibrium"),
        (9121, "Nuño-Thomas 2022 short-duration bond case"),
    ]
    for idst, reason in legit_extreme:
        m = (df["Idstudy"] == idst) & (df["Outlier_Flag"] == "extreme_value")
        df.loc[m, "Outlier_Flag"] = f"legit_high_inflation: {reason}"

    # Suspicious extremes still flagged 'extreme_value' → issue log
    for _, r in df[df["Outlier_Flag"] == "extreme_value"].iterrows():
        issues.append({
            "Idstudy": int(r["Idstudy"]),
            "IdEstimate": r["IdEstimate"],
            "Author": r["Author"],
            "Issue": "Extreme value (|annual %| > 20) not whitelisted",
            "Detail": f"pi={r['Results_Inflation']} unit={r['Inflation_Unit']} ann={r['Results_Inflation_Annualized_Pct']:.2f}",
            "Action": "Verify against PDF table",
        })

    # --- 4. Known extraction errors (from audit) --------------------------
    # Kollmann 2008 id=5: pi=13.24 quarterly is SD of inflation, not optimal pi
    m_kollmann = (df["Idstudy"] == 9097) & (df["IdEstimate"] == 5)
    if m_kollmann.any():
        df.loc[m_kollmann, "Manual_Review_Required"] = (
            "Kollmann 2008 row 5: value 13.24 is SD of inflation, not optimal π — exclude or relabel"
        )
        issues.append({
            "Idstudy": 9097, "IdEstimate": 5,
            "Author": df.loc[m_kollmann, "Author"].iloc[0],
            "Issue": "Mislabeled: SD of inflation extracted as optimal π",
            "Detail": "Table 1 col 5 reports SD(π), not steady-state π",
            "Action": "Exclude from BMA or move value to Std_Dev_Inflation",
        })

    # Adão-Correia-Teles 2001: Ramsey analysis miscoded as Ramsey_Rule=0
    # (find by Idstudy matching Adão author string)
    mask_adao = df["Author"].astype(str).str.contains("Adão", na=False) | \
                df["Author"].astype(str).str.contains("Adao", na=False)
    if mask_adao.any():
        ids_adao = df.loc[mask_adao, "Idstudy"].unique().tolist()
        for idst in ids_adao:
            m = df["Idstudy"] == idst
            issues.append({
                "Idstudy": int(idst), "IdEstimate": "ALL",
                "Author": df.loc[m, "Author"].iloc[0],
                "Issue": "Possible Ramsey_Rule miscoding",
                "Detail": "Adão et al. papers typically conduct Ramsey analysis",
                "Action": "Verify Ramsey_Rule flag against paper §Proposition 2",
            })

    # Jiang 2022: Ramsey_Rule paper-level — all 8 rows flagged, 4 are laissez-faire
    mask_jiang = df["Author"].astype(str).str.contains("Jiang", na=False)
    if mask_jiang.any():
        for idst in df.loc[mask_jiang, "Idstudy"].unique().tolist():
            issues.append({
                "Idstudy": int(idst), "IdEstimate": "ALL",
                "Author": df.loc[df["Idstudy"] == idst, "Author"].iloc[0],
                "Issue": "Row-level Ramsey_Rule needed",
                "Detail": "Ramsey_Rule is paper-level but Jiang compares Ramsey vs laissez-faire in same table",
                "Action": "v3.3 Policy_Regime row-level will fix",
            })

    # --- 5. Ensure Manual_Review_Required column exists -------------------
    if "Manual_Review_Required" not in df.columns:
        df["Manual_Review_Required"] = ""
    df["Manual_Review_Required"] = df["Manual_Review_Required"].fillna("")

    # --- 6. Save ----------------------------------------------------------
    df.to_excel(OUT_XLSX, index=False)
    print(f"\nWrote {len(df)} rows x {len(df.columns)} cols -> {OUT_XLSX.name}")

    issues_df = pd.DataFrame(issues)
    issues_df.to_csv(OUT_ISSUES, index=False, encoding="utf-8")
    print(f"Wrote {len(issues_df)} issues -> {OUT_ISSUES.name}")

    print("\nSummary by Outlier_Flag:")
    print(df["Outlier_Flag"].value_counts(dropna=False).to_string())
    print("\nSummary by Inflation_Unit:")
    print(df["Inflation_Unit"].value_counts(dropna=False).to_string())
    print("\nAnnualized stats:")
    ann = df["Results_Inflation_Annualized_Pct"].dropna()
    print(f"  n={len(ann)} mean={ann.mean():.3f} median={ann.median():.3f} "
          f"std={ann.std():.3f} min={ann.min():.3f} max={ann.max():.3f}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
