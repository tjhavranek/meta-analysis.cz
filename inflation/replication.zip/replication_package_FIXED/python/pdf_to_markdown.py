#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PDF -> Markdown conversion via opendataloader-pdf.

Purpose
-------
The round-1 audit (Abo-Zaid 2015) showed that PyPDF2-based text extraction
flattened tables into unstructured whitespace-separated lines, which is the
most likely root cause of the missed-tables and column-shift failures.
opendataloader-pdf emits properly delimited Markdown tables that Claude
reads much more reliably than raw PyPDF2 text.

This module is a thin wrapper. It caches conversions so that re-runs over
the same corpus do not repeat work. Cache key = SHA256 of the PDF bytes,
so edits to the PDF invalidate the cache automatically.

Public API
----------
    convert_pdf_to_markdown(pdf_path) -> str
        Returns the full Markdown. Cached on disk under
        ai_dataset/markdown_cache/<sha256>.md .
"""
from __future__ import annotations

import hashlib
import logging
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

logger = logging.getLogger(__name__)

REPO_ROOT = Path(__file__).resolve().parent.parent
CACHE_DIR = REPO_ROOT / "ai_dataset" / "markdown_cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _run_opendataloader(pdf_path: Path, out_dir: Path) -> Path:
    """Invoke opendataloader-pdf CLI; return path to the produced .md file."""
    # opendataloader-pdf CLI: `opendataloader-pdf -i <pdf> -o <out_dir>
    #   --generate-markdown` (flags per README). Invoked via python -m so we
    # use whichever interpreter is running this module.

    # Windows workaround: if filename contains non-ASCII characters (e.g.
    # U+2010 hyphen, em-dash), subprocess argv encoding mangles them and the
    # Java CLI reports "File not found". Copy to an ASCII-only temp name first.
    src_pdf = pdf_path
    ascii_copy: Path | None = None
    try:
        pdf_path.name.encode("ascii")
    except UnicodeEncodeError:
        ascii_copy = out_dir / "input.pdf"
        shutil.copyfile(pdf_path, ascii_copy)
        src_pdf = ascii_copy

    cmd = [
        sys.executable, "-m", "opendataloader_pdf",
        str(src_pdf),
        "-o", str(out_dir),
        "-f", "markdown",
    ]
    logger.info("opendataloader-pdf: %s", " ".join(cmd))
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    if result.returncode != 0:
        raise RuntimeError(
            f"opendataloader-pdf failed (exit {result.returncode}):\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )
    # Find the produced .md file (name depends on opendataloader version).
    md_files = sorted(out_dir.rglob("*.md"))
    if not md_files:
        raise RuntimeError(
            f"opendataloader-pdf produced no .md files in {out_dir}. "
            f"stdout: {result.stdout[:500]}"
        )
    # If multiple, concatenate them in sort order.
    if len(md_files) == 1:
        return md_files[0]
    combined = out_dir / "combined.md"
    combined.write_text(
        "\n\n".join(p.read_text(encoding="utf-8", errors="replace") for p in md_files),
        encoding="utf-8",
    )
    return combined


def convert_pdf_to_markdown(pdf_path: str | Path, *, force: bool = False) -> str:
    """Return Markdown text for `pdf_path`, using a persistent SHA-keyed cache."""
    pdf_path = Path(pdf_path)
    if not pdf_path.is_file():
        raise FileNotFoundError(pdf_path)

    key = _sha256(pdf_path)
    cache_file = CACHE_DIR / f"{key}.md"
    if cache_file.is_file() and not force:
        logger.debug("markdown cache hit: %s -> %s", pdf_path.name, cache_file.name)
        return cache_file.read_text(encoding="utf-8", errors="replace")

    with tempfile.TemporaryDirectory(prefix="odl_") as tmp:
        tmp_dir = Path(tmp)
        md_path = _run_opendataloader(pdf_path, tmp_dir)
        md_text = md_path.read_text(encoding="utf-8", errors="replace")

    cache_file.write_text(md_text, encoding="utf-8")
    logger.info("markdown cached: %s (%d chars) -> %s", pdf_path.name, len(md_text), cache_file.name)
    return md_text


if __name__ == "__main__":
    # CLI smoke test:  python pdf_to_markdown.py <file.pdf>
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    if len(sys.argv) != 2:
        print("usage: python pdf_to_markdown.py <file.pdf>")
        sys.exit(2)
    md = convert_pdf_to_markdown(sys.argv[1])
    print(f"--- Markdown ({len(md)} chars) ---")
    print(md[:2000])
    print("...")
