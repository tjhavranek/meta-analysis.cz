#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Raw-AI archival helper.

Cook et al. (2026) Journal of Economic Surveys guidance on AI meta-analysis,
Principle 3 (Human Auditing, \u00a72.3), requires that the pre-correction AI
output be preserved so that the AI-vs-human concordance (Cohen's \u03ba) can be
computed after curation. The existing extraction pipeline
(`2025/INFLATION_1_6-PDF_all-CACHE.py`) used to write only the final DataFrame;
this helper adds a locked, timestamped sidecar per paper.

Integration (3 lines in INFLATION_1_6-PDF_all-CACHE.py):

    from raw_ai_archiver import archive_raw_extraction
    ...
    # right after the AI has returned the per-paper rows as a DataFrame
    archive_raw_extraction(pdf_path, df_rows,
                           prompt_version="Super_v3",
                           model="claude-opus-4-20250514")

The sidecar is written to `ai_dataset/raw_AI_output/` with filename
    <Author_Year>__<YYYYMMDD-HHMMSS>__<prompt_version>__<model>.xlsx
and is made read-only on Windows via the archive attribute so curators do not
accidentally overwrite it. A matching `.manifest.json` records the prompt hash,
model, and file hash for audit purposes.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import re
import stat
from pathlib import Path
from typing import Iterable

import pandas as pd

REPO_ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = REPO_ROOT / "ai_dataset" / "raw_AI_output"
RAW_DIR.mkdir(parents=True, exist_ok=True)


def _slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "_", text).strip("_")[:80]


def _hash_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _paper_key(pdf_path: Path) -> str:
    """Extract Author_Year from filename; fall back to stem."""
    m = re.match(r"^([A-Za-z][A-Za-z-]+)_(\d{4})", pdf_path.name)
    return f"{m.group(1)}_{m.group(2)}" if m else _slug(pdf_path.stem)


def archive_raw_extraction(
    pdf_path: str | os.PathLike,
    rows: "pd.DataFrame | list[dict]",
    *,
    prompt_version: str,
    model: str,
    extra_meta: dict | None = None,
) -> Path:
    """
    Write the raw AI extraction for one paper to ai_dataset/raw_AI_output/.

    Returns the path to the written .xlsx sidecar.
    """
    pdf_path = Path(pdf_path)
    if isinstance(rows, list):
        df = pd.DataFrame(rows)
    else:
        df = rows.copy()

    ts = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    key = _paper_key(pdf_path)
    fname = f"{key}__{ts}__{_slug(prompt_version)}__{_slug(model)}.xlsx"
    out = RAW_DIR / fname

    with pd.ExcelWriter(out, engine="openpyxl") as w:
        df.to_excel(w, sheet_name="raw_ai", index=False)

    meta = {
        "pdf": pdf_path.name,
        "paper_key": key,
        "timestamp": ts,
        "prompt_version": prompt_version,
        "model": model,
        "n_rows": len(df),
        "columns": list(df.columns),
        "sha256": _hash_file(out),
        **(extra_meta or {}),
    }
    (out.with_suffix(".manifest.json")).write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    # mark read-only (best effort, Windows-compatible)
    try:
        os.chmod(out, stat.S_IREAD)
    except Exception:
        pass

    return out


def latest_for_paper(paper_key: str) -> Path | None:
    """Convenience: return the most recent sidecar for a given Author_Year key."""
    matches = sorted(RAW_DIR.glob(f"{paper_key}__*.xlsx"))
    return matches[-1] if matches else None


if __name__ == "__main__":
    # tiny smoke test
    import pandas as pd  # noqa: F811
    demo = pd.DataFrame([{"Idstudy": 1, "IdEstimate": 1, "Results_Inflation": -1.23}])
    out = archive_raw_extraction(
        Path("Demo_2024_example.pdf"),
        demo,
        prompt_version="Super_v3",
        model="claude-opus-4-20250514",
        extra_meta={"note": "smoke test"},
    )
    print(f"wrote {out}")
