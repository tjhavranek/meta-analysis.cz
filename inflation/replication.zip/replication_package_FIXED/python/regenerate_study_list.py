"""Regenerate ai_dataset/_study_list_v34.csv from the canonical .dta.

Per Tomáš review item R-c: the existing CSV has a ghost row (Idstudy 9075),
out-of-scope IDs (9072), an excluded study (9054), a duplicate (9040), and is
missing 9158 (Lipinska), 9200/9201 (Andrade et al.). We rebuild it directly
from inflation_v34.dta so it always matches the analysis pipeline.

Output schema (one row per Idstudy):
    Idstudy, Author, Year, Title, Journal_Name, Hand_Coded_Training

* Idstudy / Author / Year      -- straight from the .dta (most-frequent value
                                  per Idstudy when the .dta has minor variants).
* Title / Journal_Name         -- carried over from the previous CSV where the
                                  Idstudy survives; filled from a hard-coded
                                  lookup for the three IDs that were missing
                                  (9158, 9200, 9201) so the output is complete.
* Hand_Coded_Training          -- 1 for the 7 papers used in the inter-rater
                                  agreement table (tab:irr_v34); 0 otherwise.
                                  These are the papers that compute_audit.py
                                  scores against the hand-coded ground truth.

Usage:
    python regenerate_study_list.py
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
DTA = ROOT / "replication_package_FIXED/stata/inflation_v34.dta"
OLD_CSV = ROOT / "replication_package_FIXED/ai_dataset/_study_list_v34.csv"
OUT_CSV = ROOT / "replication_package_FIXED/ai_dataset/_study_list_v34.csv"

# Idstudy of the 7 hand-coded training papers (matches round1_inputs/
# hand_truth_7papers.csv that compute_audit.py reads and that reproduces
# tab:irr_v34 cell-for-cell).
TRAINING_IDSTUDIES = {9000, 9001, 9002, 9004, 9007, 9008, 9009}

# Title / Journal_Name for IDs that were missing from the old CSV.
# Verified against Bibl.bib (lipinska2015optimal, andrade2019optimal,
# andrade2021should).
MISSING_LOOKUP = {
    9158: {
        "Title": "Optimal Monetary Policy for the EMU Accession Countries: "
                 "A New Keynesian Approach",
        "Journal_Name": "Macroeconomic Dynamics",
    },
    9200: {
        "Title": "The Optimal Inflation Target and the Natural Rate of Interest",
        "Journal_Name": "NBER Working Paper",
    },
    9201: {
        "Title": "Should the ECB Adjust its Strategy in the Face of a Lower r*?",
        "Journal_Name": "Journal of Economic Dynamics and Control",
    },
    # 9005 was an "Adam (2019)" stub in the old CSV with no Title; matches
    # adam2019optinf in Bibl.bib (Adam & Weber, AER 109(2)).
    9005: {
        "Title": "Optimal Trend Inflation",
        "Journal_Name": "American Economic Review",
    },
}


def _mode_or_first(series: pd.Series):
    """Return the most-frequent non-null value, or the first non-null one."""
    s = series.dropna()
    if len(s) == 0:
        return None
    counts = s.value_counts()
    return counts.index[0]


def main() -> None:
    dta = pd.read_stata(DTA)
    old = pd.read_csv(OLD_CSV)

    # Per-Idstudy author/year from the .dta (canonical).
    grouped = (
        dta.groupby("Idstudy")
        .agg(Author=("Author", _mode_or_first), Year=("Year", _mode_or_first))
        .reset_index()
        .sort_values("Idstudy", kind="stable")
        .reset_index(drop=True)
    )

    # Title / Journal_Name look-up: prefer the old CSV row, fall back to
    # MISSING_LOOKUP, otherwise leave empty.
    title_map = (
        old.dropna(subset=["Idstudy"])
        .drop_duplicates("Idstudy")
        .set_index("Idstudy")[["Title", "Journal_Name"]]
        .to_dict(orient="index")
    )

    titles, journals = [], []
    for sid in grouped["Idstudy"]:
        if sid in title_map and pd.notna(title_map[sid].get("Title")):
            titles.append(title_map[sid]["Title"])
            journals.append(title_map[sid].get("Journal_Name"))
        elif sid in MISSING_LOOKUP:
            titles.append(MISSING_LOOKUP[sid]["Title"])
            journals.append(MISSING_LOOKUP[sid]["Journal_Name"])
        else:
            titles.append(None)
            journals.append(None)

    grouped["Title"] = titles
    grouped["Journal_Name"] = journals
    grouped["Hand_Coded_Training"] = grouped["Idstudy"].isin(TRAINING_IDSTUDIES).astype(int)
    grouped["Year"] = grouped["Year"].astype("Int64")

    grouped = grouped[["Idstudy", "Author", "Year", "Title", "Journal_Name",
                       "Hand_Coded_Training"]]
    grouped.to_csv(OUT_CSV, index=False)

    print(f"Wrote {OUT_CSV}")
    print(f"  rows:                 {len(grouped)}")
    print(f"  unique Idstudy:       {grouped['Idstudy'].nunique()}")
    print(f"  ghost (NaN Idstudy):  {grouped['Idstudy'].isna().sum()}")
    print(f"  Hand_Coded_Training:  {grouped['Hand_Coded_Training'].sum()}")
    missing_titles = grouped["Title"].isna().sum()
    if missing_titles:
        print(f"  rows with empty Title: {missing_titles} (review)")


if __name__ == "__main__":
    main()
