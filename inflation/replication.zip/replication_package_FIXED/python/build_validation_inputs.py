"""build_validation_inputs.py

Construct the small CSV inputs that ``compute_audit.py`` consumes to
reproduce manuscript Table 14 (``tab:irr_v34`` — inter-rater agreement
on the 7 hand-coded training papers). The original computation in
``2025/cohen_kappa_audit.py`` reads two large internal Excel files that
contain copyrighted excerpts and are not redistributable. This script
extracts only the 7 paper-level rows × 9 fields needed for the κ
calculation and writes them to two small, redistribution-safe CSVs in
``ai_dataset/validation/round1_inputs/``:

    hand_truth_7papers.csv  -- human-curated training set (7 rows)
    ai_extraction_7papers.csv -- raw AI extraction for the same 7 papers (7 rows)

Run from the repository root *of the unpublished workspace* (the place
that holds ``AI_dataset/``):

    python Dropbox_Tomas/replication_package_FIXED/python/build_validation_inputs.py

The resulting CSVs live inside the replication package and ARE shipped.
End users running the published replication package only need to run
``compute_audit.py``; they do not need to re-run this script.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Paths (relative to the workspace that holds AI_dataset/)
# ---------------------------------------------------------------------------
HERE = Path(__file__).resolve()
PKG_ROOT = HERE.parent.parent           # replication_package_FIXED/
DROPBOX_ROOT = PKG_ROOT.parent          # Dropbox_Tomas/
WORKSPACE_ROOT = DROPBOX_ROOT.parent    # workspace root with AI_dataset/

HAND_PATH = WORKSPACE_ROOT / "AI_dataset" / "meta_analysis_data_corrected_ORIG.xlsx"
AI_PATH = WORKSPACE_ROOT / "AI_dataset" / "v3_0_full" / "extracted_enriched_phase1.xlsx"

OUT_DIR = PKG_ROOT / "ai_dataset" / "validation" / "round1_inputs"
OUT_DIR.mkdir(parents=True, exist_ok=True)
HAND_OUT = OUT_DIR / "hand_truth_7papers.csv"
AI_OUT = OUT_DIR / "ai_extraction_7papers.csv"

# Hand Idstudy (1..7) -> AI Idstudy (9000+) mapping, established by
# matching Author + Year + (working-paper -> published version) by hand.
# This is the same mapping used in 2025/cohen_kappa_audit.py.
HAND_TO_AI: dict[int, int] = {
    1: 9001,  # Abo-Zaid & Garin 2015 (WP) -> 2016 (Economic Inquiry)
    2: 9000,  # Abo-Zaid 2013 (JEDC)
    3: 9002,  # Abo-Zaid 2015
    4: 9004,  # Adam & Billi 2006 (JME)
    5: 9007,  # Amano et al. 2007
    6: 9008,  # Amano et al. 2009
    7: 9009,  # Amato & Laubach 2004
}

BINARY_FIELDS = [
    "Augmented_base_model",
    "Ramsey_Rule",
    "HH_Included",
    "Firms_Included",
    "Banks_Included",
    "Government_Included",
    "Other_Agent_Included",
    "Empirical_Research",
]


def paper_mode(df: pd.DataFrame, idcol: str, fields: list[str]) -> pd.DataFrame:
    """Reduce rows to one per paper using mode for binaries."""
    out = {}
    for f in fields:
        if f in df.columns:
            out[f] = df.groupby(idcol)[f].agg(
                lambda s: s.dropna().mode().iloc[0] if s.dropna().size else np.nan
            )
    return pd.DataFrame(out)


def main() -> None:
    if not HAND_PATH.exists():
        raise SystemExit(
            f"Cannot find hand-coded source {HAND_PATH}.\n"
            "This script must run from the unpublished workspace that "
            "contains AI_dataset/."
        )
    if not AI_PATH.exists():
        raise SystemExit(f"Cannot find AI extraction source {AI_PATH}.")

    hand = pd.read_excel(HAND_PATH)
    ai = pd.read_excel(AI_PATH)

    # Hand-coded paper-level reduction.
    hand_paper = paper_mode(hand, "Idstudy", BINARY_FIELDS)
    hand_means = hand.groupby("Idstudy")["Results_Inflation"].mean().rename("paper_mean_pi")
    hand_authors = hand.groupby("Idstudy")["Author"].agg(
        lambda s: s.dropna().mode().iloc[0] if s.dropna().size else ""
    ).rename("Author")
    hand_full = pd.concat([hand_authors, hand_paper, hand_means], axis=1).reset_index()
    hand_full = hand_full[hand_full["Idstudy"].isin(HAND_TO_AI.keys())].copy()
    hand_full = hand_full.sort_values("Idstudy").reset_index(drop=True)

    # AI paper-level reduction.
    ai_paper = paper_mode(ai, "Idstudy", BINARY_FIELDS)
    ai_col = (
        "Results_Inflation_Annualized_Pct"
        if "Results_Inflation_Annualized_Pct" in ai.columns
        else "Results_Inflation"
    )
    ai_means = ai.groupby("Idstudy")[ai_col].mean().rename("paper_mean_pi")
    ai_authors = ai.groupby("Idstudy")["Author"].agg(
        lambda s: s.dropna().mode().iloc[0] if s.dropna().size else ""
    ).rename("Author")
    ai_full = pd.concat([ai_authors, ai_paper, ai_means], axis=1).reset_index()
    ai_full = ai_full[ai_full["Idstudy"].isin(HAND_TO_AI.values())].copy()
    # Re-key to the hand-coded 1..7 system so the two files line up
    # row-for-row in compute_audit.py.
    inverse = {v: k for k, v in HAND_TO_AI.items()}
    ai_full["Idstudy_hand"] = ai_full["Idstudy"].map(inverse)
    ai_full = ai_full.rename(columns={"Idstudy": "Idstudy_ai"})
    cols = ["Idstudy_hand", "Idstudy_ai", "Author", *BINARY_FIELDS, "paper_mean_pi"]
    ai_full = ai_full[cols].sort_values("Idstudy_hand").reset_index(drop=True)

    # Round binaries to nullable integers for clarity.
    for f in BINARY_FIELDS:
        hand_full[f] = pd.to_numeric(hand_full[f], errors="coerce").astype("Int64")
        ai_full[f] = pd.to_numeric(ai_full[f], errors="coerce").astype("Int64")

    hand_full.to_csv(HAND_OUT, index=False, encoding="utf-8")
    ai_full.to_csv(AI_OUT, index=False, encoding="utf-8")
    print(f"Wrote {HAND_OUT.relative_to(PKG_ROOT)} ({len(hand_full)} rows).")
    print(f"Wrote {AI_OUT.relative_to(PKG_ROOT)} ({len(ai_full)} rows).")


if __name__ == "__main__":
    main()
