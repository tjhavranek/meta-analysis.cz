#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
INFLATION_2_0.py — Meta-analysis extraction pipeline (April 2026 rebuild).

Replaces INFLATION_1_6-PDF_all-CACHE.py. Changes:
  * PDF -> Markdown via opendataloader-pdf (replaces PyPDF2 text flattening).
  * Prompts assembled from prompts/v3_3/{Super_v3_2.md, Super_v3_3.md,
    taxonomy.md}: v3.2 is the base ruleset, v3.3 layers on 15 new columns,
    and taxonomy.md is the closed vocabulary referenced by both. The three
    files are concatenated by load_system_prompt() in that order so the
    model receives the full instruction stack.
  * Models: Sonnet 4.5 (cheap stages), Opus 4.5 (structure + results).
  * Prompt caching: markdown body cached once, reused across the 4 stages,
    so we pay ingest cost only once per paper.
  * Strict JSON parsing (no TSV column shifting).
  * Per-paper raw AI archive via raw_ai_archiver.archive_raw_extraction.
  * Num_Citations and Impact_Factor are filled post-hoc (Scopus) — the AI is
    explicitly told these fields are NA.
  * Preferred_Estimate validator (exactly one =1 per paper).

Usage
-----
    python 2025/INFLATION_2_0.py --papers Literature/Abo_Zaid_2012*.pdf \
                                 --out ai_dataset/v3_0_pilot

    # Full run on PDFs (those added since 2026-04-01):
    python 2025/INFLATION_2_0.py --since 2026-04-01 --out ai_dataset/v3_0_full
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import re
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from config import (  # type: ignore  # noqa: E402
    CLAUDE_API_KEY,
    MODEL_PRE_SCAN, MODEL_METADATA, MODEL_STRUCTURE, MODEL_RESULTS, MODEL_FALLBACK,
    SCOPUS_API_KEY,
)
from pdf_to_markdown import convert_pdf_to_markdown  # noqa: E402
from raw_ai_archiver import archive_raw_extraction  # noqa: E402

import anthropic  # noqa: E402

REPO_ROOT = HERE.parent
PROMPT_VERSION = "Super_v3_3"
PROMPT_DIR = HERE / "prompts" / "v3_3"
# v3.3 explicitly states "All v3.2 rules remain in force" and references
# taxonomy.md "alongside this file". We therefore send all three to the
# model in this order: base rules (v3.2) -> delta (v3.3) -> taxonomy.
PROMPT_PARTS: list[Path] = [
    PROMPT_DIR / "Super_v3_2.md",
    PROMPT_DIR / "Super_v3_3.md",
    PROMPT_DIR / "taxonomy.md",
]
# Backwards-compatible alias used by tooling that inspected the old constant.
PROMPT_PATH = PROMPT_DIR / "Super_v3_3.md"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)
logger = logging.getLogger("inflation_2_0")

# Canonical 72-column schema (v3.3 = v3.2 + 15 new columns).
# New in v3.3: Publication_Status (metadata),
#   Nominal_Friction_Type / Wage_Rigidity_Type / Money_Demand_Tech /
#   Indexation_Type (structure), Policy_Regime / Shock_Type /
#   Welfare_Criterion / Steady_State_Type / Sensitivity_Type /
#   Expectations / Sample_Size / Sample_Period_Start /
#   Sample_Period_End / Estimator_Type (results).
COLUMNS: list[str] = [
    "Idstudy", "IdEstimate",
    "Title",
    "Author", "Author_Affiliation", "DOI", "Journal_Name", "Num_Citations", "Year",
    "Model_Class", "Model_Paradigm", "Publication_Status",
    "Augmented_base_model", "Augmentation_Description",
    "Augmentation_Category", "Ramsey_Rule",
    "HH_Included", "Firms_Included", "Banks_Included", "Government_Included",
    "HH_Maximization_Type", "HH_Maximized_Vars",
    "Producer_Type", "Producer_Assumption",
    "Other_Agent_Included", "Other_Agent_Assumptions",
    "Empirical_Research", "Country", "Calibration_Frequency",
    "Nominal_Friction_Type", "Wage_Rigidity_Type",
    "Money_Demand_Tech", "Indexation_Type",
    "Flexible_Price_Assumption", "Exogenous_Inflation", "Growth_Included",
    "Households_discount_factor", "Consumption_curvature_parameter",
    "Disutility_of_labor", "Inverse_of_labor_supply_elasticity",
    "Money_curvature_parameter", "Loan_to_value_ratio", "Labor_share_of_output",
    "Depositors_discount_factor", "Price_adjustment_cost",
    "Elasticity_of_substitution_between_goods",
    "AR1_coefficient_of_TFP", "Std_dev_to_TFP_shock",
    "Zero_Lower_Bound", "Results_Table",
    "Results_Inflation", "Inflation_Unit", "Horizon",
    "Results_Inflation_CI_Low", "Results_Inflation_CI_High", "Results_Inflation_CI_Level",
    "Results_Inflation_Assumption",
    "Preferred_Estimate", "Reason_for_Preferred",
    "Std_Dev_Inflation", "SE_Derivation", "Interest_Rate", "Impact_Factor",
    "Policy_Regime", "Shock_Type", "Welfare_Criterion",
    "Steady_State_Type", "Sensitivity_Type", "Expectations",
    "Sample_Size", "Sample_Period_Start", "Sample_Period_End",
    "Estimator_Type",
]

STAGE_MODEL = {
    "pre_scan":  MODEL_PRE_SCAN,
    "metadata":  MODEL_METADATA,
    "structure": MODEL_STRUCTURE,
    "results":   MODEL_RESULTS,
}
STAGE_MAX_TOKENS = {
    "pre_scan":  1500,
    "metadata":  2000,
    "structure": 3000,
    "results":   16000,
}

# Pricing (USD per 1M tokens) for logging. April 2026 list prices.
PRICES = {
    "claude-opus-4-5":       {"in": 15.0, "out": 75.0, "cache_read": 1.50, "cache_write": 18.75},
    "claude-sonnet-4-5":     {"in":  3.0, "out": 15.0, "cache_read": 0.30, "cache_write":  3.75},
    "claude-haiku-4-5":      {"in":  1.0, "out":  5.0, "cache_read": 0.10, "cache_write":  1.25},
}


@dataclass
class CostTracker:
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read: int = 0
    cache_write: int = 0
    by_model: dict[str, dict] = field(default_factory=dict)

    def add(self, model: str, usage) -> None:
        slot = self.by_model.setdefault(model, dict(input=0, output=0, cr=0, cw=0))
        i = getattr(usage, "input_tokens", 0) or 0
        o = getattr(usage, "output_tokens", 0) or 0
        cr = getattr(usage, "cache_read_input_tokens", 0) or 0
        cw = getattr(usage, "cache_creation_input_tokens", 0) or 0
        slot["input"] += i
        slot["output"] += o
        slot["cr"] += cr
        slot["cw"] += cw
        self.input_tokens += i
        self.output_tokens += o
        self.cache_read += cr
        self.cache_write += cw

    def total_usd(self) -> float:
        total = 0.0
        for m, s in self.by_model.items():
            base = m.rsplit("-", 1)[0] if re.search(r"-\d{8}$", m) else m
            # normalize to family key
            for k in PRICES:
                if base.startswith(k):
                    p = PRICES[k]
                    total += s["input"]  / 1e6 * p["in"]
                    total += s["output"] / 1e6 * p["out"]
                    total += s["cr"]     / 1e6 * p["cache_read"]
                    total += s["cw"]     / 1e6 * p["cache_write"]
                    break
        return total

    def summary(self) -> str:
        rows = []
        for m, s in sorted(self.by_model.items()):
            rows.append(f"  {m}: in={s['input']:>8} out={s['output']:>6} "
                        f"cache_r={s['cr']:>8} cache_w={s['cw']:>8}")
        rows.append(f"  TOTAL USD ~ ${self.total_usd():.2f}")
        return "\n".join(rows)


def load_system_prompt() -> str:
    """Concatenate the prompt parts (v3.2 base + v3.3 delta + taxonomy).

    The three files live side-by-side in ``prompts/v3_3/``; missing any of
    them is a hard error so a future replicator notices immediately rather
    than silently shipping a half-instructed model.
    """
    chunks: list[str] = []
    for part in PROMPT_PARTS:
        if not part.is_file():
            raise FileNotFoundError(
                f"Prompt component not found: {part}. "
                f"Expected all of {[p.name for p in PROMPT_PARTS]} in {PROMPT_DIR}."
            )
        chunks.append(
            f"<!-- ===== BEGIN {part.name} ===== -->\n"
            + part.read_text(encoding="utf-8").rstrip()
            + f"\n<!-- ===== END {part.name} ===== -->"
        )
    return "\n\n".join(chunks) + "\n"


# ---------------------------------------------------------------------------
# Per-field validation / coercion
# ---------------------------------------------------------------------------

BINARY_COLS = {
    "Augmented_base_model", "Ramsey_Rule",
    "HH_Included", "Firms_Included", "Banks_Included", "Government_Included",
    "Other_Agent_Included", "Empirical_Research",
    "Flexible_Price_Assumption", "Exogenous_Inflation", "Growth_Included",
    "Zero_Lower_Bound", "Preferred_Estimate",
}

NUMERIC_COLS = {
    "Households_discount_factor", "Consumption_curvature_parameter",
    "Disutility_of_labor", "Inverse_of_labor_supply_elasticity",
    "Money_curvature_parameter", "Loan_to_value_ratio", "Labor_share_of_output",
    "Depositors_discount_factor", "Price_adjustment_cost",
    "Elasticity_of_substitution_between_goods",
    "AR1_coefficient_of_TFP", "Std_dev_to_TFP_shock",
    "Results_Inflation", "Results_Inflation_CI_Low", "Results_Inflation_CI_High",
    "Results_Inflation_CI_Level",
    "Std_Dev_Inflation", "Interest_Rate",
    "Num_Citations", "Impact_Factor", "Year",
    "Sample_Size", "Sample_Period_Start", "Sample_Period_End",
}

VOCAB: dict[str, set[str]] = {
    "Model_Class": {
        "DSGE", "Empirical_VAR", "Reduced_form_regression",
        "Theoretical_calibration", "Other",
    },
    "Model_Paradigm": {
        "New Keynesian", "RBC", "OLG",
        "Money_in_utility", "Cash_in_advance", "Search_and_matching",
        "HANK", "TANK", "Other", "NA",
    },
    "Augmentation_Category": {
        "none", "financial_frictions", "labor_market_frictions",
        "open_economy", "heterogeneous_agents", "housing",
        "fiscal_policy", "ZLB", "learning", "other",
    },
    "Calibration_Frequency": {"Q", "M", "A", "NA"},
    "Inflation_Unit": {
        "annual_pct", "quarterly_pct", "monthly_pct",
        "decimal_annual", "decimal_quarterly", "unknown",
    },
    "Horizon": {"long_run", "short_run", "transition", "NA"},
    "SE_Derivation": {
        "reported_SE", "from_CI", "reported_SD", "posterior_SD", "NA",
    },
    # --- v3.3 additions ---
    "Publication_Status": {
        "published", "NBER_WP", "working_paper",
        "discussion_paper", "preprint", "NA",
    },
    "Nominal_Friction_Type": {
        "Calvo_prices", "Rotemberg_prices", "Taylor_contracts",
        "Calvo_prices_and_wages", "menu_cost", "information_friction",
        "flexible", "other", "NA",
    },
    "Wage_Rigidity_Type": {
        "none", "Calvo_wages", "Rotemberg_wages", "Taylor_wages",
        "DNWR", "search_and_matching", "sticky_real_wages",
        "other", "NA",
    },
    "Money_Demand_Tech": {
        "MIU", "CIA", "shopping_time", "transactions_technology",
        "cashless", "none", "NA",
    },
    "Indexation_Type": {
        "none", "past_inflation", "trend_inflation",
        "hybrid", "full", "NA",
    },
    "Policy_Regime": {
        "Ramsey", "Ramsey_discretion", "Friedman_rule",
        "Taylor_rule", "Optimized_Taylor_rule", "Zero_inflation",
        "Inflation_targeting", "Laissez_faire", "Estimated_policy",
        "Other", "NA",
    },
    "Shock_Type": {
        "TFP", "Markup", "Cost_push", "Monetary",
        "Government_spending", "Risk_premium", "Financial",
        "Wage_markup", "Preference", "Labor_supply",
        "Multiple", "None", "NA",
    },
    "Welfare_Criterion": {
        "unconditional", "conditional_efficient_SS",
        "second_order_approx", "first_order_approx",
        "consumption_equivalent", "observed", "NA",
    },
    "Steady_State_Type": {
        "stochastic", "deterministic", "transition", "NA",
    },
    "Sensitivity_Type": {
        "baseline", "robustness_parameter", "robustness_mechanism",
        "extension", "comparison", "NA",
    },
    "Expectations": {
        "rational", "adaptive", "learning",
        "heterogeneous", "boundedly_rational", "NA",
    },
    "Estimator_Type": {
        "OLS", "GLS", "IV", "GMM", "ML", "Bayesian",
        "SVAR", "VAR", "BVAR", "local_projections",
        "calibration", "NA",
    },
}

# Z-values for CI -> SE conversion
_Z = {68: 1.0, 80: 1.282, 90: 1.645, 95: 1.96, 99: 2.576}


def _as_float(x: Any) -> float | None:
    if x in (None, "", "NA", "N/A", "n/a"):
        return None
    try:
        return float(str(x).replace(",", ""))
    except (TypeError, ValueError):
        return None


def validate_row(row: dict, *, logger_: logging.Logger | None = None) -> list[str]:
    """
    Coerce/clean a merged row in place. Returns a list of warning messages.
    Rules:
      - Binary cols must be 0 or 1; anything else -> "NA".
      - Numeric cols must parse to float; otherwise -> "NA".
      - Closed-vocab cols must be in their VOCAB set; otherwise -> "NA".
      - If SE_Derivation == "from_CI" and SE blank, compute it.
    """
    warnings: list[str] = []
    log = logger_ or logger

    for col in BINARY_COLS:
        v = row.get(col, "NA")
        if v in (0, 1):
            continue
        s = str(v).strip().lower()
        if s in ("0", "0.0", "false", "no"):
            row[col] = 0
        elif s in ("1", "1.0", "true", "yes"):
            row[col] = 1
        elif s in ("na", "n/a", "nan", "", "none"):
            row[col] = "NA"
        else:
            warnings.append(f"{col}: coerced {v!r} -> NA (not 0/1)")
            row[col] = "NA"

    for col in NUMERIC_COLS:
        v = row.get(col, "NA")
        if v == "NA" or v is None:
            row[col] = "NA"
            continue
        f = _as_float(v)
        if f is None:
            warnings.append(f"{col}: coerced {v!r} -> NA (not numeric)")
            row[col] = "NA"
        else:
            row[col] = f

    for col, allowed in VOCAB.items():
        v = row.get(col, "NA")
        if v in (None, "", "NA"):
            row[col] = "NA"
            continue
        if str(v) not in allowed:
            warnings.append(f"{col}: {v!r} not in closed vocab -> NA")
            row[col] = "NA"

    # Derive SE from CI if requested
    if row.get("SE_Derivation") == "from_CI" and row.get("Std_Dev_Inflation") in ("NA", None):
        lo = _as_float(row.get("Results_Inflation_CI_Low"))
        hi = _as_float(row.get("Results_Inflation_CI_High"))
        lvl = _as_float(row.get("Results_Inflation_CI_Level")) or 95.0
        z = _Z.get(int(round(lvl)), 1.96)
        if lo is not None and hi is not None and hi > lo:
            se = (hi - lo) / (2.0 * z)
            row["Std_Dev_Inflation"] = round(se, 6)
        else:
            warnings.append("SE_Derivation=from_CI but CI bounds invalid")

    if warnings and log:
        for w in warnings:
            log.warning("    validator: %s", w)
    return warnings


def _strip_json(text: str) -> str:
    """Grab the outermost {...} block even if the model wrapped it in prose."""
    s = text.strip()
    # Remove markdown fences if present
    s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s, flags=re.MULTILINE).strip()
    if s.startswith("{") and s.endswith("}"):
        return s
    m = re.search(r"\{.*\}", s, flags=re.DOTALL)
    if not m:
        raise ValueError(f"No JSON object found in model output: {text[:200]!r}")
    return m.group(0)


class Extractor:
    def __init__(self, out_dir: Path):
        self.client = anthropic.Anthropic(api_key=CLAUDE_API_KEY)
        self.system_prompt = load_system_prompt()
        self.out_dir = out_dir
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.partials_dir = out_dir / "partials"
        self.partials_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_path = out_dir / "checkpoint.jsonl"
        self.cost = CostTracker()

    # ---- checkpoint / resume ----------------------------------------------
    def _checkpoint(self, pdf_path: Path, idstudy: int, *, status: str,
                    rows: int, skip_reason: str | None = None,
                    pre_scan: dict | None = None) -> None:
        rec = {
            "pdf": pdf_path.name,
            "idstudy": idstudy,
            "status": status,         # ok | no_quant | error
            "rows": rows,
            "ts": datetime.now().isoformat(timespec="seconds"),
        }
        if skip_reason:
            rec["skip_reason"] = skip_reason
        if pre_scan is not None:
            rec["pre_scan"] = pre_scan
        with self.checkpoint_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    def completed_pdfs(self) -> set[str]:
        """PDF filenames already recorded as ok / no_quant (skip on resume)."""
        done: set[str] = set()
        if not self.checkpoint_path.exists():
            return done
        for line in self.checkpoint_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if rec.get("status") in ("ok", "no_quant"):
                done.add(rec["pdf"])
        return done

    # ---- prompt construction ----------------------------------------------
    def _build_messages(self, markdown: str, stage: str) -> tuple[list[dict], list[dict]]:
        """Return (system_blocks, user_message_content).

        The markdown body is placed in a cache_control=ephemeral user block so
        Anthropic caches it across the 4 stages within a 5-minute window.
        """
        system_blocks = [
            {"type": "text", "text": self.system_prompt,
             "cache_control": {"type": "ephemeral"}},
        ]
        stage_instr = {
            "pre_scan":
                "STAGE: pre_scan. Follow §2 of the system prompt. "
                "Output ONLY the JSON object with keys `count` (int) and `sources` (list).",
            "metadata":
                "STAGE: metadata. Follow §3 of the system prompt. "
                "Output ONLY the JSON object with key `rows` (length-1 list of dicts).",
            "structure":
                "STAGE: structure. Follow §4 of the system prompt. "
                "Output ONLY the JSON object with key `rows` (length-1 list of dicts).",
            "results":
                "STAGE: results. Follow §5 of the system prompt. "
                "Output ONLY the JSON object with key `rows` "
                "(one dict per distinct inflation result). "
                "Exactly one row must have Preferred_Estimate=1.",
        }[stage]
        user = [
            {"type": "text",
             "text": f"PAPER MARKDOWN:\n\n{markdown}",
             "cache_control": {"type": "ephemeral"}},
            {"type": "text", "text": stage_instr},
        ]
        return system_blocks, user

    # ---- single stage call -------------------------------------------------
    def _call(self, markdown: str, stage: str) -> dict:
        system_blocks, user_content = self._build_messages(markdown, stage)
        model = STAGE_MODEL[stage]
        for attempt in range(3):
            try:
                t0 = time.time()
                resp = self.client.messages.create(
                    model=model,
                    max_tokens=STAGE_MAX_TOKENS[stage],
                    temperature=0.0,
                    system=system_blocks,
                    messages=[{"role": "user", "content": user_content}],
                )
                dt_s = time.time() - t0
                self.cost.add(model, resp.usage)
                text = resp.content[0].text if resp.content else ""
                logger.info("  %-9s %s %.1fs in=%s out=%s cr=%s cw=%s",
                            stage, model, dt_s,
                            resp.usage.input_tokens, resp.usage.output_tokens,
                            getattr(resp.usage, "cache_read_input_tokens", 0),
                            getattr(resp.usage, "cache_creation_input_tokens", 0))
                return json.loads(_strip_json(text))
            except (anthropic.APIStatusError, json.JSONDecodeError, ValueError) as e:
                logger.warning("  %s attempt %d failed: %s", stage, attempt + 1, str(e)[:200])
                if attempt == 2:
                    if model != MODEL_FALLBACK:
                        logger.warning("  falling back to %s", MODEL_FALLBACK)
                        model = MODEL_FALLBACK
                    else:
                        raise
                time.sleep(2 ** attempt)
        raise RuntimeError("unreachable")

    # ---- merge stage outputs into canonical rows ---------------------------
    def _merge(self, meta: dict, structure: dict, results: dict,
               pre_scan_count: int) -> pd.DataFrame:
        meta_row = meta["rows"][0]
        struct_row = structure["rows"][0]
        result_rows = results["rows"]

        # Enforce exactly one Preferred_Estimate=1
        prefs = [int(r.get("Preferred_Estimate", 0) or 0) for r in result_rows]
        if sum(prefs) != 1:
            logger.warning("  Preferred_Estimate sum=%d (expected 1); fixing: "
                           "keep first 1-marked or mark row 1", sum(prefs))
            for r in result_rows:
                r["Preferred_Estimate"] = 0
            # pick first row flagged, else row 0
            idx = next((i for i, p in enumerate(prefs) if p == 1), 0)
            result_rows[idx]["Preferred_Estimate"] = 1

        # Check row count vs pre-scan reconciliation
        if pre_scan_count > 0:
            ratio = len(result_rows) / pre_scan_count
            if ratio > 1.5 or ratio < 0.5:
                logger.warning("  row-count mismatch: pre_scan=%d results=%d (ratio=%.2f)",
                               pre_scan_count, len(result_rows), ratio)

        def _safe_update(dst: dict, src: dict) -> None:
            """Copy src->dst, but never overwrite a non-NA value with NA/null."""
            for k, v in src.items():
                if k not in dst:
                    continue
                if v in (None, "", "NA") and dst[k] not in (None, "", "NA"):
                    continue  # keep existing non-NA
                dst[k] = v

        df_rows = []
        for i, rr in enumerate(result_rows, start=1):
            row = {col: "NA" for col in COLUMNS}
            _safe_update(row, meta_row)
            _safe_update(row, struct_row)
            _safe_update(row, rr)
            row["IdEstimate"] = rr.get("IdEstimate", i)
            validate_row(row)
            df_rows.append(row)
        return pd.DataFrame(df_rows, columns=COLUMNS)

    # ---- main per-paper entry point ---------------------------------------
    def extract_paper(self, pdf_path: Path, idstudy: int,
                      force_extract: bool = False) -> pd.DataFrame | None:
        logger.info("=" * 70)
        logger.info("Paper %d: %s%s", idstudy, pdf_path.name,
                    " [FORCE]" if force_extract else "")
        try:
            md = convert_pdf_to_markdown(pdf_path)
        except Exception as e:
            logger.error("  markdown conversion failed: %s", e)
            self._checkpoint(pdf_path, idstudy, status="error",
                             skip_reason=f"markdown: {e}", rows=0)
            return None
        logger.info("  markdown: %d chars", len(md))

        # Stage 1: pre_scan (Sonnet, cheap). If 0 quantitative results,
        # skip the 3 expensive stages entirely.
        # When force_extract=True, skip pre_scan and always run full pipeline
        # (used to re-process papers wrongly classified as no_quant by a
        # previous, stricter pre_scan pass).
        if force_extract:
            pre = {"count": -1, "sources": [{"note": "force_extract: pre_scan bypassed"}]}
            logger.info("  pre_scan: BYPASSED (force_extract)")
        else:
            try:
                pre = self._call(md, "pre_scan")
            except Exception as e:
                logger.error("  pre_scan failed: %s", e)
                self._checkpoint(pdf_path, idstudy, status="error",
                                 skip_reason=f"pre_scan: {e}", rows=0)
                return None

        pre_count = int(pre.get("count", 0) or 0)
        logger.info("  pre_scan count=%d; sources=%s", pre_count, pre.get("sources"))

        if pre_count == 0 and not force_extract:
            logger.info("  SKIP: no quantitative inflation results in this paper")
            self._checkpoint(pdf_path, idstudy, status="no_quant",
                             skip_reason="pre_scan count=0", rows=0,
                             pre_scan=pre)
            return None

        try:
            meta  = self._call(md, "metadata")
            struc = self._call(md, "structure")
            res   = self._call(md, "results")
        except Exception as e:
            logger.error("  stage call failed: %s", e)
            self._checkpoint(pdf_path, idstudy, status="error",
                             skip_reason=f"stage: {e}", rows=0)
            return None

        df = self._merge(meta, struc, res, pre_count)
        df["Idstudy"] = idstudy

        # Archive raw AI output
        raw_combined = {
            "pre_scan": pre,
            "metadata": meta,
            "structure": struc,
            "results": res,
        }
        raw_df = pd.DataFrame(res["rows"])  # results-level raw
        try:
            archive_raw_extraction(
                pdf_path, raw_df,
                prompt_version=PROMPT_VERSION,
                model=f"{MODEL_RESULTS}+{MODEL_STRUCTURE}",
                extra_meta={"stages_json": raw_combined, "idstudy": idstudy,
                            "pre_scan_count": pre_count,
                            "models": {"pre_scan": MODEL_PRE_SCAN,
                                       "metadata": MODEL_METADATA,
                                       "structure": MODEL_STRUCTURE,
                                       "results": MODEL_RESULTS}},
            )
        except Exception as e:
            logger.warning("  archive failed: %s", e)

        # Save per-paper partial so a crash doesn't lose this paper's output.
        try:
            partial_path = self.partials_dir / f"paper_{idstudy:05d}.xlsx"
            df.to_excel(partial_path, index=False)
        except Exception as e:
            logger.warning("  partial write failed: %s", e)

        self._checkpoint(pdf_path, idstudy, status="ok", rows=len(df))
        return df


def iter_pdfs(args) -> list[Path]:
    lit = REPO_ROOT / "Literature"
    if args.papers:
        out = []
        for pat in args.papers:
            p = Path(pat)
            if p.is_file():
                out.append(p)
            else:
                out.extend(sorted(lit.glob(Path(pat).name)))
        return out
    if args.since:
        cutoff = datetime.strptime(args.since, "%Y-%m-%d")
        return sorted(p for p in lit.glob("*.pdf")
                      if datetime.fromtimestamp(p.stat().st_mtime) >= cutoff)
    return sorted(lit.glob("*.pdf"))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--papers", nargs="+", help="Specific PDFs or globs within Literature/")
    ap.add_argument("--since", help="mtime cutoff YYYY-MM-DD (e.g. 2026-04-01)")
    ap.add_argument("--out", default="ai_dataset/v3_0_full",
                    help="Output folder relative to repo root "
                         "(matches phase1_normalize.py / phase2_build_analysis_dataset.py defaults)")
    ap.add_argument("--start-id", type=int, default=1000,
                    help="Idstudy offset for this batch")
    ap.add_argument("--limit", type=int, default=None, help="Stop after N papers")
    ap.add_argument("--no-resume", action="store_true",
                    help="Re-process PDFs even if they're in checkpoint.jsonl")
    ap.add_argument("--force-extract", action="store_true",
                    help="Bypass pre_scan gate; always run metadata+structure+results")
    args = ap.parse_args()

    pdfs = iter_pdfs(args)
    if args.limit:
        pdfs = pdfs[: args.limit]
    if not pdfs:
        logger.error("No PDFs matched. Use --papers or --since.")
        return 2

    logger.info("Processing %d PDFs", len(pdfs))
    out_dir = REPO_ROOT / args.out
    ex = Extractor(out_dir)

    # Assign stable Idstudy based on full sorted list (so resumed runs reuse
    # the same idstudy for the same PDF and don't collide with prior partials).
    pdf_ids: dict[Path, int] = {p: args.start_id + i for i, p in enumerate(pdfs)}

    # Resume: skip PDFs already processed (ok or no_quant) in this output folder.
    if not args.no_resume:
        done = ex.completed_pdfs()
        if done:
            before = len(pdfs)
            pdfs = [p for p in pdfs if p.name not in done]
            logger.info("Resume: %d PDFs already in checkpoint, %d remaining",
                        before - len(pdfs), len(pdfs))

    all_rows: list[pd.DataFrame] = []
    for pdf in pdfs:
        idstudy = pdf_ids[pdf]
        df = ex.extract_paper(pdf, idstudy, force_extract=args.force_extract)
        if df is not None and not df.empty:
            all_rows.append(df)

    # Reassemble combined output from ALL partials in out_dir (this run +
    # prior resumed runs), so the final Excel is always complete.
    partials = sorted(ex.partials_dir.glob("paper_*.xlsx"))
    if partials:
        combined_all = pd.concat(
            [pd.read_excel(p) for p in partials], ignore_index=True
        )
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        out_xlsx = out_dir / f"extracted_{ts}.xlsx"
        combined_all.to_excel(out_xlsx, index=False)
        out_csv = out_dir / f"extracted_{ts}.csv"
        combined_all.to_csv(out_csv, index=False, encoding="utf-8")
        logger.info("Wrote %d rows (from %d partials) to %s",
                    len(combined_all), len(partials), out_xlsx)

    logger.info("Cost summary:\n%s", ex.cost.summary())
    return 0


if __name__ == "__main__":
    sys.exit(main())
