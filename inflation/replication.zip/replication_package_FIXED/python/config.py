# -*- coding: utf-8 -*-
"""
Local secrets. DO NOT COMMIT.

NOTE FOR COAUTHORS: API keys have been REDACTED before redistribution.
Set your own keys via environment variables (ANTHROPIC_API_KEY,
SCOPUS_API_KEY) or paste them in below before running the pipeline.
"""
import os

# Anthropic key (starts with sk-ant-api03-...)
CLAUDE_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "REDACTED-SET-ANTHROPIC_API_KEY-ENV-VAR")

# Scopus key (Elsevier developer portal)
SCOPUS_API_KEY = os.environ.get("SCOPUS_API_KEY", "REDACTED-SET-SCOPUS_API_KEY-ENV-VAR")

# Model allocation: date-stamped aliases so the run is byte-deterministic on the
# Anthropic side (matches manuscript Appendix B). Verified 2026-04-21.
MODEL_PRE_SCAN  = "claude-sonnet-4-5-20250929"   # counts inflation results, simple
MODEL_METADATA  = "claude-sonnet-4-5-20250929"   # bibliographic extraction
MODEL_STRUCTURE = "claude-opus-4-5-20251001"     # A/B tested Sonnet: failed (missed augmentations, wrong Ramsey flag)
MODEL_RESULTS   = "claude-opus-4-5-20251001"     # numerical results + signs + parameters, most critical
MODEL_FALLBACK  = "claude-opus-4-5-20251001"

# Kept for backward-compat with INFLATION_1_6
CLAUDE_MODEL = MODEL_RESULTS
