#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Phase 2B: build the final analysis dataset from Phase 1 output.

Inputs
------
- AI_dataset/v3_0_full/extracted_enriched_phase1.xlsx  (856 x 79, from phase1_normalize.py)

Outputs
-------
- AI_dataset/v3_0_full/analysis_dataset.xlsx  (human-readable)
- Stata_code/inflation_v33.dta                (Stata dataset for MAER-Net pipeline)
- AI_dataset/v3_0_full/codebook.md            (variable dictionary)
- AI_dataset/v3_0_full/plots/*.png            (sanity plots)

Pipeline steps
--------------
0. (v34 only, when --v34 flag is set) Apply v34 cleaning BEFORE downstream
   steps:
     (i)   DOI-level dedup. Group by normalized DOI (lower-case, stripped).
           When >=2 distinct Idstudy share one non-empty DOI, keep the lowest
           Idstudy and drop all rows of the others. Logged to CHANGELOG_data.md.
     (ii)  Ghost-row drop. Drop any row where Author, Year, DOI AND
           Results_Inflation_Annualized_Pct are all NaN.
     (iii) Derive Affiliation_Class in {university, central_bank, mixed,
           other, NA} from Author_Affiliation using a closed-vocab keyword
           regex. Documented in docs/v34_rebuild_instructions.md §Step 2.
     (iv)  Out-of-scope drop. Remove Idstudy values flagged during audit as
           not belonging to the optimal-inflation population (currently
           Idstudy 9072 -- Gechert/Havranek/Irsova/Kolcunova 2022, which is
           a meta-analysis of capital-labor substitution elasticity).
     (v)   Preferred-row reassignment. For Idstudy 9021, 9023, 9029, 9141 the
           AI flagged a Preferred row whose numeric Estimate is NaN while
           other rows in the same paper carry a numeric Estimate. Move
           Preferred=1 to the first numeric-Estimate row in each of these
           papers (manual audit Apr-2026).
   Outputs in --v34 mode go to AI_dataset/v3_0_full/analysis_dataset_v34.xlsx
   and Stata_code/inflation_v34.dta; the v33 files are NOT overwritten.
1. Load phase1 output.
2. Derive SE hierarchically:
   (a) SE_from_CI:  (CI_High - CI_Low) / (2 * z_level)  if both CI endpoints
                    present and CI_Level is 90/95/99.
   (b) SE_reported: Std_Dev_Inflation if Estimator_Type in {Bayesian, GMM, ML}
                    (sampling uncertainty from MCMC/GMM, treat as genuine SE).
   (c) SE_bootstrap: per-paper bootstrap standard deviation of
                     Results_Inflation_Annualized_Pct, 1000 reps, seed=1234.
                     Only if paper has >=2 non-NA estimates.
   Final SE = coalesce(SE_from_CI, SE_reported, SE_bootstrap).
   Companion flag `se_is_genuine` = 1 iff final SE came from (a) or (b).
3. Winsorize Estimate and SE at 5% each tail (following Havranek et al. default).
4. Dummy-encode the 15 new v3.3 categorical columns (one-hot, dropping NA class).
5. Add log-transforms: LCitations = log(1+Num_Citations); LIF = log(1+Impact_Factor).
6. Export Excel + Stata .dta + codebook + plots.

Design notes (for the paper)
----------------------------
- Only 15/856 rows (2 papers) have genuine CI-derived SEs in the raw data.
  Bayesian estimation (38 rows) and GMM (9 rows) provide additional genuine
  SE candidates via Std_Dev_Inflation.
- For the remaining ~800 calibration-based rows we use per-paper
  bootstrap SE as a proxy precision measure, following Havranek et al.
  (2018, JES), Zigraiova & Havranek (2015, JES), and the precedent set
  by the original Inflation_Web.do.
- The `se_is_genuine` flag lets us run a robustness subset meta-analysis
  restricted to rows with truly sampling-based SEs.
"""
from __future__ import annotations

import argparse
import logging
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

try:
    import pyreadstat  # for .dta export
except ImportError:
    pyreadstat = None  # fallback to pandas.to_stata

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("phase2")

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------
Z_LEVEL = {50: 0.674, 68: 1.0, 80: 1.282, 90: 1.645, 95: 1.96, 99: 2.576}


def se_from_ci(low: float, high: float, level: float) -> float:
    """Return symmetric SE implied by a reported CI."""
    if pd.isna(low) or pd.isna(high) or pd.isna(level):
        return np.nan
    try:
        lv = int(round(float(level)))
    except (TypeError, ValueError):
        return np.nan
    z = Z_LEVEL.get(lv)
    if z is None:
        # accept anything in Z_LEVEL ± 1 (e.g. 94, 96)
        nearest = min(Z_LEVEL.keys(), key=lambda k: abs(k - lv))
        if abs(nearest - lv) > 2:
            return np.nan
        z = Z_LEVEL[nearest]
    return abs(float(high) - float(low)) / (2.0 * z)


def bootstrap_se(values: np.ndarray, reps: int = 1000, seed: int = 1234) -> float:
    """Bootstrap SE of the mean of `values`, following Havranek convention.

    Returns NA if fewer than 2 non-NA values.
    """
    v = np.asarray(values, dtype=float)
    v = v[~np.isnan(v)]
    if len(v) < 2:
        return np.nan
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(v), size=(reps, len(v)))
    means = v[idx].mean(axis=1)
    return float(means.std(ddof=1))


def winsorize(s: pd.Series, p: float = 0.05) -> pd.Series:
    """Two-sided winsorization at quantiles [p, 1-p]."""
    lo, hi = s.quantile([p, 1 - p])
    return s.clip(lower=lo, upper=hi)


def sanitize_col(name: str) -> str:
    """Stata-safe column name (<=32 chars, alnum + _)."""
    s = "".join(ch if (ch.isalnum() or ch == "_") else "_" for ch in name)
    if s and not (s[0].isalpha() or s[0] == "_"):
        s = "_" + s
    return s[:32]


def dummy_encode(df: pd.DataFrame, col: str, prefix: str) -> pd.DataFrame:
    """Return dummy columns for a closed-vocab categorical; NA stays NA."""
    if col not in df.columns:
        return pd.DataFrame(index=df.index)
    s = df[col].astype("string")
    dummies = pd.get_dummies(s, prefix=prefix, prefix_sep="_", dummy_na=False, dtype=bool)
    dummies = dummies.astype("Int64")
    # Rename to Stata-safe short names
    dummies.columns = [sanitize_col(c) for c in dummies.columns]
    # Deduplicate colliding names
    seen: dict[str, int] = {}
    new_cols = []
    for c in dummies.columns:
        if c in seen:
            seen[c] += 1
            new_cols.append(f"{c[:30]}_{seen[c]}")
        else:
            seen[c] = 0
            new_cols.append(c)
    dummies.columns = new_cols
    # Where source col is NA, drop the whole dummy row (preserve missingness)
    mask_na = s.isna()
    dummies.loc[mask_na, :] = pd.NA
    return dummies


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
V33_CATEGORICAL_COLS = {
    "Policy_Regime":            "PR",
    "Shock_Type":               "SHK",
    "Welfare_Criterion":        "WC",
    "Steady_State_Type":        "SST",
    "Sensitivity_Type":         "SEN",
    "Expectations":             "EXP",
    "Estimator_Type":           "EST",
    "Nominal_Friction_Type":    "NFT",
    "Wage_Rigidity_Type":       "WRT",
    "Money_Demand_Tech":        "MDT",
    "Indexation_Type":          "IND",
    "Publication_Status":       "PUB",
    "Model_Class":              "MC",
    "Model_Paradigm":           "MP",
    "Augmentation_Category":    "AUG",
    "Horizon":                  "HZ",
}


# -----------------------------------------------------------------------------
# v34 cleaning helpers
# -----------------------------------------------------------------------------
def _normalize_doi(s) -> str | None:
    """Lower-case, stripped DOI; returns None for blanks."""
    if pd.isna(s):
        return None
    out = str(s).strip().lower().rstrip(".,;")
    if not out or out in {"nan", "none"}:
        return None
    # strip a leading "https://doi.org/" if present
    for pref in ("https://doi.org/", "http://doi.org/", "doi:"):
        if out.startswith(pref):
            out = out[len(pref):]
    return out


# Closed vocabulary regexes for Affiliation_Class.
# Order: central_bank tokens first (more specific), then university tokens.
_CB_PATTERNS = [
    r"\bfederal reserve\b", r"\breserve bank\b",
    r"\bcentral bank\b", r"\bbank of [a-z]+", r"\bbanco\b", r"\bbanca\b",
    r"\bbanque\b", r"\bbundesbank\b", r"\briksbank\b",
    r"\bbank for international settlements\b", r"\bBIS\b",
    r"\beuropean central bank\b", r"\bECB\b",
    r"\bIMF\b", r"\binternational monetary fund\b",
    r"\bworld bank\b", r"\bOECD\b",
]
_UNI_PATTERNS = [
    r"\buniversity\b", r"\buniversit[\u00e9\u00e0]\b", r"\buniversit\u00e4t\b",
    r"\bcollege\b", r"\bschool\b", r"\binstitute of technology\b",
    r"\bMIT\b", r"\bLSE\b", r"\bCEPR\b",  # CEPR is research network — count as university-side
    r"\bnational bureau of economic research\b", r"\bNBER\b",
    r"\bcoll\u00e8ge\b", r"\bcuni\b",
]


def _affiliation_class(s) -> str:
    """Classify a free-text affiliation string into {university, central_bank,
    mixed, other, NA}. Returns 'NA' for blanks."""
    if pd.isna(s) or str(s).strip() == "" or str(s).strip().lower() == "nan":
        return "NA"
    text = str(s).lower()
    is_cb = any(re.search(p, text, flags=re.IGNORECASE) for p in _CB_PATTERNS)
    is_uni = any(re.search(p, text, flags=re.IGNORECASE) for p in _UNI_PATTERNS)
    if is_cb and is_uni:
        return "mixed"
    if is_cb:
        return "central_bank"
    if is_uni:
        return "university"
    return "other"


def apply_v34_cleaning(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    """Apply v34 dataset cleaning. Returns (clean_df, log_lines)."""
    import re as _re  # local alias (we also import at module top later)
    log_lines: list[str] = []
    n_before = len(df)
    n_papers_before = df["Idstudy"].nunique()
    log_lines.append(f"input rows: {n_before}, unique Idstudy: {n_papers_before}")

    # (i) DOI-level dedup: keep lowest Idstudy per shared non-empty DOI.
    df = df.copy()
    df["__doi_norm"] = df["DOI"].map(_normalize_doi)
    doi_to_ids: dict[str, list[int]] = {}
    for doi, sub in df.dropna(subset=["__doi_norm"]).groupby("__doi_norm"):
        ids = sorted(sub["Idstudy"].dropna().unique().tolist())
        if len(ids) >= 2:
            doi_to_ids[doi] = ids
    drop_ids: set[int] = set()
    for doi, ids in doi_to_ids.items():
        keep = ids[0]
        for d in ids[1:]:
            drop_ids.add(d)
        log_lines.append(
            f"DOI dedup: {doi} -> keep Idstudy={keep}, drop {ids[1:]}"
        )
    if drop_ids:
        before = len(df)
        df = df[~df["Idstudy"].isin(drop_ids)].copy()
        log_lines.append(
            f"DOI dedup: dropped {before - len(df)} rows from Idstudy {sorted(drop_ids)}"
        )
    else:
        log_lines.append("DOI dedup: no duplicates found")
    df = df.drop(columns=["__doi_norm"])

    # (ii) Ghost-row drop: Author, Year, DOI, Results all NaN.
    key_cols = ["Author", "Year", "DOI", "Results_Inflation_Annualized_Pct"]
    have_all = all(c in df.columns for c in key_cols)
    if have_all:
        ghost_mask = df[key_cols].isna().all(axis=1)
        n_ghost = int(ghost_mask.sum())
        if n_ghost:
            ghost_ids = sorted(df.loc[ghost_mask, "Idstudy"].dropna().unique().tolist())
            log_lines.append(
                f"ghost-row drop: {n_ghost} rows from Idstudy {ghost_ids}"
            )
            df = df[~ghost_mask].copy()
        else:
            log_lines.append("ghost-row drop: no ghost rows found")
    else:
        log_lines.append(
            f"ghost-row drop: SKIPPED (missing one of {key_cols})"
        )

    # (iii) Derive Affiliation_Class
    if "Author_Affiliation" in df.columns:
        df["Affiliation_Class"] = df["Author_Affiliation"].map(_affiliation_class)
        vc = df["Affiliation_Class"].value_counts(dropna=False).to_dict()
        log_lines.append(f"Affiliation_Class distribution: {vc}")
    else:
        log_lines.append("Affiliation_Class: SKIPPED (no Author_Affiliation column)")

    # (iv) Out-of-scope drop: papers identified during audit as not belonging
    # to the optimal-inflation-rate population.
    out_of_scope_ids = {
        9072,  # Gechert, Havranek, Irsova, Kolcunova (2022) -- meta-analysis of
               # capital-labor substitution elasticity; not optimal-inflation.
        9084,  # Jung (2003) "Optimal Monetary Policy in an Estimated Medium-Scale
               # Model of the Euro Area" -- working paper that does not exist as
               # a verifiable record (no OpenAlex/Crossref/Scopus match); single
               # observation, dropped on user request 2026-06-01.
    }
    in_scope_drop = sorted(set(df["Idstudy"].dropna().unique().astype(int))
                           & out_of_scope_ids)
    if in_scope_drop:
        before = len(df)
        df = df[~df["Idstudy"].isin(in_scope_drop)].copy()
        log_lines.append(
            f"out-of-scope drop: removed Idstudy {in_scope_drop} "
            f"({before - len(df)} rows)"
        )
    else:
        log_lines.append("out-of-scope drop: no listed Idstudy present")

    # (v) Preferred-row reassignment: for a small set of papers the AI flagged
    # a Preferred row whose numeric Estimate is NaN (the author's preferred
    # specification is reported only as a chart / qualitative result) while
    # other rows in the same paper *do* carry a numeric estimate. Manual
    # inspection (Apr-2026) confirms the numeric rows are the appropriate
    # author-preferred quantitative pick. Reassign Preferred to the first
    # numeric-Estimate row in each of these papers.
    preferred_reassign_ids = [
        9021,  # Basu & De Leo (2017)
        9023,  # Benigno & Rossi (2021)
        9029,  # Blanchard & Galí (2008)
        9141,  # Sims (2013)
    ]
    if {"Preferred_Estimate", "Results_Inflation_Annualized_Pct"}.issubset(df.columns):
        pref_col = "Preferred_Estimate"
        est_col = "Results_Inflation_Annualized_Pct"
        for sid in preferred_reassign_ids:
            paper = df[df["Idstudy"] == sid]
            if paper.empty:
                log_lines.append(
                    f"preferred reassignment: Idstudy {sid} not present (skipped)"
                )
                continue
            cur_pref_mask = paper[pref_col] == 1
            cur_pref_numeric = paper.loc[cur_pref_mask, est_col].notna().any()
            if cur_pref_numeric:
                log_lines.append(
                    f"preferred reassignment: Idstudy {sid} already has numeric "
                    f"Preferred row (skipped)"
                )
                continue
            numeric_rows = paper[paper[est_col].notna()]
            if numeric_rows.empty:
                log_lines.append(
                    f"preferred reassignment: Idstudy {sid} has no numeric "
                    f"Estimate rows (skipped)"
                )
                continue
            new_pref_idx = numeric_rows.index[0]
            old_pref_idx = paper.index[cur_pref_mask.values].tolist()
            df.loc[old_pref_idx, pref_col] = 0
            df.loc[new_pref_idx, pref_col] = 1
            log_lines.append(
                f"preferred reassignment: Idstudy {sid} -> moved Preferred=1 "
                f"from row(s) {old_pref_idx} to row {new_pref_idx} "
                f"(Estimate={df.at[new_pref_idx, est_col]})"
            )
    else:
        log_lines.append(
            "preferred reassignment: SKIPPED (Preferred_Estimate or "
            "Results_Inflation_Annualized_Pct column missing)"
        )

    n_after = len(df)
    n_papers_after = df["Idstudy"].nunique()
    log_lines.append(f"output rows: {n_after}, unique Idstudy: {n_papers_after}")
    log_lines.append(
        f"net delta: {n_after - n_before} rows, "
        f"{n_papers_after - n_papers_before} papers"
    )
    log.info("v34 cleaning: %d -> %d rows, %d -> %d papers",
             n_before, n_after, n_papers_before, n_papers_after)
    return df, log_lines


def write_changelog(path: Path, lines: list[str]) -> None:
    """Append a dated v34 entry to CHANGELOG_data.md."""
    from datetime import datetime as _dt
    stamp = _dt.now().strftime("%Y-%m-%d %H:%M:%S")
    header = (
        f"\n## {stamp} \u2014 v34 cleaning "
        f"(phase2_build_analysis_dataset.py --v34)\n"
    )
    body = "\n".join(f"- {ln}" for ln in lines) + "\n"
    new_entry = header + body
    if path.exists():
        existing = path.read_text(encoding="utf-8")
    else:
        existing = (
            "# CHANGELOG\u2014 data\n\n"
            "Tracks every change to the analysis dataset and derived files.\n"
        )
    path.write_text(existing + new_entry, encoding="utf-8")
    log.info("Appended v34 entry to %s", path)


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input",  default=str(ROOT / "AI_dataset" / "v3_0_full" / "extracted_enriched_phase1.xlsx"))
    ap.add_argument("--outdir", default=str(ROOT / "AI_dataset" / "v3_0_full"))
    ap.add_argument("--dta",    default=str(ROOT / "Stata_code" / "inflation_v33.dta"))
    ap.add_argument("--boot-reps", type=int, default=1000)
    ap.add_argument("--winsor-p", type=float, default=0.05)
    ap.add_argument("--v34", action="store_true",
                    help="Apply v34 cleaning (DOI-dedup + ghost-row drop + "
                         "Affiliation_Class derivation) and write to v34 paths.")
    ap.add_argument("--xlsx-name", default=None,
                    help="Override output xlsx filename (in outdir). "
                         "Default: analysis_dataset.xlsx (or analysis_dataset_v34.xlsx if --v34).")
    ap.add_argument("--changelog", default=str(ROOT / "CHANGELOG_data.md"),
                    help="Path to data changelog (appended in --v34 mode).")
    args = ap.parse_args()

    # In --v34 mode, redirect outputs and pick a v34 dta path unless caller
    # has explicitly overridden them.
    if args.v34:
        if args.dta == str(ROOT / "Stata_code" / "inflation_v33.dta"):
            args.dta = str(ROOT / "Stata_code" / "inflation_v34.dta")
        if args.xlsx_name is None:
            args.xlsx_name = "analysis_dataset_v34.xlsx"
    else:
        if args.xlsx_name is None:
            args.xlsx_name = "analysis_dataset.xlsx"

    inp = Path(args.input)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "plots").mkdir(exist_ok=True)

    log.info("Loading %s", inp)
    df = pd.read_excel(inp)
    log.info("Loaded %d rows x %d cols", *df.shape)

    # ---------- 0. v34 cleaning (only if --v34) ----------------------------
    if args.v34:
        df, v34_log = apply_v34_cleaning(df)
        write_changelog(Path(args.changelog), v34_log)

    # Headline estimate (annualized %)
    df["Estimate"] = pd.to_numeric(df["Results_Inflation_Annualized_Pct"], errors="coerce")

    # ---------- 2. SE derivation --------------------------------------------
    log.info("Deriving SE hierarchically")
    # (a) SE from CI
    df["SE_from_CI"] = df.apply(
        lambda r: se_from_ci(r.get("Results_Inflation_CI_Low"),
                             r.get("Results_Inflation_CI_High"),
                             r.get("Results_Inflation_CI_Level")),
        axis=1,
    )
    n_from_ci = df["SE_from_CI"].notna().sum()
    log.info("  SE from CI: %d rows", n_from_ci)

    # (b) SE reported — only when estimator produces sampling SE
    est_has_sampling = df["Estimator_Type"].isin(["Bayesian", "GMM", "ML", "MLE", "OLS"])
    df["SE_reported"] = np.where(
        est_has_sampling & df["Std_Dev_Inflation"].notna(),
        df["Std_Dev_Inflation"],
        np.nan,
    )
    # exclude rows already covered by CI (avoid double count)
    df.loc[df["SE_from_CI"].notna(), "SE_reported"] = np.nan
    n_reported = df["SE_reported"].notna().sum()
    log.info("  SE reported (Bayesian/GMM/ML): %d rows", n_reported)

    # (c) SE bootstrap per paper
    log.info("Bootstrap SE per idstudy (reps=%d, seed=1234)", args.boot_reps)
    per_paper_se: dict[int, float] = {}
    for idstudy, g in df.groupby("Idstudy"):
        per_paper_se[idstudy] = bootstrap_se(g["Estimate"].values, reps=args.boot_reps, seed=1234)
    df["SE_bootstrap"] = df["Idstudy"].map(per_paper_se)
    # don't overwrite genuine SE
    mask_genuine = df["SE_from_CI"].notna() | df["SE_reported"].notna()
    df.loc[mask_genuine, "SE_bootstrap"] = np.nan
    n_boot = df["SE_bootstrap"].notna().sum()
    log.info("  SE bootstrap: %d rows (papers with >=2 estimates)", n_boot)

    # Final SE (coalesce)
    df["SE"] = df["SE_from_CI"].fillna(df["SE_reported"]).fillna(df["SE_bootstrap"])
    df["SE_source"] = np.select(
        [df["SE_from_CI"].notna(), df["SE_reported"].notna(), df["SE_bootstrap"].notna()],
        ["from_CI", "reported", "bootstrap"],
        default="none",
    )
    df["se_is_genuine"] = df["SE_source"].isin(["from_CI", "reported"]).astype(int)
    log.info("SE coverage: %d / %d (%.1f%%); genuine: %d",
             df["SE"].notna().sum(), len(df),
             100 * df["SE"].notna().mean(),
             df["se_is_genuine"].sum())

    # ---------- 3. Winsorization --------------------------------------------
    log.info("Winsorizing Estimate and SE at p=%.2f each tail", args.winsor_p)
    df["Estimate_win"] = winsorize(df["Estimate"], args.winsor_p)
    # winsorize SE separately (positive only)
    df["SE_win"] = df["SE"].copy()
    valid = df["SE_win"].notna() & (df["SE_win"] > 0)
    if valid.any():
        df.loc[valid, "SE_win"] = winsorize(df.loc[valid, "SE_win"], args.winsor_p)
    # guard against SE==0 -> inf
    safe_se = df["SE_win"].where(df["SE_win"] > 0)
    df["tstat"] = df["Estimate_win"] / safe_se
    df["precision"] = 1.0 / safe_se
    df["tstat"]     = df["tstat"].replace([np.inf, -np.inf], np.nan)
    df["precision"] = df["precision"].replace([np.inf, -np.inf], np.nan)

    # ---------- 4. Dummy encoding -------------------------------------------
    log.info("Dummy-encoding %d categorical columns", len(V33_CATEGORICAL_COLS))
    dummy_frames = [df]
    for col, prefix in V33_CATEGORICAL_COLS.items():
        d = dummy_encode(df, col, prefix)
        if not d.empty:
            log.info("  %s -> %d dummies", col, d.shape[1])
            dummy_frames.append(d)
    df_full = pd.concat(dummy_frames, axis=1)

    # Binary recodings for legacy Stata code compatibility
    df_full["FlexiblePrices"] = df_full["Flexible_Price_Assumption"].fillna(0).astype(int)
    df_full["StickyPrices"]   = (1 - df_full["FlexiblePrices"]).astype(int)
    df_full["ZLB"]            = df_full["Zero_Lower_Bound"].fillna(0).astype(int)
    df_full["ExogInfl"]       = df_full["Exogenous_Inflation"].fillna(0).astype(int)
    df_full["Growth"]         = df_full["Growth_Included"].fillna(0).astype(int)
    df_full["Ramsey"]         = df_full["Ramsey_Rule"].fillna(0).astype(int)
    df_full["Preferred"]      = df_full["Preferred_Estimate"].fillna(0).astype(int)

    # ---------- 5. Log transforms -------------------------------------------
    df_full["LCitations"] = np.log1p(pd.to_numeric(df_full["Num_Citations"], errors="coerce"))
    df_full["LIF"]        = np.log1p(pd.to_numeric(df_full["Impact_Factor"], errors="coerce"))

    # ---------- 5b. Drop DOI column ----------------------------------------
    # The DOI field was AI-extracted from PDFs without an OpenAlex/Scopus
    # verification step and is known to contain wrong DOIs in some rows
    # (user audit, 2026-06-01). Verified DOIs live in Bibl.bib instead;
    # the analysis dataset does not need this column.
    if "DOI" in df_full.columns:
        df_full = df_full.drop(columns=["DOI"])
        log.info("Dropped DOI column from analysis dataset (unverified field).")

    # ---------- 6. Export ---------------------------------------------------
    # Human-readable Excel
    xlsx_out = outdir / args.xlsx_name
    log.info("Writing Excel -> %s", xlsx_out)
    df_full.to_excel(xlsx_out, index=False)

    # Stata .dta — sanitize column names + drop wide object cols that Stata can't handle
    dta_out = Path(args.dta)
    dta_out.parent.mkdir(parents=True, exist_ok=True)
    log.info("Writing Stata -> %s", dta_out)

    # Build Stata-safe frame
    df_sta = df_full.copy()
    # replace inf with NaN (Stata doesn't support inf)
    df_sta = df_sta.replace([np.inf, -np.inf], np.nan)
    # Convert pandas nullable Int64 -> float for Stata
    for c in df_sta.columns:
        if pd.api.types.is_extension_array_dtype(df_sta[c]) and df_sta[c].dtype.name == "Int64":
            df_sta[c] = df_sta[c].astype("float64")
    # Truncate long free-text fields for Stata (str limit)
    TEXT_CAP = 244
    for c in df_sta.select_dtypes(include=["object", "string"]).columns:
        df_sta[c] = df_sta[c].astype(str).str.slice(0, TEXT_CAP).replace({"nan": ""})
    # Sanitize col names; de-dupe
    new_names = {}
    used = set()
    for c in df_sta.columns:
        nn = sanitize_col(c)
        base = nn
        k = 1
        while nn in used:
            nn = f"{base[:29]}_{k}"
            k += 1
        used.add(nn)
        new_names[c] = nn
    df_sta = df_sta.rename(columns=new_names)

    try:
        df_sta.to_stata(dta_out, write_index=False, version=118)
        log.info("  pandas.to_stata OK: %d rows x %d cols", *df_sta.shape)
    except Exception as e:
        log.warning("  pandas.to_stata failed: %s", e)
        if pyreadstat is not None:
            pyreadstat.write_dta(df_sta, str(dta_out))
            log.info("  pyreadstat fallback OK")
        else:
            raise

    # ---------- 7. Codebook -------------------------------------------------
    cb_path = outdir / "codebook.md"
    log.info("Writing codebook -> %s", cb_path)
    write_codebook(df_full, cb_path, new_names)

    # ---------- 8. Sanity plots --------------------------------------------
    log.info("Generating sanity plots")
    make_plots(df_full, outdir / "plots")

    # ---------- Summary -----------------------------------------------------
    log.info("=" * 60)
    log.info("Phase 2B done")
    log.info("  Final rows: %d", len(df_full))
    log.info("  Papers: %d", df_full["Idstudy"].nunique())
    log.info("  Estimate non-NA: %d", df_full["Estimate"].notna().sum())
    log.info("  SE non-NA: %d (genuine: %d)",
             df_full["SE"].notna().sum(), df_full["se_is_genuine"].sum())
    log.info("  Preferred rows: %d", df_full["Preferred"].sum())
    log.info("  SE source breakdown:")
    for k, v in df_full["SE_source"].value_counts().items():
        log.info("    %-12s %d", k, v)


# -----------------------------------------------------------------------------
# Codebook + plots
# -----------------------------------------------------------------------------
def write_codebook(df: pd.DataFrame, path: Path, stata_name_map: dict) -> None:
    lines = [
        "# Codebook — Optimal Inflation Meta-Analysis (v3.3)",
        "",
        f"- Rows: {len(df)}",
        f"- Papers: {df['Idstudy'].nunique()}",
        f"- Generated by `2025/phase2_build_analysis_dataset.py`",
        "",
        "## Variable list",
        "",
        "| Excel name | Stata name | Type | Non-NA | Description |",
        "|---|---|---|---|---|",
    ]
    for c in df.columns:
        n = df[c].notna().sum()
        dtype = str(df[c].dtype)
        stata_nm = stata_name_map.get(c, c)
        lines.append(f"| `{c}` | `{stata_nm}` | {dtype} | {n} | |")
    path.write_text("\n".join(lines), encoding="utf-8")


def make_plots(df: pd.DataFrame, plots_dir: Path) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        log.warning("matplotlib not available; skipping plots")
        return

    est = df["Estimate_win"].dropna()

    # Human-readable label maps (used across plots).
    SE_SRC_LABEL = {
        "from_CI":   "CI-derived (sampling SE)",
        "reported":  "Reported (Bayesian / GMM / ML)",
        "bootstrap": "Bootstrap within-study dispersion",
    }
    POLICY_LABEL = {
        "Ramsey_commitment":     "Ramsey (commitment)",
        "Ramsey_discretion":     "Ramsey (discretion)",
        "Optimized_Taylor_rule": "Optimized Taylor rule",
        "Taylor_rule":           "Taylor rule",
        "Friedman_rule":         "Friedman rule",
        "inflation_targeting":   "Inflation targeting",
        "price_level_targeting": "Price-level targeting",
        "laissez_faire":         "Laissez-faire",
        "discretion":            "Discretion",
        "other":                 "Other",
        "NA":                    "Unspecified",
    }
    FRICTION_LABEL = {
        "Calvo_prices":   "Calvo prices",
        "Rotemberg":      "Rotemberg prices",
        "Taylor_prices":  "Taylor prices",
        "menu_cost":      "Menu cost",
        "sticky_info":    "Sticky information",
        "flexible":       "Flexible prices",
        "mixed":          "Mixed",
        "other":          "Other",
        "NA":             "Unspecified",
    }
    def _label(mapping, key):
        return mapping.get(str(key), str(key).replace("_", " "))

    # 1. histogram
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(est, bins=60, edgecolor="black", alpha=0.8)
    ax.axvline(0, color="red", lw=1, label="Friedman rule (0%)")
    ax.axvline(2, color="orange", lw=1, linestyle="--", label="Central-bank target (2%)")
    ax.axvline(est.median(), color="black", lw=1, linestyle=":",
               label=f"Sample median ({est.median():.2f}%)")
    ax.set_xlabel("Optimal inflation rate (percent per year)")
    ax.set_ylabel("Number of estimates")
    ax.set_title("Distribution of optimal inflation estimates (5% winsorized)")
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()
    fig.savefig(plots_dir / "histogram.png", dpi=120)
    plt.close(fig)

    # 2. funnel plot (only where SE > 0)
    sub = df[(df["SE_win"].notna()) & (df["SE_win"] > 0)]
    if len(sub) > 10:
        fig, ax = plt.subplots(figsize=(8, 6))
        colors = {"from_CI": "tab:red", "reported": "tab:blue", "bootstrap": "tab:gray"}
        for src, g in sub.groupby("SE_source"):
            ax.scatter(g["Estimate_win"], 1 / g["SE_win"],
                       s=15, alpha=0.5,
                       label=f"{SE_SRC_LABEL.get(src, src)} (n={len(g)})",
                       color=colors.get(src, "black"))
        ax.axvline(0, color="red", lw=0.8, label="Friedman rule (0%)")
        ax.axvline(2, color="orange", lw=0.8, linestyle="--",
                   label="Central-bank target (2%)")
        ax.axvline(sub["Estimate_win"].median(), color="black", lw=0.8,
                   linestyle=":", label="Sample median")
        ax.set_xlabel("Optimal inflation rate (percent per year)")
        ax.set_ylabel("Precision (inverse of standard error)")
        ax.set_title("Funnel plot: precision versus estimated optimal inflation")
        ax.legend(loc="best", fontsize=8)
        fig.tight_layout()
        fig.savefig(plots_dir / "funnel.png", dpi=120)
        plt.close(fig)

    # 3. boxplot by Policy_Regime
    if "Policy_Regime" in df.columns:
        sub = df.dropna(subset=["Estimate_win", "Policy_Regime"])
        order = sub["Policy_Regime"].value_counts().index.tolist()
        counts = sub["Policy_Regime"].value_counts()
        labels = [f"{_label(POLICY_LABEL, k)}\n(n={counts[k]})" for k in order]
        data = [sub.loc[sub["Policy_Regime"] == k, "Estimate_win"].values for k in order]
        fig, ax = plt.subplots(figsize=(11, 5.5))
        ax.boxplot(data, labels=labels, showfliers=False)
        ax.axhline(0, color="red", lw=0.8, label="Friedman rule (0%)")
        ax.axhline(2, color="orange", lw=0.8, linestyle="--",
                   label="Central-bank target (2%)")
        ax.set_ylabel("Optimal inflation rate (percent per year)")
        ax.set_title("Optimal inflation estimates by assumed policy regime")
        ax.tick_params(axis="x", rotation=25)
        ax.legend(loc="best", fontsize=8)
        fig.tight_layout()
        fig.savefig(plots_dir / "box_policy.png", dpi=120)
        plt.close(fig)

    # 4. boxplot by Nominal_Friction_Type
    if "Nominal_Friction_Type" in df.columns:
        sub = df.dropna(subset=["Estimate_win", "Nominal_Friction_Type"])
        order = sub["Nominal_Friction_Type"].value_counts().index.tolist()
        counts = sub["Nominal_Friction_Type"].value_counts()
        labels = [f"{_label(FRICTION_LABEL, k)}\n(n={counts[k]})" for k in order]
        data = [sub.loc[sub["Nominal_Friction_Type"] == k, "Estimate_win"].values for k in order]
        fig, ax = plt.subplots(figsize=(11, 5.5))
        ax.boxplot(data, labels=labels, showfliers=False)
        ax.axhline(0, color="red", lw=0.8, label="Friedman rule (0%)")
        ax.axhline(2, color="orange", lw=0.8, linestyle="--",
                   label="Central-bank target (2%)")
        ax.set_ylabel("Optimal inflation rate (percent per year)")
        ax.set_title("Optimal inflation estimates by price-setting friction")
        ax.tick_params(axis="x", rotation=25)
        ax.legend(loc="best", fontsize=8)
        fig.tight_layout()
        fig.savefig(plots_dir / "box_friction.png", dpi=120)
        plt.close(fig)

    # 5. line plot of yearly mean ± 1.96*SE (95% CI) + ±1 SD band
    sub = df.dropna(subset=["Estimate_win", "Year"]).copy()
    if len(sub) > 10:
        yearly = (sub.groupby("Year")["Estimate_win"]
                  .agg(["mean", "std", "count", "median"])
                  .rename(columns={"std": "sd"}))
        yearly["se_mean"] = yearly["sd"] / np.sqrt(yearly["count"])
        yearly = yearly.sort_index()

        fig, ax = plt.subplots(figsize=(9, 5))
        ax.fill_between(yearly.index,
                        yearly["mean"] - yearly["sd"],
                        yearly["mean"] + yearly["sd"],
                        color="tab:blue", alpha=0.15,
                        label="±1 standard deviation across estimates")
        ax.fill_between(yearly.index,
                        yearly["mean"] - 1.96 * yearly["se_mean"],
                        yearly["mean"] + 1.96 * yearly["se_mean"],
                        color="tab:blue", alpha=0.35,
                        label="95% confidence interval of the mean")
        ax.plot(yearly.index, yearly["mean"], "-o", color="tab:blue",
                lw=1.8, ms=4, label="Yearly mean")
        ax.plot(yearly.index, yearly["median"], "--", color="black",
                lw=1, label="Yearly median")
        ax.axhline(0, color="red", lw=0.8, label="Friedman rule (0%)")
        ax.axhline(2, color="orange", lw=0.8, linestyle="--",
                   label="Central-bank target (2%)")
        for y, n in yearly["count"].items():
            if n >= 10:
                ax.annotate(str(int(n)),
                            xy=(y, yearly.loc[y, "mean"]),
                            xytext=(0, 8), textcoords="offset points",
                            ha="center", fontsize=7, color="gray")
        ax.set_xlabel("Publication year")
        ax.set_ylabel("Optimal inflation rate (percent per year)")
        ax.set_title("Evolution of optimal inflation estimates over publication years")
        ax.legend(loc="best", fontsize=8)
        fig.tight_layout()
        fig.savefig(plots_dir / "line_year.png", dpi=120)
        plt.close(fig)

    log.info("  wrote plots in %s", plots_dir)


if __name__ == "__main__":
    main()
