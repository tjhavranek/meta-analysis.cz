"""regenerate_table_variables.py

Regenerate the numeric Mean / S.D. columns of manuscript Table 2
(`tab:variables`) directly from the canonical analysis dataset
`stata/inflation_v34.dta`.

Why this script exists
----------------------
Table 2 in `manuscript/main.tex` is a hand-coded longtable. During the
v34 dataset rebuild the descriptive statistics in
`o_Desc_stats_v34.tex` (Stata-driven Table 3) were refreshed but the
hard-coded numbers in Table 2 were left at v33 / pre-winsor values
(e.g. Optimal inflation 0.70 / 2.43 vs. the correct 0.74 / 2.38;
Ramsey planner 0.62 vs. 0.68; Log citations 3.26 vs. 3.41).

This script:
1. Loads `stata/inflation_v34.dta`.
2. Restricts to the 777-row analysis sample (`Estimate_win` non-missing).
3. Computes Mean / S.D. for each Table 2 variable using the mapping in
   `TABLE2_MAPPING` below.
4. Surgically rewrites only the Mean and S.D. cells of the matching
   rows in `manuscript/main.tex`. Variable labels and Definitions are
   left untouched.
5. Writes an audit JSON `manuscript/_table2_audit.json` recording the
   mapping, computed values, old values, and any rows that were
   skipped.

Run from the repository root:

    python Dropbox_Tomas/replication_package_FIXED/python/regenerate_table_variables.py

Idempotent: rerunning against an already-updated tex file produces the
same output.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
HERE = Path(__file__).resolve()
PKG_ROOT = HERE.parent.parent  # replication_package_FIXED/
REPO_ROOT = PKG_ROOT.parent     # Dropbox_Tomas/
DTA_PATH = PKG_ROOT / "stata" / "inflation_v34.dta"
TEX_PATH = REPO_ROOT / "manuscript" / "main.tex"
AUDIT_PATH = REPO_ROOT / "manuscript" / "_table2_audit.json"

# ---------------------------------------------------------------------------
# Variable-label -> .dta-column mapping
# ---------------------------------------------------------------------------
# Each entry: { "label_in_tex": <verbatim text shown in column 1 of Table 2>,
#                "column":      <pandas expression / column name in df> }
# A few labels need a synthesised column (e.g. "Learning or bounded
# rationality" combines two dummies). Those use a callable.

# Continuous variables use list-wise deletion (dropna). All other rows in
# the mapping are 0/1 dummies and follow the R/Stata analysis pipeline:
# missing dummy => 0 (= feature absent), evaluated over all 777 analysis
# rows.
CONTINUOUS_LABELS = {
    "Optimal inflation",
    "Standard error",
    "Publication year",
    "Log citations",
    "Log impact factor",
}

TABLE2_MAPPING: list[dict] = [
    # A. Outcome and precision
    {"label": "Optimal inflation",                    "column": "Estimate_win"},
    {"label": "Standard error",                       "column": "SE_win"},
    # B. Policy regime
    {"label": "Ramsey planner",                       "column": "Ramsey"},
    {"label": "Optimised Taylor rule",                "column": "PR_Optimized_Taylor_rule"},
    # "Estimated Taylor rule" => generic (non-optimised) Taylor rule
    # indicator. PR_Estimated_policy applies to only 4 rows; the
    # narrative match is PR_Taylor_rule (matches the v33 mean of ~0.11).
    {"label": "Estimated Taylor rule",                "column": "PR_Taylor_rule"},
    {"label": "Friedman rule",                        "column": "PR_Friedman_rule"},
    {"label": "Inflation targeting",                  "column": "PR_Inflation_targeting"},
    {"label": "Zero inflation",                       "column": "PR_Zero_inflation"},
    # C. Nominal price frictions
    {"label": "Calvo prices",                         "column": "NFT_Calvo_prices"},
    {"label": "Rotemberg prices",                     "column": "NFT_Rotemberg_prices"},
    {"label": "Taylor contracts",                     "column": "NFT_Taylor_contracts"},
    {"label": "Flexible prices",                      "column": "NFT_flexible"},
    {"label": "Menu-cost pricing",                    "column": "NFT_menu_cost"},
    # D. Wage rigidities
    {"label": "Calvo wages",                          "column": "WRT_Calvo_wages"},
    {"label": "DNWR",                                 "column": "WRT_DNWR"},
    {"label": "Rotemberg wages",                      "column": "WRT_Rotemberg_wages"},
    {"label": "Sticky real wages",                    "column": "WRT_sticky_real_wages"},
    {"label": "No wage rigidity",                     "column": "WRT_none"},
    # E. Money-demand technology
    {"label": "Cashless",                             "column": "MDT_cashless"},
    {"label": "Money in utility (MIU)",               "column": "MDT_MIU"},
    {"label": "Cash-in-advance (CIA)",                "column": "MDT_CIA"},
    {"label": "Transactions technology",              "column": "MDT_transactions_technology"},
    # F. Indexation
    {"label": "No indexation",                        "column": "IND_none"},
    {"label": "Indexed to past inflation",            "column": "IND_past_inflation"},
    {"label": "Indexed to trend inflation",           "column": "IND_trend_inflation"},
    {"label": "Hybrid indexation",                    "column": "IND_hybrid"},
    # G. Shock structure
    {"label": "TFP shocks only",                      "column": "SHK_TFP"},
    {"label": "Multiple shocks",                      "column": "SHK_Multiple"},
    {"label": "Mark-up shocks",                       "column": "SHK_Markup"},
    {"label": "Cost-push shocks",                     "column": "SHK_Cost_push"},
    {"label": "Risk-premium shocks",                  "column": "SHK_Risk_premium"},
    {"label": "Government-spending shocks",           "column": "SHK_Government_spending"},
    {"label": "Wage mark-up shocks",                  "column": "SHK_Wage_markup"},
    {"label": "Financial shocks",                     "column": "SHK_Financial"},
    {"label": "Preference shocks",                    "column": "SHK_Preference"},
    # H. Structural augmentations
    # "Zero lower bound" matches Stata's canonical descriptive table
    # (`o_Desc_stats_v34.tex`), which uses the full-sample `ZLB` column
    # (n=777). `AUG_ZLB` is only populated for ~378 rows and is not the
    # variable referenced in the manuscript text.
    {"label": "Zero lower bound",                     "column": "ZLB"},
    {"label": "Financial frictions",                  "column": "AUG_financial_frictions"},
    {"label": "Fiscal policy",                        "column": "AUG_fiscal_policy"},
    {"label": "Heterogeneous agents",                 "column": "AUG_heterogeneous_agents"},
    {"label": "Labour-market frictions",              "column": "AUG_labor_market_frictions"},
    {"label": "Open economy",                         "column": "AUG_open_economy"},
    {"label": "Trend growth",                         "column": "Growth"},
    # I. Welfare criterion and solution
    {"label": "Unconditional welfare",                "column": "WC_unconditional"},
    {"label": "Conditional welfare at efficient SS",  "column": "WC_conditional_efficient_SS"},
    {"label": "Consumption-equivalent metric",        "column": "WC_consumption_equivalent"},
    {"label": "First-order approximation",            "column": "WC_first_order_approx"},
    {"label": "Second-order approximation",           "column": "WC_second_order_approx"},
    # NOTE: there is no `WC_global` column in the .dta. We leave the
    # "Global solution" row untouched and record this in the audit.
    {"label": "Global solution",                      "column": None},
    # J. Estimation and expectations
    {"label": "Calibration",                          "column": "EST_calibration"},
    {"label": "Bayesian estimation",                  "column": "EST_Bayesian"},
    {"label": "GMM estimation",                       "column": "EST_GMM"},
    {"label": "Rational expectations",                "column": "EXP_rational"},
    # "Learning or bounded rationality" combines the learning, adaptive,
    # and boundedly-rational expectations dummies (any one => 1).
    {"label": "Learning or bounded rationality",      "column":
        ("EXP_learning", "EXP_boundedly_rational", "EXP_adaptive")},
    # K. Publication characteristics
    {"label": "Published in a journal",               "column": "PUB_published"},
    {"label": "NBER working paper",                   "column": "PUB_NBER_WP"},
    {"label": "Other working paper",                  "column": "PUB_working_paper"},
    {"label": "Publication year",                     "column": "Year"},
    {"label": "Log citations",                        "column": "LCitations"},
    {"label": "Log impact factor",                    "column": "LIF"},
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _format_number(x: float) -> str:
    """Match the formatting used in the existing tex (mostly 2dp; small
    values use 3dp to avoid printing 0.00).
    """
    if pd.isna(x):
        return "NA"
    abs_x = abs(x)
    if abs_x >= 100:
        return f"{x:.1f}"
    if abs_x < 0.01 and abs_x > 0:
        return f"{x:.3f}"
    return f"{x:.2f}"


def compute_stat(df: pd.DataFrame, col_spec, *, is_continuous: bool) -> tuple[float, float, int]:
    """Return (mean, sd, n) for a column spec.

    `col_spec` is either a string (single column) or a tuple of strings
    (any-of dummy combination, OR over the listed columns).

    For continuous variables we drop missing values before computing
    moments (consistent with Stata's `summarize`). For dummy variables
    we recode NA -> 0, mirroring the R/Stata analysis pipeline
    (`Inflation_v34.R` line: "recoded dummy NAs to 0").
    """
    if col_spec is None:
        return (np.nan, np.nan, 0)
    if isinstance(col_spec, tuple):
        # Combined dummy: OR across listed columns; missing => 0.
        sub = df[list(col_spec)].fillna(0)
        s = (sub.sum(axis=1) > 0).astype(float)
        return (float(s.mean()), float(s.std(ddof=1)), int(s.shape[0]))
    s = pd.to_numeric(df[col_spec], errors="coerce")
    if is_continuous:
        s = s.dropna()
    else:
        s = s.fillna(0)
    return (float(s.mean()), float(s.std(ddof=1)), int(s.shape[0]))


# Regex that captures one Table 2 data row of the form
#   <label> & <definition> & $...$ & $...$\\
# We only rewrite the last two $...$ groups (Mean and S.D.).
ROW_RE = re.compile(
    r"^(?P<label>[^&\n]+?)\s*&\s*"
    r"(?P<defn>.+?)\s*&\s*"
    r"\$(?P<mean>[^$]+)\$\s*&\s*"
    r"\$(?P<sd>[^$]+)\$"
    r"(?P<tail>\s*\\\\.*)$",
    re.MULTILINE,
)


def main() -> None:
    if not DTA_PATH.exists():
        raise SystemExit(f"Cannot find {DTA_PATH}")
    if not TEX_PATH.exists():
        raise SystemExit(f"Cannot find {TEX_PATH}")

    df_all = pd.read_stata(DTA_PATH)
    n_raw = len(df_all)
    df = df_all[df_all["Estimate_win"].notna()].copy()
    n_analysis = len(df)
    print(f"Loaded {n_raw} rows; {n_analysis} in analysis sample (Estimate_win non-missing).")

    # Compute statistics for every mapping entry.
    audit_entries: list[dict] = []
    label_to_stats: dict[str, tuple[str, str]] = {}
    for entry in TABLE2_MAPPING:
        label = entry["label"]
        col = entry["column"]
        if col is None:
            audit_entries.append({
                "label": label,
                "column": None,
                "skipped": True,
                "reason": "no matching column in .dta; row left untouched",
            })
            continue
        mean, sd, n = compute_stat(df, col, is_continuous=(label in CONTINUOUS_LABELS))
        mean_str = _format_number(mean)
        sd_str = _format_number(sd)
        label_to_stats[label] = (mean_str, sd_str)
        audit_entries.append({
            "label": label,
            "column": col if not isinstance(col, tuple) else list(col),
            "mean": mean,
            "sd": sd,
            "n": n,
            "mean_tex": mean_str,
            "sd_tex": sd_str,
        })

    # Read tex, surgically replace.
    text = TEX_PATH.read_text(encoding="utf-8")
    n_replaced = 0
    n_unchanged = 0
    not_found: list[str] = []
    old_values: dict[str, tuple[str, str]] = {}

    def repl(m: re.Match) -> str:
        nonlocal n_replaced, n_unchanged
        label_raw = m.group("label").strip()
        # Strip leading TeX bracketed prefixes (e.g. \multicolumn{...}). The
        # block-header rows contain `\multicolumn{4}{@{}l}{\textbf{...}}` and
        # have no `&` separators, so they will not match this regex anyway.
        if label_raw not in label_to_stats:
            return m.group(0)
        new_mean, new_sd = label_to_stats[label_raw]
        old_mean = m.group("mean").strip()
        old_sd = m.group("sd").strip()
        if old_mean == new_mean and old_sd == new_sd:
            n_unchanged += 1
        else:
            n_replaced += 1
            old_values[label_raw] = (old_mean, old_sd)
        return (
            f"{m.group('label')}& {m.group('defn')} & "
            f"${new_mean}$ & ${new_sd}${m.group('tail')}"
        )

    # Scope replacement to the Table 2 longtable to avoid touching other
    # tables that share `& $..$ & $..$\\` patterns.
    start = text.find("\\caption{Variable definitions and summary statistics.}")
    if start == -1:
        raise SystemExit("Could not locate Table 2 caption in main.tex.")
    end = text.find("\\end{longtable}", start)
    if end == -1:
        raise SystemExit("Could not locate \\end{longtable} after Table 2 caption.")
    end += len("\\end{longtable}")

    pre, body, post = text[:start], text[start:end], text[end:]
    new_body = ROW_RE.sub(repl, body)

    matched_labels = {m.group("label").strip() for m in ROW_RE.finditer(body)}
    for label in label_to_stats:
        if label not in matched_labels:
            not_found.append(label)

    # Annotate audit with old values.
    for entry in audit_entries:
        lbl = entry["label"]
        if lbl in old_values:
            entry["old_mean_tex"], entry["old_sd_tex"] = old_values[lbl]
        elif lbl in label_to_stats and lbl not in not_found:
            entry["old_mean_tex"] = entry["mean_tex"]  # already correct
            entry["old_sd_tex"] = entry["sd_tex"]

    if new_body != body:
        TEX_PATH.write_text(pre + new_body + post, encoding="utf-8")
        print(f"Updated {TEX_PATH}: {n_replaced} rows changed, {n_unchanged} already correct.")
    else:
        print(f"No changes needed in {TEX_PATH} ({n_unchanged} rows already correct).")

    if not_found:
        print("WARNING: the following labels from TABLE2_MAPPING were not "
              "matched in the tex Table 2 body:")
        for lbl in not_found:
            print(f"  - {lbl}")

    audit = {
        "dta": str(DTA_PATH.relative_to(REPO_ROOT.parent)),
        "tex": str(TEX_PATH.relative_to(REPO_ROOT.parent)),
        "n_raw_rows": n_raw,
        "n_analysis_rows": n_analysis,
        "n_rows_replaced": n_replaced,
        "n_rows_already_correct": n_unchanged,
        "labels_not_found_in_tex": not_found,
        "entries": audit_entries,
    }
    AUDIT_PATH.write_text(json.dumps(audit, indent=2), encoding="utf-8")
    print(f"Audit written to {AUDIT_PATH}.")


if __name__ == "__main__":
    main()
