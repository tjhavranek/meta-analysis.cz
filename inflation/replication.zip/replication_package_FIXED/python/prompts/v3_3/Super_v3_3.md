# AI Meta-Analysis Extractor — Master Instructions (v3.3, 2026-04)

Revision of v3.2. **All v3.2 rules remain in force.** This document adds 15
new columns to capture heterogeneity that v3.2 missed (policy regime,
shock type, nominal rigidity type, wage rigidity, welfare criterion, etc.)
plus meta-analysis-standard fields (sample size, publication status,
estimator type).

Changes vs v3.2:

- **Row-level heterogeneity (results stage).** New: `Policy_Regime`,
  `Shock_Type`, `Welfare_Criterion`, `Steady_State_Type`,
  `Sensitivity_Type`, `Expectations`. These are row-level because a single
  paper often compares several regimes / shocks / sensitivity cases.
- **Paper-level rigidity (structure stage).** New: `Nominal_Friction_Type`,
  `Wage_Rigidity_Type`, `Money_Demand_Tech`, `Indexation_Type`. These
  supplement (not replace) the v3.2 `Flexible_Price_Assumption` flag,
  which is kept for comparability with the v3.2 extraction.
- **Publication / empirical fields.** New metadata column
  `Publication_Status`; new results-stage columns `Sample_Size`,
  `Sample_Period_Start`, `Sample_Period_End`, `Estimator_Type`.
- **Ramsey_Rule retained.** Still paper-level binary as in v3.2. The new
  row-level `Policy_Regime` is the preferred downstream regressor, but
  we keep `Ramsey_Rule` for apples-to-apples comparison across extractions.
- **Tightened CI/SE rules** — unchanged from v3.2.
- **Closed vocabularies unchanged for all v3.2 columns**; only
  additions documented below.

---

## 0. TOP-OF-STACK RULES (read before anything else)

1. **Fidelity over completeness.** If the PDF does not contain a value, output
   `"NA"`. Never guess, never interpolate from "typical" values, never invent a
   number that looks plausible. A missed cell is recoverable; an invented one
   poisons the meta-analysis.
2. **You have no tools and no internet.** You cannot query Scopus, OpenAlex,
   Google Scholar, journal websites, or any database. Fields that depend on
   external data (`Num_Citations`, `Impact_Factor`) are **always `"NA"`** in
   your output. Python fills them later from the OpenAlex API.
3. **Output is strict JSON** matching the schema in §5. No prose before or
   after. No markdown fences. No comments.
4. **One `Preferred_Estimate=1`.** At most one row per paper has
   `Preferred_Estimate=1`. If the authors never name a preferred value, mark
   their baseline/benchmark row. If there is genuinely no basis for a choice,
   mark row 1.
5. **Signs are sacred.** `-2.5` and `2.5` are different answers. The Friedman
   rule is negative. Deflation is negative. Always check for the minus sign
   in both text and tables.
6. **Units are explicit.** Report the number as the paper reports it, then
   tag its unit in `Inflation_Unit` (`annual_pct`, `quarterly_pct`,
   `monthly_pct`, `decimal_annual`, `decimal_quarterly`, or `unknown`).
   Do **not** convert.
7. **New closed vocabularies are enforced by a downstream validator.** If
   uncertain between two tags, prefer the more specific one or emit `"NA"`.
   A clean `"NA"` is always better than a creative value.

---

## 1. PIPELINE STAGE YOU ARE IN

The Python pipeline calls you four times per paper, with a different
`doc_type` each time. Only fill the columns assigned to your stage. All
others must be `"NA"`. The stages are:

| doc_type   | Columns owned (new v3.3 columns in **bold**)                                    | Rows                 |
| ---------- | ------------------------------------------------ | -------------------- |
| `pre_scan` | `count` only (integer)                           | N/A (scalar output)  |
| `metadata` | Title, Author, Author_Affiliation, DOI, Journal_Name, Year, Model_Class, Model_Paradigm, Country, **Publication_Status** | 1 |
| `structure`| Augmented_base_model, Augmentation_Description, Augmentation_Category, Ramsey_Rule, HH_Included, Firms_Included, Banks_Included, Government_Included, HH_Maximization_Type, HH_Maximized_Vars, Producer_Type, Producer_Assumption, Other_Agent_Included, Other_Agent_Assumptions, Empirical_Research, Calibration_Frequency, **Nominal_Friction_Type**, **Wage_Rigidity_Type**, **Money_Demand_Tech**, **Indexation_Type** | 1 |
| `results`  | IdEstimate, Flexible_Price_Assumption, Exogenous_Inflation, Growth_Included, Zero_Lower_Bound, Results_Table, Results_Inflation, Inflation_Unit, Horizon, Results_Inflation_CI_Low, Results_Inflation_CI_High, Results_Inflation_CI_Level, Results_Inflation_Assumption, Preferred_Estimate, Reason_for_Preferred, Std_Dev_Inflation, SE_Derivation, Interest_Rate, plus the 10 parameter columns, **Policy_Regime**, **Shock_Type**, **Welfare_Criterion**, **Steady_State_Type**, **Sensitivity_Type**, **Expectations**, **Sample_Size**, **Sample_Period_Start**, **Sample_Period_End**, **Estimator_Type** | N (one per distinct inflation result) |

`Idstudy` is injected by the Python pipeline. Always output `"NA"` for
`Idstudy`.

---

## 2. STAGE 0 — PRE-SCAN (`doc_type = "pre_scan"`)

Unchanged from v3.2.

### Output (strict JSON)

```json
{
  "count": 7,
  "sources": [
    {"location": "Table 2 p.14", "n": 4, "note": "baseline + 3 sensitivity rows"},
    {"location": "Table 5 p.19", "n": 3, "note": "with/without ZLB"}
  ]
}
```

---

## 3. STAGE 1 — METADATA (`doc_type = "metadata"`)

All v3.2 rules apply. One new column:

### NEW: `Publication_Status` — closed vocabulary

Pick exactly one based on the first page, cover page, or masthead:

- `"published"` — appeared in a peer-reviewed journal. Journal masthead
  or DOI pointing to a journal.
- `"NBER_WP"` — NBER Working Paper series.
- `"working_paper"` — any other working paper series (CEPR, IMF, ECB, BIS,
  Fed, university WP). Also includes SSRN posts explicitly marked as WP.
- `"discussion_paper"` — central-bank discussion paper series or similar.
- `"preprint"` — unreviewed preprint, arXiv, etc.
- `"NA"` — genuinely ambiguous.

**Priority rule.** If the same paper appears both as an NBER WP and a
published version, prefer `"published"` — the version you are reading is
presumably the final one.

### Output

```json
{
  "rows": [
    {
      "Title": "Optimal monetary policy and imperfect financial markets: A case for negative nominal interest rates",
      "Author": "Abo-Zaid, S. (2015)",
      "Author_Affiliation": "Texas Tech University",
      "DOI": "10.1016/j.red.2014.04.002",
      "Journal_Name": "Review of Economic Dynamics",
      "Num_Citations": "NA",
      "Year": "2015",
      "Model_Class": "DSGE",
      "Model_Paradigm": "New Keynesian",
      "Country": "US",
      "Impact_Factor": "NA",
      "Publication_Status": "published"
    }
  ]
}
```

---

## 4. STAGE 2 — STRUCTURE (`doc_type = "structure"`)

All v3.2 rules apply. Four new paper-level columns:

### NEW: `Nominal_Friction_Type` — closed vocabulary

The type of nominal price rigidity in the model. Pick exactly one:

- `"Calvo_prices"` — Calvo (1983) staggered price-setting, prices only.
- `"Rotemberg_prices"` — Rotemberg (1982) quadratic adjustment cost on prices.
- `"Taylor_contracts"` — Taylor (1980) fixed-duration contracts.
- `"Calvo_prices_and_wages"` — Calvo price AND wage stickiness jointly
  (EHL-style).
- `"menu_cost"` — state-dependent fixed menu costs (Golosov-Lucas-style).
- `"information_friction"` — rational-inattention / sticky-information
  (no direct price rigidity).
- `"flexible"` — flexible prices; no nominal friction at all (RBC, MIU,
  CIA, flex-price DMP).
- `"other"` — any other mechanism the paper describes (document in
  `Augmentation_Description`).
- `"NA"` — empirical-only paper with no explicit model of nominal rigidity.

### NEW: `Wage_Rigidity_Type` — closed vocabulary

Separate field because wage rigidity is a distinct driver of positive
optimal inflation. Pick exactly one:

- `"none"` — flexible wages (most DSGE papers default here).
- `"Calvo_wages"` — Calvo staggered wage-setting.
- `"Rotemberg_wages"` — quadratic adjustment cost on wages.
- `"Taylor_wages"` — fixed-duration wage contracts.
- `"DNWR"` — downward nominal wage rigidity (asymmetric).
- `"search_and_matching"` — DMP bargaining determines wages (not stickiness
  per se but a friction).
- `"sticky_real_wages"` — real-wage inertia (Blanchard-Gali).
- `"other"` — any other explicit wage friction.
- `"NA"` — not specified.

**Combination rule.** If the paper has BOTH Calvo prices AND Calvo wages,
set `Nominal_Friction_Type = "Calvo_prices_and_wages"` AND
`Wage_Rigidity_Type = "Calvo_wages"`. The two fields are independent.

### NEW: `Money_Demand_Tech` — closed vocabulary

How money is introduced into the economy. Pick exactly one:

- `"MIU"` — money-in-the-utility function.
- `"CIA"` — cash-in-advance constraint.
- `"shopping_time"` — shopping-time technology where money reduces
  transaction costs.
- `"transactions_technology"` — explicit transactions cost function
  (non-shopping-time variant).
- `"cashless"` — Woodford-style cashless limit with interest-rate rules;
  no money explicitly modelled.
- `"none"` — paper does not model money (e.g. empirical reduced-form
  inflation regression).
- `"NA"` — ambiguous.

### NEW: `Indexation_Type` — closed vocabulary

Whether non-optimising firms/workers index prices or wages to past
inflation or trend inflation. Pick exactly one:

- `"none"` — no indexation; non-optimisers keep last-period nominal price.
- `"past_inflation"` — full or partial indexation to last-period inflation
  (χ or λ in many NK papers).
- `"trend_inflation"` — indexation to steady-state inflation only.
- `"hybrid"` — mixture of past and trend (Christiano-Eichenbaum-Evans).
- `"full"` — 100 % indexation to some measure (treat as `"past_inflation"`
  if unclear).
- `"NA"` — flex-price / no price-setter / not described.

### Output

```json
{
  "rows": [
    {
      "Augmented_base_model": 1,
      "Augmentation_Description": "Ramsey optimal tax and monetary policy with Calvo prices and distortionary taxes",
      "Augmentation_Category": "fiscal_policy",
      "Ramsey_Rule": 1,
      "HH_Included": 1,
      "Firms_Included": 1,
      "Banks_Included": 0,
      "Government_Included": 1,
      "HH_Maximization_Type": "expected utility",
      "HH_Maximized_Vars": "consumption, labor, real money",
      "Producer_Type": "intermediate firms, final firms",
      "Producer_Assumption": "intermediate firms: monopolistic competition; final firms: perfect competition",
      "Other_Agent_Included": 0,
      "Other_Agent_Assumptions": "NA",
      "Empirical_Research": 0,
      "Calibration_Frequency": "Q",
      "Nominal_Friction_Type": "Calvo_prices",
      "Wage_Rigidity_Type": "none",
      "Money_Demand_Tech": "MIU",
      "Indexation_Type": "past_inflation"
    }
  ]
}
```

---

## 5. STAGE 3 — RESULTS (`doc_type = "results"`)

All v3.2 rules apply. Ten new row-level columns:

### NEW: `Policy_Regime` — closed vocabulary (ROW-LEVEL)

The monetary-policy rule under which THIS row's inflation value obtains.
**Crucial for row-level heterogeneity.** Many papers compare multiple
regimes in a single table; code each row separately. Pick exactly one:

- `"Ramsey"` — jointly-optimal planner solution with commitment.
- `"Ramsey_discretion"` — optimal policy without commitment.
- `"Friedman_rule"` — zero nominal interest rate / deflation at rate of
  time preference.
- `"Taylor_rule"` — simple interest-rate rule reacting to inflation
  (possibly output); "simple rules" results.
- `"Optimized_Taylor_rule"` — Taylor-type rule with coefficients optimized
  over welfare.
- `"Zero_inflation"` — price-stability target imposed by assumption.
- `"Inflation_targeting"` — empirical/announced target rate (typically 2 %);
  historical policy calibration.
- `"Laissez_faire"` — competitive equilibrium with no policy / constant
  money growth / given exogenous policy.
- `"Estimated_policy"` — estimated policy rule from data (empirical papers).
- `"Other"` — any other named rule (document in `Results_Inflation_Assumption`).
- `"NA"` — genuinely unclear.

**Priority rule.** If a row is the Ramsey solution of a model WITH a
binding fiscal constraint (= the v3.2 `Ramsey_Rule=1` case), code as
`"Ramsey"`. Use `"Friedman_rule"` even inside a Ramsey paper if that
specific row shows the Friedman-rule benchmark.

### NEW: `Shock_Type` — closed vocabulary (ROW-LEVEL)

The primary stochastic driver that generates THIS row's inflation value.
Pick exactly one:

- `"TFP"` — technology / productivity shock.
- `"Markup"` — price-markup or desired-markup shock.
- `"Cost_push"` — exogenous cost-push wedge on the NKPC.
- `"Monetary"` — monetary policy shock (or interest-rate shock).
- `"Government_spending"` — fiscal / government-spending shock.
- `"Risk_premium"` — risk-premium or discount-factor shock.
- `"Financial"` — financial / credit-spread / bank-capital shock.
- `"Wage_markup"` — wage-markup shock.
- `"Preference"` — preference / discount-factor shock (not risk premium).
- `"Labor_supply"` — labor-supply shock.
- `"Multiple"` — the row averages over several shocks (typical DSGE
  calibration simulating all estimated shocks at once).
- `"None"` — deterministic steady state with no stochastic shocks.
- `"NA"` — not specified.

**Default.** A baseline long-run Ramsey result in a paper with multiple
estimated shocks should be coded `"Multiple"`. A Friedman-rule result in
a deterministic model should be `"None"`.

### NEW: `Welfare_Criterion` — closed vocabulary (ROW-LEVEL)

Which welfare criterion was maximised to produce THIS row's inflation.
Pick exactly one:

- `"unconditional"` — unconditional expectation of lifetime utility.
- `"conditional_efficient_SS"` — conditional on starting from the
  efficient (or deterministic) steady state.
- `"second_order_approx"` — second-order approximation to welfare used
  (common in SGU-style analysis).
- `"first_order_approx"` — first-order approximation / linear-quadratic
  loss function.
- `"consumption_equivalent"` — reported as consumption-equivalent welfare
  gain (row's inflation is value that maximises this).
- `"observed"` — historical / empirical inflation rate, no welfare max.
- `"NA"` — not applicable or not specified.

### NEW: `Steady_State_Type` — closed vocabulary (ROW-LEVEL)

- `"stochastic"` — stochastic steady state (averaged over shocks).
- `"deterministic"` — deterministic steady state (no shocks).
- `"transition"` — row is from a transition / impulse-response path.
- `"NA"` — not specified.

**Default.** If `Horizon = "long_run"` and the model is stochastic, code
as `"stochastic"`. If the paper explicitly reports a deterministic
steady-state optimum (common in flexible-price analyses), code
`"deterministic"`.

### NEW: `Sensitivity_Type` — closed vocabulary (ROW-LEVEL)

Flag the role of THIS row in the paper's narrative:

- `"baseline"` — the paper's main/benchmark calibration row. Usually
  exactly one per paper (or per sub-model); same row as
  `Preferred_Estimate=1` most of the time.
- `"robustness_parameter"` — re-computation of the baseline under a
  different numerical parameter (e.g. different β, different σ). Model
  structure is unchanged.
- `"robustness_mechanism"` — re-computation of the baseline under a
  different mechanism switch (e.g. with/without ZLB, with/without
  indexation).
- `"extension"` — distinct model variant developed in a separate
  section, not just robustness (e.g. open-economy extension of a
  closed-economy baseline).
- `"comparison"` — benchmark for comparison, not the paper's own
  preferred model (e.g. a Friedman-rule reference point in a Ramsey paper).
- `"NA"` — cannot classify.

### NEW: `Expectations` — closed vocabulary (ROW-LEVEL)

- `"rational"` — full-information rational expectations.
- `"adaptive"` — adaptive / backward-looking expectations.
- `"learning"` — least-squares learning (Evans-Honkapohja style).
- `"heterogeneous"` — heterogeneous expectations across agents.
- `"boundedly_rational"` — bounded rationality / rational inattention.
- `"NA"` — not specified.

**Default.** Most DSGE papers use `"rational"` unless explicitly stated.

### NEW: `Sample_Size` (ROW-LEVEL, empirical rows)

Integer number of observations used in the estimation producing THIS
row's inflation value. For purely calibrated DSGE papers, `"NA"`.

### NEW: `Sample_Period_Start`, `Sample_Period_End` (ROW-LEVEL, empirical)

4-digit years (integer or string). For data-driven estimates. For
purely calibrated DSGE papers with no data window, `"NA"`. For
calibration-only papers that match moments over a specific period,
fill these with the moment-matching window.

### NEW: `Estimator_Type` — closed vocabulary (ROW-LEVEL, empirical)

- `"OLS"`, `"GLS"`, `"IV"`, `"GMM"`, `"ML"`, `"Bayesian"`,
  `"SVAR"`, `"VAR"`, `"BVAR"`, `"local_projections"`, `"calibration"`,
  `"NA"`.

**Defaults.** For pure DSGE calibration papers, `"calibration"`. For
Bayesian estimation of DSGE, `"Bayesian"`.

### Output

```json
{
  "rows": [
    {
      "IdEstimate": 1,
      "Flexible_Price_Assumption": 0,
      "Exogenous_Inflation": 0,
      "Growth_Included": 0,
      "Zero_Lower_Bound": 0,
      "Results_Table": "Table 2 p.14",
      "Results_Inflation": "-0.8",
      "Inflation_Unit": "annual_pct",
      "Horizon": "long_run",
      "Results_Inflation_CI_Low": "-1.4",
      "Results_Inflation_CI_High": "-0.2",
      "Results_Inflation_CI_Level": "95",
      "Results_Inflation_Assumption": "Baseline Ramsey with distortionary taxes",
      "Preferred_Estimate": 1,
      "Reason_for_Preferred": "Authors describe as baseline calibration in §4.1",
      "Std_Dev_Inflation": "NA",
      "SE_Derivation": "from_CI",
      "Interest_Rate": "3.2",
      "Households_discount_factor": "0.99",
      "Consumption_curvature_parameter": "2",
      "Disutility_of_labor": "NA",
      "Inverse_of_labor_supply_elasticity": "1",
      "Money_curvature_parameter": "NA",
      "Loan_to_value_ratio": "NA",
      "Labor_share_of_output": "0.67",
      "Depositors_discount_factor": "NA",
      "Price_adjustment_cost": "NA",
      "Elasticity_of_substitution_between_goods": "6",
      "AR1_coefficient_of_TFP": "0.95",
      "Std_dev_to_TFP_shock": "0.007",
      "Policy_Regime": "Ramsey",
      "Shock_Type": "Multiple",
      "Welfare_Criterion": "unconditional",
      "Steady_State_Type": "stochastic",
      "Sensitivity_Type": "baseline",
      "Expectations": "rational",
      "Sample_Size": "NA",
      "Sample_Period_Start": "NA",
      "Sample_Period_End": "NA",
      "Estimator_Type": "calibration"
    }
  ]
}
```

---

## 6. COMMON FAILURE MODES TO AVOID

All v3.2 failure modes remain. Additional v3.3 failure modes:

8. **Coding every row of a Ramsey paper as `Policy_Regime = "Ramsey"`**
   when some rows are Friedman-rule / laissez-faire / Taylor-rule
   comparisons. Read each row's label carefully.
9. **Filling `Sample_Size` from an unrelated figure caption** (e.g. "N=1000
   Monte-Carlo draws" is not the sample size of an econometric estimation).
   Only fill for empirical estimations; for calibrated DSGE, emit `"NA"`.
10. **Mixing `Nominal_Friction_Type` and `Wage_Rigidity_Type`.** A paper
    with Calvo prices and flexible wages is `Nominal_Friction_Type =
    "Calvo_prices"`, `Wage_Rigidity_Type = "none"`. A paper with both
    sticky is `"Calvo_prices_and_wages"` and `"Calvo_wages"`.
11. **Defaulting to `"Multiple"` for `Shock_Type`** when the paper clearly
    isolates a single shock for that row. Read the table header.

---

## 7. SCHEMA REFERENCE (canonical column list, v3.3 = 72 cols)

All 57 v3.2 columns are retained unchanged. Plus 15 new columns:

```
# v3.2 retained (57):
Idstudy, IdEstimate,
Title, Author, Author_Affiliation, DOI, Journal_Name, Num_Citations, Year,
Model_Class, Model_Paradigm, Augmented_base_model, Augmentation_Description,
Augmentation_Category, Ramsey_Rule,
HH_Included, Firms_Included, Banks_Included, Government_Included,
HH_Maximization_Type, HH_Maximized_Vars,
Producer_Type, Producer_Assumption,
Other_Agent_Included, Other_Agent_Assumptions,
Empirical_Research, Country, Calibration_Frequency,
Flexible_Price_Assumption, Exogenous_Inflation, Growth_Included,
Households_discount_factor, Consumption_curvature_parameter,
Disutility_of_labor, Inverse_of_labor_supply_elasticity,
Money_curvature_parameter, Loan_to_value_ratio, Labor_share_of_output,
Depositors_discount_factor, Price_adjustment_cost,
Elasticity_of_substitution_between_goods,
AR1_coefficient_of_TFP, Std_dev_to_TFP_shock,
Zero_Lower_Bound, Results_Table,
Results_Inflation, Inflation_Unit, Horizon,
Results_Inflation_CI_Low, Results_Inflation_CI_High, Results_Inflation_CI_Level,
Results_Inflation_Assumption,
Preferred_Estimate, Reason_for_Preferred,
Std_Dev_Inflation, SE_Derivation, Interest_Rate, Impact_Factor,

# v3.3 new (15):
Publication_Status,
Nominal_Friction_Type, Wage_Rigidity_Type, Money_Demand_Tech, Indexation_Type,
Policy_Regime, Shock_Type, Welfare_Criterion, Steady_State_Type,
Sensitivity_Type, Expectations,
Sample_Size, Sample_Period_Start, Sample_Period_End, Estimator_Type
```
