# Model Taxonomy (v3.2)

This glossary is the canonical reference for how we classify each paper's
model. It is cited in both the prompt (`Super_v3_2.md`) and the paper
write-up so that every category has a single, auditable definition.

Each paper gets three orthogonal tags:

1. **`Model_Class`** — the *methodological class*. What kind of object is
   the model?
2. **`Model_Paradigm`** — the *theoretical paradigm* inside a DSGE paper.
   `"NA"` when `Model_Class ≠ "DSGE"`.
3. **`Augmentation_Category`** — the *friction or extension* layered on
   top of the base paradigm.

This is a three-tier decomposition, so `(Class, Paradigm, Augmentation)`
identifies the model type uniquely and Stata/R dummies at each tier never
overlap.

---

## Tier 1 — `Model_Class`

| Value | Definition |
| --- | --- |
| `DSGE` | Dynamic stochastic general equilibrium. Forward-looking optimizing agents with rational (or near-rational) expectations, market-clearing, explicit intertemporal budget constraints. Includes RBC, NK, HANK, MIU, CIA, OLG variants. |
| `Empirical_VAR` | Reduced-form or structural VAR / BVAR / local projections **without** a tight DSGE nested inside. |
| `Reduced_form_regression` | OLS, panel, IV, GMM regressions of inflation on covariates. No dynamic structural model. |
| `Theoretical_calibration` | Static or two-period analytical model with a numerical example. No dynamic GE simulation. |
| `Other` | Anything else (pure game-theoretic, agent-based, ML). Describe briefly in `Augmentation_Description`. |

---

## Tier 2 — `Model_Paradigm` (DSGE only)

Meaningful only when `Model_Class = "DSGE"`. Otherwise `"NA"`.

| Value | Definition |
| --- | --- |
| `New Keynesian` | Sticky prices and/or wages (Calvo, Rotemberg, Taylor staggered contracts). Default for any DSGE with nominal rigidity. |
| `RBC` | Real business cycle: flexible prices, no nominal friction, technology-shock driven. |
| `OLG` | Overlapping generations life-cycle structure. |
| `Money_in_utility` | Money-in-utility (MIU) demand, flexible prices. |
| `Cash_in_advance` | Cash-in-advance (CIA) constraint, flexible prices. |
| `Search_and_matching` | Pure Diamond-Mortensen-Pissarides labor search with flexible prices. **If combined with NK price stickiness**, code as `New Keynesian` + `Augmentation_Category = "labor_market_frictions"`. |
| `HANK` | Heterogeneous-agent New Keynesian. |
| `TANK` | Two-agent New Keynesian (savers + hand-to-mouth). |
| `Other` | DSGE paradigm not covered above. |
| `NA` | Paper is not DSGE. |

### Decision rule for ambiguous cases

When a paper plausibly fits more than one paradigm, apply this priority:

`HANK > TANK > New Keynesian > Search_and_matching > Money_in_utility > Cash_in_advance > RBC > OLG > Other`

Rationale: a HANK model is by construction New Keynesian, so the more
specific tag wins. A NK model with DMP frictions is still fundamentally
New Keynesian (nominal rigidity drives the Phillips curve); we log the
DMP add-on via `Augmentation_Category`.

---

## Tier 3 — `Augmentation_Category`

One of:
`"none"`, `"financial_frictions"`, `"labor_market_frictions"`,
`"open_economy"`, `"heterogeneous_agents"`, `"housing"`,
`"fiscal_policy"`, `"ZLB"`, `"learning"`, `"other"`.

Unchanged from v3.1. Captures *what the paper adds* on top of the base
paradigm. Pick the single most central augmentation. If there are two
roughly equal additions (e.g. open economy **and** ZLB), pick the one the
paper's contribution abstract emphasizes and record the other in
`Augmentation_Description`.

---

## Worked examples

| Paper archetype | Class | Paradigm | Augmentation |
| --- | --- | --- | --- |
| Abo-Zaid (2013), NK + DMP labor frictions | `DSGE` | `New Keynesian` | `labor_market_frictions` |
| Schmitt-Grohé & Uribe (2004), Ramsey with distortionary taxes | `DSGE` | `New Keynesian` | `fiscal_policy` |
| Kaplan, Moll & Violante (2018), HANK | `DSGE` | `HANK` | `heterogeneous_agents` |
| Aruoba & Schorfheide (2011), MIU with flexible prices | `DSGE` | `Money_in_utility` | `none` |
| Pure Friedman-rule CIA calibration | `DSGE` | `Cash_in_advance` | `none` |
| SVAR on inflation-output trade-off | `Empirical_VAR` | `NA` | `none` |
| Cross-country panel regression of optimal-π on structural chars. | `Reduced_form_regression` | `NA` | `none` |
| Two-period model of optimal inflation tax with analytic solution | `Theoretical_calibration` | `NA` | `fiscal_policy` |

---

## Paper write-up template

In the meta-analysis description section, frequency tables report:

> "Of the _N_ studies in our final sample, **X%** are DSGE structural
> models, **Y%** are empirical VAR-based, **Z%** are reduced-form
> regressions, and **W%** fall in the theoretical-calibration or other
> categories. Within the DSGE subsample, **a%** are New Keynesian, **b%**
> HANK/TANK, **c%** pure RBC, and **d%** MIU/CIA/OLG. The most common
> augmentations are **fiscal policy (p%)**, **labor-market frictions
> (q%)**, **financial frictions (r%)**, **ZLB (s%)**, and **open economy
> (t%)**."

This three-tier decomposition lets us run interaction effects without
the leakage that plagues single-column encoding (e.g. NK vs DSGE vs HANK
were previously all in one column).
