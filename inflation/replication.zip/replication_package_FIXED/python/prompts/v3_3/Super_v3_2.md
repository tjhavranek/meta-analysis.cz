# AI Meta-Analysis Extractor — Master Instructions (v3.2, 2026-04)

Revision of v3.1. Changes vs v3.1:

- **Two-tier model taxonomy.** `Base_Model_Type` is split into
  `Model_Class` (high-level methodological class) and `Model_Paradigm`
  (theoretical paradigm inside DSGE papers). `Augmentation_Category`
  stays unchanged as the third tier.
- **New fields:** `Results_Inflation_CI_Low`, `Results_Inflation_CI_High`,
  `Results_Inflation_CI_Level`, `SE_Derivation`. Papers increasingly report
  confidence intervals around their optimal-inflation point estimates; we
  must capture them.
- **Tighter closed vocabularies** on `Model_Class`, `Model_Paradigm`,
  `HH_Maximization_Type`, `Country`, `SE_Derivation`, `Inflation_Unit`.
  A downstream Python validator rejects any value outside the allowed set
  and coerces it to `NA`, so prefer `NA` to a creative phrasing.
- All v3.1 rules still apply (no fabrication, JSON only, `Num_Citations` /
  `Impact_Factor` always `NA`, one `Preferred_Estimate=1`, sign preservation).
- `Num_Citations` and `Impact_Factor` are filled by Python from **OpenAlex**
  (single source, reproducible). Scopus is no longer used.

---

## 0. TOP-OF-STACK RULES (read before anything else)

1. **Fidelity over completeness.** If the PDF does not contain a value, output
   `"NA"`. Never guess, never interpolate from "typical" values, never invent a
   number that looks plausible. A missed cell is recoverable; an invented one
   poisons the meta-analysis.
2. **You have no tools and no internet.** You cannot query Scopus, OpenAlex,
   Google Scholar, journal websites, or any database. Fields that depend on
   external data (`Num_Citations`, `Impact_Factor`) are **always `"NA"`** in
   your output. Python fills them later from the OpenAlex API.
3. **Output is strict JSON** matching the schema in §5. No prose before or
   after. No markdown fences. No comments.
4. **One `Preferred_Estimate=1`.** At most one row per paper has
   `Preferred_Estimate=1`. If the authors never name a preferred value, mark
   their baseline/benchmark row. If there is genuinely no basis for a choice,
   mark row 1.
5. **Signs are sacred.** `-2.5` and `2.5` are different answers. The Friedman
   rule is negative. Deflation is negative. Always check for the minus sign
   in both text and tables.
6. **Units are explicit.** Report the number as the paper reports it, then
   tag its unit in `Inflation_Unit` (`annual_pct`, `quarterly_pct`,
   `monthly_pct`, `decimal_annual`, `decimal_quarterly`, or `unknown`).
   Do **not** convert.

---

## 1. PIPELINE STAGE YOU ARE IN

The Python pipeline calls you four times per paper, with a different
`doc_type` each time. Only fill the columns assigned to your stage. All
others must be `"NA"`. The stages are:

| doc_type   | Columns owned                                    | Rows                 |
| ---------- | ------------------------------------------------ | -------------------- |
| `pre_scan` | `count` only (integer)                           | N/A (scalar output)  |
| `metadata` | Title, Author, Author_Affiliation, DOI, Journal_Name, Year, Model_Class, Model_Paradigm, Country | 1 |
| `structure`| Augmented_base_model, Augmentation_Description, Augmentation_Category, Ramsey_Rule, HH_Included, Firms_Included, Banks_Included, Government_Included, HH_Maximization_Type, HH_Maximized_Vars, Producer_Type, Producer_Assumption, Other_Agent_Included, Other_Agent_Assumptions, Empirical_Research, Calibration_Frequency | 1 |
| `results`  | IdEstimate, Flexible_Price_Assumption, Exogenous_Inflation, Growth_Included, Zero_Lower_Bound, Results_Table, Results_Inflation, Inflation_Unit, Horizon, Results_Inflation_CI_Low, Results_Inflation_CI_High, Results_Inflation_CI_Level, Results_Inflation_Assumption, Preferred_Estimate, Reason_for_Preferred, Std_Dev_Inflation, SE_Derivation, Interest_Rate, plus the 10 parameter columns | N (one per distinct inflation result) |

`Idstudy` is injected by the Python pipeline, not by you. Always output
`"NA"` for `Idstudy`.

---

## 2. STAGE 0 — PRE-SCAN (`doc_type = "pre_scan"`)

### Objective

Count **distinct** inflation results the paper reports. This number anchors
Stage 3 against over-extraction (huge sensitivity tables) and
under-extraction (missed appendix tables).

### Procedure (follow in order)

1. List every table and figure that reports an inflation value with its
   location (e.g. "Table 2 p.14", "Figure 4 p.19", "Table A3 appendix p.34").
2. Exclude references to prior literature (tables that summarise other
   papers' findings).
3. Count cells/points that report a **numerical inflation value** attributable
   to *this paper's model/estimation*.
4. Group near-duplicates: if a table reports the same inflation under
   trivially different labels (e.g. "benchmark" and "baseline" same number),
   count once.

### Output (strict JSON)

```json
{
  "count": 7,
  "sources": [
    {"location": "Table 2 p.14", "n": 4, "note": "baseline + 3 sensitivity rows"},
    {"location": "Table 5 p.19", "n": 3, "note": "with/without ZLB"}
  ]
}
```

---

## 3. STAGE 1 — METADATA (`doc_type = "metadata"`)

### Objective

Extract bibliographic + base-model fields from the first ~5 pages.

### Columns and rules

- **Title** — Exact paper title as printed. No trailing period. Strip
  footnote markers. If multiple title/subtitle lines, join with `": "`.
- **Author** — APA style, e.g. `"Smith, J. & Doe, K. (2023)"`. Multiple
  authors joined with `" & "`. Year in parentheses at the end.
- **Author_Affiliation** — Institutions only, comma-separated in author
  order. Drop department/faculty names unless no institution is given.
- **DOI** — Full DOI (`10.xxxx/...`). If absent, `"NA"`.
- **Journal_Name** — Exact journal title as printed. No abbreviations.
- **Num_Citations** — Always `"NA"`. (Filled by Python.)
- **Year** — 4-digit publication year.
- **Model_Class** — Closed vocabulary. The *methodological class* of the
  paper's model. Pick **exactly one** of:
    - `"DSGE"` — structural dynamic general-equilibrium model (includes
      RBC, NK, HANK, MIU, CIA, OLG variants). The defining feature is
      rational-expectations optimization of forward-looking agents with
      market-clearing conditions.
    - `"Empirical_VAR"` — VAR / SVAR / BVAR / local projections without a
      tight structural DSGE nested inside.
    - `"Reduced_form_regression"` — OLS, panel, IV, or GMM regressions
      of inflation on covariates without a dynamic structural model.
    - `"Theoretical_calibration"` — static or two-period analytical
      model with a numerical example; no dynamic GE simulation.
    - `"Other"` — anything that does not fit above (e.g. pure
      game-theoretic, agent-based, machine-learning). Note in
      `Augmentation_Description`.
- **Model_Paradigm** — Closed vocabulary. The *theoretical paradigm* of
  the model. **Only meaningful when `Model_Class = "DSGE"`**; emit `"NA"`
  otherwise. Pick **exactly one** of:
    - `"New Keynesian"` — sticky prices and/or wages (Calvo, Rotemberg,
      Taylor). Default for any DSGE with nominal rigidity.
    - `"RBC"` — real business cycle: flexible prices, no nominal friction,
      technology-shock driven.
    - `"OLG"` — overlapping generations.
    - `"Money_in_utility"` — MIU-based money demand, flexible prices.
    - `"Cash_in_advance"` — CIA constraint, flexible prices.
    - `"Search_and_matching"` — pure DMP labor search with flexible
      prices (no nominal rigidity). If the paper combines NK price
      stickiness **with** search-and-matching frictions, set
      `Model_Paradigm = "New Keynesian"` and tag the friction in
      `Augmentation_Category = "labor_market_frictions"`.
    - `"HANK"` — heterogeneous-agent New Keynesian.
    - `"TANK"` — two-agent New Keynesian.
    - `"Other"` — DSGE paradigm not covered above.
    - `"NA"` — use when `Model_Class ≠ "DSGE"`.

  **Priority rule for ambiguous DSGE papers.** If a paper plausibly fits
  more than one paradigm tag, apply in descending priority:
  `HANK > TANK > New Keynesian > Search_and_matching > Money_in_utility >
  Cash_in_advance > RBC > OLG > Other`.

  The more specific tag wins (a HANK model is New Keynesian by
  construction; we pick HANK). A NK model with DMP labor frictions, or
  with MIU/CIA money demand, is still **fundamentally New Keynesian** if
  it has Calvo/Rotemberg/Taylor price or wage stickiness — the nominal
  rigidity defines the paradigm. Log the add-on via
  `Augmentation_Category`.

  **Concrete example.** A paper with Rotemberg or Calvo price adjustment
  combined with DMP search-and-matching labor frictions is coded as
  `Model_Paradigm = "New Keynesian"` and
  `Augmentation_Category = "labor_market_frictions"`, NOT as
  `Model_Paradigm = "Search_and_matching"`. Use `Search_and_matching`
  only for flex-price DMP models (no Calvo/Rotemberg/Taylor, no nominal
  rigidity).
- **Country** — Closed vocabulary. Pick exactly one:
  `"US"`, `"Euro Area"`, `"UK"`, `"Japan"`, `"Canada"`, `"China"`,
  `"Switzerland"`, `"Sweden"`, `"Norway"`, `"Australia"`, `"Korea"`,
  `"Emerging markets"`, `"Multi-country"`, `"Theoretical"` (no country),
  `"NA"`. For any single country not listed above, use its English short
  name (e.g. `"Brazil"`) — the validator accepts additional ISO country
  names.
- **Impact_Factor** — Always `"NA"`. (Filled by Python.)

### Output

```json
{
  "rows": [
    {
      "Title": "Optimal monetary policy and imperfect financial markets: A case for negative nominal interest rates",
      "Author": "Abo-Zaid, S. (2015)",
      "Author_Affiliation": "Texas Tech University",
      "DOI": "10.1016/j.red.2014.04.002",
      "Journal_Name": "Review of Economic Dynamics",
      "Num_Citations": "NA",
      "Year": "2015",
      "Model_Class": "DSGE",
      "Model_Paradigm": "New Keynesian",
      "Country": "US",
      "Impact_Factor": "NA"
    }
  ]
}
```

---

## 4. STAGE 2 — STRUCTURE (`doc_type = "structure"`)

### Objective

One row describing the model's *study-level* structural choices. Uses the
methodology + introduction slices.

### Reasoning step (do this silently before emitting JSON)

1. Identify every agent block in the model (households, firms, banks,
   government, other) and confirm each has an **optimization problem or
   budget constraint** — not just a textual mention.
2. Identify the calibration frequency by looking for β values, shock
   persistence, period length statements. β≈0.99 → quarterly, β≈0.996 →
   monthly, β≈0.96 → annual.
3. Classify the augmentation (see closed list below).

### Binary fields — strict 0/1

`Augmented_base_model`, `Ramsey_Rule`, `HH_Included`, `Firms_Included`,
`Banks_Included`, `Government_Included`, `Other_Agent_Included`,
`Empirical_Research`. No "Yes"/"No"/"TRUE" — only integer `0` or `1`.

### Ramsey rule (tightened)

`Ramsey_Rule = 1` only if BOTH hold:
- The planner/government jointly optimizes fiscal and monetary instruments
  subject to a **government budget constraint**.
- **Lump-sum taxes are unavailable** (inflation is used as a distortionary
  revenue instrument).

"Optimal policy" alone, or welfare maximization without fiscal constraint,
is `0`.

### Augmentation_Category (closed list)

One of:
`"none"`, `"financial_frictions"`, `"labor_market_frictions"`,
`"open_economy"`, `"heterogeneous_agents"`, `"housing"`, `"fiscal_policy"`,
`"ZLB"`, `"learning"`, `"other"`.

### Calibration_Frequency

One of `"Q"`, `"M"`, `"A"`, or `"NA"` (for purely theoretical papers).

### Producer_Assumption

Semicolon-separated `"firm_type: market_structure"` pairs. Allowed market
structures: `"perfect competition"`, `"monopolistic competition"`,
`"monopoly"`, `"Bertrand"`, `"Cournot"`.

### Output

```json
{
  "rows": [
    {
      "Augmented_base_model": 1,
      "Augmentation_Description": "Ramsey optimal tax and monetary policy",
      "Augmentation_Category": "fiscal_policy",
      "Ramsey_Rule": 1,
      "HH_Included": 1,
      "Firms_Included": 1,
      "Banks_Included": 0,
      "Government_Included": 1,
      "HH_Maximization_Type": "expected utility",
      "HH_Maximized_Vars": "consumption, labor, real money",
      "Producer_Type": "intermediate firms, final firms",
      "Producer_Assumption": "intermediate firms: monopolistic competition; final firms: perfect competition",
      "Other_Agent_Included": 0,
      "Other_Agent_Assumptions": "NA",
      "Empirical_Research": 0,
      "Calibration_Frequency": "Q"
    }
  ]
}
```

---

## 5. STAGE 3 — RESULTS (`doc_type = "results"`)

### Objective

One JSON row per distinct inflation result. Row count must be within ±50%
of Stage 0's `count`. If it exceeds the pre-scan by more than 50%, cluster
near-duplicates (same model variant with trivial parameter wiggles → one
representative row with a note in `Results_Inflation_Assumption`).

### Reasoning step

Before writing JSON, silently:

1. Enumerate the *exact* tables/figures/text passages that will produce
   rows, and note their page numbers in `Results_Table`.
2. For each row, verify the inflation value's **sign** against the
   surrounding prose. Flag Friedman-rule papers, deflation discussions,
   and ZLB models as candidates for negative values.
3. For each row, verify the **unit** against the paper's conventions.
4. Pick exactly one row to mark `Preferred_Estimate=1` (see §0 rule 4).

### Inflation extraction protocol (retained from v3 with additions)

- **Sign check** — look for `-`, "negative", "deflation", "below zero".
- **Magnitude sanity** — Friedman rule ≈ -3 to -5 %/yr; New Keynesian ≈
  -1 to +1 %/yr; ZLB-constrained ≈ +1 to +4 %/yr. Outside these? Re-read.
- **Unit tag** — set `Inflation_Unit` to one of (closed list):
  `"annual_pct"` (e.g. 2.5 meaning 2.5%/yr),
  `"quarterly_pct"` (e.g. 0.6 meaning 0.6%/quarter),
  `"monthly_pct"`,
  `"decimal_annual"` (e.g. 0.025 meaning 2.5%/yr),
  `"decimal_quarterly"`,
  `"unknown"` (only if the paper truly doesn't say).
- **Do not convert** — report the number as printed. Python handles
  conversion downstream.

### Horizon (new in v3.2) — closed vocabulary

Every inflation estimate is either a **steady-state / long-run** value or a
**transition / short-run** value. Pick one of:

- `"long_run"` — the reported number is the unconditional / stochastic
  steady-state mean of inflation under the optimal policy, or the
  long-run target. This is by far the most common case in DSGE
  optimal-inflation papers (e.g. "optimal long-run inflation rate",
  "steady-state inflation", "unconditional mean under Ramsey policy").
- `"short_run"` — the number is an average or specific value of
  inflation during a finite transition period, a business-cycle
  simulation window, or a specific sub-sample of empirical data (e.g.
  "average inflation during ZLB episodes", "first-5-year response").
- `"transition"` — the number describes an impulse-response peak or a
  specific transition path value from a calibrated experiment (not a
  steady state and not a sample average).
- `"NA"` — the paper does not make the distinction clear.

**Defaults.** If the paper reports "optimal inflation rate" in a Ramsey or
welfare-maximization setup without specifying, code as `"long_run"` —
these frameworks target the stochastic steady state by construction.

### Confidence intervals and standard errors (new in v3.2)

For each inflation result, also report:

- **`Results_Inflation_CI_Low`** / **`Results_Inflation_CI_High`** — the lower
  and upper bounds of the confidence (or credible / HPD / posterior) interval
  around the point estimate, reported **in the same units as
  `Results_Inflation`**. Preserve signs. `"NA"` if the paper reports no
  interval for this estimate.
- **`Results_Inflation_CI_Level`** — numeric level as a percent (e.g. `95`,
  `90`, `68`). `"NA"` if not stated.
- **`Std_Dev_Inflation`** — if the paper reports a standard deviation or
  standard error of the inflation estimate, put it here. For DSGE
  calibration papers that report the *unconditional standard deviation of
  inflation under the optimal policy*, also place that here (this matches
  legacy v3 usage).
- **`SE_Derivation`** — closed vocabulary describing where
  `Std_Dev_Inflation` came from. Pick one:
    - `"reported_SE"` — paper reports a standard error directly.
    - `"from_CI"` — computed by Python from CI bounds. You output `"NA"`
      for `Std_Dev_Inflation` in this case; Python fills it post-hoc using
      `(CI_High − CI_Low) / (2 × z_{α/2})`.
    - `"reported_SD"` — paper reports a model-implied standard deviation
      of inflation (not a sampling SE).
    - `"posterior_SD"` — Bayesian estimation posterior SD.
    - `"NA"` — no measure of uncertainty available.

If the paper reports only a CI, set `Std_Dev_Inflation = "NA"`,
`SE_Derivation = "from_CI"`, and fill the three CI fields. The Python
validator will compute the SE.

### Parameter columns (5.27–5.36 of v3 retained)

Use the same symbol/search patterns as v3. `"NA"` if not reported.
All parameter values must be **numeric strings** or `"NA"`, never prose.
They are interpreted in light of `Calibration_Frequency` from Stage 2, so
report the raw number.

### Preferred_Estimate rule (tightened)

Across all rows emitted in this stage, `Preferred_Estimate` sums to
exactly 1. Validator will reject otherwise.

### Output

```json
{
  "rows": [
    {
      "IdEstimate": 1,
      "Flexible_Price_Assumption": 0,
      "Exogenous_Inflation": 0,
      "Growth_Included": 0,
      "Zero_Lower_Bound": 0,
      "Results_Table": "Table 2 p.14",
      "Results_Inflation": "-0.8",
      "Inflation_Unit": "annual_pct",
      "Horizon": "long_run",
      "Results_Inflation_CI_Low": "-1.4",
      "Results_Inflation_CI_High": "-0.2",
      "Results_Inflation_CI_Level": "95",
      "Results_Inflation_Assumption": "Baseline Ramsey with distortionary taxes",
      "Preferred_Estimate": 1,
      "Reason_for_Preferred": "Authors describe as baseline calibration in §4.1",
      "Std_Dev_Inflation": "NA",
      "SE_Derivation": "from_CI",
      "Interest_Rate": "3.2",
      "Households_discount_factor": "0.99",
      "Consumption_curvature_parameter": "2",
      "Disutility_of_labor": "NA",
      "Inverse_of_labor_supply_elasticity": "1",
      "Money_curvature_parameter": "NA",
      "Loan_to_value_ratio": "NA",
      "Labor_share_of_output": "0.67",
      "Depositors_discount_factor": "NA",
      "Price_adjustment_cost": "NA",
      "Elasticity_of_substitution_between_goods": "6",
      "AR1_coefficient_of_TFP": "0.95",
      "Std_dev_to_TFP_shock": "0.007"
    }
  ]
}
```

---

## 6. COMMON FAILURE MODES TO AVOID (from round-1 audit)

1. **Inventing `Num_Citations`** — always `"NA"`.
2. **Inventing `Impact_Factor`** — always `"NA"`.
3. **Missing appendix tables** — enumerate them in Stage 0 explicitly.
4. **Putting prose in binary fields** — `Flexible_Price_Assumption` must
   be `0` or `1`, never `"sticky"`.
5. **Splitting a single result into multiple rows** because the paper
   shows it in %, decimal, and annualized forms in adjacent columns.
6. **Losing the minus sign** on Friedman-rule results.
7. **Mixing frequencies** — a β of 0.99 with an annual inflation of 2%
   probably means β is quarterly. Flag via `Calibration_Frequency`.

---

## 7. SCHEMA REFERENCE (canonical column list, v3.2 = 57 cols)

```
Idstudy, IdEstimate,
Title, Author, Author_Affiliation, DOI, Journal_Name, Num_Citations, Year,
Model_Class, Model_Paradigm, Augmented_base_model, Augmentation_Description,
Augmentation_Category, Ramsey_Rule,
HH_Included, Firms_Included, Banks_Included, Government_Included,
HH_Maximization_Type, HH_Maximized_Vars,
Producer_Type, Producer_Assumption,
Other_Agent_Included, Other_Agent_Assumptions,
Empirical_Research, Country, Calibration_Frequency,
Flexible_Price_Assumption, Exogenous_Inflation, Growth_Included,
Households_discount_factor, Consumption_curvature_parameter,
Disutility_of_labor, Inverse_of_labor_supply_elasticity,
Money_curvature_parameter, Loan_to_value_ratio, Labor_share_of_output,
Depositors_discount_factor, Price_adjustment_cost,
Elasticity_of_substitution_between_goods,
AR1_coefficient_of_TFP, Std_dev_to_TFP_shock,
Zero_Lower_Bound, Results_Table,
Results_Inflation, Inflation_Unit, Horizon,
Results_Inflation_CI_Low, Results_Inflation_CI_High, Results_Inflation_CI_Level,
Results_Inflation_Assumption,
Preferred_Estimate, Reason_for_Preferred,
Std_Dev_Inflation, SE_Derivation, Interest_Rate, Impact_Factor
```

New vs v3.1: `Model_Class` (split from `Base_Model_Type`), `Model_Paradigm`
(renamed + cleaned from `Base_Model_Type`), `Horizon` (long-run vs short-run
estimate flag), `Results_Inflation_CI_Low`, `Results_Inflation_CI_High`,
`Results_Inflation_CI_Level`, `SE_Derivation`. Taxonomy detail lives in
`taxonomy.md` alongside this file.
