# AI vs human inter-rater agreement (Round 1)

Comparison of the 7 hand-coded training papers against the v3 raw AI
extraction. Reproduces manuscript Table 14 (`tab:irr_v34`).

## Per-field results

| Field | n | Agreement | Cohen's κ | SE(κ) |
|-------|---:|---------:|----------:|------:|
| `Augmented_base_model` | 7 | 1.00 | 1.00 | — |
| `Ramsey_Rule` | 7 | 0.57 | 0.09 | 0.40 |
| `HH_Included` | 7 | 1.00 | 1.00 | — |
| `Firms_Included` | 7 | 1.00 | 1.00 | — |
| `Banks_Included` | 7 | 0.86 | 0.00 | 0.93 |
| `Government_Included` | 7 | 0.43 | -0.40 | 0.46 |
| `Other_Agent_Included` | 7 | 0.43 | -0.17 | 0.38 |
| `Empirical_Research` | 7 | 0.86 | 0.00 | 0.93 |

**Numerical (paper-mean π\*, MAE pp/year):** n=7, MAE = **2.36**.
