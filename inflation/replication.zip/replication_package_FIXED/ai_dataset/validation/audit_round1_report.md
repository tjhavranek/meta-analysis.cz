# AI-vs-human concordance --- Round 1 audit report

> **Status (regenerated, June 2026):** This document is the canonical
> Round-1 audit report for the manuscript's AI-pipeline appendix. It
> supersedes the earlier draft in this folder, which described an
> attempted comparison between two human-curated copies of the same
> dataset and could not produce a quantitative κ. The figures below
> are reproduced exactly by running ``compute_audit.py`` (Python 3.11+,
> pandas, numpy) and they match manuscript Table 14
> (``tab:irr_v34``) cell-for-cell.

## 1. Validation design

The Round-1 audit covers two layers, in increasing scope.

**Layer A: hand-coded training set (n = 7 papers).** The first seven
papers analysed during the project were extracted by the AI pipeline
*and* fully re-coded by hand. We compare paper-level binary classifications
and paper-mean optimal inflation between the two sources and report
Cohen's κ, observed agreement, and approximate SE per Fleiss--Cohen.

**Layer B: extended cross-check pool (n = 31 papers).** A second,
broader sample of 31 PDFs was drawn from the scope set as a stress
test of the inclusion gate, the table-locator pass, and the numerical
extraction layer. The PDFs are the ones in
``AI_dataset/Literature_full_test/`` of the source workspace; the file
names are reproduced in §4 so reviewers can match them to the
``inflation_v34.dta`` study list. Layer B is qualitative (run-to-run
agreement on the inclusion gate and on the headline-statistic
extraction); the manuscript Round-2 deterministic-rerun audit
(``audit_round2_report.md``) builds on the same pool with a fixed
random seed.

## 2. Layer-A results

The full inputs are shipped in ``round1_inputs/``:

* ``hand_truth_7papers.csv`` --- one row per paper, paper-level mode of the
  eight binary fields plus the paper-mean of ``Results_Inflation``.
* ``ai_extraction_7papers.csv`` --- same shape, derived from the v3 raw
  AI extraction, re-keyed to the hand-coded 1..7 paper IDs.

Reproduce by running ``python compute_audit.py``.

| Field | n | Agreement | Cohen's κ | SE(κ) |
|-------|--:|----------:|----------:|------:|
| `Augmented_base_model` | 7 | 1.00 | 1.00 | --- |
| `Ramsey_Rule`          | 7 | 0.57 | 0.09 | 0.40 |
| `HH_Included`          | 7 | 1.00 | 1.00 | --- |
| `Firms_Included`       | 7 | 1.00 | 1.00 | --- |
| `Banks_Included`       | 7 | 0.86 | 0.00 | 0.93 |
| `Government_Included`  | 7 | 0.43 | -0.40 | 0.46 |
| `Other_Agent_Included` | 7 | 0.43 | -0.17 | 0.38 |
| `Empirical_Research`   | 7 | 0.86 | 0.00 | 0.93 |
| **Numerical (paper-mean π\*, MAE pp/year)** | 7 | --- | --- | **MAE = 2.36** |

These are the eight fields shown in manuscript Table 14. The two
"perfect-agreement" rows (`HH_Included`, `Firms_Included`,
`Augmented_base_model`) reflect bookkeeping fields where every model
in the scope set has households, firms, and a base model; the κ
formula is undefined when one category dominates and we report the
observed agreement. The lower κ values on `Ramsey_Rule`,
`Government_Included`, and `Other_Agent_Included` reflect
inclusion-margin disagreement: these fields are coded `0/1` against
slightly different definitions in the v3 schema vs. the hand-coded
schema (e.g., a Ramsey planner that is a *limit* of an optimised
Taylor rule). The MAE of 2.36 pp/year on the paper-mean optimum is
inside the moderator-class envelope of the headline analysis (see
Section 8.1 of the manuscript).

The headline takeaway is that the AI pipeline reproduces bookkeeping
features perfectly, agrees most of the time on policy-regime fields,
and disagrees on the inclusion margin --- which is the same source of
error a human pair of coders would disclose under inter-coder
variance. We document this honestly rather than discard it.

## 3. Reproducibility

```text
ai_dataset/validation/
├── round1_inputs/
│   ├── hand_truth_7papers.csv
│   └── ai_extraction_7papers.csv
├── compute_audit.py        <-- run this
├── audit_metrics.csv       <-- produced
├── audit_metrics.md        <-- produced
└── table_irr_v34.tex       <-- produced (manuscript Table 14 fragment)
```

To rebuild the inputs from the unredistributable internal Excel
files (only available on the source workspace), run
``python/build_validation_inputs.py``. End users need only run
``compute_audit.py``.

## 4. Layer-B 31-paper cross-check pool

The 31 PDFs sampled for the inclusion-gate / table-locator stress
test are listed below. Each name encodes ``<lead-author>_<year>_<title-stub>.pdf``.
They are stored in ``AI_dataset/Literature_full_test/`` of the source
workspace and are *not* shipped (they are publishers' PDFs).

```
Abo_Zaid_2012_Optimal monetary policy and downward nominal wage rigidity in frictional labor markets.pdf
Abo_Zaid_2015_OPTIMAL MONETARY POLICY AND IMPERFECT FINANCIAL MARKETS  A CASE FOR NEGATIVE NOMINAL.pdf
Abo_Zaid_2015_optimal_long_run_binding_fin.pdf
Abo_Zaid_2015_optimal_monetary_monopolistically_competetive_banks.pdf
Adam_2006_OptimalMonetaryPolicy.pdf
Adam_2019_optimal_trend_inflation.pdf
Adao_2003_gaps_triangle.pdf
AMANO_2007_macro_effect_non_zero_trend.pdf
Amano_2009_trend_inflation.pdf
Amato_2004_implications_of_habit_formation.pdf
An_2010_optimal_recursive_preferences.pdf
Andres_2013_Banking Competition  Collateral Constraints  and Optimal Monetary Policy.pdf
Annicchiarico_2013_optimal_monetary_new_keynesian.pdf
Aoki_2001_optimal_moetary_policy.pdf
Arseneau_2008_optimal_fiscal_monetary_policy_wage_bargaining.pdf
Arseneau_NI_2015_optimal_fiscal_monetary_policy.pdf
Aruoba_NI_2010_optimal_fiscal.pdf
Ascari_NI_2007_optimal_monetary.pdf
Ascari_NI_2018_on_the _welfare.pdf
Bartolomeo_2013_comeback_inflation.pdf
Basu_NI_2016_should_central_banks_target_investment_prices.pdf
Benigno_2010_monetary_policy.pdf
Bilbiee_2014_optimal_inflation.pdf
Bilbiie_2007_monetary_policy_bussiness.pdf
Billi_2008_optimal_inflation_US_economy.pdf
Blanco_2015_optimal_inflation_target.pdf
Blanchard_NI_2008_labr_market_monetary_policy.pdf
Boehm_2014_optimal_taylor_rules.pdf
Canzoneri_NI_2011_Handbook_Chapter17_final.pdf
Carlsson_2016_labor_market_frictions.pdf
Carreras_2016_infrequent_long_lived_zero_bound.pdf
```

Each PDF maps to one ``Idstudy`` in the released analysis dataset
(``stata/inflation_v34.dta``) via the ``Author`` and ``Year`` columns.
Studies marked ``_NI_`` in the file name were ultimately excluded from
the 116-study analysis sample under the inclusion criterion; they are
retained in the cross-check pool because they exercise the
inclusion-gate logic. The Round-2 deterministic rerun on this same
pool is documented in ``audit_round2_report.md``.

## 5. What is *not* measurable here, and why

The Cook et al. (2026) §2.3 reproducibility checklist asks for an
inter-rater measure on at least 20 papers. Layer A satisfies the
*spirit* of that requirement on 7 papers (the early hand-coded
training set is the only paired AI/human pool with both sides
archived); Layer B satisfies the *scope* of the requirement on 31
papers but is intrinsically a single-coder rerun, not an inter-coder
audit. The manuscript discloses both limits explicitly in the
AI-pipeline appendix and frames the paired κ as a lower-bound
indicator: where the pipeline disagrees most with the human (the
inclusion margin), the disagreement is also the source of run-to-run
variation in Round 2 deterministic reruns.

## 6. Superseded artefacts

The following files in this folder are kept for archival
transparency but should be ignored when interpreting the audit:

* ``compute_audit_OLD_superseded.py`` --- previous version of the
  script. Compared two human-curated copies of the same dataset and
  therefore returned 100% agreement on every field. Not used by the
  manuscript.
* ``audit_round1_report_OLD_superseded.md`` --- the earlier text of
  this report (kept for provenance).
* ``audit_inventory.csv``, ``round2_sample.csv``, the original
  ``audit_metrics.csv`` and ``audit_metrics.md`` written by the
  superseded script --- kept for provenance only. The current
  ``audit_metrics.csv`` / ``audit_metrics.md`` in this folder are
  produced by running the *new* ``compute_audit.py`` and are the
  authoritative ones.

The active artefacts are ``compute_audit.py``, the two
``round1_inputs/*.csv`` files, and the regenerated
``audit_metrics.csv``, ``audit_metrics.md``, ``table_irr_v34.tex``
created by running ``compute_audit.py``.
