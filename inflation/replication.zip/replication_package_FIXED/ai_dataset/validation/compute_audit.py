"""compute_audit.py

Reproduce manuscript Table 14 (``tab:irr_v34``) — inter-rater agreement
between the 7 hand-coded training papers and the AI-extraction pipeline.

Reads two small CSVs that ship inside this replication package:

    round1_inputs/hand_truth_7papers.csv     (human ground truth)
    round1_inputs/ai_extraction_7papers.csv  (raw AI extraction)

Both are paper-level summaries already aligned to the same 7 paper rows
(see ``python/build_validation_inputs.py`` for how they were built from
the unredistributable internal Excel files).

Outputs (written next to this script):

    audit_metrics.csv  -- per-field n / agreement / kappa / SE
    audit_metrics.md   -- human-readable summary
    table_irr_v34.tex  -- LaTeX fragment matching manuscript Table 14

Run from the repository root or directly:

    python compute_audit.py
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
INPUT_DIR = HERE / "round1_inputs"
HAND_CSV = INPUT_DIR / "hand_truth_7papers.csv"
AI_CSV = INPUT_DIR / "ai_extraction_7papers.csv"
OUT_METRICS_CSV = HERE / "audit_metrics.csv"
OUT_METRICS_MD = HERE / "audit_metrics.md"
OUT_TEX = HERE / "table_irr_v34.tex"

# The eight paper-level binary fields shown in manuscript Table 14.
BINARY_FIELDS: list[str] = [
    "Augmented_base_model",
    "Ramsey_Rule",
    "HH_Included",
    "Firms_Included",
    "Banks_Included",
    "Government_Included",
    "Other_Agent_Included",
    "Empirical_Research",
]


def cohens_kappa(a: np.ndarray, b: np.ndarray) -> tuple[float, float]:
    """Cohen's kappa with Fleiss-style approximate SE for binary labels."""
    n = len(a)
    if n == 0:
        return float("nan"), float("nan")
    po = float((a == b).mean())
    cats = sorted(set(a.tolist()) | set(b.tolist()))
    pe = 0.0
    for c in cats:
        pe += (a == c).mean() * (b == c).mean()
    if pe >= 1.0:
        return (1.0 if po == 1.0 else float("nan")), float("nan")
    kappa = (po - pe) / (1.0 - pe)
    se = math.sqrt(po * (1.0 - po) / (n * (1.0 - pe) ** 2))
    return kappa, se


def main() -> None:
    if not HAND_CSV.exists() or not AI_CSV.exists():
        raise SystemExit(
            "Missing validation inputs. Expected\n"
            f"  {HAND_CSV}\n  {AI_CSV}\n"
            "If you obtained the replication package without the round1_inputs/ folder, "
            "rerun python/build_validation_inputs.py from the source workspace."
        )

    hand = pd.read_csv(HAND_CSV)
    ai = pd.read_csv(AI_CSV)

    # The two files are pre-aligned 1..7 by Idstudy (hand) / Idstudy_hand (ai).
    hand = hand.set_index("Idstudy").sort_index()
    ai_idx = "Idstudy_hand" if "Idstudy_hand" in ai.columns else "Idstudy"
    ai = ai.set_index(ai_idx).sort_index()

    common = sorted(set(hand.index) & set(ai.index))
    rows: list[dict] = []
    for f in BINARY_FIELDS:
        h_vals: list[int] = []
        a_vals: list[int] = []
        for sid in common:
            hv = hand.at[sid, f]
            av = ai.at[sid, f]
            if pd.notna(hv) and pd.notna(av):
                h_vals.append(int(hv))
                a_vals.append(int(av))
        n = len(h_vals)
        if n == 0:
            rows.append({"Field": f, "n": 0, "Agreement": np.nan,
                         "Kappa": np.nan, "SE_Kappa": np.nan})
            continue
        ha = np.asarray(h_vals)
        aa = np.asarray(a_vals)
        po = float((ha == aa).mean())
        kappa, se = cohens_kappa(ha, aa)
        rows.append({"Field": f, "n": n, "Agreement": po,
                     "Kappa": kappa, "SE_Kappa": se})

    # MAE on paper-mean optimal inflation (pp/year).
    abs_err: list[float] = []
    for sid in common:
        h = hand.at[sid, "paper_mean_pi"]
        a = ai.at[sid, "paper_mean_pi"]
        if pd.notna(h) and pd.notna(a):
            abs_err.append(abs(float(h) - float(a)))
    mae = float(np.mean(abs_err)) if abs_err else float("nan")
    n_mae = len(abs_err)

    metrics = pd.DataFrame(rows)
    metrics.to_csv(OUT_METRICS_CSV, index=False)

    # Human-readable summary.
    md_lines = [
        "# AI vs human inter-rater agreement (Round 1)",
        "",
        "Comparison of the 7 hand-coded training papers against the v3 raw AI",
        "extraction. Reproduces manuscript Table 14 (`tab:irr_v34`).",
        "",
        "## Per-field results",
        "",
        "| Field | n | Agreement | Cohen's κ | SE(κ) |",
        "|-------|---:|---------:|----------:|------:|",
    ]
    for r in rows:
        kap = "—" if math.isnan(r["Kappa"]) else f"{r['Kappa']:.2f}"
        se = "—" if (r["SE_Kappa"] is None or math.isnan(r["SE_Kappa"])) else f"{r['SE_Kappa']:.2f}"
        ag = "—" if math.isnan(r["Agreement"]) else f"{r['Agreement']:.2f}"
        md_lines.append(f"| `{r['Field']}` | {r['n']} | {ag} | {kap} | {se} |")
    md_lines += [
        "",
        f"**Numerical (paper-mean π\\*, MAE pp/year):** n={n_mae}, MAE = **{mae:.2f}**.",
        "",
    ]
    OUT_METRICS_MD.write_text("\n".join(md_lines), encoding="utf-8")

    # LaTeX fragment matching manuscript Table 14 layout.
    with OUT_TEX.open("w", encoding="utf-8") as fh:
        fh.write("% Inter-rater agreement, hand-coded training set vs AI extraction.\n")
        fh.write("% Auto-generated by ai_dataset/validation/compute_audit.py.\n")
        fh.write("\\begin{tabular}{lcccc}\n")
        fh.write("\\toprule\n")
        fh.write("Field & $n$ & Agreement & Cohen's $\\kappa$ & SE($\\kappa$) \\\\\n")
        fh.write("\\midrule\n")
        for r in rows:
            f_disp = r["Field"].replace("_", "\\_")
            n = r["n"]
            kap = "---" if math.isnan(r["Kappa"]) else f"{r['Kappa']:.2f}"
            se = "---" if (r["SE_Kappa"] is None or math.isnan(r["SE_Kappa"])) else f"{r['SE_Kappa']:.2f}"
            ag = "---" if math.isnan(r["Agreement"]) else f"{r['Agreement']:.2f}"
            fh.write(f"{f_disp} & {n} & {ag} & {kap} & {se} \\\\\n")
        fh.write("\\midrule\n")
        fh.write(
            "Numerical (paper-mean $\\pi^\\star$, MAE pp/year) & "
            f"{n_mae} & --- & --- & MAE = {mae:.2f} \\\\\n"
        )
        fh.write("\\bottomrule\n")
        fh.write("\\end{tabular}\n")

    # Console summary.
    print("AI-vs-human inter-rater agreement (manuscript Table 14)")
    print("-" * 60)
    for r in rows:
        kap = "nan" if math.isnan(r["Kappa"]) else f"{r['Kappa']:+.2f}"
        se = "nan" if (r["SE_Kappa"] is None or math.isnan(r["SE_Kappa"])) else f"{r['SE_Kappa']:.2f}"
        ag = "nan" if math.isnan(r["Agreement"]) else f"{r['Agreement']:.2f}"
        print(f"  {r['Field']:30s}  n={r['n']}  agree={ag}  kappa={kap}  SE={se}")
    print(f"  Numerical MAE (paper-mean pi*, n={n_mae}): {mae:.3f} pp/yr")
    print(f"\nWrote {OUT_METRICS_CSV.name}, {OUT_METRICS_MD.name}, {OUT_TEX.name}.")


if __name__ == "__main__":
    main()
