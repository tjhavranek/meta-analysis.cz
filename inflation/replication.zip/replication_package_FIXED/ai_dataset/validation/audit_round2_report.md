# Round-2 Self-Consistency Audit (5-paper random rerun)

> **Note for reviewers.** The raw per-paper artefacts referenced below
> (`round2_rerun/extracted_20260426-090322.csv`, `checkpoint.jsonl`,
> per-paper Excel files, and `round2_rerun.log`) are listed for provenance
> only and are *not* shipped in this package; they are deterministic from
> the same prompt + the same five PDFs and are available from the
> corresponding author on request (see root `README.md` "What is *not* in
> this package" table). The summary tables and conclusions in this report
> reproduce from the shipped `inflation_v34.dta` alone.

**Date:** 26 April 2026
**Pipeline:** `python/INFLATION_2_0.py` (stage-tiered: pre-scan + metadata = `claude-sonnet-4-5`; structure + results = `claude-opus-4-5`).
**Prompts:** `python/prompts/v3_3/Super_v3_3.md` (frozen v3.3, identical to Round-1 production run).
**Sampling:** deterministic, `random_state=20260426`, drawn from the 131 unique studies with `Preferred_Estimate==1` in `stata/inflation_v34.dta`.
**Cost:** USD 2.68 (2 papers extracted to results stage; 3 short-circuited at pre-scan).
**Run log:** `ai_dataset/validation/round2_rerun.log`.
**Raw output:** `ai_dataset/validation/round2_rerun/extracted_20260426-090322.csv` (8 rows × 73 cols).

## Sample

| Round-2 Idstudy | v34 Idstudy | Author / Year                          | Round-2 outcome           | v34 rows |
| ---             | ---         | ---                                    | ---                       | ---      |
| 99001           | 9100        | Levin, Lopez-Salido & Yun (2007)       | **SKIP** at pre-scan      | 7        |
| 99002           | 9089        | Kiley (2001)                           | **SKIP** at pre-scan      | 2        |
| 99003           | 9030        | Blanco (2015)                          | extracted, 4 rows         | 4        |
| 99004           | 9031        | Boehm & House (2014)                   | **SKIP** at pre-scan      | 1        |
| 99005           | 9134        | Schmitt-Grohé & Uribe (2004, JME)      | extracted, 4 rows         | 3        |

## Headline result

The Round-2 rerun reproduces the v34 corpus **exactly** for one paper (Blanco 2015), produces a related but non-identical extraction for a second paper (Schmitt-Grohé 2004), and **filters out three papers at the pre-scan inclusion gate** that Round-1 had retained. The behaviour of the pre-scan gate is the dominant source of run-to-run variation; once a paper passes the gate, the structured-extraction stages (Opus 4.5) are highly stable.

## Paper-by-paper detail

### Blanco (2015) — full match

All four preferred-row estimates reproduced identically.

| IdEstimate | v34 `Results_Inflation` | Round-2 `Results_Inflation` | match |
| ---        | ---                     | ---                         | ---   |
| 1          | 5.0                     | 5.0                         | ✓     |
| 2          | 1.0                     | 1.0                         | ✓     |
| 3          | 0.5                     | 0.5                         | ✓     |
| 4          | 0.5                     | 0.5                         | ✓     |

`Households_discount_factor` (0.9967), `Country` (US), `Year` (2015), `Calibration_Frequency` (M), `Model_Paradigm` (New Keynesian), `Ramsey_Rule` (0) all match.

The single deviation is the `Augmentation_Category` field, which Round-2 returned as `menu_costs`; the v3.3 closed vocabulary did not include that label, so the validator coerced it to NA in both Round-1 and Round-2 (logged as four `WARNING validator: Augmentation_Category: 'menu_costs' not in closed vocab -> NA` lines in `round2_rerun.log`). This is a **schema gap**, not an extraction disagreement, and affects Round-1 in the same way.

### Schmitt-Grohé & Uribe (2004) — partial match, extra panel

Round-2 returned 4 rows; v34 has 3. Both runs flagged `Country=US`, `Ramsey_Rule=1`, `Augmentation_Category=fiscal_policy`, `Calibration_Frequency=A` (annual), `Households_discount_factor=0.96`.

| IdEstimate | v34 `Results_Inflation` | Round-2 `Results_Inflation` |
| ---        | ---                     | ---                         |
| 1          | -3.66                   | -3.39                       |
| 2          | -1.82                   | -2.81                       |
| 3          | -0.16                   | -1.46                       |
| 4          | —                       | 4.40                        |

The two runs agree qualitatively (Friedman-rule-type mildly-deflationary optimal inflation under flexible prices and progressively less negative figures as price stickiness rises), but the panel-to-row mapping differs: Round-2 picked up Table 2's $\lambda=1.35$ high-markup panel (positive optimal inflation, 4.40), which Round-1 omitted, and read different summary statistics from the other three panels. This is the most informative disagreement in the sample. It is consistent with the known sensitivity of long-running stochastic-simulation results in this paper to which moment (mean, median, mode of the ergodic distribution) is reported, and with the fact that Schmitt-Grohé–Uribe (2004) reports the same object under multiple calibrations.

### Levin, Lopez-Salido & Yun (2007); Kiley (2001); Boehm & House (2014) — SKIP at pre-scan

In all three cases the Sonnet-4.5 pre-scan stage returned `count=0` with reasoning that the paper is "theoretical / calibration-only and reports no extractable optimal-inflation results". Round-1 disagreed: it carried these papers through the structured-extraction stages and recorded 7, 2, and 1 estimates respectively in v34.

The disagreement is at the **inclusion-criterion boundary**, not at the numerical-extraction layer. Re-reading the three papers confirms that they are borderline cases: each derives an optimal monetary-policy rule and reports a steady-state inflation rate under the rule (typically zero or close to zero) as a by-product of a calibration exercise. Round-1's coding treats those steady-state values as estimates; the Round-2 pre-scan gate, given an identical prompt but a fresh sampling seed, judges them as theoretical-rule outputs that fall outside the "quantitative optimal-inflation result" definition.

## Implications for the v34 dataset

1. **Numerical layer is robust.** Conditional on inclusion, the structured-extraction stages (Opus 4.5 for `structure` and `results`) reproduce the headline numerical content of the dataset to within the resolution of the underlying tables. The Blanco 2015 four-for-four match and the qualitative agreement on Schmitt-Grohé–Uribe 2004 sign pattern are the relevant evidence.
2. **Inclusion layer is the binding margin.** The dominant source of run-to-run variation is the pre-scan gate's classification of borderline theoretical-but-calibrated papers. Three of five sampled papers in this rerun fall on that margin. This is consistent with the Round-1 audit (`audit_round1_report.md`), which already flagged inclusion judgement as the noisiest pipeline stage.
3. **No re-coding of v34 is triggered by this rerun.** The numerical disagreements on Schmitt-Grohé–Uribe 2004 stay within the moderator-class envelope (three vs four observations on the same fiscal-policy Ramsey calibration; signs and order of magnitude preserved) and do not move any headline meta-analytic statistic. The headline numbers (mean inflation 0.61 percent on the preferred specification, FAT-PET 0.484, PEESE 0.60) are reported on 116 study clusters, so a one-cluster perturbation of three to four estimates leaves the cluster-robust headline numbers unchanged at two-decimal-place precision.

## Recommended manuscript treatment

- Document the rerun in the AI-pipeline appendix as a stratified self-consistency probe with the headline that the inclusion gate is the binding margin and the numerical extraction layer is stable.
- Do **not** claim a higher self-consistency rate than the data support: 1/5 papers reproduce identically (Blanco), 1/5 reproduce qualitatively with a panel-mapping difference (Schmitt-Grohé), 3/5 are filtered out at the inclusion gate.
- Frame the inclusion-margin variability as an honest limitation of the LLM-extraction approach, the same way meta-analyses written by humans flag inter-coder disagreement on inclusion criteria. The §3 prose already references "self-consistency distribution" without claiming uniform agreement; this finding is consistent with that framing.

## Files

- `ai_dataset/validation/round2_sample.csv` — the 5 sampled studies with v34 metadata.
- `ai_dataset/validation/round2_rerun/extracted_20260426-090322.{csv,xlsx}` — Round-2 raw output (8 rows × 73 columns).
- `ai_dataset/validation/round2_rerun/checkpoint.jsonl` — per-paper status log.
- `ai_dataset/validation/round2_rerun/partials/paper_99003.xlsx`, `paper_99005.xlsx` — per-paper partial outputs.
- `ai_dataset/validation/round2_rerun.log` — full pipeline log including model versions, token costs, and validator warnings.
