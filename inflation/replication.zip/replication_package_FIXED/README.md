# Optimal Inflation Rate — Meta-Analysis (Reproducibility Package, v34)

**Manuscript:** *Optimal Inflation Rate: A Meta-Analysis* — Opatrny, Opatrny,
Havranek, Havrankova, Hampl (2026).
**Target venue:** *Journal of Economic Surveys*, special issue on
Reproducibility and Meta-Science in Economics.

This package reproduces, end-to-end, every quantitative result in the
manuscript: from the LLM-assisted extraction of optimal-inflation point
estimates out of 116 primary studies, through the construction of the analysis
dataset, to the Stata meta-regression and the R Bayesian model averaging.

The package is licensed under MIT (code) + CC-BY-4.0 (data and documentation);
see `LICENSE`.

## Key dataset facts (single source of truth)

| Quantity | Value |
|---|---:|
| Primary studies in the analysis set | 116 |
| Raw point estimates in `inflation_v34.dta` | 885 |
| Distinct `Idstudy` values in the .dta (scope set) | 130 |
| Analysis rows after dropping `missing(Estimate_win)` | 777 |
| Author-preferred subsample (one row per study) | 116 |
| Author-preferred mean optimum (pp/year) | 0.61 |

## Folder layout

```
.
├── LICENSE                          MIT (code) + CC-BY-4.0 (data)
├── README.md                        this file
├── python/                          AI extraction + dataset construction
│   ├── INFLATION_2_0.py             Anthropic-API extraction driver
│   ├── pdf_to_markdown.py           PDF → Markdown helper
│   ├── raw_ai_archiver.py           archives raw Claude JSON responses
│   ├── config.py                    API config (keys redacted)
│   ├── phase1_normalize.py          normalises extracted rows
│   ├── phase2_build_analysis_dataset.py  builds inflation_v34.dta + .xlsx
│   ├── prompts/v3_3/Super_v3_2.md   base ruleset referenced by v3.3
│   ├── prompts/v3_3/Super_v3_3.md   production prompt delta (frozen 2026-04-22)
│   ├── prompts/v3_3/taxonomy.md     closed vocabulary cited by both
│   └── requirements.txt             pinned Python dependencies
├── R/                               BMA, p-uniform*, classical meta-analysis
│   ├── Inflation_v34.R              main analysis
│   ├── make_bma_figure.R            Figure 3
│   ├── out_v34/                     reference outputs from a clean run
│   └── sessionInfo.txt              R packages + versions
├── stata/                           main meta-regression analysis
│   ├── Inflation_v34.do             main do-file
│   ├── inflation_v34.dta            analysis dataset (130 studies, 885 rows)
│   ├── install_packages.do          one-time user-package installer
│   ├── Selection_Kasy_v34.csv       Kasy (2024) selection-bias inputs
│   └── Graphs/                      auxiliary plots written by the do-file
└── ai_dataset/                      extraction artefacts + validation
    ├── _study_list_v34.csv          130-study scope set (one row per Idstudy;
    │                                regenerate with python/regenerate_study_list.py)
    ├── _study_list_v34_enriched.csv same + affiliations + citations
    └── validation/                  inter-rater agreement, Cohen's kappa
```

## How to reproduce, end-to-end

All scripts are designed to be run from their own folder with relative paths.
The LaTeX manuscript itself lives in the parent project repository under
`Dropbox_Tomas/manuscript/` and is not duplicated here.

### 1. Reproduce the Stata meta-regression and tables

```
cd stata
stata -b do install_packages.do      # one-time, installs metan/psacalc/etc.
stata -b do Inflation_v34.do         # reads inflation_v34.dta in the same folder
```

Writes per-table `.tex` files (the manuscript embeds tables inline) and
auxiliary plots into `stata/Graphs/`. The do-file pins `set seed 1234`.

### 2. Reproduce the BMA, p-uniform*, REML, and Figure 3

```
cd R
Rscript Inflation_v34.R              # reads ../stata/inflation_v34.dta
Rscript make_bma_figure.R            # reads out_v34/bma_posterior.csv
```

Outputs land in `R/out_v34/`. `set.seed(1234)` is fixed before the BMS draws.

### 3. (Optional) Re-run the AI extraction pipeline

Requires an Anthropic API key and the source PDFs of the 116 primary studies
(not shipped — see "What is not in this package" below).

```
export ANTHROPIC_API_KEY=sk-ant-api03-...
cd python
pip install -r requirements.txt
python INFLATION_2_0.py --papers <pdf-dir> --out ../ai_dataset/v3_0_full
python phase1_normalize.py
python phase2_build_analysis_dataset.py --v34
```

The production prompt lives in `python/prompts/v3_3/`. `INFLATION_2_0.py`
concatenates three components in this order before sending them to the
model: `Super_v3_2.md` (base ruleset), `Super_v3_3.md` (delta with the
15 new columns, frozen 2026-04-22), and `taxonomy.md` (closed
vocabulary). All three files are required at runtime; see
`load_system_prompt()` in `python/INFLATION_2_0.py`. Models stamped in
`python/config.py`:
`claude-sonnet-4-5-20250929` and `claude-opus-4-5-20251001`, temperature 0.
`phase2_build_analysis_dataset.py --v34` is the script that drops `Idstudy
9072` and `9084`, drops the unverified `DOI` column, derives the
`Affiliation_Class` variable, and writes `stata/inflation_v34.dta`.

## What is *not* in this package, and why

| Excluded | Reason | Where to get it |
|---|---|---|
| `Literature/` (the 116 primary PDFs) | Copyright | Source journals / NBER / SSRN / authors' homepages; bibliographic details in `ai_dataset/_study_list_v34.csv` and in the manuscript's `Bibl.bib` |
| Raw Claude JSON responses | Deterministic from the same prompt + PDFs (≈6 MB) | Re-runnable from step 4 above; archived locally by `raw_ai_archiver.py` |
| PDF→Markdown intermediates | Regenerated automatically | Re-runnable from step 4 above |
| Mirror files of the .dta | The `.dta` is the canonical analysis dataset | `analysis_dataset_v34.xlsx` is regenerated by `phase2_build_analysis_dataset.py --v34`; or convert from `stata/inflation_v34.dta` with `haven::read_dta` |

## Reviewer notes

- **`config.py` API keys are redacted.** Set `ANTHROPIC_API_KEY` (and
  optionally `SCOPUS_API_KEY`) as environment variables before running
  step 4.
- **All numbers in the manuscript are reproducible from `inflation_v34.dta`**
  via the Stata do-file in step 2 and the R script in step 3.
- **Andrade et al.** appears as two distinct study records (2018 NBER WP and
  2021 JEDC), contributing 33 row-level estimates jointly to the analysis
  dataset.
- **Lipinska 2015** is the only structural calibration in the corpus that
  targets a post-communist economy; the implied policy applies to the wider
  EMU-accession set.
- **Dinh 2025** was excluded at full-text screening as off-topic
  (digital-financial-inclusion threshold regression, not a structural
  welfare-optimal-inflation study).
- **Section 2 (Related literature)** frames the policy-oriented low-r\*
  literature (Blanchard, Dell'Ariccia & Mauro 2010; Ball 2014; Kiley &
  Roberts 2017; Bernanke, Kiley & Roberts 2019; Afrouzi, Halac, Rogoff &
  Yared 2024) as policy benchmarks, not as entries in the meta-analytic
  dataset.

## Changelog

- **2026-06-01** — Removed the duplicated `manuscript/` folder from the
  replication package; the canonical LaTeX sources, figures, and
  compiled PDF live only at `Dropbox_Tomas/manuscript/`. Dropped
  `Idstudy 9084` (Jung 2003, unverifiable working paper); removed
  unverified `DOI` column from analysis dataset; rebuilt
  `inflation_v34.dta` (now 885 rows × 130 studies, was 886 × 131).
  Trimmed `python/` folder to the six scripts strictly needed for
  extraction + dataset construction (audit / claim-verification
  scripts removed). Updated `Bibl.bib` (≈16 entries finalised against
  OpenAlex / Crossref; bibliography style switched from `apalike` to
  `plainnat` so DOIs render in the rendered references; residual
  `@misc` entries with real metadata converted to `@techreport` /
  `@article`).

## Contact

Matej Opatrny, `matej.opatrny@fsv.cuni.cz`.
For replication or audit questions, please cc `tomas.havranek@fsv.cuni.cz`.
