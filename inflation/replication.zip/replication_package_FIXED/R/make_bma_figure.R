# =============================================================================
# BMA posterior-inclusion-probability figure (PDF, vector, high-quality)
# Produces: out_v34/bma_pip.pdf
# Run from R/ folder after Inflation_v34.R has produced out_v34/bma_posterior.csv
# =============================================================================

rm(list = ls())

library(ggplot2)
library(dplyr)

bma <- read.csv("out_v34/bma_posterior.csv", stringsAsFactors = FALSE)

# ---- Human-readable labels (keys must match bma$variable exactly) -----------
lbl <- c(
  "PR_Optimized_Taylor_rule"    = "Optimised Taylor rule",
  "PR_Ramsey"                   = "Ramsey optimal policy",
  "PR_Ramsey_discretion"        = "Ramsey with discretion",
  "PR_Taylor_rule"              = "Simple Taylor rule",
  "PR_Inflation_targeting"      = "Inflation targeting",
  "PR_Friedman_rule"            = "Friedman rule imposed",
  "PR_Other"                    = "Other policy regime",
  "SHK_Markup"                  = "Mark-up shocks",
  "SHK_Multiple"                = "Multiple shocks",
  "SHK_Preference"              = "Preference shocks",
  "SHK_Government_spending"     = "Government-spending shocks",
  "SHK_Financial"               = "Financial shocks",
  "SHK_Risk_premium"            = "Risk-premium shocks",
  "WC_conditional_efficient_SS" = "Conditional-efficient steady state",
  "WC_second_order_approx"      = "Second-order welfare approximation",
  "SST_deterministic"           = "Deterministic steady state",
  "SEN_baseline"                = "Baseline specification",
  "SEN_comparison"              = "Comparison specification",
  "SEN_extension"               = "Extension specification",
  "SEN_robustness_mechanism"    = "Robustness / mechanism check",
  "EST_Bayesian"                = "Bayesian estimation",
  "NFT_Calvo_prices"            = "Calvo price rigidity",
  "NFT_Calvo_prices_and_wages"  = "Calvo prices and wages",
  "WRT_DNWR"                    = "Downward nominal wage rigidity",
  "WRT_Rotemberg_wages"         = "Rotemberg wage rigidity",
  "MDT_MIU"                     = "Money in the utility function",
  "MDT_CIA"                     = "Cash in advance",
  "MDT_cashless"                = "Cashless environment",
  "MDT_none"                    = "No money-demand technology",
  "IND_none"                    = "No indexation",
  "IND_past_inflation"          = "Indexation to past inflation",
  "AUG_heterogeneous_agents"    = "Heterogeneous-agent model",
  "AUG_open_economy"            = "Open-economy extension",
  "AUG_financial_frictions"     = "Financial frictions",
  "AUG_fiscal_policy"           = "Fiscal-policy extension",
  "AUG_ZLB"                     = "Zero lower bound (augment)",
  "ZLB"                         = "Zero lower bound active",
  "Ramsey"                      = "Ramsey planner",
  "Growth"                      = "Trend growth",
  "Year"                        = "Publication year",
  "LCitations"                  = "Log citations",
  "LIF"                         = "Log impact factor",
  "SE_win"                      = "Standard error (publication bias)"
)

# Fallback: snake_case -> "Title case" if a variable is not in the map above
prettify <- function(x) {
  out <- gsub("_", " ", x)
  out <- gsub("^(\\w)", "\\U\\1", out, perl = TRUE)
  out
}
bma$label <- ifelse(bma$variable %in% names(lbl),
                    unname(lbl[bma$variable]),
                    prettify(bma$variable))

bma$prior_label <- recode(bma$prior,
  "UIP_dilution" = "UIP + Dilution (main)",
  "BRIC_random"  = "BRIC + Random (robust.)",
  "HQ_random"    = "HQ + Random (robust.)")

# ---- Select top 20 by main-prior PIP ----------------------------------------
ord_df <- bma %>%
  filter(prior == "UIP_dilution") %>%
  arrange(desc(PIP)) %>%
  slice_head(n = 20) %>%
  select(variable, label)
ord_labels <- ord_df$label

plot_df <- bma %>%
  filter(variable %in% ord_df$variable) %>%
  mutate(
    label       = factor(label, levels = rev(ord_labels)),
    prior_label = factor(prior_label,
                         levels = c("UIP + Dilution (main)",
                                    "BRIC + Random (robust.)",
                                    "HQ + Random (robust.)"))
  )

# Sanity check: no NA labels should remain
stopifnot(!any(is.na(plot_df$label)))
stopifnot(!any(is.na(plot_df$PIP)))

g <- ggplot(plot_df, aes(x = PIP, y = label,
                         colour = prior_label, shape = prior_label)) +
  geom_vline(xintercept = 0.5, linetype = "dashed", colour = "gray60") +
  geom_point(size = 2.8, alpha = 0.85) +
  scale_x_continuous(limits = c(0, 1.02), breaks = seq(0, 1, 0.2)) +
  scale_colour_manual(values = c("steelblue", "firebrick", "darkgreen")) +
  labs(x = "Posterior inclusion probability",
       y = NULL,
       colour = "Prior", shape = "Prior",
       title = NULL) +
  theme_bw(base_size = 10) +
  theme(
    panel.grid.major.y = element_line(colour = "gray92"),
    panel.grid.minor   = element_blank(),
    legend.position    = "top",
    legend.title       = element_text(size = 9),
    axis.text.y        = element_text(size = 9)
  )

pdf("out_v34/bma_pip.pdf", width = 7.5, height = 6.2)
print(g)
dev.off()

cat("Saved out_v34/bma_pip.pdf\n")
