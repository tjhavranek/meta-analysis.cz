# =============================================================================
# Optimal Inflation Rate: Meta-Analysis (v3.3 dataset)
# R script -- Bayesian Model Averaging, p-uniform*, classical meta-analysis
#
# Inputs:
#   ../stata/inflation_v34.dta                   (analysis dataset, 885 rows)
#
# Outputs (written to out_v34/ inside this R/ folder):
#   out_v34/bma_posterior.csv                    (posterior summaries)
#   out_v34/fma_weights.csv                      (Frequentist model averaging)
#   out_v34/puniform_results.txt                 (p-uniform* summary)
#   out_v34/metafor_results.txt                  (classical REML on genuine-SE)
#   out_v34/corrplot.pdf                         (correlation heatmap)
#
# To run:  cd to the R/ folder of this package, then `Rscript Inflation_v34.R`.
#
# Priors for BMA (following Havranek et al. 2018, JES):
#   (1) UIP (uniform) + Dilution  -- main specification
#   (2) BRIC + Random             -- robustness 1
#   (3) HQ  + Random              -- robustness 2
# =============================================================================

rm(list = ls())
# Run from the R/ folder of this package; no setwd() needed.
# The script reads ../stata/inflation_v34.dta and writes to out_v34/.

pkgs <- c("readxl", "BMS", "metafor", "puniform", "corrplot",
          "dplyr", "tidyr", "ggplot2", "haven")
missing_pkgs <- pkgs[!pkgs %in% rownames(installed.packages())]
if (length(missing_pkgs) > 0) install.packages(missing_pkgs)

library(readxl);  library(BMS);     library(metafor)
library(puniform);library(corrplot);library(dplyr)
library(tidyr);   library(ggplot2); library(haven)

dir.create("out_v34", showWarnings = FALSE, recursive = TRUE)

# -----------------------------------------------------------------------------
# 1. Load dataset (read .dta directly to avoid xlsx intermediate dependency)
# -----------------------------------------------------------------------------
df <- as.data.frame(haven::read_dta("../stata/inflation_v34.dta"))
cat("Loaded ", nrow(df), " rows x ", ncol(df), " cols (raw extraction)\n", sep = "")

# Restrict to the analysis dataset (777 rows, 116 studies): rows with a
# non-missing winsorised optimal-inflation estimate. The remaining 108
# rows in the raw extraction are theoretical/qualitative entries from the
# 14 narrative-only studies in the 130-study scope set, plus a handful of
# rows for which the outcome could not be annualised; they are excluded
# from every quantitative result reported in the manuscript.
df <- df %>% filter(!is.na(Estimate_win))
cat("Analysis dataset (777 target): ", nrow(df), " rows from ",
    length(unique(df$Idstudy)), " studies\n", sep = "")

# Add a single-reference affiliation contrast (university = reference).
# Affiliation_Class has four levels: university, central_bank, mixed,
# other; 4 rows are missing and we pool them into "other" so that no
# observation is lost on this margin. The three dummies are then added
# to the BMA design matrix so that referees can read whether reported
# optima differ systematically by author affiliation, conditional on the
# structural moderator schema.
df <- df %>% mutate(
  Affiliation_Class = ifelse(is.na(Affiliation_Class) | Affiliation_Class == "",
                             "other", Affiliation_Class),
  Affil_central_bank = as.integer(Affiliation_Class == "central_bank"),
  Affil_mixed        = as.integer(Affiliation_Class == "mixed"),
  Affil_other        = as.integer(Affiliation_Class == "other")
)

# Drop rows whose bootstrap precision proxy is degenerate (SE_win = 0 or NA).
# These rows have a valid point estimate but no within-study dispersion,
# so equation~(\ref{eq:fatpet}) is undefined for them.
df <- df %>% filter(!is.na(SE_win), SE_win > 0)
cat("After SE_win > 0 filter: ", nrow(df), " rows\n", sep = "")

# -----------------------------------------------------------------------------
# 2. Bayesian Model Averaging  (BMS)
# -----------------------------------------------------------------------------
# Columns to include: SE + all methodological dummies + year + citations + IF
bma_vars <- c("Estimate_win", "SE_win",
              grep("^(PR_|SHK_|WC_|SST_|SEN_|EXP_|EST_|NFT_|WRT_|MDT_|IND_|PUB_|AUG_|HZ_|MC_|MP_)",
                   names(df), value = TRUE),
              "ZLB", "Growth", "Ramsey", "Year", "LCitations", "LIF",
              "Affil_central_bank", "Affil_mixed", "Affil_other")
bma_vars <- intersect(bma_vars, names(df))

# --- Block-level "unknown" indicators + NA->0 in dummy blocks --------------
# Each PR_/SHK_/WC_/.../MP_ family is a one-hot encoding of a categorical
# study feature. Some rows have the entire block missing because the AI
# extractor could not classify the paper on that dimension; e.g. analytical
# Friedman-rule papers carry no shock-type, and minimalist NK papers carry
# no augmentation. Listwise deletion across all dummies would drop most
# of the 702 usable rows. We instead add a block-level missingness
# indicator BLOCK_unknown = 1 if every column in that block is NA, and
# then set the original block dummies to zero. The BMA can therefore
# absorb "unclassified on dimension X" as its own category and learn
# whether unclassified rows differ systematically. The continuous controls
# Year, LCitations and LIF are still used in listwise mode (a handful of
# non-journal rows drop on LIF). This matches the convention in
# Havranek et al. (2018, JES).
block_prefixes <- c("PR_","SHK_","WC_","SST_","SEN_","EXP_","EST_",
                    "NFT_","WRT_","MDT_","IND_","PUB_","AUG_","HZ_",
                    "MC_","MP_")
new_unknown <- character(0)
for (pfx in block_prefixes) {
  cols <- grep(paste0("^", pfx), names(df), value = TRUE)
  if (length(cols) == 0) next
  unk_col <- paste0(pfx, "unknown")
  block_all_na <- apply(df[, cols, drop = FALSE], 1,
                        function(x) all(is.na(x)))
  df[[unk_col]] <- as.integer(block_all_na)
  for (cc in cols) df[[cc]][is.na(df[[cc]])] <- 0
  if (length(unique(df[[unk_col]])) > 1) {
    new_unknown <- c(new_unknown, unk_col)
  } else {
    df[[unk_col]] <- NULL
  }
}
bma_vars <- c(bma_vars, new_unknown)
cat("Added ", length(new_unknown), " block-unknown indicators; ",
    "recoded dummy NAs to 0\n", sep = "")

bma_data <- df %>%
  select(all_of(bma_vars)) %>%
  drop_na()

# Drop zero-variance columns (collinear with constant)
zerovar <- sapply(bma_data, function(x) length(unique(x)) < 2)
bma_data <- bma_data[, !zerovar]
# Drop perfectly collinear columns (keep first)
keep <- logical(ncol(bma_data)); keep[1] <- TRUE
for (j in 2:ncol(bma_data)) {
  fit <- try(lm(bma_data[[j]] ~ ., data = bma_data[, keep, drop = FALSE]),
             silent = TRUE)
  if (inherits(fit, "try-error")) next
  r2 <- summary(fit)$r.squared
  if (!is.na(r2) && r2 < 0.999) keep[j] <- TRUE
}
bma_data <- bma_data[, keep]
cat("BMA matrix: ", nrow(bma_data), " x ", ncol(bma_data), "\n")

# Ensure Estimate_win is the 1st column (dependent)
bma_data <- bma_data[, c("Estimate_win", setdiff(names(bma_data), "Estimate_win"))]

set.seed(1234)

bma_uip    <- bms(bma_data, burn = 2e4, iter = 1e5,
                  g = "UIP",  mprior = "dilution", mcmc = "bd",
                  user.int = FALSE)
bma_bric   <- bms(bma_data, burn = 2e4, iter = 1e5,
                  g = "BRIC", mprior = "random", mcmc = "bd",
                  user.int = FALSE)
bma_hq     <- bms(bma_data, burn = 2e4, iter = 1e5,
                  g = "HQ",   mprior = "random", mcmc = "bd",
                  user.int = FALSE)

post_summary <- function(bmaobj, tag) {
  co <- coef(bmaobj, order.by.pip = FALSE)
  data.frame(prior = tag,
             variable = rownames(co),
             PIP      = co[, "PIP"],
             PostMean = co[, "Post Mean"],
             PostSD   = co[, "Post SD"],
             CondMean = co[, "Post Mean"] / pmax(co[, "PIP"], 1e-8))
}

bma_out <- rbind(
  post_summary(bma_uip,  "UIP_dilution"),
  post_summary(bma_bric, "BRIC_random"),
  post_summary(bma_hq,   "HQ_random")
)
write.csv(bma_out, "out_v34/bma_posterior.csv", row.names = FALSE)
cat("BMA done. Top PIPs (UIP+Dilution):\n")
print(head(bma_out[bma_out$prior == "UIP_dilution", ][order(-bma_out$PIP[bma_out$prior == "UIP_dilution"]), ], 15))

# --- Robustness: BMA without the bootstrap dispersion proxy SE_win ---------
# Because 761 of 777 within-paper SEs are bootstrap-derived rather than
# sampling SEs, the SE coefficient in the main BMA cannot be read as a
# FAT-PET test of publication bias (the FAT-PET reading requires SE to
# measure estimation precision). We therefore re-fit the main BMA on the
# same 692 rows but without SE_win in the regressor set, to verify that
# the structural-moderator ranking is invariant to its inclusion. The
# publication-bias verdict for this paper rests on the caliper test and
# the p-uniform* on the 16 genuine-SE rows, not on this coefficient.
bma_data_noSE <- bma_data[, setdiff(names(bma_data), "SE_win")]
bma_uip_noSE  <- bms(bma_data_noSE, burn = 2e4, iter = 1e5,
                     g = "UIP",  mprior = "dilution", mcmc = "bd",
                     user.int = FALSE)
bma_out_noSE  <- post_summary(bma_uip_noSE, "UIP_dilution_noSE")
write.csv(bma_out_noSE,
          "out_v34/bma_posterior_noSE.csv", row.names = FALSE)
cat("\nRobustness BMA (no SE) top PIPs:\n")
print(head(bma_out_noSE[order(-bma_out_noSE$PIP), ], 15))

pdf("out_v34/bma_plots.pdf", width = 9, height = 6)
plotModelsize(bma_uip);  title(sub = "UIP + Dilution")
plotModelsize(bma_bric); title(sub = "BRIC + Random")
plotModelsize(bma_hq);   title(sub = "HQ + Random")
# image(bma_uip) skipped: internal bug in BMS when Estimate_win contains nothing
# non-constant after collinearity drop. The plotModelsize() pages above are
# the key visual.
dev.off()

# -----------------------------------------------------------------------------
# 2b. Stylised-economy scenarios -- predict optima from the BMA posterior
# -----------------------------------------------------------------------------
# We compute fitted values from the main UIP+dilution BMA at user-specified
# design points, with all other moderators held at their sample mean. The
# resulting "scenario" optima are written to out_v34/bma_scenarios.csv
# and feed Table~\ref{tab:scenarios} in the manuscript.
#
# Scenario design: a Ramsey planner, Calvo prices, rational expectations,
# long-run welfare, in a US-calibrated NK economy. The columns we vary are
# documented in the manuscript.
xbar      <- colMeans(bma_data)
co_uip    <- coef(bma_uip, order.by.pip = FALSE,
                  exact = TRUE, condi.coef = FALSE)
post_mean <- co_uip[, "Post Mean"]
intercept <- mean(bma_data[[1]]) - sum(post_mean * xbar[names(post_mean)])

# Use BMS::predict.bma to get model-averaged fitted value + posterior SD
# at each scenario design point.
mk_row <- function(overrides) {
  v <- xbar
  for (nm in names(overrides)) {
    if (nm %in% names(v)) v[nm] <- overrides[[nm]]
  }
  v <- v[names(post_mean)]   # align to BMA regressor order
  matrix(v, nrow = 1, dimnames = list(NULL, names(v)))
}

scenarios <- list(
  baseline = list(set = c(),                                          anchor = NULL),
  cashless = list(set = c(MDT_cashless = 1, MDT_MIU = 0),             anchor = "MDT_cashless"),
  dnwr     = list(set = c(WRT_DNWR = 1, WRT_none = 0),                anchor = "WRT_DNWR"),
  dnwr_zlb = list(set = c(WRT_DNWR = 1, WRT_none = 0, AUG_ZLB = 1),   anchor = "AUG_ZLB"),
  hank     = list(set = c(AUG_heterogeneous_agents = 1, AUG_ZLB = 1), anchor = "AUG_heterogeneous_agents")
)

# Sample dispersion: SD of the dependent variable among rows that match
# the *anchor* dummy of the scenario. This gives a reasonable plausibility
# range when the joint conjunction of all overrides is empty in the
# 692-row sample.
sample_disp <- function(anchor) {
  if (is.null(anchor)) {
    list(n = nrow(bma_data), sd = sd(bma_data[[1]]))
  } else if (anchor %in% names(bma_data)) {
    m <- bma_data[[anchor]] == 1
    list(n = sum(m), sd = if (sum(m) > 1) sd(bma_data[[1]][m]) else NA_real_)
  } else {
    list(n = NA_integer_, sd = NA_real_)
  }
}

sc_rows <- lapply(scenarios, function(s) {
  X <- mk_row(s$set)
  fit <- intercept + as.numeric(X %*% post_mean[colnames(X)])
  disp <- sample_disp(s$anchor)
  data.frame(fit = fit, n = disp$n, samp_sd = disp$sd)
})
sc_tbl <- do.call(rbind, sc_rows)
sc_tbl$scenario <- names(scenarios)
sc_tbl$lo <- sc_tbl$fit - sc_tbl$samp_sd
sc_tbl$hi <- sc_tbl$fit + sc_tbl$samp_sd
sc_tbl <- sc_tbl[, c("scenario","fit","lo","hi","n","samp_sd")]
write.csv(sc_tbl, "out_v34/bma_scenarios.csv", row.names = FALSE)
cat("\nScenario predictions (UIP+dilution, n=", nrow(bma_data), "):\n", sep = "")
print(sc_tbl, row.names = FALSE)

# -----------------------------------------------------------------------------
# 3. Frequentist Model Averaging (Mallows) via metafor::rma + manual weights
#    (BMA acts as main, FMA as robustness -- per Havranek et al.)
# -----------------------------------------------------------------------------
tryCatch({
  if (requireNamespace("MuMIn", quietly = TRUE)) {
    library(MuMIn)
    # MuMIn::dredge becomes exponential in #predictors; cap to top predictors
    univ_t <- sapply(2:ncol(bma_data), function(j) {
      r <- try(lm(bma_data[[1]] ~ bma_data[[j]]), silent = TRUE)
      if (inherits(r, "try-error")) return(0)
      abs(summary(r)$coefficients[2, "t value"])
    })
    topvars <- names(bma_data)[c(1, 1 + order(univ_t, decreasing = TRUE)[1:min(14, length(univ_t))])]
    # Put the model frame in global env (MuMIn requirement).
    fma_data <<- bma_data[, topvars]
    fm_small <- lm(Estimate_win ~ ., data = fma_data, na.action = "na.fail")
    dd <- dredge(fm_small, rank = "AIC")
    avg <- model.avg(dd, subset = cumsum(weight) <= 0.95, fit = TRUE)
    sum_avg <- summary(avg)
    write.csv(sum_avg$coefmat.full,
              "out_v34/fma_weights.csv", row.names = TRUE)
    cat("FMA done (MuMIn, top ", length(topvars)-1, ").\n", sep="")
  } else {
    cat("MuMIn not installed; skipping FMA.\n")
  }
}, error = function(e) cat("FMA failed: ", conditionMessage(e), "\n"))

# -----------------------------------------------------------------------------
# 4. p-uniform* publication-bias test (van Aert & van Assen 2020)
#    on median preferred estimate per paper (exported by Stata).
# -----------------------------------------------------------------------------
pu_path <- "../stata/puniform_v34.csv"
if (file.exists(pu_path)) {
  pu <- read.csv(pu_path)
  cat("p-uniform* input (paper medians): ", nrow(pu), " papers\n")
  # Drop papers with degenerate variance (bootstrap produced ~0 dispersion
  # because all estimates in that paper are numerically identical).
  pu <- pu[!is.na(pu$variance_med) & pu$variance_med > 1e-6, ]
  cat("After variance filter: ", nrow(pu), " papers\n")

  run_puni <- function(yi, vi, side, label) {
    cat(sprintf("\n====== p-uniform* %s ======\n", label))
    r <- try(puni_star(yi = yi, vi = vi, side = side,
                       method = "P", alpha = 0.05), silent = TRUE)
    if (inherits(r, "try-error")) {
      cat("[P method failed; retrying with LNP]\n")
      r <- try(puni_star(yi = yi, vi = vi, side = side,
                         method = "LNP", alpha = 0.05), silent = TRUE)
    }
    print(r)
    invisible(r)
  }

  sink("out_v34/puniform_results.txt")
    cat("### Sample 1: paper medians with bootstrap variance (n = ",
        nrow(pu), ")\n", sep = "")
    run_puni(pu$est_med,       pu$variance_med, "right", "null=0 right-sided")
    run_puni(pu$est_med,       pu$variance_med, "left",  "null=0 left-sided")
    run_puni(pu$est_med - 2,   pu$variance_med, "right", "null=2 right-sided")
    run_puni(pu$est_med - 2,   pu$variance_med, "left",  "null=2 left-sided")

    # Fallback: genuine-SE subsample (CI-derived variance is truly sampling).
    gen_sub <- df %>% filter(se_is_genuine == 1,
                             !is.na(Estimate_win), !is.na(SE_win), SE_win > 0)
    cat("\n### Sample 2: genuine CI-derived SE (n = ", nrow(gen_sub), ")\n", sep = "")
    run_puni(gen_sub$Estimate_win,     gen_sub$SE_win^2, "right", "null=0 right-sided")
    run_puni(gen_sub$Estimate_win,     gen_sub$SE_win^2, "left",  "null=0 left-sided")
    run_puni(gen_sub$Estimate_win - 2, gen_sub$SE_win^2, "right", "null=2 right-sided")
    run_puni(gen_sub$Estimate_win - 2, gen_sub$SE_win^2, "left",  "null=2 left-sided")
  sink()
  cat("p-uniform* results saved.\n")
} else {
  cat("Run Inflation_v34.do first to create puniform_v34.csv\n")
}

# -----------------------------------------------------------------------------
# 5. Classical REML meta-analysis on genuine-SE subsample
# -----------------------------------------------------------------------------
gen <- df %>% filter(se_is_genuine == 1)
cat("Genuine-SE rows: ", nrow(gen), "\n")
sink("out_v34/metafor_results.txt")
  if (nrow(gen) >= 10) {
    # REML random-effects
    m1 <- rma(yi = gen$Estimate_win, sei = gen$SE_win, method = "REML")
    print(m1)
    cat("\nTrim-and-fill (L0 estimator):\n")
    print(trimfill(m1, estimator = "L0"))
    cat("\nEgger's regression:\n")
    print(regtest(m1))
  } else {
    cat("Not enough genuine-SE observations.\n")
  }
sink()

# -----------------------------------------------------------------------------
# 6. Correlation heatmap of methodological dummies (sanity)
# -----------------------------------------------------------------------------
dummy_cols <- grep("^(PR_|NFT_|WRT_|MDT_|IND_|EST_|SEN_|EXP_|WC_|SST_|AUG_|HZ_|PUB_)",
                   names(df), value = TRUE)
if (length(dummy_cols) >= 4) {
  dmat <- df %>% select(all_of(dummy_cols)) %>% mutate_all(as.numeric) %>% as.matrix()
  ok <- apply(dmat, 2, function(x) sd(x, na.rm = TRUE) > 0)
  dmat <- dmat[, ok]
  co <- cor(dmat, use = "pairwise.complete.obs")
  # Replace residual NAs (pair never co-observed) with 0 so hclust works
  co[!is.finite(co)] <- 0
  pdf("out_v34/corrplot.pdf", width = 14, height = 14)
  corrplot(co, method = "color", tl.cex = 0.55, tl.col = "black",
           diag = FALSE, order = "original")
  dev.off()
  cat("Corrplot saved.\n")
}

cat("\n============================================================\n")
cat("Inflation_v34.R finished. Outputs in out_v34/\n")
cat("============================================================\n")
