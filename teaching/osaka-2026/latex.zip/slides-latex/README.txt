LaTeX source of the slides: Introduction to Meta-Analysis in Economics, ISER, University of Osaka, 16 March 2026
Tomas Havranek, Charles University, Prague. https://meta-analysis.cz/teaching/

Compile with pdflatex, twice:  pdflatex slides.tex
slides.tex is encoded in cp1250 (see \usepackage[cp1250]{inputenc}). The figures sit in
the folders next to it. Licence: CC BY 4.0; a few figures reproduce other people's work,
and those remain under their original terms.
