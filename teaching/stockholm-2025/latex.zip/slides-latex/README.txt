LaTeX source of the slides: Meta-Analysis for Policy Economists, Tillväxtanalys, Stockholm, 28 and 29 August 2025
Tomas Havranek, Charles University, Prague. https://meta-analysis.cz/teaching/

Compile with pdflatex, twice:  pdflatex slides.tex
slides.tex is encoded in cp1250 (see \usepackage[cp1250]{inputenc}). The figures sit in
the folders next to it. Licence: CC BY 4.0.
