LaTeX source of the slides: Research Synthesis in Economics and Finance (ECON670),
University of Canterbury, Christchurch, Term 1 2025. Tomas Havranek, Charles University, Prague.
https://meta-analysis.cz/teaching/christchurch-2025/

Each lecture is in its own folder: compile it there with pdflatex, twice (pdflatex lecture5.tex).
The files are UTF-8, and the figures each lecture uses sit next to its .tex. Licence: CC BY 4.0.
