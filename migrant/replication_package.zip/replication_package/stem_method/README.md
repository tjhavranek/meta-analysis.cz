Bundled external method code for the stem-based publication-bias estimator lives in this folder.

This code is sourced by `run_replication_package.R` and is not the project-owned workflow logic.

Original source reference:
- Stem-based method in R, https://github.com/Chishio318/stem-based_method

Method reference used in the manuscript:
- Furukawa, C. (2020). "Publication bias under aggregation frictions: Theory, evidence, and a new correction method." 

Package usage note:
- `run_replication_package.R` is the only intended entry point; it sources `stem_method.R` from here when needed.
