Bundled external method code for the Andrews-Kasy selection model lives in this folder.

This code is sourced by `run_replication_package.R` and is not the project-owned workflow logic.

Original method reference:
- Andrews, I. and M. Kasy (2019). "Identification of and correction for publication bias." American Economic Review 109(8): 2766-2794.

Replication provenance:
- The distributed package bundles the local selection-model implementation used by the maintained replication workflow, adapted from the `MetaStudiesApp` source in the main repository at https://maxkasy.github.io/home/metastudy/.
- The final manuscript and updated replication materials refer to this as the "Selection Model (Andrews & Kasy, 2019)".

Package usage note:
- `run_replication_package.R` is the only intended entry point; it sources the files here when needed.
