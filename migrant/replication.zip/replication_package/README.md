# Replication Package

This folder is the self-contained distribution version of the replication package for the paper's main tables and figures.

## Requirements

The script was tested on **R 4.5.1** and **R 4.6.1**. It uses the following CRAN packages and will **install any
that are missing automatically** the first time it runs: `readxl`, `dplyr`, `BMS`, `multcomp`,
`sandwich`, `fixest`, `quadprog`. (To install them yourself beforehand:
`install.packages(c("readxl","dplyr","BMS","multcomp","sandwich","fixest","quadprog"))`.)
The Andrews–Kasy selection model and the stem method are bundled locally under `andrews_kasy/`
and `stem_method/`, so no extra installation is needed for those.

## How to run it

From the repository root, run either of the following in R:

```r
source("replication_package/run_replication_package.R")
```

or from a shell:

```sh
Rscript replication_package/run_replication_package.R
```

## Inputs

- `Data.xlsx`: packaged copy of the canonical workbook used by this distribution script.
- `stem_method/`: local copy of the stem-method implementation used for Table 2.
- `andrews_kasy/`: local copy of the selection-model implementation used for Table 2.

## Outputs

The script rewrites the replication-package outputs in:

- `replication_package/tables/`
- `replication_package/figures/`

Main artifacts created by the script:

- `table_1_summary_statistics.csv`
- `table_a2_summary_by_country.csv`
- `table_2_publication_bias.csv`
- `table_4_heterogeneity.csv`
- `table_5_bpe.csv`
- `table_b1_variable_description.csv`
- `figure_1_estimates_by_study.pdf`
- `figure_2_funnel_plot.pdf`
- `figure_3_bma_inclusion.pdf`
- `figure_supplementary_trend.pdf` (exploratory; not numbered in the manuscript)
- `figure_a2_estimates_by_country.pdf`
- `table_b2_bma_robustness_random_priors.csv` and `table_b3_bma_robustness_uniform_priors.csv`
- `figure_b1_bma_uip_random.pdf` … `figure_b8_bma_bric_uniform.pdf` (BMA inclusion plots, Figures B1–B8)
- `figure_b9_pmp_uip_random.pdf` … `figure_b16_pmp_bric_uniform.pdf` (posterior model probability plots, Figures B9–B16)

## Notes

- The script validates the expected sample sizes before producing outputs.
- Every BMA run sets the random seed (`bma_seed <- 123`) immediately before the sampler, so Table 4, Tables B2–B3 and Figures 3 and B1–B16 reproduce exactly. `BMS::bms()` normally reseeds R's generator from the system clock (`set.seed(as.numeric(Sys.time()))`) just before its MCMC loop, which makes a caller's `set.seed()` ineffective. The script therefore calls `bms_seeded()`, a copy of `bms()` in which only that reseed is disabled; the sampler is otherwise unchanged.
- The Table B2 and B3 robustness runs (seven BMA models in addition to the baseline) are enabled and dominate the run time; a full run takes about 8–9 minutes on a recent laptop.
- With N = 1,087 and K = 27 regressors, the BRIC prior's g = max(N, K²) equals N, so the BRIC columns of Tables B2 and B3 coincide with the UIP columns.
- In Table A2 a study counts once for each country it reports estimates for; Aydemir and Borjas (2007) covers both Canada and the US, so the country rows sum to 42 studies while the total row reports 41.
- The main driver script is organized in numbered sections so each table/figure block can be located quickly.
