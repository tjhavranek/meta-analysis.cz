# Replication Package

This folder is the self-contained distribution version of the replication package for the paper's main tables and figures.

## Requirements

The script was tested on **R 4.5.1** and **R 4.6.1**. It uses the following CRAN packages and will **install any
that are missing automatically** the first time it runs: `readxl`, `dplyr`, `BMS`, `multcomp`,
`sandwich`, `fixest`, `quadprog`. (To install them yourself beforehand:
`install.packages(c("readxl","dplyr","BMS","multcomp","sandwich","fixest","quadprog"))`.)
The Andrews–Kasy selection model and the stem method are bundled locally under `andrews_kasy/`
and `stem_method/`, so no extra installation is needed for those.

## How to run it

From the repository root, run either of the following in R:

```r
source("replication_package/run_replication_package.R")
```

or from a shell:

```sh
Rscript replication_package/run_replication_package.R
```

## Inputs

- `Data.xlsx`: packaged copy of the canonical workbook used by this distribution script.
- `stem_method/`: local copy of the stem-method implementation used for Table 2.
- `andrews_kasy/`: local copy of the selection-model implementation used for Table 2.

## Outputs

The script rewrites the replication-package outputs in:

- `replication_package/tables/`
- `replication_package/figures/`

Main artifacts created by the script:

- `table_1_summary_statistics.csv`
- `table_a2_summary_by_country.csv`
- `table_2_publication_bias.csv`
- `table_4_heterogeneity.csv`
- `table_5_bpe.csv`
- `table_b1_variable_description.csv`
- `figure_1_estimates_by_study.pdf`
- `figure_2_funnel_plot.pdf`
- `figure_3_bma_inclusion.pdf`
- `figure_a1_trend.pdf`
- `figure_a3_estimates_by_country.pdf`

## Notes

- The script validates the expected sample sizes before producing outputs.
- Table B2 and Table B3 robustness runs remain present but commented out because they are slow in the distributed package.
- The main driver script is organized in numbered sections so each table/figure block can be located quickly.
