rm(list=ls())

library("data.table")
library("BMS")
library("openxlsx")
library("RStata")
library("stargazer")
library("readstata13")
library("foreign")
library("ggplot2")
library("reshape2")
library("corrplot")
library("installr")
library("puniform")
library("metafor")
library("dmetar")
library("haven")
library("tidyverse")
library("meta")
library("xtable")
library("LowRankQP")


#Set directory
setwd("C:/Users/")


############################################################
## P-UNIFORM*
############################################################

data 	<- read_dta("pcurve_med.dta")
puni_star(yi = data$frischwinmed, vi = data$variancemed, side="right", method="ML",alpha = 0.05, control=list(tol=0.001,reps=10000, int=c(0,2), verbose=TRUE))
data 	<- read_dta("pcurve_med_quasi.dta")
puni_star(yi = data$frischwinmed, vi = data$variancemed, side="right", method="ML",alpha = 0.05, control=list(tol=0.001,reps=10000, int=c(0,2), verbose=TRUE))
data 	<- read_dta("pcurve_med_inv.dta")
puni_star(yi = data$frischwinmed, vi = data$variancemed, side="right", method="ML",alpha = 0.05, control=list(tol=0.001,reps=10000, int=c(0,2), verbose=TRUE))
data 	<- read_dta("pcurve_med_quasi_inv.dta")
puni_star(yi = data$frischwinmed, vi = data$variancemed, side="right", method="ML",alpha = 0.05, control=list(tol=0.001,reps=10000, int=c(0,2), verbose=TRUE))
data 	<- read_dta("pcurve_med_ftest_inv.dta")
puni_star(yi = data$frischwinmed, vi = data$variancemed, side="right", method="ML",alpha = 0.05, control=list(tol=0.001,reps=10000, int=c(0,2), verbose=TRUE))


############################################################
## DATA PREPARATION
############################################################

# Loading data 
data_ext		= read.dta13("bma_ext.dta")
data_int		= read.dta13("bma_int.dta")

# Columns' names
colnames(data_ext)	<- c("ID","Frisch", "Standard error", "Prime age","Near retirement", "Females only", "Males only", "Married", "Single", "Time span", "Monthly", "Quarterly", "Ratio", "Industry", "Macro", "USA","Indivisible labor",  "Quasi-experimental", "Probit", "Non-parametric", "IV", "Publication year", "Top journal","Citations", "Byproduct")
colnames(data_int)  	<- c("ID","Frisch", "Standard error", "Prime age","Near retirement", "Females only", "Males only", "Married", "Single", "Time span", "Monthly", "Quarterly", "Ratio", "Industry", "Macro", "USA","Indivisible labor",  "Quasi-experimental", "Non-parametric", "IV", "Publication year", "Top journal","Citations", "Byproduct")

# Specifying the datasets
keeps_ext 			<- c("Frisch", "Standard error", "Prime age","Near retirement", "Females only", "Males only", "Married", "Single", "Time span", "Monthly", "Quarterly", "Ratio", "Industry", "Macro", "USA","Indivisible labor",  "Quasi-experimental", "Probit", "Non-parametric", "IV", "Publication year", "Top journal","Citations", "Byproduct")
keeps_int 			<- c("Frisch", "Standard error", "Prime age","Near retirement", "Females only", "Males only", "Married", "Single", "Time span", "Monthly", "Quarterly", "Industry", "Macro", "USA", "Quasi-experimental", "IV", "Publication year", "Top journal","Citations", "Byproduct")

df_ext 			<- data_ext[keeps_ext]
df_int 			<- data_int[keeps_int]


############################################################
## Stem-based method - Furukawa 2019
############################################################

source("stem_method.R") #https://github.com/Chishio318/stem-based_method

secomb    <- data_ext[1:3]
# data = read.table("clipboard-512", sep="\t", header=TRUE)
# mcomb<-aggregate(cbind(data$frisch_win, data$se_comb_win), by=list(ID=data$idstudy), median)
		
# Median values for the sample with combined standard errors 
mcomb<-aggregate(cbind(secomb$Frisch, secomb$`Standard error`), by=list(ID=secomb$ID), median)
colnames(mcomb) <- c("id","mefr","mese")

# Stem
stem_comb <- stem(mcomb$mefr, mcomb$mese, param)
funnel_comb <- stem_funnel(mcomb$mefr, mcomb$mese, stem_comb$estimates)
View(stem_comb$estimates)

############################################################
## MODEL AVERAGING -- EXTENSIVE MARGIN
############################################################

##Parameters for in-sample estimation
burn_       = 1e6
iter_       = 3e6
gprior      = "UIP"
modelprior  = "uniform"
order_PIP   = F
separator   = ","


## Correlation matrix for data with re-sampling 
cormatd<-round(cor(subset(df_ext, select= -Frisch)),3)
cormatd[upper.tri(cormatd)] <- NA
pdf("matrix_ext.pdf")
cor1<-corrplot(cormatd,method = "color", tl.col = "black", tl.cex=0.7, cl.cex=0.7,
               col = colorRampPalette(c("red","white","#124978"))(100), 
               number.digits = 2, number.cex = 0.5, addCoef.col = "black", type= "lower", tl.srt=45)
dev.off()

############################################################
## BMA UIP and dilution 
BMA_dilut = bms(df_ext, burn=1e6,iter=3e6, g="UIP", mprior="dilut", nmodel=10000, mcmc="bd", user.int=FALSE)
BMA_dilbase<-coef(BMA_dilut,std.coefs=F, order.by.pip = F, exact=T,include.constant = T)
write.table(BMA_dilbase,"BMA_dilut.csv",sep=separator)
summary(BMA_dilut)


#saving plots
pdf("bma_dilut.pdf")
image(BMA_dilut, cex=0.7, xlab="", main="", col=c("red","#124978"))
dev.off()

pdf("bma_dilut_pmp.pdf")
plot(BMA_dilut, col=c("red","#124978"))
dev.off()

############################################################
## BMA BRIC and Random 

BMA_bric  = bms(df_ext, burn=burn_,iter=iter_, g="BRIC", mprior="random", nmodel=10000, mcmc="bd", user.int=FALSE)
BMA_bricbase<-coef(BMA_bric ,std.coefs=F, order.by.pip = order_PIP, exact=F,include.constant = T)
write.table(BMA_bricbase,"BMA_bric.csv",sep=separator)
summary(BMA_bric)


#saving plots
pdf("bma_bric.pdf")
image(BMA_bric, cex=0.7, xlab="", main="", col=c("red","#124978"))
dev.off()

pdf("bma_bric_pmp.pdf")
plot(BMA_bric, col=c("red","#124978"))
dev.off()

############################################################
## BMA HQ and Random 

BMA_hyper  = bms(df_ext, burn=burn_,iter=iter_, g="HQ", mprior="random", nmodel=10000, mcmc="bd", user.int=FALSE)
BMA_hyperbase<-coef(BMA_hyper ,std.coefs=F, order.by.pip = order_PIP, exact=F,include.constant = T)
write.table(BMA_hyperbase,"BMA_hyper.csv",sep=separator)
summary(BMA_hyper)


#saving plots
pdf("bma_hq.pdf")
image(BMA_hyper, cex=0.7, xlab="", main="", col=c("red","#124978"))
dev.off()

pdf("bma_hq_pmp.pdf")
plot(BMA_hyper, col=c("red","#124978"))
dev.off()

############################################################
## BMA PIPs across different priors

pdf("pips_across_priors_ext.pdf")
plotComp("UIP and Dilution"=BMA_dilut,"BRIC and Random"=BMA_bric,"HQ and Random"=BMA_hyper, add.grid=F, cex.xaxis=0.8)
dev.off()

############################################################
## FMA

mydata <- df_ext
#mydata = read.table("clipboard-512", sep="\t", header=TRUE)
#deleting missing observations
mydata <-na.omit(mydata)
x.data <- mydata[,-1]

#adding constant
const_<-c(1)
x.data <-cbind(const_,x.data)


x <- sapply(1:ncol(x.data),function(i){x.data[,i]/max(x.data[,i])})   
scale.vector <- as.matrix(sapply(1:ncol(x.data),function(i){max(x.data[,i])}))        
Y <- as.matrix(mydata[,1])
output.colnames <- colnames(x.data)
full.fit <- lm(Y~x-1)
beta.full <- as.matrix(coef(full.fit))
M <- k <- ncol(x)
n <- nrow(x)
beta <- matrix(0,k,M)
e <- matrix(0,n,M)
K_vector <- matrix(c(1:M))
var.matrix <- matrix(0,k,M)
bias.sq <- matrix(0,k,M)             


# MMA Estimator using orthogonalization 
for(i in 1:M)
{
  X <- as.matrix(x[,1:i])
  ortho <- eigen(t(X)%*%X)
  Q <- ortho$vectors ; lambda <- ortho$values 
  x.tilda <- X%*%Q%*%(diag(lambda^-0.5,i,i))
  beta.star <- t(x.tilda)%*%Y
  beta.hat <- Q%*%diag(lambda^-0.5,i,i)%*%beta.star
  beta[1:i,i] <- beta.hat
  e[,i] <- Y-x.tilda%*%as.matrix(beta.star)
  bias.sq[,i] <- (beta[,i]-beta.full)^2
  var.matrix.star <- diag(as.numeric(((t(e[,i])%*%e[,i])/(n-i))),i,i)
  var.matrix.hat <- var.matrix.star%*%(Q%*%diag(lambda^-1,i,i)%*%t(Q))
  var.matrix[1:i,i] <- diag(var.matrix.hat)
  var.matrix[,i] <- var.matrix[,i]+ bias.sq[,i]
} # End loop over i

e_k <- e[,M]
sigma_hat <- as.numeric((t(e_k)%*%e_k)/(n-M))
G <- t(e)%*%e
a <- ((sigma_hat)^2)*K_vector
A <- matrix(1,1,M)
b <- matrix(1,1,1)
u <- matrix(1,M,1)
optim <- LowRankQP(Vmat=G,dvec=a,Amat=A,bvec=b,uvec=u,method="LU",verbose=TRUE)
weights <- as.matrix(optim$alpha)
beta.scaled <- beta%*%weights
final.beta <- beta.scaled/scale.vector
std.scaled <- sqrt(var.matrix)%*%weights
final.std <- std.scaled/scale.vector
results.reduced <- as.matrix(cbind(final.beta,final.std))
rownames(results.reduced) <- output.colnames; colnames(results.reduced) <- c("Coefficient", "Sd. Err")
#MMA.fls <- round(results.reduced,4)[-1,]
MMA.fls <- round(results.reduced,4)
list(MMA.fls)


MMA.fls <- data.frame(MMA.fls)
t <- as.data.frame(MMA.fls$Coefficient/MMA.fls$Sd..Err)
MMA.fls$pv <-round( (1-apply(as.data.frame(apply(t,1,abs)), 1, pnorm))*2,3)
MMA.fls$names <- rownames(MMA.fls)
names <- c(colnames(mydata))
names <- c(names,"const_")
MMA.fls <- MMA.fls[match(names, MMA.fls$names),]
MMA.fls$names <- NULL
MMA.fls


library(xtable)
xtable(MMA.fls,digits=c(0,3,3,3))

separator   = ";"
write.table(MMA.fls,"FMA_ext.csv",sep=separator, append = FALSE)


############################################################
## MODEL AVERAGING -- INTENSIVE MARGIN
############################################################

##Parameters for in-sample estimation
burn_       = 1e6
iter_       = 3e6
gprior      = "UIP"
modelprior  = "uniform"
order_PIP   = F
separator   = ","


## Correlation matrix for data with re-sampling 
cormatd<-round(cor(subset(df_int, select= -Frisch)),3)
cormatd[upper.tri(cormatd)] <- NA
pdf("matrix_int.pdf")
cor1<-corrplot(cormatd,method = "color", tl.col = "black", tl.cex=0.7, cl.cex=0.7,
               col = colorRampPalette(c("red","white","#124978"))(100),
               number.digits = 2, number.cex = 0.5, addCoef.col = "black", type= "lower", tl.srt=45)
dev.off()


############################################################
## BMA UIP and dilution 

BMA_dilut_int = bms(df_int, burn=1e6,iter=3e6, g="UIP", mprior="dilut", nmodel=10000, mcmc="bd", user.int=FALSE)
BMA_dilintbase<-coef(BMA_dilut_int,std.coefs=F, order.by.pip = F, exact=T,include.constant = T)
write.table(BMA_dilintbase,"BMA_dilut_int.csv",sep=separator)
summary(BMA_dilut_int)


#saving plots
pdf("bma_dilut_int.pdf")
image(BMA_dilut_int, cex=0.8, xlab="", main="", col=c("red","#124978"))
dev.off()

pdf("bma_dilut_int_pmp.pdf")
plot(BMA_dilut_int, col=c("red","#124978"))
dev.off()

############################################################
## BMA BRIC and Random 

BMA_bric_int  = bms(df_int, burn=burn_,iter=iter_, g="BRIC", mprior="random", nmodel=10000, mcmc="bd", user.int=FALSE)
BMA_bric_intbase<-coef(BMA_bric_int ,std.coefs=F, order.by.pip = F, exact=F,include.constant = T)
write.table(BMA_bric_intbase,"BMA_bric_int.csv",sep=separator)
image(BMA_bric_int , cex=0.7, xlab="", main="")
summary(BMA_bric_int)


#saving plots
pdf("bma_bric_int.pdf")
image(BMA_bric_int, cex=0.8, xlab="", main="", col=c("red","#124978"))
dev.off()

pdf("bma_bric_int_pmp.pdf")
plot(BMA_bric_int, col=c("red","#124978"))
dev.off()

############################################################
## BMA HQ and Random 

BMA_hyper_int  = bms(df_int, burn=burn_,iter=iter_, g="HQ", mprior="random", nmodel=10000, mcmc="bd", user.int=FALSE)
BMA_hyper_intbase<-coef(BMA_hyper_int ,std.coefs=F, order.by.pip = F, exact=F,include.constant = T)
write.table(BMA_hyper_intbase,"BMA_hyper_int.csv",sep=separator)
summary(BMA_hyper_int)


#saving plots
pdf("bma_hyper_int.pdf")
image(BMA_hyper_int, cex=0.8, xlab="", main="", col=c("red","#124978"))
dev.off()

pdf("bma_hyper_pmp_int.pdf")
plot(BMA_hyper_int, col=c("red","#124978"))
dev.off()

############################################################
## BMA PIPs across different priors

pdf("pips_across_priors_int.pdf")
plotComp("UIP and Dilution"=BMA_dilut_int,"BRIC and Random"=BMA_bric_int,"HQ and Random"=BMA_hyper_int, add.grid=F, cex.xaxis=0.8)
dev.off()


############################################################
## FMA

mydata <- df_int
#mydata = read.table("clipboard-512", sep="\t", header=TRUE)
#deleting missing observations
mydata <-na.omit(mydata)
x.data <- mydata[,-1]

#adding constant
const_<-c(1)
x.data <-cbind(const_,x.data)


x <- sapply(1:ncol(x.data),function(i){x.data[,i]/max(x.data[,i])})   
scale.vector <- as.matrix(sapply(1:ncol(x.data),function(i){max(x.data[,i])}))        
Y <- as.matrix(mydata[,1])
output.colnames <- colnames(x.data)
full.fit <- lm(Y~x-1)
beta.full <- as.matrix(coef(full.fit))
M <- k <- ncol(x)
n <- nrow(x)
beta <- matrix(0,k,M)
e <- matrix(0,n,M)
K_vector <- matrix(c(1:M))
var.matrix <- matrix(0,k,M)
bias.sq <- matrix(0,k,M)             


# MMA Estimator using orthogonalization 
for(i in 1:M)
{
  X <- as.matrix(x[,1:i])
  ortho <- eigen(t(X)%*%X)
  Q <- ortho$vectors ; lambda <- ortho$values 
  x.tilda <- X%*%Q%*%(diag(lambda^-0.5,i,i))
  beta.star <- t(x.tilda)%*%Y
  beta.hat <- Q%*%diag(lambda^-0.5,i,i)%*%beta.star
  beta[1:i,i] <- beta.hat
  e[,i] <- Y-x.tilda%*%as.matrix(beta.star)
  bias.sq[,i] <- (beta[,i]-beta.full)^2
  var.matrix.star <- diag(as.numeric(((t(e[,i])%*%e[,i])/(n-i))),i,i)
  var.matrix.hat <- var.matrix.star%*%(Q%*%diag(lambda^-1,i,i)%*%t(Q))
  var.matrix[1:i,i] <- diag(var.matrix.hat)
  var.matrix[,i] <- var.matrix[,i]+ bias.sq[,i]
} # End loop over i

e_k <- e[,M]
sigma_hat <- as.numeric((t(e_k)%*%e_k)/(n-M))
G <- t(e)%*%e
a <- ((sigma_hat)^2)*K_vector
A <- matrix(1,1,M)
b <- matrix(1,1,1)
u <- matrix(1,M,1)
optim <- LowRankQP(Vmat=G,dvec=a,Amat=A,bvec=b,uvec=u,method="LU",verbose=TRUE)
weights <- as.matrix(optim$alpha)
beta.scaled <- beta%*%weights
final.beta <- beta.scaled/scale.vector
std.scaled <- sqrt(var.matrix)%*%weights
final.std <- std.scaled/scale.vector
results.reduced <- as.matrix(cbind(final.beta,final.std))
rownames(results.reduced) <- output.colnames; colnames(results.reduced) <- c("Coefficient", "Sd. Err")
#MMA.fls <- round(results.reduced,4)[-1,]
MMA.fls <- round(results.reduced,4)
list(MMA.fls)


MMA.fls <- data.frame(MMA.fls)
t <- as.data.frame(MMA.fls$Coefficient/MMA.fls$Sd..Err)
MMA.fls$pv <-round( (1-apply(as.data.frame(apply(t,1,abs)), 1, pnorm))*2,3)
MMA.fls$names <- rownames(MMA.fls)
names <- c(colnames(mydata))
names <- c(names,"const_")
MMA.fls <- MMA.fls[match(names, MMA.fls$names),]
MMA.fls$names <- NULL
MMA.fls


library(xtable)
xtable(MMA.fls,digits=c(0,3,3,3))

separator   = ";"
write.table(MMA.fls,"FMA_int.csv",sep=separator, append = FALSE)


######## End of Code ----------
