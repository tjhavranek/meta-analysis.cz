********************************************************************************
********************************************************************************
********************************************************************************
********************************************************************************
*Frisch Elasticity of Labor Supply at the Extensive Margin
********************************************************************************
********************************************************************************
********************************************************************************
********************************************************************************

log using frisch.log, replace
*set more off

*ssc install ivreg2, replace
*ssc install estout
*ssc install winsor2
*ssc install ranktest
*ssc install outreg2
*ssc install boottest

********************************************************************************
* Re-sampling stderrors - BOOTSTRAPPING
********************************************************************************
import excel data_extensive.xlsx, sheet("data") firstrow
generate frisch_boot = frisch
save frisch_data_boot.dta, replace

summarize idstudy
local boots = r(max)
*local boots = 2
local reps = 1000

***generating blank dataset for storage
clear
set obs `boots'
generate idstudy = .
generate store_means = .
generate original_means = .
generate store_stdevs = .

*making output quietly
quietly{
	*bootstrapping for each study in the panel
	forvalues i = 1(1) `boots' {
		*preserving generated storage dataset
		preserve
		
		use frisch_boot idstudy using frisch_data_boot.dta, clear
		
		*adding counter and display noisily
		if floor((`i'-1)/1) == (`i'-1)/1 {
			noisily display "Working on `i' out of `boots' at $S_TIME"
		}
		*keep the data for i-th study only
		keep if idstudy==`i'
		
		*storing mean coefficient of original data
		summarize frisch_boot
		local mean_frisch_orig = r(mean)
	
		*tempfile boot_study_`i'

		*actual bootstrapping
		*bsample
		bootstrap mean=r(mean), reps(`reps') strata(idstudy) seed(1234) saving(boot_study_`i', replace): summarize frisch_boot, detail
		*estat bootstrap, all
		*so the problem is that the bootstrapped command does not pass the stored result from r(mean)-probably it even does not do so...		
		use boot_study_`i', replace
		summarize mean
		*storing into local macro
		local mean_frisch = r(mean)
		local mean_frisch_sd = r(sd)		
		
		*restoring generated storage dataset
		restore
		
		replace idstudy = `i' in `i'
		
		display "replacing store_means = `mean_frisch' in `i'"	
		replace store_means = `mean_frisch' in `i'
		display "replacing original_means = `mean_frisch_orig' in `i'"
		replace original_means = `mean_frisch_orig' in `i'
		display "replacing store_stdevs = `mean_frisch_sd' in `i'"
		replace store_stdevs = `mean_frisch_sd' in `i'
			erase boot_study_`i'.dta
	}
}
*saving bootstrapped results
save boot_results.dta, replace
*merge and store
use frisch_data_boot.dta, replace
merge m:1 idstudy using boot_results.dta

drop _merge store_means frisch_boot
rename original_means study_mean
rename store_stdevs study_se
quietly: destring, replace

save frisch_data_boot.dta, replace

use frisch_data_boot.dta, replace

********************************************************************************
*VARIABLES 
********************************************************************************
gen nusa=.
replace nusa=1 if usa==0
replace nusa=0 if usa==1

*Generating new variables from original SEs
replace se=0.001 if se==0 
gen prec = 1/se
gen prec2 = 1/(se*se)
gen lnprec = ln(prec)
gen tstat = frisch/se
gen invperstudy = 1/est_per_study
gen lnpubyear = ln(pub_year_dif)
gen invobs = 1/no_obs
gen invsqrtnobs = 1/sqrt(no_obs)
gen sqrtnobs = sqrt(no_obs)

*Winsorizing original variables
winsor2 frisch se, suffix(_win) cuts(5 95) label
winsor2 invsqrtnobs, suffix(_win) cuts(5 95) label
gen tstat_win = frisch_win/se_win
gen prec_win = 1/se_win
gen prec2_win = 1/(se_win*se_win)

*Combining bootstrapped and reported sandard errors
gen se_comb = .
replace se_comb = se if se != .
replace se_comb = study_se if se == .

*Generating variables from combined SEs
replace se_comb=0.001 if se_comb==0 
gen prec_comb = 1/se_comb
gen prec2_comb = 1/(se_comb*se_comb)
gen tstat_comb = frisch/se_comb
gen lnprec_comb = ln(prec_comb)

*Winsorizing variables from combined SEs
winsor2 se_comb, suffix(_win) cuts(5 95) label
gen se2_comb_win = se_comb_win*se_comb_win
gen tstat_comb_win = frisch_win/se_comb_win
gen prec_comb_win = 1/se_comb_win
gen prec2_comb_win = 1/(se_comb_win*se_comb_win)

********************************************************************************
* SUMMARY STATISTICS 
********************************************************************************
sum frisch_win se_comb_win frisch se_comb prime nearretirement female male married single ln_timespan monthly quarterly ratio_wage industry macro usa indivlab quasi probit nonpar_sim sls_iv lnpubyear top lnycite byproduct
sum frisch_win se_comb_win frisch se_comb prime nearretirement female male married single ln_timespan monthly quarterly ratio_wage industry macro usa indivlab quasi probit nonpar_sim sls_iv lnpubyear top lnycite byproduct [aweight=invperstudy]

sum frisch, detail
return list
gen fmean = r(mean)
gen fmed= r(p50)
gen ftest_se_comb_win = ftest*se_comb_win

sum frisch frisch_win se se_win se_comb_win se_comb

*female > male
sum frisch if male==1
gen mamean = r(mean)
sum frisch if female==1
gen femean = r(mean)
sum frisch if female==0 & male==0 
sum frisch if malefemale==1

*quasi exp < other micro
sum frisch if quasi_exp==1
gen quasmean = r(mean)
sum frisch if quasi_exp==0 & micro==1
gen nquasmean = r(mean)

*macro > micro
sum frisch if macro==1
gen macmean = r(mean) 
sum frisch if micro==1
gen micmean = r(mean) 

*prime-age and near to retirment groups
sum frisch if prime==1
gen prmean= r(mean)
sum frisch if nearretirement==1
gen nrmean= r(mean)
sum frisch if  prime==0 & nearretirement==0
gen almean= r(mean)
sum frisch if prime==0
gen nprmean = r(mean)

********************************************************************************
*Plots and graphs
********************************************************************************

*Histogram of all estimated elasticities 
local m1 = fmean
local m2 = fmed
hist frisch if  frisch >-1 & frisch <3, width(0.1) xlabel(-1(1)3) start(-1) fcolor(gs13) lcolor(navy) width(0.1)  frequency xtitle("Estimated elasticity (extensive margin)")  ///
xlabel(, format(%9.1f)) saving(histogram_ext, replace) graphregion(color(white)) legend(off) /// 
addplot (scatteri 0 `m1' 150 `m1', color (black) c(1) m(i) || scatteri 0 `m2' 150 `m2', color (black) lpattern(dash) c(1) m(i) || scatteri  150 `m1' (3) "0.48", mlabcolor (black) msymbol(none)  || scatteri 150 `m2' (9) "0.35", mlabcolor (black) msymbol(none)) 
*saving plot
graph use histogram_ext
graph export histogram_ext.pdf, replace

*Histogram comparing male and female esimates
local m1 = mamean
local m2 = femean
twoway (hist frisch if male==1 & frisch<3 & frisch>-1, freq barwidth(0.15) color(gs12) xtitle("Estimated elasticity (extensive margin)") ytitle("Frequency"))  ///
(hist frisch if female==1  & frisch<3 & frisch>-1, freq barwidth(0.15) color(navy)) (scatteri 0 `m2' 80 `m2', color (black) c(1) m(i)) (scatteri 0 `m1' 80 `m1', color (black) lpattern(dash) c(1) m(i))(scatteri  80 `m1' (9) "0.40", mlabcolor (black) msymbol(none)) (scatteri 80 `m2' (3) "0.54", mlabcolor (black) msymbol(none)),  ///
xlabel(, format(%9.0f)) xlab(-1 0 1 2 3 , nogrid) graphregion(color(white)) legend(order(1 "Male" 2 "Female")) saving(hist_mafemean_ext, replace)
*saving plot
graph use hist_mafemean_ext
graph export hist_mafemean_ext.pdf, replace


*Histogram comparing micro and macro estimates
local m1 = micmean
local m2 = macmean
twoway (hist frisch if micro==1  & frisch<3 & frisch>-1, freq barwidth(0.12) color(gs12)  xtitle("Estimated elasticity (extensive margin)") ytitle("Frequency")) ///
(hist frisch if macro==1 & frisch<3 & frisch>-1, freq barwidth(0.15) color(navy)) (scatteri 0 `m2' 150 `m2', color (black) c(1) m(i)) (scatteri 0 `m1' 150 `m1', color (black) lpattern(dash) c(1) m(i)) (scatteri  150 `m1' (9) "0.40", mlabcolor (black) msymbol(none)) (scatteri 150 `m2' (3) "0.71", mlabcolor (black) msymbol(none)), ///
 xlabel(, format(%9.0f)) xlab(-1 0 1 2 3 , nogrid) graphregion(color(white)) legend(order(1 "Micro" 2 "Macro")) saving(hist_micmac_ext, replace)
*saving plot
graph use hist_micmac_ext
graph export hist_micmac_ext.pdf, replace

*Histogram comparing quasi-experimental and other micro estimates
local m1 = nquasmean
local m2 = quasmean
twoway (hist frisch if quasi_exp==0 & micro==1 & frisch<3 & frisch>-1, freq barwidth(0.11) color(navy) xtitle("Estimated elasticity (extensive margin)") ytitle("Frequency")) ///
(hist frisch if quasi_exp==1 & micro==1 & frisch<3 & frisch>-1, freq barwidth(0.13) color(gs12))(scatteri 0 `m1' 150 `m1', color (black)  c(1) m(i)) (scatteri 0 `m2' 150 `m2', color (black) lpattern(dash) c(1) m(i)) (scatteri  150 `m1' (3) "0.51", mlabcolor (black) msymbol(none)) (scatteri 150 `m2' (9) "0.21",  mlabcolor (black) msymbol(none)), ///
xlabel(, format(%9.0f)) xlab(-1 0 1 2 3 , nogrid) graphregion(color(white)) legend(order(2 "Quasi-experiment" 1 "Micro non quasi-experiment")) saving(hist_quasi_ext, replace)
*saving plot
graph use hist_quasi_ext
graph export hist_quasi_ext.pdf, replace

*Histogram comparing prime age and near-retirement estimates
local m1 = nrmean
local m2 = prmean
twoway (hist frisch if prime==1 & frisch<2 & frisch>-1, freq barwidth(0.15) color(gs12) xtitle("Estimated elasticity (extensive margin)") ytitle("Frequency")) ///
(hist frisch if nearretirement==1 & frisch<3 & frisch>-1, freq  barwidth(0.15) color(navy))(scatteri 0 `m1' 50 `m1', color (black)  c(1) m(i)) (scatteri 0 `m2' 50 `m2', color (black) lpattern(dash) c(1) m(i)) (scatteri  50 `m1' (3) "0.53", mlabcolor (black) msymbol(none)) (scatteri 50 `m2' (9) "0.34",  mlabcolor (black) msymbol(none)), ///
xlabel(, format(%9.0f)) xlab(-1 0 1 2 3 , nogrid) graphregion(color(white)) legend(order(1 "Prime age" 2 "Near retirement")) saving(hist_prime50_ext, replace)
*saving plot
graph use hist_prime50_ext
graph export hist_prime50_ext.pdf, replace

********************************************************************************
********************************************************************************
********************************PUBLICATION BIAS********************************
********************************************************************************
********************************************************************************

*Funnel plot of all estimates - Egger et al., 1997
scatter prec_comb frisch if prec<500,  xline(0, lpattern(dott) lcolor (gs10)) msize(*.6) msymbol(O)  xlabel(-2(1)4) ///
xtitle("Estimated elasticity (extensive margin)") ///
ytitle("Precision of the estimate (1/SE)") ///
legend(off) graphregion(color(white)) saving(funnel_ext, replace) 
*saving plot
graph use funnel_ext
graph export funnel_ext.pdf, replace

*t-stat plot
twoway histogram tstat_comb if tstat_comb <30 & tstat_comb>-5, freq width(0.46) lcolor(navy) fcolor(gs13) lstyle(thin) xtitle("t-statistics of the estimated elasticities (extensive margin)") ytitle("Frequency") xline(0, lcolor (gs12) lpattern(shortdash)) xline(0 1.96, lcolor(black)) xlabel(-5 0 1.96 5 10 15 20 25 30) ylabel( ,glcolor(ltbluishgray)) graphregion(color(white))  legend(off) saving(caliper_ext, replace)
*saving plot
graph export caliper_ext.pdf, replace

********************************************************************************
*Publication bias: funnel assymmetry tests 
********************************************************************************
***PET tests: OLS, FE, Precision, Study, IV

*whole sample
xtset idstudy
eststo: ivreg2 frisch_win se_comb_win, cluster(idstudy)
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: xtreg frisch_win se_comb_win, fe
eststo: ivreg2 frisch_win se_comb_win [pweight=prec_comb_win], cluster(idstudy)
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: ivreg2 frisch_win se_comb_win [pweight=invperstudy], cluster(idstudy)
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: ivreg2 frisch_win (se2_comb_win = invobs), cluster(idstudy)
		twostepweakiv 2sls frisch_win (se2_comb_win = invobs), cluster(idstudy)
ivreg2 frisch_win (se_comb_win=invsqrtnobs), cluster(idstudy)	
esttab using table_bias_ext.tex, replace se title(Linear funnel asymmetry tests - PET /// \
	\label{tab: PET}) mtitles("OLS" "FE" "Precision" "Study" "IV" ) /// \
	star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) /// \
	label nonumber width(1\\hsize)
eststo clear


*quasi-experimental subsample
eststo: ivreg2 frisch_win se_comb_win if quasi==1, cluster(idstudy)
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: xtreg frisch_win se_comb_win if quasi==1, fe
eststo: ivreg2 frisch_win se_comb_win [pweight=prec_comb_win] if quasi==1, cluster(idstudy)
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: ivreg2 frisch_win se_comb_win [pweight=invperstudy] if quasi==1, cluster(idstudy)
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: ivreg2 frisch_win (se_comb_win = invsqrtnobs) if quasi==1, cluster(idstudy)
		twostepweakiv 2sls frisch_win (se_comb_win = invsqrtnobs) if quasi==1, cluster(idstudy)
*MAIVE
ivreg2 frisch_win (se2_comb_win = invobs) if quasi==1, cluster(idstudy)
esttab using table_bias_ext-quasi.tex, replace se title(Linear funnel asymmetry tests - PET /// \
	\label{tab: PET}) mtitles("OLS" "FE" "Precision" "Study" "IV" ) /// \
	star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) /// \
	label nonumber width(1\\hsize)
eststo clear

ivreg2 frisch_win se_comb_win ftest_se_comb_win, robust

saveold frisch_data_boot2, replace

********************************************************************************
*Non-linear techniques - Publication bias
********************************************************************************
*drop if quasi==0
*drop if ftest<10 | ftest==.
*	Ioaninidis et al. 2017
summarize frisch_win [aweight=(prec_comb_win*prec_comb_win)] 
gen waapbound = abs(r(mean))/2.8
reg tstat_comb_win prec_comb_win if se < waapbound, noconstant cluster(idstudy)

*	Andrews & Kasy 2019
outsheet frisch_win se_comb_win idstudy using ak-secomb.csv, comma replace

*	Bom & Rachinger 2019
quietly {
clear 
insheet using "ak-secomb.csv", comma clear
rename frisch_win bs
rename se_comb_win sebs
gen ones=1
sum
local M=r(N)
sum sebs
local sebs_min=r(min)
local sebs_max=r(max)
gen sebs2=sebs^2
gen wis=ones/sebs2
gen bs_sebs=bs/sebs
gen ones_sebs=ones/sebs

gen bswis=bs*wis
sum wis
local wis_sum=r(sum)
* FAT-PET
regress bs_sebs ones_sebs ones,noc
local pet=_b[ones_sebs]
local t1_linreg = (_b[ones_sebs]/_se[ones_sebs])
local b_lin=_b[ones_sebs]
local Q1_lin = e(rss)
di `t1_linreg'
local abs_t1_linreg = abs(`t1_linreg')
di `abs_t1_linreg'
* PEESE
regress bs_sebs ones_sebs sebs,noc
local peese=_b[ones_sebs]
local b_sq=_b[ones_sebs]
local Q1_sq = e(rss)
di `Q1_sq'
* FAT-PET-PEESE
if `abs_t1_linreg' > invt(`M-2', 0.975) {
    local combreg=`b_sq'
	local Q1=`Q1_sq'
	}
else {
    local combreg=`b_lin'
	local Q1=`Q1_lin'
}
* estimation of random effects variance component
local sigh2hat=max(0,`M'*((`Q1'/(`M'-e(df_m)-1))-1)/`wis_sum') 
local sighhat=sqrt(`sigh2hat') 
* Cutoff value for EK
if `combreg'>1.96*`sighhat' {
    local a1=(`combreg'-1.96*`sighhat')*(`combreg'+1.96*`sighhat')/(2*1.96*`combreg')
}
else {
	local a1=0
	}
	rename bs bs_original
	rename bs_sebs bs
	rename ones_sebs constant
	rename ones pub_bias
    noisily: display "EK regression: "
if `a1'>`sebs_min' & `a1'<`sebs_max' {
    gen sebs_a1=sebs-`a1' if sebs>`a1'
	replace sebs_a1=0 if sebs<=`a1'
	gen pubbias=sebs_a1/sebs
	noisily regress bs constant pubbias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pubbias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pubbias]
}
else if `a1'<`sebs_min' {
    noisily regress bs constant pub_bias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pub_bias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pub_bias]
}
else if `a1'>`sebs_max' {
    noisily regress bs constant, noc
	local b0_ek=_b[constant]
	local sd0_ek=_se[constant]	
}
noisily: display "EK's mean effect estimate (alpha1) and standard error:"
noisily: di `b0_ek' 
noisily: di `sd0_ek' 
noisily: display "EK's publication bias estimate (delta) and standard error:"
noisily: di `b1_ek' 
noisily: di `sd1_ek' 
}
clear
********************************************************************************
* Publication bias - p-uniform* (van Aert & van Assen, 2019) - code for Stata & R
********************************************************************************
use frisch_data_boot2.dta, replace
*drop if quasi==0
*drop if ftest<10 | ftest==.
*generate median values
gen variance_comb_win = se_comb_win*se_comb_win
bysort idstudy: egen variancemed = median(variance_comb_win)
bysort idstudy: egen frischwinmed = median(frisch_win)
bysort idstudy: egen secomwinbmed = median(se_comb_win)
bysort idstudy: egen tstatcombwinmed = median(tstat_comb_win)

preserve
collapse  (lastnm) frischwinmed variancemed secomwinbmed tstatcombwinmed  (p50) nobs_med=no_obs, by(idstudy)
save "pcurve_med.dta", replace
restore
*save "pcurve_med_quasi.dta", replace
*save "pcurve_med_ftest.dta", replace

********************************************************************************
********************************************************************************
********************************HETEROGENEITY***********************************
********************************************************************************
********************************************************************************

*Data preparation for model averaging techniques in R

preserve
order idstudy frisch_win se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly ratio_wage industry  macro usa indivlab quasi_exp probit nonpar_sim sls_iv lnpubyear top lnycite byproduct
keep idstudy frisch_win se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly ratio_wage industry  macro usa indivlab quasi_exp probit nonpar_sim sls_iv lnpubyear top lnycite byproduct
saveold bma_base_comb, replace
restore

********************************************************************************
* Now switch to the R-PART OF THE CODE: BMA
********************************************************************************

*************************FREQUENTIST CHECK OF BMA*******************************
********************************************************************************

* SE combined - regressors with pip > 0.75
sum  se_comb_win prime male industry macro quasi_exp probit lnycite
correlate se_comb_win prime male industry macro quasi_exp probit lnycite
collin se_comb_win prime male industry macro quasi_exp probit lnycite

*UIP-dilution prior
reg frisch_win se_comb_win prime male industry macro quasi_exp probit lnycite, cluster(idstudy)
********************************************************************************
********************************************************************************
********************************BEST PRACTICE***********************************
********************************************************************************
********************************************************************************

sum frisch_win se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly ratio_wage industry macro usa indivlab quasi_exp probit nonpar_sim sls_iv lnpubyear top lnycite byproduct

local variables se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly ratio_wage industry macro usa indivlab quasi_exp probit nonpar_sim sls_iv lnpubyear top lnycite byproduct
foreach x of varlist `variables' {
sum  `x' 
local m`x' = r(mean)
local max`x' =r(max)
}
ivreg2 frisch_win se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly ratio_wage industry macro usa indivlab quasi_exp probit nonpar_sim sls_iv lnpubyear top lnycite byproduct, cluster(idstudy)

***Subjective best practice***

*baseline
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 0*female + 0*male + 0*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*ratio_wage + 0*industry + 0*macro + `musa'*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + `mlnpubyear'*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*nearretirement
lincom _cons + 0*se_comb_win + 0*prime + 1*nearretirement + 0*female + 0*male + 0*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*ratio_wage + 0*industry + 0*macro + `musa'*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + `mlnpubyear'*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*prime
lincom _cons + 0*se_comb_win + 1*prime + 0*nearretirement + 0*female + 0*male + 0*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*ratio_wage + 0*industry + 0*macro + `musa'*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + `mlnpubyear'*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*female
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 1*female + 0*male + 0*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*ratio_wage + 0*industry + 0*macro + `musa'*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + `mlnpubyear'*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*married female
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 1*female + 0*male + 1*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*ratio_wage + 0*industry + 0*macro + `musa'*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + `mlnpubyear'*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*single female
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 1*female + 0*male + 0*married + 1*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*ratio_wage + 0*industry + 0*macro + `musa'*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + `mlnpubyear'*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*male
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 0*female + 1*male + 0*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*ratio_wage + 0*industry + 0*macro + `musa'*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + `mlnpubyear'*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*married male
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 0*female + 1*male + 1*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*ratio_wage + 0*industry + 0*macro + `musa'*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + `mlnpubyear'*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*single male
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 0*female + 1*male + 0*married + 1*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*ratio_wage + 0*industry + 0*macro + `musa'*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + `mlnpubyear'*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct


***Martinez et al (2021)


*baseline
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 0*female + 0*male + 0*married + 0*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 1*ratio_wage + 0*industry + 0*macro + 0*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + 3.610918*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*nearretirement
lincom _cons + 0*se_comb_win + 0*prime + 1*nearretirement + 0*female + 0*male + 0*married + 0*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 1*ratio_wage + 0*industry + 0*macro + 0*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + 3.610918*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*prime
lincom _cons + 0*se_comb_win + 1*prime + 0*nearretirement + 0*female + 0*male + 0*married + 0*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 1*ratio_wage + 0*industry + 0*macro + 0*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + 3.610918*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*female
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 1*female + 0*male + 0*married + 0*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 1*ratio_wage + 0*industry + 0*macro + 0*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + 3.610918*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*married female
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 1*female + 0*male + 1*married + 0*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 1*ratio_wage + 0*industry + 0*macro + 0*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + 3.610918*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*single female
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 1*female + 0*male + 0*married + 1*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 1*ratio_wage + 0*industry + 0*macro + 0*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + 3.610918*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*male
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 0*female + 1*male + 0*married + 0*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 1*ratio_wage + 0*industry + 0*macro + 0*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + 3.610918*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*married male
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 0*female + 1*male + 1*married + 0*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 1*ratio_wage + 0*industry + 0*macro + 0*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + 3.610918*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct
*single male
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 0*female + 1*male + 0*married + 1*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 1*ratio_wage + 0*industry + 0*macro + 0*usa + 0*indivlab + 1*quasi_exp + 0*probit + 0*nonpar_sim + 1*sls_iv + 3.610918*lnpubyear +1*top + `mlnycite'*lnycite + 0*byproduct



clear
*log close	
*exit, clear

********************************************************************************
********************************************************************************
********************************************************************************
********************************************************************************
*Frisch Elasticity of Labor Supply at the Intensive Margin
********************************************************************************
********************************************************************************
********************************************************************************
********************************************************************************

********************************************************************************
* Re-sampling stderrors - BOOTSTRAPPING
********************************************************************************
import excel data_intensive.xlsx, sheet("data") firstrow
generate frisch_boot = frisch
save frisch_data_boot_int.dta, replace

summarize idstudy
local boots = r(max)
*local boots = 2
local reps = 1000

***generating blank dataset for storage
clear
set obs `boots'
generate idstudy = .
generate store_means = .
generate original_means = .
generate store_stdevs = .

*making output quietly
quietly{
	*bootstrapping for each study in the panel
	forvalues i = 1(1) `boots' {
		*preserving generated storage dataset
		preserve
		
		use frisch_boot idstudy using frisch_data_boot_int.dta, clear
		
		*adding counter and display noisily
		if floor((`i'-1)/1) == (`i'-1)/1 {
			noisily display "Working on `i' out of `boots' at $S_TIME"
		}
		*keep the data for i-th study only
		keep if idstudy==`i'
		
		*storing mean coefficient of original data
		summarize frisch_boot
		local mean_frisch_orig = r(mean)
	
		*tempfile boot_study_`i'

		*actual bootstrapping
		*bsample
		bootstrap mean=r(mean), reps(`reps') strata(idstudy) seed(1234) saving(boot_study_`i', replace): summarize frisch_boot, detail
		*estat bootstrap, all
		*so the problem is that the bootstrapped command does not pass the stored result from r(mean)-probably it even does not do so...		
		use boot_study_`i', replace
		summarize mean
		*storing into local macro
		local mean_frisch = r(mean)
		local mean_frisch_sd = r(sd)		
		
		*restoring generated storage dataset
		restore
		
		replace idstudy = `i' in `i'
		
		display "replacing store_means = `mean_frisch' in `i'"	
		replace store_means = `mean_frisch' in `i'
		display "replacing original_means = `mean_frisch_orig' in `i'"
		replace original_means = `mean_frisch_orig' in `i'
		display "replacing store_stdevs = `mean_frisch_sd' in `i'"
		replace store_stdevs = `mean_frisch_sd' in `i'
			erase boot_study_`i'.dta
	}
}
*saving bootstrapped results
save boot_results_int.dta, replace
*merge and store
use frisch_data_boot_int.dta, replace
merge m:1 idstudy using boot_results_int.dta

drop _merge store_means frisch_boot
rename original_means study_mean
rename store_stdevs study_se
quietly: destring, replace

save frisch_data_boot_int.dta, replace

use frisch_data_boot_int.dta, replace

********************************************************************************
*VARIABLES 
********************************************************************************
gen nusa=.
replace nusa=1 if usa==0
replace nusa=0 if usa==1

*Generating new variables from original SEs
replace se=0.001 if se==0 
gen prec = 1/se
gen prec2 = 1/(se*se)
gen lnprec = ln(prec)
gen invperstudy = 1/est_per_study
gen invobs = 1/obs
gen invsqrtnobs = 1/sqrt(obs)
gen sqrtnobs = sqrt(obs)

*Winsorizing original variables
winsor2 frisch se, suffix(_win) cuts(5 95) label
winsor2 invsqrtnobs sqrtnobs obs, suffix(_win) cuts(5 95) label
gen tstat_win = frisch_win/se_win
gen prec_win = 1/se_win
gen prec2_win = 1/(se_win*se_win)

*Combining bootstrapped and reported sandard errors
gen se_comb = .
replace se_comb = se if se != .
replace se_comb = study_se if se == .

*Generating variables from combined SEs
replace se_comb=0.001 if se_comb==0 
gen prec_comb = 1/se_comb
gen prec2_comb = 1/(se_comb*se_comb)
gen tstat_comb = frisch/se_comb
gen lnprec_comb = ln(prec_comb)

*Winsorizing variables from combined SEs
winsor2 se_comb, suffix(_win) cuts(5 95) label
gen se2_comb_win = se_comb_win*se_comb_win
gen tstat_comb_win = frisch_win/se_comb_win
gen prec_comb_win = 1/se_comb_win
gen prec2_comb_win = 1/(se_comb_win*se_comb_win)

********************************************************************************
* SUMMARY STATISTICS 
********************************************************************************
sum frisch_win se_comb_win frisch se_comb prime nearretirement female male married single ln_timespan monthly quarterly ratio_wage industry macro usa indivlab quasi nonpar_sim sls_iv lnpubyear top lnycite byproduct
sum frisch_win se_comb_win frisch se_comb prime nearretirement female male married single ln_timespan monthly quarterly ratio_wage industry macro usa indivlab quasi nonpar_sim sls_iv lnpubyear top lnycite byproduct [aweight=invperstudy]

sum frisch, detail
sum frisch_win, detail
return list
gen fmean = r(mean)
gen fmed= r(p50)
gen ftest_se_comb_win = ftest*se_comb_win

sum frisch frisch_win se se_win se_comb_win se_comb

*female > male
sum frisch if male==1
gen mamean = r(mean)
sum frisch if female==1
gen femean = r(mean)
sum frisch if female==0 & male==0 
sum frisch if malefemale==1

*quasi exp < others
sum frisch if quasi_exp==1 & micro==1
gen quasmean = r(mean)
sum frisch if quasi_exp==0 & micro==1
gen nquasmean = r(mean)

*macro > micro
sum frisch if macro==1
gen macmean = r(mean) 
sum frisch if micro==1
gen micmean = r(mean) 

*prime-age and near to retirment groups
sum frisch if prime==1
gen prmean= r(mean)
sum frisch if nearretirement==1
gen nrmean= r(mean)
sum frisch if  prime==0 & nearretirement==0
gen almean= r(mean)
sum frisch if prime==0
gen nprmean = r(mean)

********************************************************************************
*Plots and graphs
********************************************************************************

*Histogram of all estimated elasticities 
local m1 = fmean
local m2 = fmed
hist frisch if  frisch >-1 & frisch <3, width(0.1) xlabel(-1(1)3) start(-1) fcolor(gs13) lcolor(navy) width(0.1)  frequency xtitle("Estimated elasticity (intensive margin)")  ///
xlabel(, format(%9.1f)) saving(histogram_int, replace) graphregion(color(white)) legend(off) /// 
addplot (scatteri 0 `m1' 100 `m1', color (black) c(1) m(i) || scatteri 0 `m2' 100 `m2', color (black) lpattern(dash) c(1) m(i) || scatteri  100 `m1' (3) "0.49", mlabcolor (black) msymbol(none)  || scatteri 100 `m2' (9) "0.41", mlabcolor (black) msymbol(none)) 
*saving plot
graph use histogram_int
graph export histogram_int.pdf, replace


*Histogram comparing male and female esimates
local m1 = mamean
local m2 = femean
twoway (hist frisch if male==1 & frisch<3 & frisch>-1, freq barwidth(0.12) color(gs12) xtitle("Estimated elasticity (intensive margin)") ytitle("Frequency"))  ///
(hist frisch if female==1  & frisch<3 & frisch>-1, freq barwidth(0.10) color(navy)) (scatteri 0 `m2' 80 `m2', color (black) c(1) m(i)) (scatteri 0 `m1' 80 `m1', color (black) lpattern(dash) c(1) m(i))(scatteri  80 `m1' (9) "0.45", mlabcolor (black) msymbol(none)) (scatteri 80 `m2' (3) "0.60", mlabcolor (black) msymbol(none)),  ///
xlabel(, format(%9.0f)) xlab(-1 0 1 2 3 , nogrid) graphregion(color(white)) legend(order(1 "Male" 2 "Female")) saving(hist_mafemean_int, replace)
*saving plot
graph use hist_mafemean_int
graph export hist_mafemean_int.pdf, replace


*Histogram comparing micro and macro estimates
local m1 = micmean
local m2 = macmean
twoway (hist frisch if micro==1  & frisch<3 & frisch>-1, freq barwidth(0.11) color(gs12)  xtitle("Estimated elasticity (intensive margin)") ytitle("Frequency")) ///
(hist frisch if macro==1 & frisch<3 & frisch>-1, freq barwidth(0.14) color(navy)) (scatteri 0 `m2' 150 `m2', color (black) c(1) m(i)) (scatteri 0 `m1' 150 `m1', color (black) lpattern(dash) c(1) m(i)) (scatteri  150 `m1' (9) "0.44", mlabcolor (black) msymbol(none)) (scatteri 150 `m2' (3) "0.63", mlabcolor (black) msymbol(none)), ///
 xlabel(, format(%9.0f)) xlab(-1 0 1 2 3 , nogrid) graphregion(color(white)) legend(order(1 "Micro" 2 "Macro")) saving(hist_micmac_int, replace)
*saving plot
graph use hist_micmac_int
graph export hist_micmac_int.pdf, replace

*Histogram comparing micro quasi-experimental and other micro estimates
local m1 = nquasmean
local m2 = quasmean
twoway (hist frisch if quasi_exp==0 & micro==1 & frisch<3 & frisch>-1, freq barwidth(0.11) color(navy) xtitle("Estimated elasticity (intensive margin)") ytitle("Frequency")) ///
(hist frisch if quasi_exp==1 & micro==1 & frisch<3 & frisch>-1, freq barwidth(0.14) color(gs12))(scatteri 0 `m1' 150 `m1', color (black)  c(1) m(i)) (scatteri 0 `m2' 150 `m2', color (black) lpattern(dash) c(1) m(i)) (scatteri  150 `m1' (9) "0.31", mlabcolor (black) msymbol(none)) (scatteri 150 `m2' (3) "0.60",  mlabcolor (black) msymbol(none)), ///
xlabel(, format(%9.0f)) xlab(-1 0 1 2 3 , nogrid) graphregion(color(white)) legend(order(2 "Quasi-experiment" 1 "Micro non quasi-experiment")) saving(hist_quasi_int, replace)
*saving plot
graph use hist_quasi_int
graph export hist_quasi_int.pdf, replace

*Histogram comparing prime age and near-retirement estimates
local m1 = nrmean
local m2 = prmean
twoway (hist frisch if prime==1 & frisch<2 & frisch>-1, freq barwidth(0.11) color(gs12) xtitle("Estimated elasticity (intensive margin)") ytitle("Frequency")) ///
(hist frisch if nearretirement==1 & frisch<3 & frisch>-1, freq  barwidth(0.15) color(navy))(scatteri 0 `m1' 50 `m1', color (black)  c(1) m(i)) (scatteri 0 `m2' 50 `m2', color (black) lpattern(dash) c(1) m(i)) (scatteri  50 `m1' (3) "0.56", mlabcolor (black) msymbol(none)) (scatteri 50 `m2' (9) "0.48",  mlabcolor (black) msymbol(none)), ///
xlabel(, format(%9.0f)) xlab(-1 0 1 2 3 , nogrid) graphregion(color(white)) legend(order(1 "Prime age" 2 "Near retirement")) saving(hist_prime50_int, replace)
*saving plot
graph use hist_prime50_int
graph export hist_prime50_int.pdf, replace

saveold frisch_data_boot2_int, replace
********************************************************************************
********************************************************************************
********************************PUBLICATION BIAS********************************
********************************************************************************
********************************************************************************

*Funnel plot of all estimates - Egger et al., 1997
scatter prec_comb frisch if frisch<4 & frisch>-1 & prec_comb<350, xline(0, lpattern(dott) lcolor (gs10)) msize(*.6) msymbol(O) mcolor(navy) xlabel(-2(1)4) ///
xtitle("Estimated elasticity (intensive margin)") ///
ytitle("Precision of the estimate (1/SE)") ///
legend(off) graphregion(color(white)) saving(funnel_int, replace) 
*saving plot
graph use funnel_int
graph export funnel_int.pdf, replace

*t-stat plot
twoway histogram tstat_comb if tstat_comb <30 & tstat_comb>-5, freq width(0.4) lcolor(navy) fcolor(gs13) lstyle(thin) xtitle("t-statistics of the estimated elasticities (intensive margin)") ytitle("Frequency") xline(0, lcolor (gs12) lpattern(shortdash)) xline(0 1.96, lcolor(black)) xlabel(-5 0 1.96 5 10 15 20 25 30) ylabel( ,glcolor(ltbluishgray)) graphregion(color(white))  legend(off) saving(caliper_int, replace)
*saving plot
graph export caliper_int.pdf, replace

********************************************************************************
*Publication bias: funnel assymmetry tests 
********************************************************************************


***PET tests: OLS, FE, Precision, Study, IV

*whole sample
xtset idstudy
eststo: ivreg2 frisch_win se_comb_win, cluster(idstudy)
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: xtreg frisch_win se_comb_win, fe
eststo: ivreg2 frisch_win se_comb_win [pweight=prec_comb_win], cluster(idstudy)
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: ivreg2 frisch_win se_comb_win [pweight=invperstudy], cluster(idstudy)
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: ivreg2 frisch_win (se2_comb_win = sqrtnobs), cluster(idstudy)
		twostepweakiv 2sls frisch_win (se2_comb_win = sqrtnobs), cluster(idstudy)
esttab using table_bias_int.tex, replace se title(Linear funnel asymmetry tests - PET /// \
	\label{tab: PET}) mtitles("OLS" "FE" "Precision" "Study" "IV" ) /// \
	star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) /// \
	label nonumber width(1\\hsize)
eststo clear


*quasi-experimental subsample
xtset idstudy
eststo: ivreg2 frisch_win se_comb_win if quasi==1, cluster(idstudy)
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: xtreg frisch_win se_comb_win if quasi==1, fe 
eststo: ivreg2 frisch_win se_comb_win [pweight=prec_comb_win] if quasi==1, cluster(idstudy)
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: ivreg2 frisch_win se_comb_win [pweight=invperstudy] if quasi==1, cluster(idstudy)
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: ivreg2 frisch_win (se2_comb_win = sqrtnobs ) if quasi==1, cluster(idstudy)
		twostepweakiv 2sls frisch_win (se2_comb_win = sqrtnobs ) if quasi==1, cluster(idstudy)
esttab using table_bias_int-quasi.tex, replace se title(Linear funnel asymmetry tests - PET /// \
	\label{tab: PET}) mtitles("OLS" "FE" "Precision" "Study" "IV" ) /// \
	star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) /// \
	label nonumber width(1\\hsize)
eststo clear


*IV with F-test > 10 subsample
xtset idstudy
eststo: ivreg2 frisch_win se_comb_win if ftest>=10 & ftest!=., robust
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: xtreg frisch_win se_comb_win if ftest>10 & ftest!=., fe 
eststo: ivreg2 frisch_win se_comb_win [pweight=prec_comb_win] if ftest>10 & ftest!=., robust
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: ivreg2 frisch_win se_comb_win [pweight=invperstudy] if ftest>10 & ftest!=., robust
		boottest se_comb_win, nograph
		boottest _cons, nograph
eststo: ivreg2 frisch_win (se2_comb_win = sqrtnobs) if ftest>10 & ftest!=., robust
		twostepweakiv 2sls frisch_win (se2_comb_win = sqrtnobs) if ftest>10 & ftest!=., robust
esttab using table_bias_int-ftest.tex, replace se title(Linear funnel asymmetry tests - PET /// \
	\label{tab: PET}) mtitles("OLS" "FE" "Precision" "Study" "IV" ) /// \
	star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) /// \
	label nonumber width(1\\hsize)
eststo clear

ivreg2 frisch_win se_comb_win ftest_se_comb_win, robust

use frisch_data_boot2_int.dta, replace

********************************************************************************
*Non-linear techniques - Publication bias
********************************************************************************
*drop if quasi==0
*drop if ftest<10 | ftest==.
*	Ioaninidis et al. 2017
summarize frisch_win [aweight=(prec_comb_win*prec_comb_win)] 
gen waapbound = abs(r(mean))/2.8
reg tstat_comb_win prec_comb_win if se < waapbound, noconstant cluster(idstudy)

*	Andrews & Kasy 2019
outsheet frisch_win se_comb_win idstudy using ak-secomb_inv.csv, comma replace

*	Bom & Rachinger 2019
quietly {
clear 
insheet using "ak-secomb_inv.csv", comma clear
rename frisch_win bs
rename se_comb_win sebs
gen ones=1
sum
local M=r(N)
sum sebs
local sebs_min=r(min)
local sebs_max=r(max)
gen sebs2=sebs^2
gen wis=ones/sebs2
gen bs_sebs=bs/sebs
gen ones_sebs=ones/sebs

gen bswis=bs*wis
sum wis
local wis_sum=r(sum)
* FAT-PET
regress bs_sebs ones_sebs ones,noc
local pet=_b[ones_sebs]
local t1_linreg = (_b[ones_sebs]/_se[ones_sebs])
local b_lin=_b[ones_sebs]
local Q1_lin = e(rss)
di `t1_linreg'
local abs_t1_linreg = abs(`t1_linreg')
di `abs_t1_linreg'
* PEESE
regress bs_sebs ones_sebs sebs,noc
local peese=_b[ones_sebs]
local b_sq=_b[ones_sebs]
local Q1_sq = e(rss)
di `Q1_sq'
* FAT-PET-PEESE
if `abs_t1_linreg' > invt(`M-2', 0.975) {
    local combreg=`b_sq'
	local Q1=`Q1_sq'
	}
else {
    local combreg=`b_lin'
	local Q1=`Q1_lin'
}
* estimation of random effects variance component
local sigh2hat=max(0,`M'*((`Q1'/(`M'-e(df_m)-1))-1)/`wis_sum') 
local sighhat=sqrt(`sigh2hat') 
* Cutoff value for EK
if `combreg'>1.96*`sighhat' {
    local a1=(`combreg'-1.96*`sighhat')*(`combreg'+1.96*`sighhat')/(2*1.96*`combreg')
}
else {
	local a1=0
	}
	rename bs bs_original
	rename bs_sebs bs
	rename ones_sebs constant
	rename ones pub_bias
    noisily: display "EK regression: "
if `a1'>`sebs_min' & `a1'<`sebs_max' {
    gen sebs_a1=sebs-`a1' if sebs>`a1'
	replace sebs_a1=0 if sebs<=`a1'
	gen pubbias=sebs_a1/sebs
	noisily regress bs constant pubbias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pubbias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pubbias]
}
else if `a1'<`sebs_min' {
    noisily regress bs constant pub_bias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pub_bias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pub_bias]
}
else if `a1'>`sebs_max' {
    noisily regress bs constant, noc
	local b0_ek=_b[constant]
	local sd0_ek=_se[constant]	
}
noisily: display "EK's mean effect estimate (alpha1) and standard error:"
noisily: di `b0_ek' 
noisily: di `sd0_ek' 
noisily: display "EK's publication bias estimate (delta) and standard error:"
noisily: di `b1_ek' 
noisily: di `sd1_ek' 
}
clear
********************************************************************************
* Publication bias - p-uniform* (van Aert & van Assen, 2019) - code for Stata & R
********************************************************************************
use frisch_data_boot2_inv.dta, replace
*drop if quasi==0
*drop if ftest<10 | ftest==.
*generate median values
gen variance_comb_win = se_comb_win*se_comb_win
bysort idstudy: egen variancemed = median(variance_comb_win)
bysort idstudy: egen frischwinmed = median(frisch_win)
bysort idstudy: egen secomwinbmed = median(se_comb_win)
bysort idstudy: egen tstatcombwinmed = median(tstat_comb_win)

preserve
collapse  (lastnm) frischwinmed variancemed secomwinbmed tstatcombwinmed  (p50) nobs_med=obs, by(idstudy)
save "pcurve_med_inv.dta", replace
restore
*save "pcurve_med_quasi_inv.dta", replace
*save "pcurve_med_ftest_inv.dta", replace

********************************************************************************
********************************************************************************
********************************HETEROGENEITY***********************************
********************************************************************************
********************************************************************************

*Data preparation for model averaging techniques in R

preserve
order idstudy frisch_win se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly ratio_wage industry  macro usa indivlab quasi_exp nonpar_sim sls_iv lnpubyear top lnycite byproduct
keep idstudy frisch_win se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly ratio_wage industry  macro usa indivlab quasi_exp nonpar_sim sls_iv lnpubyear top lnycite byproduct
saveold bma_int, replace
restore

********************************************************************************
* Now switch to the R-PART OF THE CODE: BMA
********************************************************************************

*************************FREQUENTIST CHECK OF BMA*******************************
********************************************************************************
sum frisch_win se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly ratio_wage industry  macro usa indivlab quasi_exp nonpar_sim sls_iv lnpubyear top lnycite byproduct
correl se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly industry  macro usa quasi_exp sls_iv lnpubyear top lnycite byproduct
collin se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly industry  macro usa quasi_exp sls_iv lnpubyear top lnycite byproduct

ivreg2 frisch_win se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly industry  macro usa quasi_exp sls_iv lnpubyear top lnycite byproduct, cluster(idstudy)
stepwise, pr(.05): regress frisch_win se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly industry  macro usa quasi_exp sls_iv lnpubyear top lnycite byproduct, cluster(idstudy) 


* SE combined - regressors with pip > 0.75
sum se_comb_win prime female  ln_timespan monthly quarterly macro usa quasi_exp lnpubyear
correl se_comb_win prime female  ln_timespan monthly quarterly macro usa quasi_exp lnpubyear
collin se_comb_win prime female  ln_timespan monthly quarterly macro usa quasi_exp lnpubyear

ivreg2 frisch_win se_comb_win prime female  ln_timespan monthly quarterly macro usa quasi_exp lnpubyear, cluster(idstudy)
reg frisch_win se_comb_win prime female  ln_timespan monthly quarterly macro usa quasi_exp lnpubyear, cluster(idstudy)

********************************************************************************
********************************************************************************
********************************BEST PRACTICE***********************************
********************************************************************************
********************************************************************************

sum frisch_win se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly industry macro usa quasi_exp sls_iv lnpubyear top lnycite byproduct

local variables se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly industry macro usa quasi_exp sls_iv lnpubyear top lnycite byproduct
foreach x of varlist `variables' {
sum  `x' 
local m`x' = r(mean)
local max`x' =r(max)
}
ivreg2 frisch_win se_comb_win prime nearretirement female male married single ln_timespan  monthly quarterly industry macro usa quasi_exp sls_iv lnpubyear top lnycite byproduct, cluster(idstudy)

***Subjective best practice***

*baseline
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 0*female + 0*male + 0*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + `mlnpubyear'*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*nearretirement
lincom _cons + 0*se_comb_win + 0*prime + 1*nearretirement + 0*female + 0*male + 0*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + `mlnpubyear'*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*prime
lincom _cons + 0*se_comb_win + 1*prime + 0*nearretirement + 0*female + 0*male + 0*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + `mlnpubyear'*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*female
lincom _cons + 0*se_comb_win + 1*prime + 0*nearretirement + 1*female + 0*male + 0*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + `mlnpubyear'*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*married female
lincom _cons + 0*se_comb_win + 1*prime + 0*nearretirement + 1*female + 0*male + 1*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + `mlnpubyear'*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*single female
lincom _cons + 0*se_comb_win + 1*prime + 0*nearretirement + 1*female + 0*male + 1*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + `mlnpubyear'*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*male
lincom _cons + 0*se_comb_win + 1*prime + 0*nearretirement + 0*female + 1*male + 0*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + `mlnpubyear'*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*married male
lincom _cons + 0*se_comb_win + 1*prime + 0*nearretirement + 0*female + 1*male + 1*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + `mlnpubyear'*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*single male
lincom _cons + 0*se_comb_win + 1*prime + 0*nearretirement + 0*female + 1*male + 1*married + 0*single + `maxln_timespan'*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + `mlnpubyear'*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct


***Martinez et al (2021)


*baseline
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 0*female + 0*male + 0*married + 0*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + 3.610918*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*nearretirement
lincom _cons + 0*se_comb_win + 0*prime + 1*nearretirement + 0*female + 0*male + 0*married + 0*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + 3.610918*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*prime
lincom _cons + 0*se_comb_win + 1*prime + 0*nearretirement + 0*female + 0*male + 0*married + 0*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + 3.610918*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*female
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 1*female + 0*male + 0*married + 0*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + 3.610918*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*married female
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 1*female + 0*male + 1*married + 0*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + 3.610918*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*single female
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 1*female + 0*male + 0*married + 1*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + 3.610918*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*male
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 0*female + 1*male + 0*married + 0*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + 3.610918*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*married male
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 0*female + 1*male + 1*married + 0*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + 3.610918*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct
*single male
lincom _cons + 0*se_comb_win + 0*prime + 0*nearretirement + 0*female + 1*male + 0*married + 1*single + 2.5649494*ln_timespan + 0*monthly + 0*quarterly + 0*industry + 0*macro + 0*usa + 1*quasi_exp + 1*sls_iv + 3.610918*lnpubyear + 1*top + `mlnycite'*lnycite + 0*byproduct



