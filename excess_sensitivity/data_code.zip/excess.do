******************************************************************************
******************************************************************************
*EXCESS SENSITIVITY OF CONSUMPTION TO INCOME: A META-ANALYSIS
******************************************************************************
******************************************************************************
*Stata 15.1
*August 16, 2018
log using excess.log, replace
use excess.dta, clear
set more off
******************************************************************************
*DEFINITION OF VARIABLES
******************************************************************************
gen prec = 1/se
gen tstat = excess/se
replace csunits = ln(csunits)
replace years = ln(years)
replace periods = ln(1+periods)
gen ratio = csunits/periods
replace months=ln(months)
replace avyear = avyear - 1907
replace pay_amount=ln(pay_amount)
gen df = obs - tastes
replace tastes = ln(1+tastes)
gen noyearfe = 0
gen lnobs=ln(obs)
replace noyearfe = 1 if micro==1 & yearfe==0 & quasipan==0
replace pubyear2 = pubyear2 - 1980
replace yearcits = ln(1+yearcits)
xtset idstudy
encode country, generate(idcountry)
replace LC_not_bind =0 if switch==1
bysort idstudy: egen emed = median(excess)
bysort idstudy: egen precmed = median(prec)
bysort idstudy: egen semed = median(se)
bysort idstudy: egen tmed = median(tstat)
bysort idstudy: egen perstudy = count(excess)
gen invperstudy = 1/perstudy
bysort idstudy: egen idmax = max(id)
gen last=0
replace last = 1 if idmax==id
gen microse = micro*se
******************************************************************************
*VARIABLE LABELS
******************************************************************************
label variable microse "Micro x SE"
label variable lnobs "No. of obs."
label variable avyear "Midpoint of data"
label variable micro "Micro"
label variable panel "Panel"
label variable quasipan "Synthetic cohort"
label variable annual "Annual frequency"
label variable monthly "Monthly frequency"
label variable LC_not_bind "Liquidity unconstr."
label variable decrease "Decrease in income"
label variable LC_bind "Liquidity constr."
label variable increase "Increase in income"
label variable habits "Habits"
label variable sepgov "Nonsep. public"
label variable seplab_total "Nonsep. labor"
label variable ir "Interest rate"
label variable totalc "Total consumption"
label variable food "Food"
label variable cat "Indiv. category"
label variable out "Outside income"
label variable y_actual_current "Current income"
label variable y_actual_lagged "Lagged income"
label variable GDP_proxy "GDP proxy"
label variable v5 "Instruments signif."
label variable v_nr "Signif. not reported"
label variable inst_c "Consumption instr."
label variable inst_y "Income instr."
label variable inst_cy "Difference instr."
label variable inst_in "Nominal IR instr."
label variable inst_inf "Inflation instr."
label variable inst_ir "Real IR instr."
label variable inst_other "Other instr."
label variable levels_euler_exact "Exact Euler"
label variable levels_other "Estimated in levels"
label variable secord "Second order"
label variable ES_short_run "Short run"
label variable ES_long_run "Long run"
label variable shift_dummy "Time shift"
label variable noyearfe "No year dummies"
label variable MA_control "Time aggregation"
label variable ml "ML"
label variable tsls "TSLS"
label variable ols "OLS"
label variable switch "Switching regr."
label variable pubyear2 "Publication year"
label variable yearcits "Citations"
label variable top "Top journal"
label variable impact "Journal impact"
******************************************************************************
*GRAPHS AND FUNNEL ASYMMETRY TESTS
******************************************************************************
graph hbox excess if micro==1 & excess<1.6, over(study, sort(avyear)) xsize(6.3) ysize(8) scale(0.4) saving(box, replace)
scatter prec excess if prec<80 & excess<3 & excess>-2 & micro==1, msize(*.3) msymbol(Oh) saving(funnel_micro, replace)
scatter prec excess if prec<100 & excess<3 & excess>-2 & micro==0, msize(*.3) msymbol(Oh) saving(funnel_macro, replace)
hist tstat if micro==1 & tstat>-2 & tstat<6, width(0.28) normal saving(hist_micro, replace)
hist tstat if micro==0 & tstat>-2 & tstat<8, width(0.335) normal saving(hist_macro, replace)
byhist excess if excess>-0.6 & excess<1.6, by(micro) width(0.1)

eststo: ivreg2 excess se if micro==1, cluster (idstudy countryyear)
eststo: xtreg excess se if micro==1, fe vce(cluster idstudy)
eststo: xtreg excess se if micro==1, be
eststo: ivreg2 excess se if micro==1 [pweight=prec], cluster (idstudy countryyear)
eststo: ivreg2 excess se if micro==1 [pweight=invperstudy], cluster (idstudy countryyear)
eststo: ivreg2 excess (se=lnobs csunits years) if micro==1, cluster(idstudy countryyear)
esttab using fat_micro.tex, se booktabs replace compress title(Funnel asymmetry test\label{tab:fat}) mtitles("1" "2" "3" "4") addnote("Standard errors are clustered at the study level.") star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) label nonumber nogaps width(1\hsize)
eststo clear

eststo: ivreg2 excess se if micro==0, cluster (idstudy countryyear)
eststo: xtreg excess se if micro==0, fe vce(cluster idstudy)
eststo: xtreg excess se if micro==0, be
eststo: ivreg2 excess se if micro==0 [pweight=prec], cluster (idstudy countryyear)
eststo: ivreg2 excess se if micro==0 [pweight=invperstudy], cluster (idstudy countryyear)
eststo: ivreg2 excess (se=lnobs csunits years) if micro==0, cluster(idstudy countryyear)
esttab using fat_macro.tex, se booktabs replace compress title(Funnel asymmetry test\label{tab:fat}) mtitles("1" "2" "3" "4") addnote("Standard errors are clustered at the study level.") star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) label nonumber nogaps width(1\hsize)
eststo clear
******************************************************************************
*HEDGES' TEST FOR PUBLICATION BIAS
******************************************************************************
global t1=invnormal(1-.5*.01)
global t2=invnormal(1-.5*.05)
global t3=invnormal(1-.5*.10)
dis %8.3f $t1 %8.3f $t2 %8.3f $t3

gen group=1
replace group=2 if tstat<$t1
replace group=3 if tstat<$t2
replace group=4 if tstat<$t3

program hedges1
         version 14.1
         args todo b lnf
         tempvar theta1 sigma l eta
         mleval `theta1' = `b', eq(1)
         mleval `sigma'=`b', eq(2)

         gen double `eta'=sqrt(se*se+`sigma'*`sigma')

         quietly gen double `l' = -ln(`eta')-.5*(($ML_y1-`theta1')/`eta')^2
         mlsum `lnf' = `l'
end

program hedges2
         version 14.1
         args todo b lnf
         tempvar theta1 sigma l lg lgg g1 g2 g3 g4 eta
         mleval `theta1' = `b', eq(1)
         mleval `sigma'=`b', eq(2)
         mleval `g2'=`b', eq(3)
         mleval `g3'=`b', eq(4)
         mleval `g4'=`b', eq(5)

         gen double `eta'=sqrt(se*se+`sigma'*`sigma')
         gen double `g1'=1
         quietly gen double `lg'=`g1' if group==1
         quietly replace `lg'=(1-`g2') if group==2
         quietly replace `lg'=(1-`g3') if group==3
         quietly replace `lg'=(1-`g4') if group==4
         quietly gen double `lgg'=`g1'*(1-normal(($t1*se-`theta1')/`eta'))
         quietly replace `lgg'=`lgg'+(1-`g2')*(normal(($t1*se-`theta1')/`eta')-normal(($t2*se-`theta1')/`eta'))
         quietly replace `lgg'=`lgg'+(1-`g3')*(normal(($t2*se-`theta1')/`eta')-normal(($t3*se-`theta1')/`eta'))
         quietly replace `lgg'=`lgg'+(1-`g4')*(normal(($t3*se-`theta1')/`eta'))
         quietly gen double `l' =-ln(`eta')-.5*(($ML_y1-`theta1')/`eta')^2+ln(`lg')-ln(`lgg')
         mlsum `lnf' = `l'
end

ml model d0 hedges1 (equation:excess = ) (sigma:) if micro==1
ml maximize
gen ll1=e(ll)
ml model d0 hedges2 (equation:excess = ) (sigma:)(g2:)(g3:)(g4:) if micro==1
ml maximize
gen ll2=e(ll)
ml model d0 hedges1 (equation:excess = pubyear2 yearcits top impact) (sigma:) if micro==1
ml maximize
gen ll5=e(ll)
ml model d0 hedges2 (equation:excess = pubyear2 yearcits top impact) (sigma:)(g2:)(g3:)(g4:) if micro==1
ml maximize
gen ll6=e(ll)
gen lldiff12=2*abs(ll1-ll2)
display lldiff12
display chi2tail(3, lldiff12)
gen lldiff56=2*abs(ll5-ll6)
display lldiff56
display chi2tail(3, lldiff56)
drop group ll1 ll2 ll5 ll6 lldiff12 lldiff56
******************************************************************************
*HETEROGENEITY
******************************************************************************
sum lnobs avyear micro microse panel quasipan annual monthly LC_not_bind decrease LC_bind increase habits sepgov seplab_total ir totalc food cat out y_actual_current y_actual_lagged GDP_proxy v5 v_nr inst_c inst_y inst_cy inst_in inst_inf inst_ir inst_other levels_euler_exact levels_other secord ES_short_run ES_long_run shift_dummy noyearfe MA_control ml tsls ols switch pubyear2 yearcits top impact
eststo: ivreg2 excess micro microse, cluster (idstudy countryyear)
lincom _cons + micro
eststo: ivreg2 excess micro microse LC_not_bind, cluster (idstudy countryyear)
lincom _cons + micro + LC_not_bind
eststo: ivreg2 excess micro LC_not_bind, cluster (idstudy countryyear)
lincom _cons + micro + LC_not_bind
eststo: ivreg2 excess micro microse LC_not_bind [pweight=prec], cluster (idstudy countryyear)
lincom _cons + micro + LC_not_bind
eststo: ivreg2 excess micro microse LC_not_bind [pweight=invperstudy], cluster (idstudy countryyear)
lincom _cons + micro + LC_not_bind
esttab using het.tex, se booktabs replace compress title(Heterogeneity\label{tab:het}) mtitles("1" "2" "3" "4" "5") addnote("Standard errors are clustered at the study level.") star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) label nonumber nogaps width(1\hsize)
eststo clear
******************************************************************************
*DATA PREPARATION FOR BMA
******************************************************************************
preserve
order excess lnobs avyear micro microse panel quasipan annual monthly LC_not_bind decrease LC_bind increase habits sepgov seplab_total ir totalc food cat out y_actual_current y_actual_lagged GDP_proxy v5 v_nr inst_c inst_y inst_cy inst_in inst_inf inst_ir inst_other levels_euler_exact levels_other secord ES_short_run ES_long_run shift_dummy noyearfe MA_control ml tsls ols switch pubyear2 yearcits top impact new mpc mpc_se exo_var cumul months lags_include pay_amount pay_data_quality dollars_year account_cons account_inc

drop se id idstudy tastes yearfe category country startyear endyear years periods obs csunits es_trend pubyear countryyear prec tstat df emed precmed semed tmed perstudy invperstudy last idmax new mpc mpc_se exo_var cumul months lags_include pay_amount pay_data_quality dollars_year account_cons account_inc study idcountry
saveold excess_bma, version(12) replace
restore

preserve
local rhsvars excess lnobs avyear micro microse panel quasipan annual monthly habits sepgov seplab_total ir levels_euler_exact levels_other secord ES_short_run ES_long_run shift_dummy noyearfe MA_control totalc food cat out y_actual_current y_actual_lagged GDP_proxy v5 v_nr inst_c inst_y inst_in inst_ir inst_inf inst_cy inst_other LC_not_bind decrease LC_bind increase ml tsls ols switch pubyear2 yearcits top impact
foreach x of varlist `rhsvars' {
    replace `x' = `x' / sqrt(se)
}
order excess lnobs avyear micro microse panel quasipan annual monthly LC_not_bind decrease LC_bind increase habits sepgov seplab_total ir totalc food cat out y_actual_current y_actual_lagged GDP_proxy v5 v_nr inst_c inst_y inst_cy inst_in inst_inf inst_ir inst_other levels_euler_exact levels_other secord ES_short_run ES_long_run shift_dummy noyearfe MA_control ml tsls ols switch pubyear2 yearcits top impact new mpc mpc_se exo_var cumul months lags_include pay_amount pay_data_quality dollars_year account_cons account_inc
drop se id idstudy tastes yearfe category country startyear endyear years periods obs csunits es_trend pubyear countryyear prec tstat df emed precmed semed tmed perstudy invperstudy last idmax new mpc mpc_se exo_var cumul months lags_include pay_amount pay_data_quality dollars_year account_cons account_inc study idcountry
saveold excess_bma_se, version(12) replace
restore

preserve
local rhsvars excess lnobs avyear micro microse panel quasipan annual monthly habits sepgov seplab_total ir levels_euler_exact levels_other secord ES_short_run ES_long_run shift_dummy noyearfe MA_control totalc food cat out y_actual_current y_actual_lagged GDP_proxy v5 v_nr inst_c inst_y inst_in inst_ir inst_inf inst_cy inst_other LC_not_bind decrease LC_bind increase ml tsls ols switch pubyear2 yearcits top impact
foreach x of varlist `rhsvars' {
    replace `x' = `x' * sqrt(invperstudy)
}
order excess lnobs avyear micro microse panel quasipan annual monthly LC_not_bind decrease LC_bind increase habits sepgov seplab_total ir totalc food cat out y_actual_current y_actual_lagged GDP_proxy v5 v_nr inst_c inst_y inst_cy inst_in inst_inf inst_ir inst_other levels_euler_exact levels_other secord ES_short_run ES_long_run shift_dummy noyearfe MA_control ml tsls ols switch pubyear2 yearcits top impact new mpc mpc_se exo_var cumul months lags_include pay_amount pay_data_quality dollars_year account_cons account_inc
drop se id idstudy tastes yearfe category country startyear endyear years periods obs csunits es_trend pubyear countryyear prec tstat df emed precmed semed tmed perstudy invperstudy last idmax new mpc mpc_se exo_var cumul months lags_include pay_amount pay_data_quality dollars_year account_cons account_inc study idcountry
saveold excess_bma_ps, version(12) replace
restore
preserve
drop if exo_var!=1 | mpc==.
order mpc mpc_se avyear  pay_amount ratio  LC_not_bind decrease LC_bind increase totalc food cat account_cons   ES_long_run  months  ols yearcits top impact
drop id idstudy study excess se new exo_var cumul lags_include pay_data_quality dollars_year account_inc ir micro panel quasipan yearfe sepgov habits category ml tsls MA_control ES_short_run country annual monthly startyear endyear years periods obs csunits out y_actual_current y_actual_lagged GDP_proxy v5 v_nr inst_c inst_y inst_in inst_ir inst_inf inst_cy inst_other levels_euler_exact levels_other secord es_trend shift_dummy switch pubyear2 pubyear countryyear prec tstat df noyearfe lnobs idcountry emed precmed semed tmed perstudy invperstudy idmax last microse seplab_total tastes
saveold excess_bma_micro, version(12) replace
restore
******************************************************************************
*BMA: now run the R code
******************************************************************************
*FREQUENTIST CHECKS (follows from BMA)
******************************************************************************
ivreg2 excess microse decrease yearcits impact ir MA_control LC_not_bind levels_euler_exact lnobs secord totalc micro switch pubyear2 panel y_actual_lagged habits GDP_proxy, cluster (idstudy countryyear)

ivreg2 excess avyear micro microse annual monthly decrease habits seplab_total ir y_actual_current y_actual_lagged GDP_proxy inst_in inst_ir levels_euler_exact secord ES_short_run tsls switch pubyear2 yearcits top impact [pweight=invperstudy], cluster (idstudy countryyear)

ivreg2 excess lnobs avyear micro microse panel decrease LC_bind habits seplab_total ir cat out y_actual_lagged GDP_proxy inst_in inst_inf secord ES_long_run MA_control tsls pubyear2 yearcits top impact [pweight=prec], cluster (idstudy countryyear)
******************************************************************************
******************************************************************************
*MICRO DATA
******************************************************************************
eststo: ivreg2 mpc mpc_se if exo_var==1, cluster (idstudy countryyear)
eststo: xtreg mpc mpc_se if exo_var==1, fe vce(cluster idstudy)
eststo: xtreg mpc mpc_se if exo_var==1, be
eststo: ivreg2 mpc mpc_se if exo_var==1 [pweight=prec], cluster (idstudy countryyear)
eststo: ivreg2 mpc mpc_se if exo_var==1 [pweight=invperstudy], cluster (idstudy countryyear)
eststo: ivreg2 mpc (mpc_se=lnobs csunits years) if exo_var==1, cluster(idstudy countryyear)
esttab using fat_micro2.tex, se booktabs replace compress title(Funnel asymmetry test\label{tab:fat}) mtitles("1" "2" "3" "4") addnote("Standard errors are clustered at the study level.") star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) label nonumber nogaps width(1\hsize)
eststo clear

gen precmpc = 1/mpc_se
scatter precmpc mpc if precmpc<80 & micro==1 & exo_var==1, msize(*.3) msymbol(Oh)
hist tstat if micro==1 & tstat>-2 & tstat<6 & exo_var==1, width(0.285) normal saving(hist_micro2, replace)

collin mpc_se avyear  pay_amount ratio LC_not_bind decrease LC_bind increase totalc food cat account_cons   ES_long_run  months  ols yearcits top impact if exo_var==1 & mpc!=.
*For BMA on micro data run the attached R code.
