rm(list=ls())
###################
# loading library #
###################
library(BMS)
library(foreign)


###################
# set directory   #
###################
setwd("C:\\Papers\\Excess_Sensitivity\\")

#######################################
# Parameters for in-sample estimation #
#######################################
burn_       = 0.5e8
iter_       = 1e8
gprior      = "UIP"
modelprior  = "uniform"
order_PIP   = F
separator   = ";"

################
# loading data #
################
data_nw         = read.dta("excess_bma.dta")
data_se         = read.dta("excess_bma_se.dta")
data_ps         = read.dta("excess_bma_ps.dta")
data_micro      = read.dta("excess_bma_micro.dta")

##############
# Estimation #
##############
BMA_nw  = bms(data_nw, burn=burn_,iter=iter_, g=gprior, mprior=modelprior, nmodel=5000, mcmc="bd", user.int=FALSE)
BMA_nw_res<-coef(BMA_nw,std.coefs=F, order.by.pip = order_PIP, exact=T,include.constant = T)
write.table(BMA_nw_res,"BMA_nw.csv",sep=separator)
image(BMA_nw, cex=0.5)
summary(BMA_nw)
plot(BMA_nw)

BMAse1  = bms(data_se, burn=burn_,iter=iter_, g=gprior, mprior=modelprior, nmodel=5000, mcmc="bd", user.int=FALSE)
BMAse1_res<-coef(BMAse1,std.coefs=F, order.by.pip = order_PIP, exact=T,include.constant = T)
write.table(BMAse1_res,"BMAse1.csv",sep=separator)
image(BMAse1, cex=0.5)
summary(BMAse1)
plot(BMAse1)

BMAps  = bms(data_ps, burn=burn_,iter=iter_, g=gprior, mprior=modelprior, nmodel=5000, mcmc="bd", user.int=FALSE)
BMAps_res<-coef(BMAps,std.coefs=F, order.by.pip = order_PIP, exact=T,include.constant = T)
write.table(BMAps_res,"BMAps.csv",sep=separator)
image(BMAps, cex=0.5)
summary(BMAps)
plot(BMAps)

#Prior sensitivity
#BMA_ps1  = bms(data_nw, burn=burn_,iter=iter_, g="UIP", mprior="uniform", nmodel=5000, mcmc="bd", user.int=FALSE)
BMA_ps2  = bms(data_nw, burn=burn_,iter=iter_, g="BRIC", mprior="random", nmodel=5000, mcmc="bd", user.int=FALSE)
BMA_ps3  = bms(data_nw, burn=burn_,iter=iter_, g="hyper=BRIC", mprior="random", nmodel=5000, mcmc="bd", user.int=FALSE)

plotComp("UIP and Uniform"=BMA_nw,"BRIC and Random"=BMA_ps2,"HyperBRIC and Random"=BMA_ps3,add.grid=F,cex.xaxis=0.7)

#Micro data
BMA_micro  = bms(data_micro, burn=burn_,iter=iter_, g=gprior, mprior=modelprior, nmodel=5000, mcmc="bd", user.int=FALSE)
BMA_micro_res<-coef(BMA_micro,std.coefs=F, order.by.pip = order_PIP, exact=T,include.constant = T)
write.table(BMA_micro_res,"BMA_micro.csv",sep=separator)
image(BMA_micro, cex=0.5)
summary(BMA_micro)
plot(BMA_micro)

######################
# Save the workspace #
######################

save.image("results_excess.Rdata")

####################
# Correlation plot #
####################
library(corrplot)
M_nw=cor(data_nw)
corrplot(M_nw,type="upper",tl.pos="tp",tl.col="black", tl.cex=0.5, tl.srt=45)
par(cex=0.3)
corrplot(M_nw,add=TRUE, type="lower", method="number",diag=FALSE,tl.pos="n", cl.pos="n",cl.cex=0.2)

density(BMA_nw, reg="Micro")
density(BMA_nw, reg="Liquidity_unconstr_")
density(BMA_nw, reg="Habits")
density(BMA_nw, reg="Exact_Euler")