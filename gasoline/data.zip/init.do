* dependencies: _gwtmean

clear all
set more off

c thesis
cd "data-graphics/MRA"
use "mra-data.dta", clear

* let's generate variables

gen unpublished = 1-Journal
label variable unpublished "=1 if paper is not published"
gen nonOECD = 1-OECD
label variable nonOECD "=1 if country studied is not a member of OECD"

* standard errors and inverse standard errors
quietly {
gen Ysrse = abs(Ysr/tYsr)
gen Ysrseinv = 1/Ysrse
label variable Ysrseinv "1/se"
gen Ystatse = abs(Ystat/tYstat)
gen Ystatseinv = 1/Ystatse
label variable Ystatseinv "1/se"
}

* Cross sections, cross section time series, or time series
quietly{
gen cross = 1 if Type == "C"
replace cross = 0 if cross == .
gen crosst = 1 if regexm(Type, "CT")
replace crosst = 0 if crosst == .
gen tseries = 1 if regexm(Type, "^T")
replace tseries = 0 if tseries == .
gen nontseries = 1 - tseries
gen auto = 1 if regexm(Model, "Sk")
replace auto = 0 if auto == .
label variable auto "=1 if vehicle stock used"
gen nonauto = 1-auto
}

* weighted variables
quietly {
gen wsrY = Y/Ysrse
gen wstatY = Y/Ystatse
gen wsrunpublished = unpublished/Ysrse
gen wstatunpublished = unpublished/Ystatse
gen wsrnonOECD = nonOECD/Ysrse
gen wstatnonOECD = nonOECD/Ystatse
gen wsrcross = cross/Ysrse
gen wstatcross = cross/Ystatse
gen wsrcrosst = crosst/Ysrse
gen wstatcrosst = crosst/Ystatse
gen wsrtseries = tseries/Ysrse
gen wstattseries = tseries/Ystatse
gen wsrnontseries = nontseries/Ysrse
gen wstatnontseries = nontseries/Ystatse
gen wsrauto = auto/Ysrse
gen wstatauto = auto/Ystatse
gen wsrnonauto = nonauto/Ysrse
gen wstatnonauto = nonauto/Ystatse
}

* Summary statistics
gen Ystatauto = Ystat if auto == 1
gen Ystatnonauto = Ystat if auto == 0
label variable Ysr "Short-run"
label variable Ystatauto "Long-run, car stock"
label variable Ystatnonauto "Long-run, no car stock"
estpost tabstat Ysr Ystatauto Ystatnonauto if Ystatseinv < 100 | Ysrseinv < 100, columns(statistics) statistics(count mean p50 sd min max)
esttab using "../../content/stata/summary.tex", cells("count mean(fmt(3)) p50(fmt(3)) sd(fmt(3)) min max") booktabs noobs nogaps nonumbers label compress nomtitle replace title("Summary statistics\label{tab:summary}")
eststo clear
drop Ystatauto
drop Ystatnonauto

* top 10% from the funnel
eststo: xtmixed Ysr if Ysrseinv < 100 & Ysrseinv > 37 || paperid:
eststo: xtmixed Ystat if Ystatseinv < 100 & auto == 1 & Ystatseinv > 25 || paperid:
eststo: xtmixed Ystat if Ystatseinv < 100 & auto == 0 & Ystatseinv > 40 || paperid:
esttab, nonumbers wide mtitle("Short-run" "Long-run, car stock" "Long-run, no car stock")
eststo clear

* weighted average for the top 10%
quietly{
egen refcnt1 = count(Ysr != .) if Ysrseinv < 100 & Ysrseinv > 37, by(Ref)
egen refcnt2 = count(Ystat != .) if Ystatseinv < 100 & auto == 1 & Ystatseinv > 25, by(Ref)
egen refcnt3 = count(Ystat != .) if Ystatseinv < 100 & auto == 0 & Ystatseinv > 40, by(Ref)
egen refcnt11 = wtmean(Ysr), weight(refcnt1)
egen refcnt21 = wtmean(Ystat), weight(refcnt2)
egen refcnt31 = wtmean(Ystat), weight(refcnt3)
}
estpost tabstat refcnt?1, statistics(mean)
drop refcnt*

*twoway (kdensity Ystat if auto == 0 || kdensity Ystat if auto == 1)



* FAT tests
eststo: xtmixed tYsr Ysrseinv Ysrse if Ysrseinv < 100 || paperid:
eststo: xtmixed tYstat Ystatseinv Ystatse if Ystatseinv < 100 || paperid:
eststo: xtmixed tYstat Ystatseinv Ystatse if Ystatseinv < 100 & auto == 1|| paperid:
eststo: xtmixed tYstat Ystatseinv Ystatse if Ystatseinv < 100 & auto == 0|| paperid:
* super model na stratifikaci aut: xtmixed tYstat Ystatseinv auto wstatauto if Ystatseinv < 150|| paperid:
*esttab using "../../content/stata/mra-overall.tex", wide compress nonumbers booktabs replace title("Overall results without moderator variables\label{tab:mra-overall}") mtitle("Short-run" "Long-run")
esttab using "../../content/stata/mra-overall.tex", label replace wide compress nonumbers booktabs title("Overall results without moderator variables\label{tab:mra-overall}") mtitle("Whole sample" "Whole sample" "Car stock" "No car stock") mgroups("Short-run" "Long-run", pattern (0 1 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span}))
eststo clear

* FAT-PEEVE
xtmixed tYsr Ysrse Ysrseinv cross crosst unpublished nonOECD Y wsrunpublished wsrcross wsrcrosst wsrnonOECD wsrnonauto wsrY if Ysrseinv < 100 || paperid:
* xtmixed tYsr Ysrse Ysrseinv wsrnontseries if Ysrseinv < 100 || paperid:
eststo
xtmixed tYstat Ystatse Ystatseinv cross crosst unpublished nonOECD Y wstatunpublished wstatcross wstatcrosst wstatnonOECD wstatnonauto wstatY if Ystatseinv < 100 || paperid:
*xtmixed tYstat Ystatse Ystatseinv wstatnonOECD wstatunpublished wstatnonauto wstatY if Ystatseinv < 100|| paperid:
*fajn: xtmixed tYstat Ystatse Ystatseinv tseries unpublished nonOECD wstatunpublished wstatnontseries wstatnonOECD wstatnonauto if Ystatseinv < 100|| paperid:
* supr model xtmixed tYstat Ystatse Ystatseinv tseries auto unpublished nonOECD wstatunpublished wstatnontseries wstatnonOECD wstatnonauto if Ystatseinv < 100|| paperid:
eststo
esttab using "../../content/stata/mra-moderator.tex", wide compress nonumbers booktabs replace title("Overall results with moderator variables\label{tab:mra-moderator}") mtitle("Short-run" "Long-run")
eststo clear














* pre-shock, post-shock
eststo clear
quietly {
eststo: xtmixed tYstat Ystatseinv Ystatse if yr2 < 1980 & auto == 1 &Ystatseinv < 150|| paperid:
eststo: xtmixed tYstat Ystatseinv Ystatse if yr1 > 1979 & auto == 1  &Ystatseinv < 150 || paperid:
eststo: xtmixed tYstat Ystatseinv Ystatse if yr1 < 1980 & yr2 > 1980 & auto ==1  &Ystatseinv < 150|| paperid:
}
esttab, wide nonumbers
eststo clear
quietly {
eststo: xtmixed tYstat Ystatseinv Ystatse if yr2 < 1980 & auto == 0  &Ystatseinv < 100|| paperid:
eststo: xtmixed tYstat Ystatseinv Ystatse if yr1 > 1979 & auto == 0  &Ystatseinv < 100|| paperid:
eststo: xtmixed tYstat Ystatseinv Ystatse if yr1 < 1980 & yr2 > 1980 & auto ==0  &Ystatseinv < 100|| paperid:
}
esttab, wide nonumbers
eststo clear

quietly {
eststo: xtmixed tYsr Ysrseinv Ysrse if yr2 < 1980 & auto == 1 &Ysrseinv < 150|| paperid:
eststo: xtmixed tYsr Ysrseinv Ysrse if yr1 > 1979 & auto == 1  &Ysrseinv < 150 || paperid:
eststo: xtmixed tYsr Ysrseinv Ysrse if yr1 < 1980 & yr2 > 1980 & auto ==1  &Ysrseinv < 150|| paperid:
}
esttab, wide nonumbers
eststo clear
quietly {
eststo: xtmixed tYsr Ysrseinv Ysrse if yr2 < 1980 & auto == 0  &Ysrseinv < 150|| paperid:
eststo: xtmixed tYsr Ysrseinv Ysrse if yr1 > 1979 & auto == 0  &Ysrseinv < 150|| paperid:
eststo: xtmixed tYsr Ysrseinv Ysrse if yr1 < 1980 & yr2 > 1980 & auto ==0  &Ysrseinv < 150|| paperid:
}
esttab, wide nonumbers
eststo clear

*multivariate MRA: open file gas_income_revision.dta

gen se = abs(e/tstat)
gen prec = 1/se

xtmixed tstat prec if prec < 100 & Carstock == 1|| Studyid:
xtmixed tstat prec if prec < 100 & Carstock == 0|| Studyid:

replace Pubyear = Pubyear - 1966
replace Datayear = Datayear - 1946.5
replace Timespan = ln(Timespan)
gen sqrtn = sqrt(Observations)


local allvariables Published Pubyear Australia Canada France Germany Japan Sweden usa Developing Datayear Timespan Cross_section Timeseries Quarterly Monthly Carstock Static ols iv sur ml ecm gls

sum Published Pubyear Australia Canada France Germany Japan Sweden usa Developing Datayear Timespan Cross_section Timeseries Quarterly Monthly Carstock Static ols iv sur ml ecm gls

foreach x of varlist `allvariables' {
				gen `x'_se = `x' / se
}

ivregress 2sls tstat (prec=sqrtn) if prec<100


eststo: xtmixed tstat prec Datayear_se Timespan_se Cross_section_se Timeseries_se Quarterly_se Monthly_se Carstock_se Static_se ols_se iv_se sur_se ml_se ecm_se gls_se if prec < 100 || Studyid:

eststo: xtmixed tstat prec Australia_se Canada_se France_se Germany_se Japan_se Sweden_se usa_se Developing_se Datayear_se Timespan_se Cross_section_se Timeseries_se Quarterly_se Monthly_se Carstock_se Static_se ols_se iv_se sur_se ml_se ecm_se gls_se if prec < 100 || Studyid:

eststo: xtmixed tstat prec Published Pubyear Australia_se Canada_se France_se Germany_se Japan_se Sweden_se usa_se Developing_se Datayear_se Timespan_se Cross_section_se Timeseries_se Quarterly_se Monthly_se Carstock_se Static_se ols_se iv_se sur_se ml_se ecm_se gls_se if prec < 100 || Studyid:

esttab using "multiple.tex", wide compress booktabs replace title("Determinants of heterogeneity in the reported long.run estimates\label{tab:multiple}") star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01)
eststo clear

lincom prec + 53*Datayear_se + 2.688879*Timespan_se + Monthly_se + Carstock_se + iv_se

lincom prec + 53*Datayear_se + 2.688879*Timespan_se + Monthly_se + Carstock_se + Developing_se + iv_se

lincom prec + 53*Datayear_se + 2.688879*Timespan_se + Monthly_se + iv_se

lincom prec + 53*Datayear_se + 2.688879*Timespan_se + Monthly_se + Developing_se + iv_se

