# Run from the replication root. No numerical result is inserted into TeX.
root <- normalizePath(getwd(), winslash="/")
stopifnot(file.exists("data/alphas.xlsx"))
for (d in c("logs","fits","bootstrap","tables","figures","validation")) dir.create(file.path("work/compute",d),recursive=TRUE,showWarnings=FALSE)
setwd("work/compute")
source("code/frequentist.R")
source("code/later_studies.R")
# Full BMA and bootstrap require substantial compute time; invoke the documented stages.
