$ErrorActionPreference='Stop'
$taskDir=Split-Path -Parent $MyInvocation.MyCommand.Path
if(Test-Path -LiteralPath "$taskDir\logs\production.pid"){
 $oldId=[int](Get-Content -LiteralPath "$taskDir\logs\production.pid")
 $old=Get-Process -Id $oldId -ErrorAction SilentlyContinue
 if($old -and $old.ProcessName -eq 'Rscript'){Write-Output "Production already running: $oldId";exit 0}
}
foreach($file in @('logs\fits_stage_done','logs\postfit.error','logs\postfit_stage_done','logs\bootstrap.error')){
 $target=Join-Path $taskDir $file
 if(Test-Path -LiteralPath $target){Remove-Item -LiteralPath $target}
}
$rscript=$env:RSCRIPT_EXE; if(-not $rscript){$c=Get-Command Rscript.exe -ErrorAction SilentlyContinue; if($c){$rscript=$c.Source}}; if(-not $rscript){$rscript='C:\Program Files\R\R-4.6.1\bin\Rscript.exe'}; if(-not (Test-Path -LiteralPath $rscript)){throw 'Rscript.exe not found: put R on PATH or set $env:RSCRIPT_EXE'}
$p=Start-Process -WindowStyle Hidden -FilePath $rscript -ArgumentList 'code/production.R' -WorkingDirectory $taskDir -RedirectStandardOutput "$taskDir\logs\production.log" -RedirectStandardError "$taskDir\logs\production.err" -PassThru
$p.Id | Set-Content -LiteralPath "$taskDir\logs\production.pid"
Write-Output "Detached production PID $($p.Id). Logs: logs/production.log and logs/production.err"
powershell -NoProfile -ExecutionPolicy Bypass -File "$taskDir\launch_bootstrap.ps1"
