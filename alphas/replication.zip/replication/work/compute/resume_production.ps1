param([double]$Hours=6)
$ErrorActionPreference='Stop'
$taskDir=Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $taskDir
foreach($file in @('logs/production.pid','logs/bootstrap.pid')){
 if(Test-Path -LiteralPath $file){$oldId=[int](Get-Content -LiteralPath $file);$old=Get-Process -Id $oldId -ErrorAction SilentlyContinue;if($old -and $old.ProcessName -eq 'Rscript'){throw "A coordinator is still running ($oldId). Monitor it; do not start a duplicate."}}
}
$Hours.ToString([Globalization.CultureInfo]::InvariantCulture) | Set-Content -LiteralPath 'RUN_BUDGET_HOURS.txt'
([DateTimeOffset]::UtcNow.ToUnixTimeSeconds()).ToString() | Set-Content -LiteralPath 'logs/run_started_epoch.txt'
powershell -NoProfile -ExecutionPolicy Bypass -File '.\launch_production.ps1'
