$ErrorActionPreference='Stop'
$taskDir=Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $taskDir
if(Test-Path -LiteralPath 'logs/bootstrap.pid'){
 $oldId=[int](Get-Content -LiteralPath 'logs/bootstrap.pid')
 $old=Get-Process -Id $oldId -ErrorAction SilentlyContinue
 if($old -and $old.ProcessName -eq 'Rscript'){Write-Output "Bootstrap coordinator already running: $oldId";exit 0}
}
$rscript=$env:RSCRIPT_EXE; if(-not $rscript){$c=Get-Command Rscript.exe -ErrorAction SilentlyContinue; if($c){$rscript=$c.Source}}; if(-not $rscript){$rscript='C:\Program Files\R\R-4.6.1\bin\Rscript.exe'}; if(-not (Test-Path -LiteralPath $rscript)){throw 'Rscript.exe not found: put R on PATH or set $env:RSCRIPT_EXE'}
$p=Start-Process -WindowStyle Hidden -FilePath $rscript -ArgumentList 'code/bootstrap_detached.R' -WorkingDirectory $taskDir -RedirectStandardOutput "$taskDir\logs\bootstrap.log" -RedirectStandardError "$taskDir\logs\bootstrap.err" -PassThru
$p.Id | Set-Content -LiteralPath 'logs/bootstrap_launcher.pid'
Write-Output "Detached bootstrap launcher PID $($p.Id); coordinator PID will be in logs/bootstrap.pid"
