All paths assume the working directory is work/compute.

To regenerate the fits and the bootstrap draws, run launch_production.ps1 (code/production.R) and then launch_bootstrap.ps1 (code/bootstrap_detached.R). Both stages call run_finalize.R at the end. With saved fits and draws in fits/ and bootstrap/, `Rscript run_finalize.R` alone rebuilds the tables. The launchers look for Rscript.exe in the RSCRIPT_EXE environment variable, then on PATH.

Seeds. code/core.R builds a locally seeded copy of the bms function; the installed BMS package is unchanged. Each bootstrap draw is saved as bootstrap/{spec}/rep_XXXX.rds.

Outputs go to tables/, figures/ and validation/. The folders fits/, bootstrap/ and logs/ are empty in this archive.
