.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
owner<-if(file.exists('bootstrap/DETACHED_OWNER'))as.integer(readLines('bootstrap/DETACHED_OWNER',warn=FALSE)[1]) else Sys.getpid()
if(is.finite(owner) && owner!=Sys.getpid()){
 cat('Bootstrap delegated to detached R coordinator PID',owner,'\n')
}else{
source('code/bootstrap_core.R');library(parallel)
stopifnot(file.exists('validation/PREFLIGHT_PASS'))
while(!file.exists('logs/postfit_stage_done') && !file.exists('validation/UNION_STABILITY_ACCEPTED')){
 if(file.exists('logs/postfit.error'))stop('Original-sample pooled-model stability/post-fit checks failed. Main bootstrap deferred; pilot draws are saved.')
 if(budget_exhausted())stop('BUDGET STOP while waiting for original-sample pooled-model stability/post-fit checks')
 Sys.sleep(2)
}
while(file.exists('bootstrap/PILOT_RUNNING')){if(budget_exhausted())stop('BUDGET STOP while waiting for the single-process pilot');Sys.sleep(10)}
for(s in specs)dir.create(file.path('bootstrap',s),showWarnings=FALSE)
if(!file.exists('bootstrap/study_draws.rds'))atomic_rds(lapply(1:3999,function(b){set.seed(1000+b);sample(IDS,length(IDS),replace=TRUE)}),'bootstrap/study_draws.rds')
# Identity-sample reproduction uses the frozen original data and the production chain settings.
if(!file.exists('validation/bootstrap_identity.csv')){
 identity<-lapply(specs,function(s){df<-design(bma_full,s);z<-vectors(s,settings=s=='log');f<-fit_chain(df,s,500000+10000*(match(s,specs)-1),burn=1e5,iter=3e5,nmodel=5000,start=0);p<-predict(f,z,exact=TRUE);ref<-read.csv(paste0('tables/',s,'_m1.csv'));mu<-ref$mean[match(rownames(z),ref$row)];data.frame(spec=s,row=rownames(z),identity=p,reference=mu,difference=p-mu)})
 csv(do.call(rbind,identity),'validation/bootstrap_identity.csv')
}
cl<-makeCluster(6,outfile='logs/bootstrap_workers.log');clusterEvalQ(cl,source('code/bootstrap_core.R'))
run_batch <- function(B,slist=specs) {
 tasks<-list();for(b in seq_len(B))for(s in slist){path<-sprintf('bootstrap/%s/rep_%04d.rds',s,b);if(!file.exists(path))tasks[[length(tasks)+1]]<-list(b=b,spec=s)}
 cat('BOOTSTRAP tasks',length(tasks),'B',B,format(Sys.time()),'\n');flush.console()
  result<-parLapplyLB(cl,tasks,function(t){path<-sprintf('bootstrap/%s/rep_%04d.rds',t$spec,t$b);if(budget_exhausted())return('budget_stop');tryCatch({r<-boot_one_final(t$b,t$spec);atomic_rds(r,path);ep<-sub('.rds$','.error',path);if(file.exists(ep))file.remove(ep);if(any(r$drop_kind=='dependency')){rr<-boot_one_final(t$b,t$spec,reverse=TRUE);atomic_rds(rr,sub('.rds$','_reverse.rds',path))};cat(t$spec,t$b,'DONE',format(Sys.time()),'\n');'done'},error=function(e){if(!grepl('BUDGET STOP',conditionMessage(e)))writeLines(conditionMessage(e),sub('.rds$','.error',path));conditionMessage(e)})});print(table(unlist(result)))
}
run_batch(1999)
stopCluster(cl)
source('code/capped_validation.R')
}
