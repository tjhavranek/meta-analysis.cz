.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
source('code/bootstrap_core.R')
path<-'bootstrap/study_draws.rds'
if(!file.exists(path))atomic_rds(lapply(1:3999,function(b){set.seed(1000+b);sample(IDS,length(IDS),replace=TRUE)}),path)
draws<-readRDS(path);stopifnot(length(draws)==3999,all(lengths(draws)==74))
csv(data.frame(b=1:3999,sampled_study_ids=sapply(draws,paste,collapse=';')),'bootstrap/study_draws.csv')
files<-list.files('bootstrap',pattern='^rep_[0-9]{4}\\.rds$',recursive=TRUE,full.names=TRUE)
checks<-lapply(files,function(p){r<-readRDS(p);data.frame(file=p,b=r$b,spec=r$spec,draw_identical=identical(unname(r$draw),unname(draws[[r$b]])),g_equals_N=r$g==r$N,clusters=length(r$cluster_sizes),N=sum(r$cluster_sizes))})
if(length(checks)){cc<-do.call(rbind,checks);csv(cc,'validation/paired_study_draws.csv');stopifnot(all(cc$draw_identical),all(cc$g_equals_N),all(cc$clusters==74))}
cat('FROZEN 3999 DRAWS; EXISTING REPLICATES MATCH\n')
