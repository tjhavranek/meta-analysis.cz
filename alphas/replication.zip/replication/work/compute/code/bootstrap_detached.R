.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
writeLines(as.character(Sys.getpid()),'bootstrap/DETACHED_OWNER')
writeLines(as.character(Sys.getpid()),'logs/bootstrap.pid')
source('code/core.R')
cat('Detached bootstrap coordinator PID',Sys.getpid(),'waiting for original-sample fits',format(Sys.time()),'\n');flush.console()
repeat {
 if(budget_exhausted()){writeLines('BUDGET STOP: original-sample stage not yet ready; bootstrap is resumable.','logs/bootstrap.error');source('run_finalize.R');quit(status=0)}
 if(file.exists('validation/UNION_STABILITY_ACCEPTED') || (file.exists('logs/fits_stage_done') && (file.exists('logs/postfit_stage_done')||file.exists('logs/postfit.error'))))break
 Sys.sleep(10)
}
cat('Starting detached bootstrap stage',format(Sys.time()),'\n');flush.console()
tryCatch(source('code/bootstrap_driver.R'),error=function(e){writeLines(conditionMessage(e),'logs/bootstrap.error');cat('BOOTSTRAP ERROR',conditionMessage(e),'\n')})
source('run_finalize.R')
