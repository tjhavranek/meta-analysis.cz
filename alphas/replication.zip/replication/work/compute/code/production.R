.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
source('code/core.R'); library(parallel)
while(!file.exists('validation/PREFLIGHT_PASS') && !file.exists('validation/W1_pilot_PASS')) {
 if(file.exists('logs/preflight.err') && any(grepl('Execution halted',readLines('logs/preflight.err',warn=FALSE))))stop('Preflight failed; production not launched')
 Sys.sleep(10)
}
chain_job <- function(task) {
 source('code/core.R')
 spec<-task$spec;arm<-task$arm;c<-task$chain;tag<-if(arm=='baseline')spec else paste0('prior_',arm)
 path<-sprintf('fits/%s_chain%d.rds',tag,c);log<-sprintf('logs/%s_chain%d.log',tag,c)
 sink(log,append=TRUE);on.exit(sink(),add=TRUE)
 if(spec=='log' && arm=='baseline' && c==1 && file.exists('validation/W1_pilot_PASS')) {
  while(!file.exists(path)) {
   if(any(grepl('Execution halted',readLines('logs/preflight.err',warn=FALSE))))stop('Long baseline preflight chain failed')
   Sys.sleep(10)
  }
 }
 if(file.exists(path)) return(path)
 if(budget_exhausted())return('BUDGET STOP: no new chain started')
 cat('START',format(Sys.time()),spec,arm,c,'\n');df<-design(bma_full,spec)
 start<-switch(c,rep(0,ncol(df)-1),as.numeric(names(df)[-1]%in%nine),rep(1,ncol(df)-1))
 seed<-if(arm=='baseline')202611060+10*(match(spec,specs)-1)+c else 202611100+10*match(arm,c('uniform','bric','dilution'))+c
 fit<-fit_chain(df,spec,seed,start=start,arm=arm);saveRDS(fit,path)
 cat('DONE',format(Sys.time()),'occupancy',bp_top_models(fit)$mass_share_mcmc,'\n');path
}
summarise_chains <- function(spec,arm='baseline') {
 tag<-if(arm=='baseline')spec else paste0('prior_',arm);df<-design(bma_full,spec);z<-vectors(spec,settings=spec=='log')
 fs<-lapply(1:3,function(c)readRDS(sprintf('fits/%s_chain%d.rds',tag,c)))
 report<-function(fs) {
 ss<-lapply(fs,function(f)analytic(f,z));pp<-sapply(fs,function(f)coef(f,exact=TRUE,order.by.pip=FALSE)[,'PIP'])
 data.frame(chain=1:3,retention=sapply(fs,function(f)bp_top_models(f)$mass_share_mcmc),nmodel=sapply(fs,function(f)bp_top_models(f)$nmodel),max_pip_range=max(apply(pp,1,function(v)diff(range(v)))),max_mean_range=max(apply(sapply(ss,`[[`,'mean'),1,function(v)diff(range(v)))),max_endpoint_range=max(c(apply(sapply(ss,`[[`,'lo'),1,function(v)diff(range(v))),apply(sapply(ss,`[[`,'hi'),1,function(v)diff(range(v))))),exact_frequency_max=sapply(fs,function(f)max(abs(predict(f,z,exact=TRUE)-predict(f,z,exact=FALSE)))))
 }
 dd<-report(fs);csv(dd,paste0('validation/',tag,'_convergence_initial.csv'))
 # Retention expansion and chain extension retain independent starts and seeded draws.
 for(nm in c(500000)) {
 if(all(dd$retention>.999) && dd$max_pip_range[1]<.01 && dd$max_mean_range[1]<.003 && dd$max_endpoint_range[1]<.005) break
 for(c in 1:3) {
  cat('EXTEND',tag,c,nm,format(Sys.time()),'\n')
  seed<-if(arm=='baseline')202611060+10*(match(spec,specs)-1)+c else 202611100+10*match(arm,c('uniform','bric','dilution'))+c
  start<-switch(c,rep(0,ncol(df)-1),as.numeric(names(df)[-1]%in%nine),rep(1,ncol(df)-1))
  ep<-sprintf('fits/%s_chain%d_n%d.rds',tag,c,nm)
  if(!file.exists(ep) && budget_exhausted())stop('BUDGET STOP: convergence extension pending')
  ext<-if(file.exists(ep))readRDS(ep) else fit_chain(df,spec,seed,burn=1e6,iter=if(nm==500000)6e6 else 12e6,nmodel=nm,start=start,arm=arm)
  saveRDS(ext,ep);fs[[c]]<-ext
 };dd<-report(fs)
 }
 dd$pass<-dd$retention>.999 & dd$max_pip_range<.01 & dd$max_mean_range<.003 & dd$max_endpoint_range<.005
 csv(dd,paste0('validation/',tag,'_convergence.csv'))
 final<-do.call(BMS:::combine_chains,fs)
 # combine_chains unions model identities, adds visit counts, and retains each analytic log target once.
 stopifnot(!anyDuplicated(final$topmod$bool()))
 saveRDS(final,paste0('fits/',tag,'_final.rds'))
 ce<-coef(final,exact=TRUE,order.by.pip=FALSE,include.constant=TRUE)
 csv(data.frame(variable=rownames(ce),ce,check.names=FALSE),paste0('tables/',tag,'_coefficients.csv'))
 an<-analytic(final,z);an$spec<-spec;an$arm<-arm;csv(an,paste0('tables/',tag,'_m1.csv'))
 cat('FINAL',tag,format(Sys.time()),'pass',all(dd$pass),'\n');invisible(TRUE)
}
cl<-makeCluster(9,outfile='logs/production_workers.log');clusterEvalQ(cl,source('code/core.R'))
tasks<-list();for(s in specs)for(c in 1:3)tasks[[length(tasks)+1]]<-list(spec=s,arm='baseline',chain=c)
for(a in c('uniform','bric','dilution'))for(c in 1:3)tasks[[length(tasks)+1]]<-list(spec='log',arm=a,chain=c)
clusterExport(cl,'chain_job');res<-parLapplyLB(cl,tasks,function(t)tryCatch(chain_job(t),error=function(e){cat(conditionMessage(e),'\n');conditionMessage(e)}));print(res)
clusterExport(cl,'summarise_chains')
tags<-c(as.list(specs),as.list(c('uniform','bric','dilution')))
res<-parLapplyLB(cl,tags,function(t)tryCatch(if(t%in%specs)summarise_chains(t) else summarise_chains('log',t),error=function(e){cat(conditionMessage(e),'\n');conditionMessage(e)}));print(res)
stopCluster(cl)
writeLines('Original-sample fit stage completed; consult convergence CSVs.','logs/fits_stage_done')
tryCatch(source('code/postfit.R'),error=function(e){writeLines(conditionMessage(e),'logs/postfit.error');cat('POSTFIT ERROR',conditionMessage(e),'\n')})
tryCatch(source('code/bootstrap_driver.R'),error=function(e){writeLines(conditionMessage(e),'logs/bootstrap.error');cat('BOOTSTRAP ERROR',conditionMessage(e),'\n')})
source('run_finalize.R')
