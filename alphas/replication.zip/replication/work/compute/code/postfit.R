.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
source('code/core.R')
cat('POSTFIT',format(Sys.time()),'\n')
source('code/union_stability.R')
ensure_union_stability_all()
# Recompute analytic log targets on the deduplicated union before deriving every linked output.
tags<-c(setNames(specs,specs),prior_uniform='log',prior_bric='log',prior_dilution='log')
for(tag in names(tags)){
 spec<-tags[[tag]];path<-paste0('fits/',tag,'_final.rds');f<-readRDS(path)
 if(spec=='quad_hier'){hp<-hier_prior(names(f$arguments$X.data)[-1],K=36);f$mprior.info$mp.msize<-hp$mp.msize;f$mprior.info$mp.Kdist<-hp$mp.Kdist}
 z<-vectors(spec,settings=spec=='log');before<-predict(f,z,exact=TRUE);oldpip<-coef(f,exact=TRUE,order.by.pip=FALSE)[,'PIP']
 rw<-reweight_union(f);f<-rw$fit;saveRDS(f,path)
 rw$diagnostic$max_mean_change<-max(abs(predict(f,z,exact=TRUE)-before));rw$diagnostic$max_pip_change<-max(abs(coef(f,exact=TRUE,order.by.pip=FALSE)[,'PIP']-oldpip))
 csv(rw$diagnostic,paste0('validation/',tag,'_union_reweight.csv'))
 ce<-coef(f,exact=TRUE,order.by.pip=FALSE,include.constant=TRUE);csv(data.frame(variable=rownames(ce),ce,check.names=FALSE),paste0('tables/',tag,'_coefficients.csv'))
 aa<-analytic(f,z);aa$spec<-spec;aa$arm<-if(tag%in%specs)'baseline' else sub('^prior_','',tag);csv(aa,paste0('tables/',tag,'_m1.csv'))
}
hp<-hier_prior(names(design(bma_full,'quad_hier'))[-1],K=36);csv(data.frame(size=0:36,probability=hp$mp.Kdist,expected_size=hp$mp.msize),'validation/hierarchy_prior_size_distribution.csv')
m1<-do.call(rbind,lapply(specs,function(s){r<-read.csv(paste0('tables/',s,'_m1.csv'));r[1:9,]}));csv(m1,'tables/m1_all_specifications.csv')
base<-readRDS('fits/log_final.rds');an<-read.csv('tables/log_m1.csv');csv(an[10:nrow(an),],'tables/m1_settings.csv')
ce<-coef(base,exact=TRUE,order.by.pip=FALSE,include.constant=TRUE);t3<-data.frame(variable=rownames(ce),ce,check.names=FALSE)
if(file.exists('tables/database_sensitivity.csv')){ol<-read.csv('tables/database_sensitivity.csv');ol<-ol[ol$spec=='original',];ix<-match(t3$variable,ol$variable);t3$ols_coefficient<-ol$coefficient[ix];t3$ols_cluster_se<-ol$se[ix];t3$ols_p<-ol$p[ix]}
csv(t3,'tables/table3.csv')
effects<-data.frame(variable=bma_regressors,coefficient=ce[bma_regressors,'Post Mean'],sd=sapply(bma_df[-1],sd),range=sapply(bma_df[-1],function(x)diff(range(x))))
effects$pip<-ce[bma_regressors,'PIP'];effects$original_nine<-effects$variable%in%nine
effects$sd_change<-effects$coefficient*effects$sd;effects$range_change<-effects$coefficient*effects$range;effects$sd_percent<-100*effects$sd_change/an$mean[1];effects$range_percent<-100*effects$range_change/an$mean[1];csv(effects,'tables/table5.csv')
# Independent QR implementation of the final retained-model mixture.
tm<-bp_top_models(base);X<-as.matrix(bma_df[-1]);y<-bma_df$alpha_w;xc<-sweep(X,2,colMeans(X));yc<-y-mean(y);D<-sweep(X0,2,colMeans(X));N<-length(y);g<-N;cc<-g/(1+g)
loc<-matrix(mean(y),tm$nmodel,9);scale<-matrix(NA_real_,tm$nmodel,9);target<-numeric(tm$nmodel)
for(j in seq_len(tm$nmodel)) {
 ix<-which(tm$incl[,j]==1);k<-length(ix)
 if(k){Q<-qr(xc[,ix,drop=FALSE],tol=1e-10);stopifnot(Q$rank==k);bh<-qr.coef(Q,yc);U<-qr.R(Q);stopifnot(min(abs(diag(U)))>1e-10)
  loc[j,]<-mean(y)+cc*drop(D[,ix,drop=FALSE]%*%bh)
  # QR pivoting is represented explicitly in the inverse quadratic form.
  dd<-t(D[,ix,drop=FALSE]) [Q$pivot,,drop=FALSE];uu<-forwardsolve(t(U),dd);lev<-colSums(uu^2)
  SSE<-sum((yc-xc[,ix,drop=FALSE]%*%bh)^2);qm<-sum(yc^2)/(1+g)+cc*SSE
 }else{qm<-sum(yc^2);SSE<-qm;lev<-rep(0,9)}
 scale[j,]<-sqrt(qm/(N-1)*(1/N+cc*lev));target[j]<-base$gprior.info$lprobcalc$just.loglik(ymy=SSE,k=k)+base$mprior.info$pmp(ki=k,mdraw=tm$incl[,j])
}
ww<-exp(target-max(target));ww<-ww/sum(ww)
indmean<-colSums(ww*loc);indlo<-sapply(1:9,function(r).bp_mix_quantile(.025,ww,loc[,r],scale[,r],N-1));indhi<-sapply(1:9,function(r).bp_mix_quantile(.975,ww,loc[,r],scale[,r],N-1))
ind<-data.frame(row=labs,mean=indmean,mean_difference=indmean-an$mean[1:9],lo_difference=indlo-an$lo[1:9],hi_difference=indhi-an$hi[1:9],max_weight_difference=max(abs(ww-tm$w)))
csv(ind,'validation/m1_independent.csv');stopifnot(max(abs(ind$mean_difference))<1e-8,max(ind$max_weight_difference)<1e-8)
mq<-bp_model_quantities(base,X0)
component<-lapply(unique(c(1,2,3,round(seq(4,tm$nmodel,length.out=12)))),function(j){
 ix<-which(tm$incl[,j]==1);if(!length(ix))return(NULL)
 zz<-BMS:::as.zlm(base,j);bb<-coef(zz);vv<-vcov(zz);ours<-mq$bmean[ix,j];vours<-mq$bvar[ix,j];vn<-colnames(X)[ix]
 L<-cbind('(Intercept)'=1,X0[,vn,drop=FALSE]);L<-L[,names(bb),drop=FALSE]
 # vcov.zlm omits intercept uncertainty (include.const=TRUE returns NA for it).
 # Add the flat-prior centered-intercept variance using BMS's own OLS residual SS.
 qz<-(sum(yc^2)+g*zz$olsres$ymy)/(1+g);DD<-D[,vn,drop=FALSE]
 fvar<-qz/((N-3)*N)+rowSums((DD%*%vv)*DD)
 data.frame(model=j,k=length(ix),mean_error=max(abs(bb[vn]-ours)),variance_error=max(abs(diag(vv)[vn]-vours)),fitted_mean_error=max(abs(drop(L%*%bb)-mq$m[j,])),fitted_variance_error=max(abs(fvar-mq$vf[j,])))
})
cmp<-do.call(rbind,component);csv(cmp,'validation/m1_components_as_zlm.csv')
stopifnot(max(abs(as.matrix(cmp[,-c(1,2)])))<1e-8)
set.seed(6202601);mdl<-sample.int(tm$nmodel,2e6,replace=TRUE,prob=tm$w)
sim<-lapply(1:9,function(r){dd<-loc[mdl,r]+scale[mdl,r]*rt(2e6,N-1);qs<-quantile(dd,c(.025,.975),type=7,names=FALSE);dq<-sapply(c(an$lo[r],an$hi[r]),function(q)sum(tm$w*dt((q-loc[,r])/scale[,r],N-1)/scale[,r]));mc<-sqrt(.025*.975/2e6)/dq;data.frame(row=labs[r],mean=mean(dd),exact_mean=an$mean[r],lo=qs[1],exact_lo=an$lo[r],lo_mcse=mc[1],hi=qs[2],exact_hi=an$hi[r],hi_mcse=mc[2],lo_z=(qs[1]-an$lo[r])/mc[1],hi_z=(qs[2]-an$hi[r])/mc[2])});csv(do.call(rbind,sim),'validation/m1_simulation.csv')
priors<-c(baseline='log',uniform='prior_uniform',bric='prior_bric',dilution='prior_dilution')
pc<-do.call(rbind,lapply(names(priors),function(p){f<-readRDS(paste0('fits/',priors[p],'_final.rds'));ce<-coef(f,exact=TRUE,order.by.pip=FALSE);data.frame(prior=p,variable=rownames(ce),pip=ce[,'PIP'],mean=ce[,'Post Mean'],sd=ce[,'Post SD'],conditional_mean=ce[,'Post Mean']/ce[,'PIP'])}));csv(pc,'tables/prior_comparison.csv')
pb<-do.call(rbind,lapply(names(priors),function(p){r<-read.csv(paste0('tables/',priors[p],'_m1.csv'));r$prior<-p;r[1:9,]}));csv(pb,'tables/prior_benchmarks.csv')
R<-cor(bma_df[-1]);ix<-setdiff(bma_regressors,nine);corr<-do.call(rbind,lapply(ix,function(v){nn<-nine[abs(R[v,nine])>=.6];if(!length(nn))return(NULL);data.frame(variable=v,selected_proxy=nn,correlation=R[v,nn])}))
if(is.null(corr))corr<-data.frame(variable=character(),selected_proxy=character(),correlation=numeric())
csv(merge(corr,pc,by='variable'),'tables/prior_correlated_predictors.csv')
csv(data.frame(variable=ix,max_abs_correlation=sapply(ix,function(v)max(abs(R[v,nine]))),nearest_original_control=sapply(ix,function(v)nine[which.max(abs(R[v,nine]))])),'tables/prior_correlation_screen.csv')
dp<-dilution_prior(as.matrix(bma_df[-1]));sX<-as.matrix(bma_df[,2:6]);sp<-dilution_prior(sX);mods<-as.matrix(expand.grid(rep(list(0:1),5)));w<-apply(mods,1,function(m)exp(sp$pmp(sum(m),m)));sz<-rowsum(w,rowSums(mods),reorder=TRUE)[,1]/sum(w)
stopifnot(max(abs(sz-sp$mp.Kdist))<1e-10,abs(sum(dp$mp.Kdist)-1)<1e-12)
csv(data.frame(k=0:34,size_probability=dp$mp.Kdist,expected_size=dp$mp.msize,polynomial_small_enum_max_error=max(abs(sz-sp$mp.Kdist)),normalization=sum(dp$mp.Kdist)),'validation/dilution_prior_checks.csv')
source('code/figures.R')  # Figures 7 and 8
cat('POSTFIT COMPLETE',format(Sys.time()),'\n')
writeLines('PASS','logs/postfit_stage_done')
