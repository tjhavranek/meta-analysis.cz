.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
if(!requireNamespace('clubSandwich',quietly=TRUE)) install.packages('clubSandwich',repos='https://cloud.r-project.org')
print(requireNamespace('clubSandwich',quietly=TRUE))
