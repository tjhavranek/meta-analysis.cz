.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
source('code/core.R')
union_stability_one <- function(task){
 source('code/core.R')
 tag<-task$tag;spec<-task$spec;arm<-task$arm;z<-vectors(spec,settings=spec=='log');df<-design(bma_full,spec)
 history<-list();previous<-NULL
 tryCatch({
 # Runtime decision 2026-11-07: accept completed 6M fits; retain failed diagnostics.
 for(level in 1:2){
  nm<-c(200000,500000,1000000)[level];it<-c(3e6,6e6,12e6)[level]
  fs<-vector('list',3);ss<-vector('list',3)
  for(c in 1:3){
   p<-if(level==1)sprintf('fits/%s_chain%d.rds',tag,c) else sprintf('fits/%s_chain%d_n%d.rds',tag,c,nm)
   if(!file.exists(p)){
    seed<-if(arm=='baseline')202611060+10*(match(spec,specs)-1)+c else 202611100+10*match(arm,c('uniform','bric','dilution'))+c
    start<-switch(c,rep(0,ncol(df)-1),as.numeric(names(df)[-1]%in%nine),rep(1,ncol(df)-1))
    cat('UNION EXTENSION',tag,c,nm,format(Sys.time()),'\n')
    lp<-sprintf('logs/%s_chain%d.log',tag,c);cat('UNION-STABILITY EXTENSION START nmodel=',nm,' iter=',it,' seed=',seed,' ',format(Sys.time()),'\n',file=lp,append=TRUE)
    ff<-fit_chain(df,spec,seed,burn=1e6,iter=it,nmodel=nm,start=start,arm=arm);atomic_rds(ff,p)
    cat('UNION-STABILITY EXTENSION DONE ',format(Sys.time()),' retention=',bp_top_models(ff)$mass_share_mcmc,'\n',file=lp,append=TRUE)
   }
   fs[[c]]<-readRDS(p)
   cp<-paste0(p,'_analytic_cache.rds');hash<-unname(tools::md5sum(p));cached<-if(file.exists(cp))readRDS(cp) else NULL
   if(!is.null(cached)&&identical(cached$hash,hash)&&identical(cached$z,z))ss[[c]]<-cached$summary else {ss[[c]]<-analytic(fs[[c]],z);atomic_rds(list(hash=hash,z=z,summary=ss[[c]]),cp)}
  }
  f<-do.call(BMS:::combine_chains,fs)
  if(spec=='quad_hier'){hp<-hier_prior(names(df)[-1],36);f$mprior.info$mp.msize<-hp$mp.msize;f$mprior.info$mp.Kdist<-hp$mp.Kdist}
  rw<-reweight_union(f);f<-rw$fit;u<-analytic(f,z)
  pp<-cbind(sapply(fs,function(ff)coef(ff,exact=TRUE,order.by.pip=FALSE)[,'PIP']),coef(f,exact=TRUE,order.by.pip=FALSE)[,'PIP'])
  mm<-cbind(sapply(ss,`[[`,'mean'),u$mean);ll<-cbind(sapply(ss,`[[`,'lo'),u$lo);hh<-cbind(sapply(ss,`[[`,'hi'),u$hi)
  prange<-max(apply(pp,1,function(x)diff(range(x))));mrange<-max(apply(mm,1,function(x)diff(range(x))));erange<-max(apply(ll,1,function(x)diff(range(x))),apply(hh,1,function(x)diff(range(x))))
  ret<-sapply(fs,function(ff)bp_top_models(ff)$mass_share_mcmc)
  dmean<-if(is.null(previous))0 else max(abs(u$mean-previous$mean));dend<-if(is.null(previous))0 else max(abs(u$lo-previous$lo),abs(u$hi-previous$hi))
  pass<-all(ret>.999)&&prange<.01&&mrange<.003&&erange<.005&&dmean<.003&&dend<.005
  dd<-data.frame(tag=tag,level=level,requested_nmodel=nm,iterations=it,minimum_retention=min(ret),max_pip_range=prange,max_mean_range=mrange,max_endpoint_range=erange,previous_union_mean_change=dmean,previous_union_endpoint_change=dend,pass=pass)
  history[[level]]<-dd;csv(do.call(rbind,history),paste0('validation/',tag,'_union_convergence.csv'))
  csv(u,paste0('validation/',tag,'_union_benchmarks_n',nm,'.csv'))
  csv(data.frame(chain=rep(1:3,each=nrow(z)),do.call(rbind,ss)),paste0('validation/',tag,'_chain_benchmarks_n',nm,'.csv'))
  cat('UNION CHECK',tag,nm,'pass',pass,'endpoint range',erange,format(Sys.time()),'\n')
  if(pass || level==2){
   atomic_rds(f,paste0('fits/',tag,'_final.rds'))
   old<-read.csv(paste0('validation/',tag,'_convergence.csv'));old$requested_nmodel<-nm;old$retained_iterations<-it;old$retention<-ret;old$nmodel<-sapply(fs,function(ff)bp_top_models(ff)$nmodel);old$max_pip_range<-prange;old$max_mean_range<-mrange;old$max_endpoint_range<-erange;old$exact_frequency_max<-sapply(fs,function(ff)max(abs(predict(ff,z,exact=TRUE)-predict(ff,z,exact=FALSE))));old$union_checked<-TRUE;old$union_max_endpoint_range<-erange;old$union_accepted<-TRUE;csv(old,paste0('validation/',tag,'_convergence.csv'))
   ce<-coef(f,exact=TRUE,order.by.pip=FALSE,include.constant=TRUE);csv(data.frame(variable=rownames(ce),ce,check.names=FALSE),paste0('tables/',tag,'_coefficients.csv'))
   u$spec<-spec;u$arm<-arm;csv(u,paste0('tables/',tag,'_m1.csv'));return(TRUE)
  }
  previous<-u
 }
 FALSE
 },error=function(e){
  csv(data.frame(tag=tag,pass=FALSE,reason=conditionMessage(e)),paste0('validation/',tag,'_union_pending.csv'))
  cat('UNION PENDING',tag,conditionMessage(e),'\n');FALSE
 })
}
ensure_union_stability_all <- function(){
 if(file.exists('validation/UNION_STABILITY_ACCEPTED'))return(invisible(TRUE))
 library(parallel)
 tasks<-lapply(specs,function(s)list(tag=s,spec=s,arm='baseline'))
 tasks<-c(tasks,lapply(c('uniform','bric','dilution'),function(a)list(tag=paste0('prior_',a),spec='log',arm=a)))
 cl<-makeCluster(7,outfile='logs/union_stability_workers.log');on.exit(stopCluster(cl),add=TRUE)
 invisible(clusterEvalQ(cl,source('code/union_stability.R')))
 result<-parLapplyLB(cl,tasks,union_stability_one)
 if(!all(unlist(result)))stop('Original-sample pooled-model stability is incomplete; see validation/*_union_convergence.csv and *_union_pending.csv. No main bootstrap is authorized by the numerical validation gate yet.')
 if(all(vapply(tasks,function(t)isTRUE(tail(read.csv(paste0('validation/',t$tag,'_union_convergence.csv'))$pass,1)),logical(1))))writeLines('PASS','validation/UNION_STABILITY_PASS') else writeLines('Accepted completed 6M unions under the 2026-11-07 runtime decision; numerical failures remain recorded.','validation/UNION_STABILITY_ACCEPTED')
}
