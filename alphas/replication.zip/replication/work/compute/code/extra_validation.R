.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
source('code/core.R')
# Enumerated small hierarchy design validates the actual BMS custom-prior interface.
dd<-design(bma_full,'quad_hier')[,c('alpha_w','data_midyear','publication_year','data_year_c2','pub_year_c2','depvar_net_returns')]
vv<-names(dd)[-1];mp<-hier_prior(vv);set.seed(8202601)
en<-bms_seeded(dd,mcmc='enum',g=nrow(dd),mprior=mp,user.int=FALSE,nmodel=32)
tm<-bp_top_models(en);admissible<-apply(tm$incl,2,function(m)is.finite(mp$pmp(sum(m),m)))
stopifnot(all(admissible[tm$w>0]),sum(tm$w>0)==18)
X<-as.matrix(dd[-1]);y<-dd[[1]];X<-scale(X,scale=FALSE);yc<-y-mean(y);g<-nrow(dd);K<-ncol(X)
grid<-as.matrix(expand.grid(rep(list(0:1),K)));lt<-apply(grid,1,function(m){lp<-mp$pmp(sum(m),m);if(!is.finite(lp))return(-Inf);ix<-which(m==1);sse<-if(length(ix))sum(qr.resid(qr(X[,ix,drop=FALSE]),yc)^2) else sum(yc^2);lp+en$gprior.info$lprobcalc$just.loglik(ymy=sse,k=sum(m))})
w<-exp(lt-max(lt));w<-w/sum(w);pip<-drop(crossprod(w,grid));ce<-coef(en,exact=TRUE,order.by.pip=FALSE)
rawprior<-apply(grid,1,function(m)exp(mp$pmp(sum(m),m)));sizedist<-rowsum(rawprior,rowSums(grid),reorder=TRUE)[,1]/sum(rawprior)
stopifnot(max(abs(sizedist-mp$mp.Kdist))<1e-12)
csv(data.frame(variable=vv,enumerated_direct_pip=pip,BMS_enum_pip=ce[vv,'PIP'],difference=pip-ce[vv,'PIP']),'validation/prior_interface_enumeration.csv');stopifnot(max(abs(pip-ce[vv,'PIP']))<1e-8)
# Compare all three winsorized fields with our independent Stata run.
st<-read.csv('validation/stata_winsor.csv');csv(data.frame(variable=c('alpha_w','se_w','se_method_iv'),max_abs_difference=sapply(c('alpha_w','se_w','se_method_iv'),function(v)max(abs(st[[v]]-bma_full[[v]])))),'validation/preprocessing_stata_comparison.csv')
# Reject singularity explicitly in a constructed design.
sing<-cbind(X[,1:2],X[,1]);stopifnot(qr(sing,tol=1e-8)$rank==2)
csv(data.frame(check=c('hierarchy_all_retained_admissible','prior_interface_enumerated','constructed_singularity_rejected'),pass=TRUE),'validation/additional_preflight.csv')
cat('EXTRA VALIDATION PASSED\n')
