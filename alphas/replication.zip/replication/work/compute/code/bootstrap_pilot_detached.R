.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
source('code/bootstrap_core.R')
stopifnot(file.exists('validation/PREFLIGHT_PASS'))
writeLines(as.character(Sys.getpid()),'logs/bootstrap_pilot.pid')
writeLines(as.character(Sys.getpid()),'bootstrap/PILOT_RUNNING')
for(s in specs)dir.create(file.path('bootstrap',s),showWarnings=FALSE)
cat('ONE SERIAL PILOT PROCESS; original pool has nine workers. First 24 paired draws, all four specifications.\n');flush.console()
failures<-character()
for(b in 1:24)for(s in specs){
 p<-sprintf('bootstrap/%s/rep_%04d.rds',s,b)
 tryCatch({
  r<-if(file.exists(p))readRDS(p) else boot_one_final(b,s)
  saveRDS(r,p)
  if(any(r$drop_kind=='dependency')){rv<-boot_one_final(b,s,reverse=TRUE);saveRDS(rv,sub('.rds$','_reverse.rds',p))}
  ep<-sub('.rds$','.error',p);if(file.exists(ep))file.remove(ep)
  cat(format(Sys.time()),s,b,'DONE retention',r$retention,'unsupported',sum(!r$support),'seconds',r$secs,'\n');flush.console()
 },error=function(e){failures<<-c(failures,paste(s,b,conditionMessage(e)));writeLines(conditionMessage(e),sub('.rds$','.error',p));cat(s,b,'FAILED',conditionMessage(e),'\n');flush.console()})
 if(budget_exhausted())break
}
if(length(failures))writeLines(failures,'bootstrap/PILOT_STOPPED') else writeLines('DONE','bootstrap/PILOT_COMPLETE')
file.remove('bootstrap/PILOT_RUNNING')
cat('PILOT FINISHED',format(Sys.time()),'failures',length(failures),'\n')
