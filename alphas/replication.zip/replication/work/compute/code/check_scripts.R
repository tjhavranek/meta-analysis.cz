.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
files<-c('run_finalize.R',list.files('code',pattern='\\.R$',full.names=TRUE))
res<-lapply(files,function(f){tryCatch({invisible(parse(f));data.frame(script=f,parse='PASS')},error=function(e)data.frame(script=f,parse=conditionMessage(e)))})
out<-do.call(rbind,res);write.csv(out,'validation/script_parse_checks.csv',row.names=FALSE);stopifnot(all(out$parse=='PASS'));cat('All',nrow(out),'scripts parsed\n')
