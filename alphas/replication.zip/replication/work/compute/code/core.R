.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
HERE <- normalizePath(getwd(), winslash='/')
if(any(grepl('--file=code/production.R',commandArgs(),fixed=TRUE)))writeLines(as.character(Sys.getpid()),'logs/production_coordinator.pid')
BMA_ROOT <- normalizePath('../..', winslash='/'); BMA_DATA_NOSAVE <- TRUE
source('code/bma_data.R'); source('code/bma_bestpractice.R')
RNGkind("L'Ecuyer-CMRG", 'Inversion', 'Rejection')
src <- deparse(BMS::bms)
hit <- grep('^    set.seed\\(as.numeric\\(Sys.time\\(\\)\\)\\)$',src)
stopifnot(length(hit)==1L)
seeded <- src[-hit]; bms_seeded <- eval(parse(text=seeded))
environment(bms_seeded) <- environment(BMS::bms)
if (!file.exists('code/bms_seeded.R')) {
 writeLines(c('.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))','bms_seeded <-',seeded,'environment(bms_seeded) <- asNamespace("BMS")'), 'code/bms_seeded.R')
 writeLines(c('--- BMS::bms','+++ local bms_seeded',paste0('- ',src[hit])), 'validation/bms_seed_patch.diff')
}
specs <- c('log','linear','quad_hier','nocit')
nine <- c('depvar_net_returns','data_midyear','database_cisdm','number_of_databases','market_bear','strategy_fund_of_funds','model_1factor','backfilling_treated','publication_year')
labs <- c('All strategies','All funds','Equity hedge','Event driven','Relative value','Global','Funds of funds','Multistrategy','Other')
xold <- bp_parse_lincom(BMA_DO,bma_regressors); X0 <- xold
means <- colMeans(bma_df[,-1]); strategy <- grep('^strategy_',bma_regressors,value=TRUE)
meanvars <- c('depvar_individual_funds','depvar_equalw_funds','database_default','database_cst','database_cisdm','number_of_databases','market_developed','market_bull','market_bear')
X0[,meanvars] <- matrix(means[meanvars],9,length(meanvars),byrow=TRUE)
X0[1,strategy] <- means[strategy]
X0[,'data_midyear'] <- log(max(bma_full$year_data)-1989)
X0[,'publication_year'] <- log(max(bma_full$year_publication)-2000)
X0[,'citations'] <- max(bma_full$citations); X0[,'impact_factor'] <- max(bma_full$impact_factor)
rownames(X0) <- labs
SET <- do.call(rbind,lapply(0:8,function(s) {z<-X0[c(1,7),,drop=FALSE]
 if(s %in% c(1,3,4)) z[,'method_iv']<-0
 if(s %in% c(2,3,4)) z[,'model_uncertainty']<-0
 if(s %in% c(2,3)) z[,'model_7factor']<-1
 if(s==5) z[,c('citations','impact_factor')]<-matrix(means[c('citations','impact_factor')],2,2,byrow=TRUE)
 if(s==6) z[,c('citations','impact_factor')]<-matrix(apply(bma_df[,c('citations','impact_factor')],2,median),2,2,byrow=TRUE)
 if(s==7) z[,c('data_cross_section','database_handcollect')]<-matrix(means[c('data_cross_section','database_handcollect')],2,2,byrow=TRUE)
 if(s==8) {v<-setdiff(bma_regressors,c('se_w','se_method_iv','depvar_net_returns','survivorship_treated','backfilling_treated','data_midyear','publication_year',strategy)); z[,v]<-matrix(means[v],2,length(v),byrow=TRUE)}
 rownames(z)<-paste0('S',s,':',rownames(z));z}))
vectors <- function(spec,settings=FALSE) {z<-if(settings) rbind(X0,SET) else X0
 if(spec %in% c('linear','quad_hier')) {z[,'data_midyear']<-25.5;z[,'publication_year']<-21}
 if(spec=='quad_hier') z<-cbind(z,data_year_c2=z[,'data_midyear']^2,pub_year_c2=z[,'publication_year']^2)
 if(spec=='nocit') z<-z[,!colnames(z)%in%c('citations','impact_factor'),drop=FALSE]; z}
design <- function(d,spec) {z<-d[,c('alpha_w',bma_regressors)]
 if(spec %in% c('linear','quad_hier')) {z$data_midyear<-d$year_data-1989;z$publication_year<-d$year_publication-2000}
 if(spec=='quad_hier'){z$data_year_c2<-z$data_midyear^2;z$pub_year_c2<-z$publication_year^2}
 if(spec=='nocit') z<-z[,!names(z)%in%c('citations','impact_factor')]; z}
hier_prior <- function(v,K=length(v)) {
 pairs<-list(c('data_year_c2','data_midyear'),c('pub_year_c2','publication_year'))
 prodpoly<-function(a,b){o<-numeric(length(a)+length(b)-1);for(i in seq_along(a))o[seq_along(b)+i-1]<-o[seq_along(b)+i-1]+a[i]*b;o}
 counts<-1;handled<-character()
 for(p in pairs){present<-p%in%v;handled<-c(handled,p[present]);term<-if(all(present))c(1,1,1) else if(present[2])c(1,1) else 1;counts<-prodpoly(counts,term)}
 for(vv in setdiff(v,handled))counts<-prodpoly(counts,c(1,1))
 counts<-c(counts,rep(0,length(v)+1-length(counts)));kk<-0:length(v)
 kd<-counts*exp(lbeta(kk+1,K-kk+1));kd<-kd/sum(kd)
 child<-match(c('data_year_c2','pub_year_c2'),v,nomatch=0L)
 parent<-match(c('data_midyear','publication_year'),v,nomatch=0L)
 lp<-lbeta(kk+1,K-kk+1)
 list(mp.mode='random_hierarchy',mp.msize=sum(kk*kd),mp.Kdist=kd,pmp=function(ki,mdraw,...) {
 if(child[1]>0L && mdraw[child[1]]==1 && (parent[1]==0L||mdraw[parent[1]]==0))return(-Inf)
 if(child[2]>0L && mdraw[child[2]]==1 && (parent[2]==0L||mdraw[parent[2]]==0))return(-Inf)
 lp[ki+1L]})
}
dilution_prior <- function(X) {
 R<-cor(X); ev<-pmax(eigen(R,symmetric=TRUE,only.values=TRUE)$values,0)
 pol<-1; for(e in ev) pol<-c(pol,0)+c(0,pol*e)
 probs<-pol/sum(pol)
 list(mp.mode='determinant_uniform',mp.msize=sum(ev/(1+ev)),mp.Kdist=probs,pmp=function(ki,mdraw,...) {
 if(ki<2) return(0); dd<-determinant(R[as.logical(mdraw),as.logical(mdraw),drop=FALSE],logarithm=TRUE)
 if(dd$sign<=0 || !is.finite(dd$modulus)) return(-Inf); as.numeric(dd$modulus)})
}
prior_for <- function(spec,X,arm='baseline') {if(arm=='dilution') return(dilution_prior(X));if(arm=='uniform') return('uniform');if(spec=='quad_hier') return(hier_prior(colnames(X),K=ncol(X)));'random'}
fit_chain <- function(df,spec,seed,burn=1e6,iter=3e6,nmodel=200000,start=0,arm='baseline') {
 if(budget_exhausted(reserve_seconds=(burn+iter)/4e6*1800))stop('BUDGET STOP: insufficient remaining budget for the scheduled full chain')
 set.seed(seed); bms_seeded(df,burn=burn,iter=iter,nmodel=nmodel,g=if(arm=='bric') max(nrow(df),ncol(df[-1])^2) else nrow(df),mprior=prior_for(spec,as.matrix(df[,-1]),arm),mcmc='bd',user.int=FALSE,start.value=start)
}
.bp_mix_quantile <- function(p,w,loc,sc,df) {br<-range(loc+sc*qt(p,df)); if(diff(br)<1e-13)return(mean(br));uniroot(function(q)sum(w*pt((q-loc)/sc,df))-p,br,tol=1e-11)$root}
analytic <- function(fit,z) {
 mq<-bp_model_quantities(fit,z);w<-mq$tm$w;sc<-sqrt(mq$vf*(mq$core$N-3)/(mq$core$N-1));df<-mq$core$N-1
 mu<-colSums(w*mq$m)
 out<-data.frame(row=rownames(z),mean=mu,sd=sqrt(pmax(0,colSums(w*(mq$vf+mq$m^2))-mu^2)),lo=sapply(seq_len(nrow(z)),function(r).bp_mix_quantile(.025,w,mq$m[,r],sc[,r],df)),hi=sapply(seq_len(nrow(z)),function(r).bp_mix_quantile(.975,w,mq$m[,r],sc[,r],df)),p_positive=colSums(w*pt(-mq$m/sc,df,lower.tail=FALSE)))
 stopifnot(max(abs(mu-predict(fit,z,exact=TRUE)))<1e-8);out
}
reweight_union <- function(fit) {
 z<-matrix(colMeans(as.matrix(fit$arguments$X.data)[,-1,drop=FALSE]),nrow=1,dimnames=list('sample_mean',fit$reg.names))
 mq<-bp_model_quantities(fit,z);tm<-mq$tm;co<-mq$core
 sse<-(mq$S-(1-co$cc)*co$yty)/co$cc
 stopifnot(all(sse>0))
 logprior<-vapply(seq_len(tm$nmodel),function(j)fit$mprior.info$pmp(ki=mq$k[j],mdraw=tm$incl[,j]),0.0)
 lik<-fit$gprior.info$lprobcalc$just.loglik(ymy=sse,k=mq$k)+logprior
 fresh<-exp(lik-max(lik));fresh<-fresh/sum(fresh)
 diagnostic<-data.frame(models=tm$nmodel,max_abs_weight_change=max(abs(fresh-tm$w)),sum_weights=sum(fresh),deduplicated=!anyDuplicated(fit$topmod$bool()))
 fit$topmod<-BMS:::topmod(nbmodels=tm$nmodel,nmaxregressors=co$K,bbeta=TRUE,liks=lik,ncounts=tm$ncount,modelbinaries=tm$incl,betas=mq$bmean,betas2=mq$bvar+mq$bmean^2,fixed_vector=fit$topmod$fixed_vector())
 list(fit=fit,diagnostic=diagnostic)
}
csv <- function(x,f){tmp<-paste0(f,'.writing_',Sys.getpid());write.csv(x,tmp,row.names=FALSE,na='');if(file.exists(f))file.remove(f);if(!file.rename(tmp,f))stop('Cannot finalize CSV: ',f);invisible(f)}
atomic_rds <- function(x,f){tmp<-paste0(f,'.writing_',Sys.getpid());saveRDS(x,tmp);if(file.exists(f))file.remove(f);if(!file.rename(tmp,f))stop('Cannot finalize RDS: ',f);invisible(f)}
budget_exhausted <- function(reserve_seconds=0) {
 if(!file.exists('logs/run_started_epoch.txt')||!file.exists('RUN_BUDGET_HOURS.txt'))return(FALSE)
 hours<-as.numeric(readLines('RUN_BUDGET_HOURS.txt',warn=FALSE)[1]);start<-as.numeric(readLines('logs/run_started_epoch.txt',warn=FALSE)[1])
 is.finite(hours) && (as.numeric(Sys.time())-start+reserve_seconds)>hours*3600
}
