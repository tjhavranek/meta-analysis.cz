.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
source('code/core.R')
# Reuse the production convergence routine without starting any additional MCMC fits.
expressions<-parse('code/production.R')
is_assignment<-function(e,name)is.call(e)&&identical(e[[1]],as.name('<-'))&&identical(e[[2]],as.name(name))
where<-which(vapply(expressions,is_assignment,TRUE,name='summarise_chains'));stopifnot(length(where)==1)
eval(expressions[[where]])
fit_chain<-function(...)stop('Initial diagnostics require extension; leave that fit to the production pool')
for(s in specs){
 paths<-sprintf('fits/%s_chain%d.rds',s,1:3)
 if(!all(file.exists(paths))){cat(s,'not ready\n');next}
 tryCatch({
  summarise_chains(s)
  path<-paste0('fits/',s,'_final.rds');f<-readRDS(path)
  if(s=='quad_hier'){hp<-hier_prior(names(f$arguments$X.data)[-1],36);f$mprior.info$mp.msize<-hp$mp.msize;f$mprior.info$mp.Kdist<-hp$mp.Kdist}
  rw<-reweight_union(f);f<-rw$fit;atomic_rds(f,path);csv(rw$diagnostic,paste0('validation/',s,'_union_reweight.csv'))
  ce<-coef(f,exact=TRUE,order.by.pip=FALSE,include.constant=TRUE);csv(data.frame(variable=rownames(ce),ce,check.names=FALSE),paste0('tables/',s,'_coefficients.csv'))
  aa<-analytic(f,vectors(s,settings=s=='log'));aa$spec<-s;aa$arm<-'baseline';csv(aa,paste0('tables/',s,'_m1.csv'))
  cat('PROMOTED',s,'after production convergence checks; no new chains\n')
 },error=function(e)cat('DEFERRED',s,conditionMessage(e),'\n'))
}
if(file.exists('fits/log_final.rds')){
 f<-readRDS('fits/log_final.rds');ce<-coef(f,exact=TRUE,order.by.pip=FALSE,include.constant=TRUE)
 t3<-data.frame(variable=rownames(ce),ce,check.names=FALSE)
 ol<-read.csv('tables/database_sensitivity.csv');ol<-ol[ol$spec=='original',];ix<-match(t3$variable,ol$variable);t3$ols_coefficient<-ol$coefficient[ix];t3$ols_cluster_se<-ol$se[ix];t3$ols_p<-ol$p[ix];csv(t3,'tables/table3.csv')
 mu<-read.csv('tables/log_m1.csv')$mean[1]
 eff<-data.frame(variable=bma_regressors,coefficient=ce[bma_regressors,'Post Mean'],sd=sapply(bma_df[-1],sd),range=sapply(bma_df[-1],function(x)diff(range(x))),pip=ce[bma_regressors,'PIP'],original_nine=bma_regressors%in%nine)
 eff$sd_change<-eff$coefficient*eff$sd;eff$range_change<-eff$coefficient*eff$range;eff$sd_percent<-100*eff$sd_change/mu;eff$range_percent<-100*eff$range_change/mu;csv(eff,'tables/table5.csv')
 source('code/validate_final_baseline.R')
}
source('run_finalize.R')
