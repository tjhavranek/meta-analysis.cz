# Figures 7 and 8 in the layout of the original submission:
# Table 3 variable labels, variables ordered by posterior inclusion probability, no title.
# Reads the saved fits only; nothing is re-estimated. Run from work/compute.
.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
library(BMS)
lab <- c(
  se_w = "Standard error (SE)", se_method_iv = "SE * IV method",
  depvar_individual_funds = "Individual funds", depvar_equalw_funds = "Equal-weighted funds",
  depvar_net_returns = "Net-of-fee returns", data_cross_section = "Cross-section data",
  data_midyear = "Data year", database_default = "Database: default",
  database_cst = "Database: CST", database_cisdm = "Database: CISDM",
  database_handcollect = "Database: hand-collected", number_of_databases = "Number of databases",
  market_developed = "Developed markets", market_bull = "Bull market", market_bear = "Bear market",
  strategy_all = "Strategy: all funds", strategy_equity = "Strategy: equity hedge",
  strategy_events = "Strategy: event driven", strategy_relative_value = "Strategy: relative value",
  strategy_global = "Strategy: global", strategy_fund_of_funds = "Strategy: fund of funds",
  strategy_multi = "Strategy: multi", method_iv = "IV method", model_1factor = "1-factor model",
  model_3factor = "3-factor model", model_4factor = "4-factor model", model_7factor = "7-factor model",
  model_uncertainty = "Modeling model uncertainty", model_asset_based = "Asset-based model",
  survivorship_treated = "Survivorship treated", backfilling_treated = "Backfilling treated",
  publication_year = "Publication year", citations = "Citations", impact_factor = "Impact factor")

dir.create("figures", showWarnings = FALSE)
base <- readRDS("fits/log_final.rds")
stopifnot(all(base$reg.names %in% names(lab)))
base$reg.names <- unname(lab[base$reg.names])
# main and xlab override the BMS defaults (a title with the model count, and an axis label).
draw7 <- function() image(base, cex.axis = 0.7, do.par = FALSE, main = "", xlab = "")
pdf("figures/F7_bma.pdf", width = 6, height = 5.6); par(mar = c(2.5, 10.5, 0.5, 0.5)); draw7(); dev.off()
# The manuscript uses a 450-dpi PNG (the vector file has about 200,000 shapes).
png("figures/F7_bma.png", width = 6, height = 5.6, units = "in", res = 450); par(mar = c(2.5, 10.5, 0.5, 0.5)); draw7(); dev.off()

priors <- c(baseline = "log", uniform = "prior_uniform", bric = "prior_bric", dilution = "prior_dilution")
pip <- sapply(priors, function(p) {
  ce <- read.csv(paste0("tables/", p, "_coefficients.csv"), check.names = FALSE)
  ce <- ce[ce$variable != "(Intercept)", ]
  setNames(ce$PIP, ce$variable)[names(lab)]
})
pip <- pip[order(-pip[, "baseline"]), ]
draw8 <- function() {
  par(mar = c(8.2, 4, 0.5, 0.5))
  n <- nrow(pip)
  plot(NA, xlim = c(1, n), ylim = c(0, 1), xaxt = "n", xlab = "", ylab = "Posterior inclusion probability",
       las = 1, cex.axis = 0.75, cex.lab = 0.8)
  pc <- c(16, 1, 3, 2); cl <- c("black", "seagreen3", "purple", "darkorange")
  for (j in 1:4) points(1:n, pip[, j], pch = pc[j], col = cl[j], cex = 0.8)
  axis(1, at = 1:n, labels = unname(lab[rownames(pip)]), las = 2, cex.axis = 0.55)
  legend("topright", bty = "n", cex = 0.75, pch = pc, col = cl,
         legend = c("UIP and random (baseline)", "UIP and uniform", "BRIC and random", "UIP and dilution"))
}
pdf("figures/F8_comparison.pdf", width = 7, height = 4); draw8(); dev.off()
cat("FIGURES 7-8 DONE\n")
