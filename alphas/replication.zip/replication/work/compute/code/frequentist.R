.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
if(dir.exists('code/Rlib')) .libPaths(c(normalizePath('code/Rlib'),.libPaths()))
source('code/core.R');library(clubSandwich)
sink('logs/frequentist_checks.log',split=TRUE);on.exit(sink())
ols <- function(d,v)lm(reformulate(v,'alpha_w'),d)
cr1 <- function(f,d) {V<-sandwich::vcovCL(f,cluster=d$study_id,type='HC0',cadjust=FALSE);b<-coef(f);se<-sqrt(diag(V));data.frame(variable=names(b),coefficient=b,se=se,lo=b-1.96*se,hi=b+1.96*se,p=2*pnorm(-abs(b/se)),N=nrow(d),studies=length(unique(d$study_id)))}
base<-ols(bma_full,nine);ten<-c(nine,'market_bull');ft<-ols(bma_full,ten)
cr2<-do.call(rbind,lapply(list(nine=nine,ten=ten),function(v){f<-ols(bma_full,v);V<-vcovCR(f,cluster=bma_study_id,type='CR2');ct<-as.data.frame(coef_test(f,vcov=V,test='Satterthwaite'));ci<-as.data.frame(conf_int(f,vcov=V,test='Satterthwaite'));print(ct);data.frame(spec=if(length(v)==9)'nine' else 'ten',variable=rownames(ct),coefficient=ct$beta,se=ct$SE,df=ct$df_Satt,lo=ci$CI_L,hi=ci$CI_U,p=ct$p_Satt)}))
csv(cr2,'tables/tableA6_CR2.csv')
loso<-list();j<-0
for(type in c('nine','ten'))for(id in sort(unique(bma_study_id))) {
 d<-bma_full[bma_study_id!=id,];r<-cr1(ols(d,if(type=='nine')nine else ten),d);r<-r[r$variable%in%c('depvar_net_returns','market_bull','market_bear'),];r$omitted_study_id<-id;r$omitted_study<-bma_full$study[match(id,bma_study_id)];r$spec<-type
 ix<-bma_study_id==id;r$gross_contributor<-any(bma_full$depvar_gross_returns[ix]==1);r$bull_contributor<-any(bma_full$market_bull[ix]==1);r$bear_contributor<-any(bma_full$market_bear[ix]==1);j<-j+1;loso[[j]]<-r
}
loso<-do.call(rbind,loso);csv(loso[loso$spec=='ten',],'tables/loso_ten_variables.csv');csv(loso,'tables/loso_all.csv')
summary<-list();j<-0
for(type in c('nine','ten'))for(var in c('depvar_net_returns','market_bull','market_bear'))for(subset in c('all','contributors')) {
 r<-loso[loso$spec==type & loso$variable==var,];if(subset=='contributors')r<-r[r[[switch(var,depvar_net_returns='gross_contributor',market_bull='bull_contributor',market_bear='bear_contributor')]],];if(!nrow(r))next
 j<-j+1;summary[[j]]<-data.frame(spec=type,variable=var,subset=subset,omissions=nrow(r),min=min(r$coefficient),max=max(r$coefficient),max_p=max(r$p),significant=sum(r$p<.05),N_min=min(r$N),N_max=max(r$N))
};csv(do.call(rbind,summary),'tables/tableA4.csv')
dbvars<-c('database_default','database_cst','database_cisdm','database_handcollect','database_other');key<-apply(bma_full[,dbvars],1,paste,collapse='+')
dbtab<-do.call(rbind,lapply(unique(key),function(k){ix<-key==k;data.frame(combination=k,bma_full[which(ix)[1],dbvars],estimates=sum(ix),studies=length(unique(bma_study_id[ix])),count_min=min(bma_full$number_of_databases[ix]),count_max=max(bma_full$number_of_databases[ix]),count_distinct=length(unique(bma_full$number_of_databases[ix])))}));csv(dbtab,'tables/database_combinations.csv')
bma_full$count_cisdm<-bma_full$number_of_databases*bma_full$database_cisdm
db<-list(original=list(d=bma_full,v=nine),no_cisdm=list(d=bma_full[bma_full$database_cisdm==0,],v=setdiff(nine,'database_cisdm')),count_interaction=list(d=bma_full,v=c(nine,'number_of_databases','count_cisdm')))
dbres<-do.call(rbind,lapply(names(db),function(s){d<-db[[s]]$d;r<-cr1(ols(d,unique(db[[s]]$v)),d);r$spec<-s;r}));csv(dbres,'tables/database_sensitivity.csv')
full<-ols(bma_full,bma_regressors);V<-sandwich::vcovCL(full,cluster=bma_study_id,type='HC0',cadjust=FALSE);z<-rbind(X0,SET);L<-cbind('(Intercept)'=1,z);b<-coef(full);est<-drop(L%*%b);se<-sqrt(rowSums((L%*%V)*L))
out<-data.frame(row=rownames(z),estimate=est,se=se,lo=est-1.96*se,hi=est+1.96*se,cr2_se=NA_real_,cr2_df=NA_real_,cr2_lo=NA_real_,cr2_hi=NA_real_)
# coef_test for a nonsingular reparameterization places each principal contrast first.
for(i in which(grepl('All strategies',rownames(z)))) {
 li<-L[i,];A<-diag(length(li));A[1,]<-li;W<-model.matrix(full)%*%solve(A);ff<-lm(bma_df$alpha_w~W-1)
 vv<-vcovCR(ff,cluster=bma_study_id,type='CR2');tt<-as.data.frame(coef_test(ff,vcov=vv,test='Satterthwaite'));ci<-as.data.frame(conf_int(ff,vcov=vv,test='Satterthwaite'))
 out$cr2_se[i]<-tt$SE[1];out$cr2_df[i]<-tt$df_Satt[1];out$cr2_lo[i]<-ci$CI_L[1];out$cr2_hi[i]<-ci$CI_U[1]
}
csv(out,'tables/ols_settings.csv')
ot<-do.call(rbind,lapply(specs,function(s){d<-design(bma_full,s);r<-bp_ols_lincom(d,bma_study_id,vectors(s),type='HC0',cadjust=FALSE);r$lo<-r$ols_est-1.96*r$ols_se;r$hi<-r$ols_est+1.96*r$ols_se;r$spec<-s;r}));csv(ot,'tables/ols_time_specifications.csv')
print(table(bma_full[['country...12']]));print(table(bma_full$market_world));print(names(bma_full))
# Figure 5 is the country boxplot in alphas.do: raw alpha restricted to (-3,3).
ix<-tolower(trimws(bma_full[['country...12']]))=='global funds' & bma_full$alpha > -3 & bma_full$alpha < 3
if(!any(ix))stop('Cannot identify global-country Figure 5 selection')
qu<-quantile(bma_full$alpha[ix],c(.25,.5,.75),type=2,names=FALSE)
csv(data.frame(selection='first country column = Global funds; -3 < raw alpha < 3; Figure 5 country boxplot',N=sum(ix),studies=length(unique(bma_study_id[ix])),q25=qu[1],median=qu[2],q75=qu[3],annual_q25=12*qu[1],annual_q75=12*qu[3]),'tables/global_market_quantiles.csv')
print(out[c(1,10,16),]);cat('FREQUENTIST COMPLETE\n')
