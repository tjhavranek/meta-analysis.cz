# Diagnostics only: never fit, repair, extend, or replace any saved draw.
source('code/core.R')
cap_B <- 1999L
cap_lines <- c('Post-bootstrap cap: diagnostics only; B=1999 per specification.',
 'No new chains, longer chains, reverse-priority repairs, upgrades, or bootstrap rounds are authorized.',
 'COMPLETE means capped computation finished; it does not certify numerical release readiness.')
cap_mc <- list(); cap_support <- list(); cap_fit <- list(); cap_pairs <- list()
for (s in specs) {
 paths <- sprintf('bootstrap/%s/rep_%04d.rds',s,seq_len(cap_B))
 stopifnot(all(file.exists(paths)))
 rr <- lapply(paths,readRDS)
 stopifnot(all(vapply(seq_along(rr),function(i)rr[[i]]$b==i && rr[[i]]$spec==s,logical(1))))
 est <- do.call(rbind,lapply(rr,`[[`,'est_exact'))
 freq <- do.call(rbind,lapply(rr,`[[`,'est_frequency'))
 sup <- do.call(rbind,lapply(rr,`[[`,'support'))
 set.seed(7202601+match(s,specs)-1)
 qs <- replicate(2000,apply(est[sample.int(cap_B,cap_B,replace=TRUE),,drop=FALSE],2,quantile,probs=c(.025,.975),type=7))
 mc <- apply(qs,c(1,2),sd)
 cap_mc[[s]] <- data.frame(spec=s,row=colnames(est),B=cap_B,lo_mcse=mc[1,],hi_mcse=mc[2,])
 cap_support[[s]] <- data.frame(spec=s,row=colnames(est),B=cap_B,unsupported=colSums(!sup))
 ret <- vapply(rr,`[[`,numeric(1),'retention')
 cap_fit[[s]] <- data.frame(spec=s,min_retention=min(ret),max_retention=max(ret),max_exact_frequency=max(abs(est-freq)))
 # Independent comparisons are evaluated only if already saved.
 for (i in seq_along(paths)) {
  lp <- sub('.rds$','_long.rds',paths[i])
  if(!file.exists(lp))next
  sp <- sub('.rds$','_short.rds',paths[i])
  old <- if(file.exists(sp))readRDS(sp) else rr[[i]]
  if(isTRUE(old$long))next
  lng <- readRDS(lp)
  cap_pairs[[length(cap_pairs)+1L]] <- data.frame(spec=s,b=i,row=names(old$est_exact),difference=lng$est_exact-old$est_exact)
 }
 cap_lines <- c(cap_lines,sprintf('%s: B=%d; endpoint MCSE max=%.6f (target <=0.02: %s); retained-model occupancy %.6f to %.6f; max exact/frequency difference %.6f; unsupported evaluations %d.',s,cap_B,max(mc),if(max(mc)<=.02)'PASS' else 'FAIL',min(ret),max(ret),max(abs(est-freq)),sum(!sup)))
}
csv(do.call(rbind,cap_mc),'validation/bootstrap_endpoint_mcse.csv')
csv(do.call(rbind,cap_support),'validation/capped_support.csv')
csv(do.call(rbind,cap_fit),'validation/capped_saved_fit_diagnostics.csv')
if(length(cap_pairs)) {
 cp <- do.call(rbind,cap_pairs);csv(cp,'validation/capped_existing_chain_comparison.csv')
 cap_lines <- c(cap_lines,sprintf('Existing short/long comparisons only: %d row comparisons; RMS difference %.6f; max absolute difference %.6f. No new independent chains run.',nrow(cp),sqrt(mean(cp$difference^2)),max(abs(cp$difference))))
} else cap_lines <- c(cap_lines,'Bootstrap independent-chain convergence: NOT ASSESSED (no saved short/long pairs); occupancy and exact/frequency agreement do not establish convergence.')
for(f in list.files('validation',pattern='_convergence.csv$',full.names=TRUE)) {
 d <- read.csv(f)
 passed <- if(grepl('_union_convergence.csv$',f))isTRUE(tail(d$pass,1)) else all(d$pass)
 cap_lines <- c(cap_lines,paste(basename(f),'saved convergence pass:',passed))
}
writeLines(cap_lines,'validation/capped_diagnostics.md')
# Record diagnostics before finalization; the finalizer also preserves them.
for(p in c('STATUS.md','validation/release_checks.md'))write(cap_lines,p,append=TRUE)
source('run_finalize.R')
writeLines(paste('DONE: capped diagnostics and finalization',format(Sys.time())),'bootstrap/COMPLETE')
ch <- read.csv('validation/release_checks.csv',stringsAsFactors=FALSE)
ch$pass[ch$check=='All capped bootstrap draws and finalization'] <- TRUE
csv(ch,'validation/release_checks.csv')
# Refresh marker text without running the finalizer twice.
for(p in c('STATUS.md','validation/release_checks.md')) {
 x <- readLines(p,warn=FALSE)
 x <- sub('Computation complete marker: FALSE','Computation complete marker: TRUE',x,fixed=TRUE)
 x <- sub('Bootstrap complete: FALSE','Bootstrap complete: TRUE (capped computation only)',x,fixed=TRUE)
 x <- sub('All numerical release checks passed: FALSE',paste('All numerical release checks passed:',all(ch$pass)),x,fixed=TRUE)
 writeLines(c(x,'Capped finalization finished; bootstrap/COMPLETE records execution, not a convergence or release pass.'),p)
}
cat('CAPPED FINALIZATION COMPLETE',format(Sys.time()),'\n')
