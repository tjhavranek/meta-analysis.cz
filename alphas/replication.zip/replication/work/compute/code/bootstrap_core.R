.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
source('code/core.R')
IDS<-readRDS('validation/study_id_order.rds');ROWS<-lapply(IDS,function(id)which(bma_study_id==id))
sample_studies <- function(b) {set.seed(1000+b);draw<-sample.int(length(IDS),length(IDS),replace=TRUE);d<-bma_full[unlist(ROWS[draw]),,drop=FALSE];d$boot_cluster<-rep(seq_along(draw),lengths(ROWS[draw]));a<-winsor2_stata(d$alpha);s<-winsor2_stata(d$se);cuts<-c(attr(a,'cuts'),attr(s,'cuts'));attributes(a)<-attributes(s)<-NULL;d$alpha_w<-a;d$se_w<-s;d$se_method_iv<-s*d$method_iv;list(d=d,draw=IDS[draw],cuts=cuts)}
rank_info <- function(X,z,reverse=FALSE) {
 X<-as.matrix(X);v<-colnames(X);ord<-if(reverse)rev(seq_along(v)) else seq_along(v)
 sdv<-apply(X,2,sd);keep<-which(sdv>1e-14);keep<-ord[ord%in%keep]
 Z<-scale(X[,keep,drop=FALSE]);q<-qr(cbind(1,Z),tol=1e-8);sel<-q$pivot[seq_len(q$rank)]
 # Explicit parentheses prevent precedence ambiguity in pivot membership.
 kk<-keep[(seq_along(keep)+1L)%in%sel]
 dropped<-setdiff(seq_along(v),kk)
 kinds<-ifelse(sdv[dropped]<1e-14,ifelse(abs(colMeans(X)[dropped])<1e-14,'absent_zero','constant_nonzero'),'dependency')
 # Estimability is computed in standardized coordinates, retaining constant original columns.
 mn<-colMeans(X);ss<-sdv;ss[ss<1e-14]<-1
 ZZ<-cbind(1,sweep(sweep(X,2,mn),2,ss,'/'));zz<-cbind(1,sweep(sweep(z,2,mn),2,ss,'/'))
 qq<-qr(t(ZZ),tol=1e-8);Q<-qr.Q(qq)[,seq_len(qq$rank),drop=FALSE];err<-sqrt(rowSums((zz-zz%*%Q%*%t(Q))^2));support<-err<1e-8*pmax(1,sqrt(rowSums(zz^2)))
 list(keep=v[sort(kk)],dropped=v[dropped],kind=kinds,support=support,support_error=err,rank=q$rank)
}
boot_one_final <- function(b,spec,long=FALSE,reverse=FALSE) {
 if(file.exists('validation/POST_BOOTSTRAP_CAP') && (isTRUE(long) || b>1999L))stop('CAPPED: no longer chains or additional bootstrap rounds')
 if(budget_exhausted())stop('BUDGET STOP: no new bootstrap fit started')
 t0<-Sys.time();sm<-sample_studies(b);df<-design(sm$d,spec);z<-vectors(spec,settings=spec=='log');ri<-rank_info(df[,-1],z,reverse)
 df<-df[,c('alpha_w',ri$keep),drop=FALSE];zz<-z[,ri$keep,drop=FALSE];s<-match(spec,specs)-1
 seed<-500000+10000*s+b+if(long)1000000 else 0
 fit<-fit_chain(df,spec,seed,burn=if(long)1e6 else 1e5,iter=if(long)3e6 else 3e5,nmodel=if(long)200000 else 5000,start=0)
 ce<-coef(fit,exact=TRUE,order.by.pip=FALSE,include.constant=TRUE);cc<-setNames(rep(0,ncol(z)+1),c('(Intercept)',colnames(z)));cc[rownames(ce)]<-ce[,'Post Mean']
 pp<-setNames(rep(0,ncol(z)),colnames(z));pp[ri$keep]<-ce[ri$keep,'PIP'];pe<-setNames(drop(predict(fit,zz,exact=TRUE)),rownames(z));pf<-setNames(drop(predict(fit,zz,exact=FALSE)),rownames(z))
 stopifnot(max(abs(drop(cbind(1,z)%*%cc)-pe))<1e-8)
 list(b=b,spec=spec,long=long,reverse=reverse,N=nrow(df),draw=sm$draw,cuts=sm$cuts,cluster_sizes=table(sm$d$boot_cluster),dropped=ri$dropped,drop_kind=ri$kind,rank=ri$rank,nominal_K=ncol(z),prior_K=ncol(df)-1,support=ri$support,support_error=ri$support_error,coef=cc,pip=pp,est_exact=pe,est_frequency=pf,retention=bp_top_models(fit)$mass_share_mcmc,seed=seed,g=fit$gprior.info$g,secs=as.numeric(Sys.time()-t0,units='secs'))
}
