.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
source('code/core.R')
f<-readRDS('fits/log_chain1.rds');a<-analytic(f,X0[1,,drop=FALSE]);u<-read.csv('tables/log_m1.csv')[1,]
csv(data.frame(row='All strategies',chain1_mean=a$mean,chain1_lo=a$lo,chain1_hi=a$hi,union_mean=u$mean,union_lo=u$lo,union_hi=u$hi,lo_difference=u$lo-a$lo,hi_difference=u$hi-a$hi),'validation/log_union_endpoint_check.csv')
print(read.csv('validation/log_union_endpoint_check.csv'))
