.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
source('code/core.R')
files<-list.files('fits',pattern='_chain[123]\\.rds$',full.names=TRUE)
ds<-list();bs<-list()
for(p in files){f<-readRDS(p);tag<-sub('_chain[123]\\.rds$','',basename(p));s<-if(tag%in%specs)tag else 'log';z<-vectors(s,settings=s=='log');tm<-bp_top_models(f);pe<-predict(f,z,exact=TRUE);pf<-predict(f,z,exact=FALSE)
 ds[[p]]<-data.frame(file=p,spec=s,retention=tm$mass_share_mcmc,models=tm$nmodel,max_exact_frequency=max(abs(pe-pf)),N=f$info$N,g=f$gprior.info$g)
 bs[[p]]<-data.frame(file=p,row=rownames(z),mean=pe,frequency_mean=pf)
}
if(length(ds)){d<-do.call(rbind,ds);csv(d,'validation/current_chain_diagnostics.csv');csv(do.call(rbind,bs),'validation/current_chain_benchmarks.csv');print(d)}
cat('PRELIMINARY SAVED-CHAIN SNAPSHOT; NOT THE FINAL UNION\n')
