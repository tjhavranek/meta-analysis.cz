.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
## bma_data.R -- rebuild the BMA dataset of the hedge-fund meta-analysis exactly as
## data/alphas.do does it (Stata), and save it as bma_data.rds.
##
## Source it from any script:
##   source(file.path(normalizePath("../..", winslash="/"), "work/bma/bma_data.R"))
## After sourcing, the workspace holds
##   bma_regressors : the 34 regressors, in the column order of hedge_4R.xlsx (alphas.do l.150)
##   bma_df         : data.frame, alpha_w (dependent, first column) + the 34 regressors,
##                    i.e. exactly the `datahedge` that the R code in alphas.do passes to bms()
##   bma_study_id   : study_id for each row (cluster variable)
##   bma_full       : the whole spreadsheet plus the constructed columns
##   winsor2_stata(): Stata winsor2 replica (used here, reusable)
## and bma_data.rds is (re)written next to this file unless BMA_DATA_NOSAVE is TRUE.
##
## Construction (alphas.do lines 17-29 and 149-151):
##   winsor2 alpha, suffix(_w) cuts(1 99)
##   winsor2 se,    suffix(_w) cuts(1 99)
##   gen se_method_iv = se_w * method_iv
## winsor2 calls `_pctile x, p(1 99)` (Stata default percentile definition) on the
## non-missing values and replaces x by max(min(p99, x), p1). Stata's default _pctile
## definition (no weights): with n sorted values and P = n*p/100, the percentile is
## x_(ceil P) if P is not an integer and (x_(P)+x_(P+1))/2 if it is. That is R's
## quantile(type = 2).  The time variables data_midyear and publication_year are used
## as stored in alphas.xlsx, which already holds ln(year_data - 1989) and
## ln(year_publication - 2000); the script verifies this.

.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
suppressPackageStartupMessages(library(readxl))

if (!exists("BMA_ROOT")) {
  BMA_ROOT <- normalizePath('../..', winslash='/')
}
BMA_XLSX <- file.path(BMA_ROOT, "data", "alphas.xlsx")
BMA_DO   <- file.path(BMA_ROOT, "data", "alphas.do")
BMA_OUT  <- normalizePath(getwd(), winslash='/')

## Stata winsor2 replica ----------------------------------------------------------
winsor2_stata <- function(x, low = 1, high = 99) {
  ok <- !is.na(x)
  q  <- stats::quantile(x[ok], probs = c(low, high) / 100, type = 2, names = FALSE)
  out <- x
  out[ok] <- pmax(pmin(q[2], x[ok]), q[1])
  attr(out, "cuts") <- q
  out
}

## the 34 regressors in the order of the `order` statement, alphas.do line 150 ----
bma_regressors <- c(
  "se_w", "se_method_iv", "depvar_individual_funds", "depvar_equalw_funds",
  "depvar_net_returns", "data_cross_section", "data_midyear", "database_default",
  "database_cst", "database_cisdm", "database_handcollect", "number_of_databases",
  "market_developed", "market_bull", "market_bear", "strategy_all",
  "strategy_equity", "strategy_events", "strategy_relative_value", "strategy_global",
  "strategy_fund_of_funds", "strategy_multi", "method_iv", "model_1factor",
  "model_3factor", "model_4factor", "model_7factor", "model_uncertainty",
  "model_asset_based", "survivorship_treated", "backfilling_treated",
  "publication_year", "citations", "impact_factor")

## cross-check the list against the `order` line in alphas.do (fails loudly if not equal)
local_check_order <- function(do_file, regs) {
  if (!file.exists(do_file)) return(invisible(NA))
  dl <- readLines(do_file, warn = FALSE)
  ol <- grep("^order study_id alpha_w", dl, value = TRUE)
  if (length(ol) != 1) stop("could not find the unique `order` line in alphas.do")
  v <- strsplit(trimws(ol), "\\s+")[[1]][-1]
  v <- setdiff(v, c("study_id", "alpha_w"))
  if (!identical(v, regs)) stop("regressor order differs from alphas.do line 150")
  invisible(TRUE)
}
local_check_order(BMA_DO, bma_regressors)

build_bma_data <- function(xlsx = BMA_XLSX) {
  d <- suppressMessages(as.data.frame(readxl::read_excel(xlsx, sheet = "data")))
  if (nrow(d) != 1019) stop("expected 1,019 rows, got ", nrow(d))
  if (any(is.na(d$alpha)) || any(is.na(d$se))) stop("missing alpha or se")
  d$alpha_w <- winsor2_stata(d$alpha, 1, 99)
  d$se_w    <- winsor2_stata(d$se, 1, 99)
  cuts <- rbind(alpha = attr(d$alpha_w, "cuts"), se = attr(d$se_w, "cuts"))
  colnames(cuts) <- c("p1", "p99")
  attr(d$alpha_w, "cuts") <- NULL; attr(d$se_w, "cuts") <- NULL
  d$se_method_iv <- d$se_w * d$method_iv
  ## the time variables must be logs of the shifted years
  dev_dy <- max(abs(d$data_midyear - log(d$year_data - 1989)))
  dev_py <- max(abs(d$publication_year - log(d$year_publication - 2000)))
  miss <- setdiff(c("study_id", bma_regressors), names(d))
  if (length(miss)) stop("missing columns: ", paste(miss, collapse = ", "))
  if (any(is.na(d[, bma_regressors]))) stop("NA in a regressor")
  bma_df <- d[, c("alpha_w", bma_regressors)]
  rownames(bma_df) <- NULL
  list(bma_df = bma_df, study_id = d$study_id, full = d, cuts = cuts,
       time_check = c(max_dev_data_midyear_vs_ln_year_minus_1989 = dev_dy,
                      max_dev_publication_year_vs_ln_year_minus_2000 = dev_py),
       n_winsorized = c(alpha_low = sum(d$alpha < cuts["alpha", "p1"]),
                        alpha_high = sum(d$alpha > cuts["alpha", "p99"]),
                        se_low = sum(d$se < cuts["se", "p1"]),
                        se_high = sum(d$se > cuts["se", "p99"])))
}

bma_data <- build_bma_data()
bma_df       <- bma_data$bma_df
bma_study_id <- bma_data$study_id
bma_full     <- bma_data$full

if (!isTRUE(get0("BMA_DATA_NOSAVE", ifnotfound = FALSE))) {
  saveRDS(list(bma_df = bma_df, study_id = bma_study_id, regressors = bma_regressors,
               cuts = bma_data$cuts, time_check = bma_data$time_check,
               n_winsorized = bma_data$n_winsorized,
               source = BMA_XLSX, built = Sys.time()),
          file.path(BMA_OUT, "bma_data.rds"))
}

if (sys.nframe() == 0L || isTRUE(get0("BMA_DATA_VERBOSE", ifnotfound = FALSE))) {
  cat("bma_data.R: N =", nrow(bma_df), " studies =", length(unique(bma_study_id)),
      " K =", length(bma_regressors), "\n")
  cat("winsor cut points (p1, p99):\n"); print(bma_data$cuts, digits = 10)
  cat("values replaced:\n"); print(bma_data$n_winsorized)
  cat("time-variable check (max abs deviation from logs):\n"); print(bma_data$time_check)
}
