.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
## bma_bestpractice.R -- functions for best-practice ("implied") values from a BMS fit
## with a fixed g-prior (UIP etc.), and for their uncertainty. No side effects: source it.
##
##   bp_parse_lincom(do_file, regressors)   evaluation vectors x0 of the lincom lines in alphas.do
##   bp_top_models(bma)                     top-model inclusion matrix, exact PMPs, MCMC mass share
##   bp_model_quantities(bma, x0)           per-model posterior quantities under Zellner's g-prior
##   bp_M1(bma, x0, ndraw, seed)            exact BMA posterior of the fitted value x0'beta (mixture)
##   bp_M2(bma, x0, cluster)                law of total variance, study-clustered within-model var.
##   bp_ols_lincom(X.data, cluster, x0)     full-variable OLS lincom with cluster-robust SEs
##   bp_dilution_mprior(X, power)           George (2010) dilution model prior as a BMS custom mprior
##
## Notation follows Zeugner and Feldkircher (2015, JSS) and the BMS source (v0.3.5):
## y and X are demeaned; for model M with k regressors, bhat = OLS on demeaned data,
## c = g/(1+g), S = yty * (1 - c R2_M), yty = (y-ybar)'(y-ybar);
##   E(beta|M,y)   = c * bhat
##   Cov(beta|M,y) = S/(N-3) * c * (X_M'X_M)^{-1}       (multivariate t, N-1 df)
## The intercept has a flat prior; with demeaned X it is ybar, and given sigma^2 it is
## N(ybar, sigma^2/N), independent of beta. Hence the fitted value f = ybar + (x0-xbar)'beta
## is, within model M, Student t with N-1 df, location m_M = ybar + c (x0-xbar)'bhat and
## variance S/(N-3) * (1/N + c (x0-xbar)'(X_M'X_M)^{-1}(x0-xbar)).
## This is exactly BMS's pred.density() without the observation-noise term ("1 +").

.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
suppressPackageStartupMessages({ library(BMS); library(sandwich) })

## ---- evaluation vectors -----------------------------------------------------------
bp_parse_lincom <- function(do_file, regressors) {
  dl <- readLines(do_file, warn = FALSE)
  li <- grep("^lincom _cons", dl)
  if (!length(li)) stop("no lincom lines found")
  labs <- sub("^\\*\\s*", "", dl[li - 1])
  x0 <- matrix(NA_real_, length(li), length(regressors),
               dimnames = list(labs, regressors))
  for (r in seq_along(li)) {
    terms <- strsplit(sub("^lincom\\s+", "", trimws(dl[li[r]])), "+", fixed = TRUE)[[1]]
    terms <- trimws(terms)
    if (terms[1] != "_cons") stop("lincom line ", li[r], " does not start with _cons")
    terms <- terms[-1]
    vn <- sub("\\*.*$", "", terms)
    vv <- as.numeric(sub("^[^*]*\\*", "", terms))
    if (anyNA(vv) || anyDuplicated(vn) || !setequal(vn, regressors))
      stop("lincom line ", li[r], " does not list every regressor exactly once")
    x0[r, vn] <- vv
  }
  attr(x0, "do_lines") <- li
  x0
}

## ---- top models ----------------------------------------------------------------------
bp_top_models <- function(bma) {
  incl <- bma$topmod$bool_binary()               # K x M, 0/1
  lik  <- bma$topmod$lik()                       # log marginal likelihood + log model prior
  w    <- exp(lik - max(lik)); w <- w / sum(w)   # exact PMPs normalised over the top models
  cnt  <- bma$topmod$ncount()
  list(incl = incl, w = w, lik = lik, ncount = cnt,
       mass_share_mcmc = sum(cnt) / bma$info$cumsumweights,
       nmodel = ncol(incl))
}

## internal: demeaned data and cross products, from the bma object itself
.bp_core <- function(bma) {
  Xd <- as.matrix(bma$arguments$X.data)
  y <- Xd[, 1]; X <- Xd[, -1, drop = FALSE]
  N <- nrow(X); K <- ncol(X)
  if (!isTRUE(bma$gprior.info$is.constant)) stop("only fixed-g priors are supported")
  g <- bma$gprior.info$g
  xbar <- colMeans(X); ybar <- mean(y)
  Xc <- sweep(X, 2, xbar); yc <- y - ybar
  list(y = y, X = X, Xc = Xc, yc = yc, N = N, K = K, g = g, cc = g / (1 + g),
       xbar = xbar, ybar = ybar, XtX = crossprod(Xc), Xty = drop(crossprod(Xc, yc)),
       yty = sum(yc^2), names = colnames(X))
}

.bp_x0 <- function(x0, core) {
  x0 <- as.matrix(x0)
  if (is.null(dim(x0)) || ncol(x0) != core$K) x0 <- matrix(x0, ncol = core$K)
  if (!is.null(colnames(x0)) && !identical(colnames(x0), core$names)) {
    if (!setequal(colnames(x0), core$names)) stop("x0 columns do not match the regressors")
    x0 <- x0[, core$names, drop = FALSE]
  }
  x0
}

## ---- per-model quantities ------------------------------------------------------------
bp_model_quantities <- function(bma, x0, tm = bp_top_models(bma), keep_chol = FALSE) {
  core <- .bp_core(bma); x0 <- .bp_x0(x0, core)
  D <- t(x0) - core$xbar                          # K x R deviations from sample means
  M <- tm$nmodel; R <- ncol(D); K <- core$K; N <- core$N; cc <- core$cc
  m   <- matrix(core$ybar, M, R)                  # within-model posterior mean of f
  vf  <- matrix(NA_real_, M, R)                   # within-model posterior variance of f
  qf  <- matrix(0, M, R)                          # d'(X'X)^-1 d
  bmean <- matrix(0, K, M); bvar <- matrix(0, K, M)
  S <- numeric(M); kk <- integer(M)
  chols <- if (keep_chol) vector("list", M) else NULL
  for (j in seq_len(M)) {
    idx <- which(tm$incl[, j] == 1); k <- length(idx); kk[j] <- k
    if (k == 0) {
      S[j] <- core$yty
    } else {
      XtXi <- chol2inv(chol(core$XtX[idx, idx, drop = FALSE]))
      b <- drop(XtXi %*% core$Xty[idx])
      R2 <- sum(core$Xty[idx] * b) / core$yty
      S[j] <- core$yty * (1 - cc * R2)
      Dk <- D[idx, , drop = FALSE]
      m[j, ] <- core$ybar + cc * drop(crossprod(Dk, b))
      qf[j, ] <- colSums(Dk * (XtXi %*% Dk))
      bmean[idx, j] <- cc * b
      bvar[idx, j]  <- S[j] / (N - 3) * cc * diag(XtXi)
      if (keep_chol) chols[[j]] <- list(idx = idx, b = cc * b, U = chol(cc * XtXi))
    }
    vf[j, ] <- S[j] / (N - 3) * (1 / N + cc * qf[j, ])
  }
  colnames(m) <- colnames(vf) <- rownames(x0)
  list(m = m, vf = vf, qf = qf, S = S, k = kk, bmean = bmean, bvar = bvar,
       chols = chols, core = core, x0 = x0, D = D, tm = tm)
}

## mixture CDF quantile (exact, by root finding)
.bp_mix_quantile <- function(p, w, loc, sc, df) {
  f <- function(q) sum(w * pt((q - loc) / sc, df = df)) - p
  lo <- min(loc - 50 * sc); hi <- max(loc + 50 * sc)
  uniroot(f, c(lo, hi), tol = 1e-12)$root
}

## ---- M1: exact BMA posterior of the fitted value -------------------------------------
## The exact columns (mean, sd, q025, q975, p_positive) are analytic; sim_* come from
## ndraw iid draws (model ~ exact PMP, then sigma^2, intercept and beta jointly, i.e. the
## multivariate t). Rare models in the tails make the simulated SD and 2.5% quantile
## converge slowly, so use ndraw >= 1e6 when the simulation should match to 3 dp.
bp_M1 <- function(bma, x0, ndraw = 2e6, seed = 2026, mq = NULL, keep_draws = FALSE) {
  if (is.null(mq)) mq <- bp_model_quantities(bma, x0, keep_chol = TRUE)
  if (is.null(mq$chols)) stop("mq must be computed with keep_chol = TRUE")
  core <- mq$core; tm <- mq$tm; w <- tm$w; N <- core$N; K <- core$K; R <- ncol(mq$m)
  df <- N - 1
  ## analytic mixture moments
  mean_a <- colSums(w * mq$m)
  var_a  <- colSums(w * (mq$vf + mq$m^2)) - mean_a^2
  sc <- sqrt(mq$vf * (N - 3) / (N - 1))          # t scale within model
  q_exact <- sapply(seq_len(R), function(r)
    c(.bp_mix_quantile(0.025, w, mq$m[, r], sc[, r], df),
      .bp_mix_quantile(0.975, w, mq$m[, r], sc[, r], df)))
  p_pos_exact <- sapply(seq_len(R), function(r)
    sum(w * pt((0 - mq$m[, r]) / sc[, r], df = df, lower.tail = FALSE)))
  ## simulation from the mixture: draw a model, then (sigma^2, intercept, beta) jointly
  set.seed(seed)
  mdl <- sample.int(tm$nmodel, ndraw, replace = TRUE, prob = w)
  fdraw <- matrix(NA_real_, ndraw, R, dimnames = list(NULL, colnames(mq$m)))
  ## coefficient draws are not stored; running sums give their simulated mean and SD
  csum <- numeric(K + 1); csq <- numeric(K + 1)
  pos <- split(seq_len(ndraw), mdl)
  for (jj in names(pos)) {
    j <- as.integer(jj); rows <- pos[[jj]]; nj <- length(rows)
    sig2 <- mq$S[j] / rchisq(nj, df)
    astar <- core$ybar + sqrt(sig2 / N) * rnorm(nj)
    ch <- mq$chols[[j]]
    if (is.null(ch)) {
      fdraw[rows, ] <- astar
      a <- astar
    } else {
      Z <- matrix(rnorm(nj * length(ch$idx)), nj, length(ch$idx))
      beta <- sweep((Z %*% ch$U) * sqrt(sig2), 2, ch$b, "+")
      fdraw[rows, ] <- astar + beta %*% mq$D[ch$idx, , drop = FALSE]
      a <- astar - drop(beta %*% core$xbar[ch$idx])
      csum[ch$idx] <- csum[ch$idx] + colSums(beta)
      csq[ch$idx]  <- csq[ch$idx] + colSums(beta^2)
    }
    csum[K + 1] <- csum[K + 1] + sum(a); csq[K + 1] <- csq[K + 1] + sum(a^2)
  }
  cmean <- csum / ndraw
  csd <- sqrt((csq - ndraw * cmean^2) / (ndraw - 1))
  summ <- data.frame(row = colnames(mq$m),
                     mean = mean_a, sd = sqrt(var_a),
                     q025 = q_exact[1, ], q975 = q_exact[2, ], p_positive = p_pos_exact,
                     sim_mean = colMeans(fdraw), sim_sd = apply(fdraw, 2, sd),
                     sim_q025 = apply(fdraw, 2, quantile, 0.025, names = FALSE),
                     sim_q975 = apply(fdraw, 2, quantile, 0.975, names = FALSE),
                     sim_p_positive = colMeans(fdraw > 0), row.names = NULL)
  ## validation against BMS
  ce <- coef(bma, exact = TRUE, order.by.pip = FALSE, include.constant = TRUE)
  my_mean <- drop(mq$bmean %*% w)
  my_sd   <- sqrt(drop((mq$bvar + mq$bmean^2) %*% w) - my_mean^2)
  my_pip  <- drop(tm$incl %*% w)
  pr <- predict(bma, newdata = mq$x0, exact = TRUE)
  val <- list(
    max_abs_coef_mean_vs_bms = max(abs(my_mean - ce[core$names, "Post Mean"])),
    max_abs_coef_sd_vs_bms   = max(abs(my_sd - ce[core$names, "Post SD"])),
    max_abs_pip_vs_bms       = max(abs(my_pip - ce[core$names, "PIP"])),
    max_abs_topmod_betas     = max(abs(mq$bmean - bma$topmod$betas())),
    max_abs_topmod_betas2    = max(abs(mq$bvar + mq$bmean^2 - bma$topmod$betas2())),
    max_abs_fit_vs_predict   = max(abs(mean_a - pr)),
    intercept_mine = core$ybar - sum(core$xbar * my_mean),
    intercept_bms  = ce["(Intercept)", "Post Mean"],
    sim_coef_mean_maxdev = max(abs(cmean[seq_len(K)] - my_mean)),
    sim_coef_sd_maxdev   = max(abs(csd[seq_len(K)] - my_sd)),
    sim_intercept_mean   = cmean[K + 1],
    n_distinct_models_drawn = length(pos))
  out <- list(summary = summ, validation = val, mass_share_mcmc = tm$mass_share_mcmc,
              nmodel = tm$nmodel, ndraw = ndraw, seed = seed)
  if (keep_draws) out$fdraw <- fdraw
  out
}

## check of the within-model formula against BMS's own pred.density():
## within model M, predictive variance of a new observation = posterior variance of f
## + S/(N-3). Note: pred.density()$std.err averages only the within-model variances
## (BMS 0.3.5: Varyf = Sigmas %*% pmps); it omits the between-model dispersion of the
## model means, so it is compared with the within-model average here. Its densities()
## are proper mixtures.
bp_check_pred_density <- function(bma, x0, mq) {
  core <- mq$core; w <- mq$tm$w; N <- core$N
  mean_a <- colSums(w * mq$m)
  vpred_within <- colSums(w * (mq$vf + mq$S / (N - 3)))
  pd <- pred.density(bma, newdata = mq$x0)
  c(pred_density_max_abs_fit = max(abs(pd$fit - mean_a)),
    pred_density_max_abs_sd_within = max(abs(pd$std.err - sqrt(vpred_within))))
}

## ---- cluster-robust covariance of a linear combination, fast ------------------------
## Var(L'theta) for OLS of yc on [1, Xc_M], CR1 as sandwich::vcovCL(type = "HC1"):
## adj = G/(G-1) * (N-1)/(N-p), p = k + 1.  `cadjust`/`type` mimic vcovCL arguments.
.bp_crvar <- function(Z, e, cl, L, type = "HC1", cadjust = TRUE) {
  N <- nrow(Z); p <- ncol(Z)
  G <- length(unique(cl))
  bread <- chol2inv(chol(crossprod(Z)))
  Ug <- rowsum(Z * e, cl, reorder = FALSE)
  adj <- 1
  if (cadjust) adj <- adj * G / (G - 1)
  if (type == "HC1") adj <- adj * (N - 1) / (N - p)
  W <- bread %*% L
  adj * colSums((Ug %*% W)^2)
}

## ---- M2: law of total variance, study-clustered within-model variance --------------
bp_M2 <- function(bma, x0, cluster, mq = NULL, type = "HC1", cadjust = TRUE,
                  n_check = 25) {
  if (is.null(mq)) mq <- bp_model_quantities(bma, x0)
  core <- mq$core; tm <- mq$tm; w <- tm$w; cc <- core$cc
  M <- tm$nmodel; R <- ncol(mq$m)
  within <- matrix(NA_real_, M, R, dimnames = list(NULL, colnames(mq$m)))
  for (j in seq_len(M)) {
    idx <- which(tm$incl[, j] == 1)
    Z <- cbind(1, core$Xc[, idx, drop = FALSE])
    if (length(idx)) {
      bh <- mq$bmean[idx, j] / cc                 # OLS slopes
      e <- core$yc - drop(core$Xc[, idx, drop = FALSE] %*% bh)
    } else e <- core$yc
    L <- rbind(1, cc * mq$D[idx, , drop = FALSE]) # intercept unshrunk, slopes shrunk
    within[j, ] <- .bp_crvar(Z, e, cluster, L, type = type, cadjust = cadjust)
  }
  m_bar <- colSums(w * mq$m)
  W_part <- colSums(w * within)
  B_part <- colSums(w * sweep(mq$m, 2, m_bar)^2)
  V <- W_part + B_part
  ## validation: sandwich::vcovCL on lm() with the ORIGINAL (uncentred) regressors
  chk <- unique(c(seq_len(min(n_check, M)),
                  if (M > n_check) round(seq(n_check + 1, M, length.out = n_check))))
  dev <- 0
  for (j in chk) {
    idx <- which(tm$incl[, j] == 1)
    dfj <- data.frame(y = core$y, core$X[, idx, drop = FALSE])
    fit <- lm(y ~ ., data = dfj)
    Vj <- sandwich::vcovCL(fit, cluster = cluster, type = type, cadjust = cadjust)
    ## shrunk fitted value = a + (xbar + c d)'b  in the uncentred parametrisation
    Lu <- rbind(1, core$xbar[idx] + cc * mq$D[idx, , drop = FALSE])
    vj <- colSums(Lu * (Vj %*% Lu))
    dev <- max(dev, max(abs(vj - within[j, ])))
  }
  data.frame(row = colnames(mq$m), mean = m_bar, within_var = W_part,
             between_var = B_part, var = V, sd = sqrt(V),
             lo = m_bar - 1.96 * sqrt(V), hi = m_bar + 1.96 * sqrt(V),
             row.names = NULL) -> res
  attr(res, "max_abs_dev_vs_vcovCL") <- dev
  attr(res, "n_models_checked_vs_vcovCL") <- length(chk)
  res
}

## ---- full-variable OLS lincom (the original Table 4 uncertainty) --------------------
bp_ols_lincom <- function(X.data, cluster, x0, type = "HC0", cadjust = TRUE) {
  X.data <- as.data.frame(X.data)
  names(X.data)[1] <- "y"
  fit <- lm(y ~ ., data = X.data)
  V <- sandwich::vcovCL(fit, cluster = cluster, type = type, cadjust = cadjust)
  x0 <- as.matrix(x0)
  L <- rbind(1, t(x0[, names(coef(fit))[-1], drop = FALSE]))
  est <- drop(crossprod(L, coef(fit)))
  se <- sqrt(colSums(L * (V %*% L)))
  data.frame(row = rownames(x0), ols_est = est, ols_se = se, row.names = NULL)
}

## ---- George (2010) dilution prior as a BMS custom model prior -----------------------
## log p(M) = power * log|R_M| + log p_base(M); R_M = correlation matrix of the included
## regressors; base prior uniform over models (p = 1/2 for every regressor).
bp_dilution_mprior <- function(X, power = 1) {
  Rc <- stats::cor(as.matrix(X)); K <- ncol(Rc)
  list(mp.mode = "dilution", mp.msize = K / 2,
       pmp = function(ki, mdraw, ...) {
         if (ki < 2) return(0)
         idx <- as.logical(mdraw)
         power * as.numeric(determinant(Rc[idx, idx, drop = FALSE], logarithm = TRUE)$modulus)
       },
       mp.Kdist = stats::dbinom(0:K, K, 0.5))
}
