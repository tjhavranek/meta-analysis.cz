# Parse every distributed R file; validate the relocated preprocessing without fitting models.
.libPaths(unique(c(Sys.getenv("R_LIBS_USER"), .libPaths())))
files <- list.files(".", pattern="\\.[Rr]$", recursive=TRUE, full.names=TRUE)
for (f in files) parse(f)
cat("Parsed", length(files), "R scripts\n")
setwd("work/compute")
source("code/core.R")
stopifnot(nrow(bma_df)==1019, length(unique(bma_study_id))==74, ncol(bma_df)==35)
cat("Relocated preprocessing: 1019 estimates, 74 studies, 34 regressors\n")
for (p in c("BMS","readxl","sandwich","lmtest","clubSandwich","writexl","data.table")) {
 if(p=="clubSandwich" && dir.exists("code/Rlib")) .libPaths(c(normalizePath("code/Rlib"), .libPaths()))
 cat(p, if(requireNamespace(p,quietly=TRUE)) as.character(packageVersion(p)) else "NOT INSTALLED", "\n")
}
