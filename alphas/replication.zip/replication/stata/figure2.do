* Figure 2: median alpha of each study against the median year of its data,
* one point per study, with a linear fit.

capture log close
log using "results/stata_figure2.log", text replace
set more off

import excel "data/alphas.xlsx", sheet("data") firstrow clear
collapse (median) alpha_plot=alpha plot_year=year_data, by(study_id study)

twoway ///
    (scatter alpha_plot plot_year, msymbol(Oh) mcolor(navy) msize(*1)) ///
    (lfit alpha_plot plot_year, lcolor(black) lpattern(dash)), ///
    scheme(s2color) ///
    xtitle("Median year of data used by a study") ///
    ytitle("Median estimate of the alpha") ///
    ylabel(, glcolor(ltbluishgray)) ///
    graphregion(color(ltbluishgray)) ///
    legend(off)
graph export "results/figures/F2_trend.pdf", replace

log close
