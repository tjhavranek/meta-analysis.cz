* Figure A2: median alpha of each of the 74 original studies and of the later studies, with a logarithmic
* trend and a 95% prediction band for an individual study fitted to the 74 original studies only.

capture log close
log using "results/stata_figure_A2.log", text replace
set more off

***************************************************************************************
* Original studies: one point per study, as in Figure 2
***************************************************************************************

import excel "data/alphas.xlsx", sheet("data") firstrow clear
collapse (median) alpha_plot=alpha plot_year=year_data, by(study_id study)
generate byte sample_group = 0
tempfile original
save `original'

***************************************************************************************
* Later studies: one point per study
***************************************************************************************

import excel "data/new_studies.xlsx", sheet("new_studies") firstrow allstring case(lower) clear
destring alpha_monthly_pct start_year end_year, replace
generate str12 study_code = strtrim(no)
generate double plot_year = (start_year+end_year)/2

* Studies without a usable alpha are not plotted.
* Study 2: equal-weighted portfolio; study 5: portfolio of non-signatories.
drop if missing(alpha_monthly_pct, start_year, end_year)
drop if study_code == "2" & portfolio != "equal-weighted"
drop if study_code == "5" & strpos(portfolio, "non-signatories") == 0

* Studies with several alphas: median across them
collapse (median) alpha_plot=alpha_monthly_pct plot_year ///
    (firstnm) fee_status=net_or_gross, by(study_code study)
replace fee_status = lower(strtrim(fee_status))
generate byte sample_group = 1

generate str32 point_label = ""
replace point_label = "Ardia (2024)" if study_code == "1"
replace point_label = "Chen (2025)" if study_code == "2"
replace point_label = "Jorion (2021)" if study_code == "4"
replace point_label = "Liang (2022)" if study_code == "5"
replace point_label = "Platanakis (2025)" if study_code == "8"
replace point_label = "Ben Khelife (2022)" if study_code == "9"
replace point_label = "Grobys (2022)" if study_code == "10"
replace point_label = "Agarwal (2024; gross)" if study_code == "14"

* Labels are placed at the right-hand edge of the plot and joined to their points by thin lines
generate double label_x = 2014.8
generate double label_line_x = 2014.5
generate double label_y = .
replace label_y = 0.61 if study_code == "1"
replace label_y = 0.27 if study_code == "2"
replace label_y = -0.17 if study_code == "4"
replace label_y = 0.10 if study_code == "5"
replace label_y = 0.95 if study_code == "8"
replace label_y = -0.34 if study_code == "9"
replace label_y = 0.44 if study_code == "10"
replace label_y = 0.78 if study_code == "14"

sort study_code
list study_code point_label alpha_plot plot_year fee_status, noobs

***************************************************************************************
* Logarithmic trend and prediction band, original studies only
***************************************************************************************

append using `original'
generate double log_year = ln(plot_year-1989)
regress alpha_plot log_year if sample_group == 0
estimates store log_trend
scalar prediction_t = invttail(e(df_r), .025)

summarize plot_year, meanonly
scalar grid_min = r(min)
scalar grid_max = r(max)

* Pointwise 95% prediction interval; stdf includes the residual variance
preserve
clear
set obs 501
generate double plot_year = grid_min+(grid_max-grid_min)*(_n-1)/500
generate double log_year = ln(plot_year-1989)
generate byte sample_group = 2
estimates restore log_trend
predict double fitted_alpha, xb
predict double forecast_se, stdf
generate double pi_lower = fitted_alpha-prediction_t*forecast_se
generate double pi_upper = fitted_alpha+prediction_t*forecast_se
list plot_year fitted_alpha pi_lower pi_upper if _n == 1 | _n == _N, noobs
tempfile grid
save `grid'
restore
append using `grid'

***************************************************************************************
* Figure A2
***************************************************************************************

twoway ///
    (rarea pi_lower pi_upper plot_year if sample_group == 2, ///
        sort fcolor(gs14) fintensity(100) lcolor(gs14) lwidth(vthin)) ///
    (line fitted_alpha plot_year if sample_group == 2, ///
        sort lcolor(black) lpattern(dash) lwidth(medthin)) ///
    (pcspike alpha_plot plot_year label_y label_line_x if sample_group == 1, ///
        lcolor(gs10) lwidth(vthin)) ///
    (scatter alpha_plot plot_year if sample_group == 0, ///
        msymbol(Oh) mcolor(navy) msize(*1)) ///
    (scatter alpha_plot plot_year if sample_group == 1 & fee_status == "net", ///
        msymbol(D) mcolor(maroon) msize(*1.1)) ///
    (scatter alpha_plot plot_year if sample_group == 1 & fee_status == "gross", ///
        msymbol(S) mcolor(forest_green) msize(*1.2)) ///
    (scatter label_y label_x if sample_group == 1 & fee_status == "net", ///
        msymbol(i) mlabel(point_label) mlabposition(3) mlabgap(0) ///
        mlabsize(vsmall) mlabcolor(maroon)) ///
    (scatter label_y label_x if sample_group == 1 & fee_status == "gross", ///
        msymbol(i) mlabel(point_label) mlabposition(3) mlabgap(0) ///
        mlabsize(vsmall) mlabcolor(forest_green)), ///
    scheme(s2color) ///
    xtitle("Representative year of data used by a study") ///
    ytitle("Estimate of the alpha") ///
    xlabel(1990(5)2020) xscale(range(1990 2020)) ///
    ylabel(-.5(.5)1.5, glcolor(ltbluishgray)) ///
    graphregion(color(ltbluishgray)) ///
    plotregion(color(white)) ///
    legend(order(4 "Original 74 studies" 5 "New studies: net" 6 "New study: gross") ///
        rows(1) position(6) size(small) region(lstyle(none))) ///
    xsize(7.5) ysize(5)
graph export "results/figures/FA2_trend.pdf", replace

log close
