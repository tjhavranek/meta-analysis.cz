version 15
clear all
set more off
* Start Stata in the replication root. User-written commands, installed once:
*   ssc install winsor2
*   ssc install ivreg2
*   ssc install ranktest
*   net install collin, from(https://stats.oarc.ucla.edu/stat/stata/ado/analysis)
* Versions used: winsor2 1.1 (2014.12.16), ivreg2 4.1.12 (14aug2024), ranktest 2.0.04 (21sept2020), collin 1.6 (23nov2010).
* descriptives.do: Table 2 (results/tables/table2_means.csv), Figures 3-6 and the OLS regressions in the log.
* figure2.do: Figure 2. figure_A2.do: Figure A2.
do "stata/descriptives.do"
do "stata/figure2.do"
do "stata/figure_A2.do"
