* Summary statistics, mean alphas and study counts by category (Table 2), Figures 3-6, and OLS regressions with standard
* errors clustered by study (the nine-variable specification of Table 3 and the full specification), reported in the log.

capture log close
log using "results/stata_descriptives.log", text replace
import excel "data/alphas.xlsx", sheet("data") firstrow clear
set more off

***************************************************************************************
* Data preparation
***************************************************************************************

winsor2 alpha, suffix(_w) cuts(1 99)
winsor2 se, suffix(_w) cuts(1 99)
gen tstat_w = alpha_w/se_w
generate byte method_noniv = (method_iv==0)
generate byte bias_treated = (survivorship_treated==1 | backfilling_treated==1)
generate byte bias_not_treated = (survivorship_treated==0 & backfilling_treated==0)

gen se_method_iv = se_w * method_iv

***************************************************************************************
* Summary statistics
***************************************************************************************

sum alpha alpha_w se se_w tstat tstat_w, detail
sum alpha_w se_w se_method_iv depvar_individual_funds depvar_equalw_funds depvar_valuew_funds depvar_net_returns depvar_gross_returns data_cross_section data_longitudinal data_midyear database_default database_cst database_cisdm database_handcollect database_other number_of_databases market_developed market_world market_bull market_bear strategy_all strategy_equity strategy_events strategy_relative_value strategy_global strategy_fund_of_funds strategy_multi strategy_other method_iv method_noniv model_1factor model_3factor model_4factor model_7factor model_uncertainty model_asset_based model_other survivorship_treated backfilling_treated bias_treated bias_not_treated publication_year citations impact_factor
sum alpha_w se_w se_method_iv depvar_individual_funds depvar_equalw_funds depvar_valuew_funds depvar_net_returns depvar_gross_returns data_cross_section data_longitudinal data_midyear database_default database_cst database_cisdm database_handcollect database_other number_of_databases market_developed market_world market_bull market_bear strategy_all strategy_equity strategy_events strategy_relative_value strategy_global strategy_fund_of_funds strategy_multi strategy_other method_iv method_noniv model_1factor model_3factor model_4factor model_7factor model_uncertainty model_asset_based model_other survivorship_treated backfilling_treated bias_treated bias_not_treated publication_year citations impact_factor [aweight=weight]
correlate se_w se_method_iv depvar_individual_funds depvar_equalw_funds depvar_net_returns data_cross_section data_midyear database_default database_cst database_cisdm database_handcollect number_of_databases market_developed market_bull market_bear strategy_all strategy_equity strategy_events strategy_relative_value strategy_global strategy_fund_of_funds strategy_multi method_iv model_1factor model_3factor model_4factor model_7factor model_uncertainty model_asset_based survivorship_treated backfilling_treated publication_year citations impact_factor
collin se_w se_method_iv depvar_individual_funds depvar_equalw_funds depvar_net_returns data_cross_section data_midyear database_default database_cst database_cisdm database_handcollect number_of_databases market_developed market_bull market_bear strategy_all strategy_equity strategy_events strategy_relative_value strategy_global strategy_fund_of_funds strategy_multi method_iv model_1factor model_3factor model_4factor model_7factor model_uncertainty model_asset_based survivorship_treated backfilling_treated publication_year citations impact_factor

* Figures 3-5: the vertical line is the sample mean of the winsorized alpha
quietly summarize alpha_w
local mean_alpha = r(mean)
histogram alpha if alpha>-3 & alpha<3, bin(70) fcolor(gs14) lstyle(thin) frequency xtitle("Estimate of the alpha") xline(`mean_alpha', lcolor(red)) xlabel(-2 -1 0 0.36 1 2) ylabel( ,glcolor(ltbluishgray)) graphregion(color(ltbluishgray))
graph export "results/figures/F3_histogram.pdf", replace

* Table 2: number of estimates and studies, unweighted and weighted means of the winsorized alpha by category
capture program drop table2_row
program define table2_row
    args category condition
    local restriction ""
    if `"`condition'"' != "" local restriction `"if `condition'"'
    count `restriction'
    local estimates = r(N)
    egen byte study_tag = tag(study_id) `restriction'
    count if study_tag==1
    local studies = r(N)
    drop study_tag
    mean alpha_w `restriction'
    matrix unweighted = r(table)
    mean alpha_w [aweight=weight] `restriction'
    matrix weighted = r(table)
    post table2_means (`"`category'"') (`"`condition'"') (`estimates') (`studies') ///
        (unweighted[1,1]) (unweighted[2,1]) (unweighted[5,1]) (unweighted[6,1]) ///
        (weighted[1,1]) (weighted[2,1]) (weighted[5,1]) (weighted[6,1])
end

preserve
tempfile means
postfile table2_means str32 category str64 condition long estimates int studies ///
    double(mean se lo hi weighted_mean weighted_se weighted_lo weighted_hi) using `means'
table2_row "All estimates" ""
table2_row "Individual funds" "depvar_individual_funds==1"
table2_row "Equal-weighted funds" "depvar_equalw_funds==1"
table2_row "Value-weighted funds" "depvar_valuew_funds==1"
table2_row "Net-of-fee returns" "depvar_net_returns==1"
table2_row "Gross returns" "depvar_gross_returns==1"
table2_row "Cross-section data" "data_cross_section==1"
table2_row "Longitudinal data" "data_longitudinal==1"
table2_row "Database: default" "database_default==1"
table2_row "Database: CST" "database_cst==1"
table2_row "Database: CISDM" "database_cisdm==1"
table2_row "Database: hand-collected" "database_handcollect==1"
table2_row "Database: other" "database_other==1"
table2_row "Developed markets" "market_developed==1"
table2_row "World market" "market_world==1"
table2_row "Bull market" "market_bull==1"
table2_row "Bear market" "market_bear==1"
table2_row "Strategy: all funds" "strategy_all==1"
table2_row "Strategy: equity hedge" "strategy_equity==1"
table2_row "Strategy: event driven" "strategy_events==1"
table2_row "Strategy: relative value" "strategy_relative_value==1"
table2_row "Strategy: global" "strategy_global==1"
table2_row "Strategy: fund of funds" "strategy_fund_of_funds==1"
table2_row "Strategy: multi" "strategy_multi==1"
table2_row "Strategy: other" "strategy_other==1"
table2_row "Method: IV" "method_iv==1"
table2_row "Method: non-IV" "method_iv==0"
table2_row "Method: other" "method_other==1"
table2_row "1-factor model" "model_1factor==1"
table2_row "3-factor model" "model_3factor==1"
table2_row "4-factor model" "model_4factor==1"
table2_row "7-factor model" "model_7factor==1"
table2_row "Modeling model uncertainty" "model_uncertainty==1"
table2_row "Asset-based model" "model_asset_based==1"
table2_row "Other model" "model_other==1"
table2_row "Survivorship treated" "survivorship_treated==1"
table2_row "Backfilling treated" "backfilling_treated==1"
table2_row "Both biases untreated" "backfilling_treated==0 & survivorship_treated==0"
table2_row "Any bias treated" "(survivorship_treated==1 | backfilling_treated==1)"
postclose table2_means
use `means', clear
export delimited using "results/tables/table2_means.csv", replace
list category estimates studies mean lo hi weighted_mean weighted_lo weighted_hi, noobs abbreviate(14)
restore

* Figures 4 and 5
graph hbox alpha if alpha<3 & alpha>-3, over(study,label(grid) sort(year_data)) xsize(2.6) ysize(4) scale(0.55) yline(`mean_alpha', lcolor(red)) box(1,lcolor(black) fcolor(none)) marker(1,msymbol(circle_hollow) mcolor(gs12)) ytitle("Estimate of the alpha") ylabel(, nogrid)
graph export "results/figures/F4_studies.pdf", replace
graph hbox alpha if alpha<3 & alpha>-3, over(country,label(grid)) xsize(6) ysize(3.5) scale(1) yline(`mean_alpha', lcolor(red)) box(1,lcolor(black) fcolor(none)) marker(1,msymbol(circle_hollow) mcolor(gs12)) ytitle("Estimate of the alpha") ylabel(, nogrid)
graph export "results/figures/F5_countries.pdf", replace

* Figure 6, panels 1-6
twoway(hist alpha if method_iv==0 & alpha>-3 & alpha<3, bin(60) freq fcolor(navy) lcolor(navy) legend(label(1 "Non-IV method"))) (hist alpha if method_iv==1 & alpha>-3 & alpha<3, bin(20) gap(20) freq lcolor(gs12) fcolor(gs12) legend(label(2 "Instrumental variables (IV)"))) , legend(ring(0) position(2) bmargin(small) rows(10) region(lstyle(none))) xtitle("Estimate of the alpha")
graph export "results/figures/F6_pattern1.pdf", replace
twoway(hist alpha if market_world==1 & alpha>-3 & alpha<3, bin(60) freq fcolor(navy) lcolor(navy) legend(label(1 "World market")))(hist alpha if market_developed==1 & alpha>-3 & alpha<3, bin(60) freq fcolor(gs12) lcolor(gs12) legend(label(2 "Developed market"))) , legend(ring(0) position(2) bmargin(medium) rows(3) region(lstyle(none))) xtitle("Estimate of the alpha")
graph export "results/figures/F6_pattern2.pdf", replace
twoway(hist alpha if depvar_equalw_funds==1 & alpha>-3 & alpha<3, bin(60) freq fcolor(gs12) lcolor(gs12) legend(label(1 "Equal-weighted funds")))(hist alpha if depvar_valuew_funds==1 & alpha>-3 & alpha<3, bin(60) gap(10) freq fcolor(cranberry) lcolor(cranberry) legend(label(2 "Value-weighted funds"))) (hist alpha if depvar_individual_funds==1 & alpha>-3 & alpha<3, bin(60) freq fcolor(navy) lcolor(navy) legend(label(3 "Individual funds"))), legend(ring(0) position(2) bmargin(medium) rows(3) region(lstyle(none))) xtitle("Estimate of the alpha")
graph export "results/figures/F6_pattern3.pdf", replace
twoway(hist alpha if bias_treated==1 & alpha>-3 & alpha<3, bin(60) freq fcolor(navy) lcolor(navy) legend(label(1 "Biases treated")))(hist alpha if bias_treated==0 & alpha>-3 & alpha<3, bin(60) gap(10) freq fcolor(gs12) lcolor(gs12) legend(label(2 "Biases untreated"))), legend(ring(0) position(2) bmargin(medium) rows(3) region(lstyle(none))) xtitle("Estimate of the alpha")
graph export "results/figures/F6_pattern4.pdf", replace
twoway(kdensity alpha if model_1factor==1 & alpha<3 & alpha>-3, legend(label(1 "1-factor model")))(kdensity alpha if model_3factor==1 & alpha<3 & alpha>-3, legend(label(2 "3-factor model")))(kdensity alpha if model_4factor==1 & alpha<3 & alpha>-3, legend(label(3 "4-factor model")))(kdensity alpha if model_7factor==1 & alpha<3 & alpha>-3, legend(label(4 "7-factor model")))(kdensity alpha if model_uncertainty==1 & alpha<3 & alpha>-3, legend(label(5 "modelling uncertainty")))(kdensity alpha if model_asset_based==1 & alpha<3 & alpha>-3, legend(label(6 "asset-based model")))(kdensity alpha if model_other==1 & alpha<3 & alpha>-3, legend(label(7 "other model"))) , legend(ring(0) position(2) bmargin(medium) rows(7) region(lstyle(none))) xtitle("Estimate of the alpha") ytitle("Kernel density (alpha)")
graph export "results/figures/F6_pattern5.pdf", replace
twoway(kdensity alpha if strategy_all==1 & alpha<3 & alpha>-3, legend(label(1 "all funds")))(kdensity alpha if strategy_equity==1 & alpha<3 & alpha>-3, legend(label(2 "equity hedge")))(kdensity alpha if strategy_events==1 & alpha<3 & alpha>-3, legend(label(3 "events strategy")))(kdensity alpha if strategy_relative_value==1 & alpha<3 & alpha>-3, legend(label(4 "relative value strategy")))(kdensity alpha if strategy_global==1 & alpha<3 & alpha>-3, legend(label(5 "global funds")))(kdensity alpha if strategy_fund_of_funds==1 & alpha<3 & alpha>-3, legend(label(6 "fund of funds")))(kdensity alpha if strategy_multi==1 & alpha<3 & alpha>-3, legend(label(7 "multi-strategy"))) (kdensity alpha if strategy_other==1 & alpha<3 & alpha>-3, legend(label(8 "other strategy"))), legend(ring(0) position(2) bmargin(medium) rows(8) region(lstyle(none))) xtitle("Estimate of the alpha") ytitle("Kernel density (alpha)")
graph export "results/figures/F6_pattern6.pdf", replace

***************************************************************************************
* Heterogeneity: OLS with standard errors clustered by study
***************************************************************************************

* Full specification: all 34 explanatory variables
ivreg2 alpha_w se_w se_method_iv depvar_individual_funds depvar_equalw_funds depvar_net_returns data_cross_section data_midyear database_default database_cst database_cisdm database_handcollect number_of_databases market_developed market_bull market_bear strategy_all strategy_equity strategy_events strategy_relative_value strategy_global strategy_fund_of_funds strategy_multi method_iv model_1factor model_3factor model_4factor model_7factor model_uncertainty model_asset_based survivorship_treated backfilling_treated publication_year citations impact_factor, cluster(study_id)

* Nine-variable specification of Table 3
ivreg2 alpha_w depvar_net_returns data_midyear database_cisdm number_of_databases market_bear strategy_fund_of_funds model_1factor backfilling_treated publication_year, cluster(study_id)

log close
