version 15
clear all
set more off
* Start Stata in the replication root. User-written SSC commands (install once: ssc install winsor2; ssc install ivreg2; ssc install ranktest; ssc install collin).
* Versions used: winsor2 1.1 (2014.12.16), ivreg2 4.1.12 (14aug2024), ranktest 2.0.04 (21sept2020), collin 1.6 (23nov2010).
capture mkdir outputs
capture mkdir outputs/stata
copy "data/alphas.xlsx" "outputs/stata/alphas.xlsx", replace
copy "data/new_studies_to_code.xlsx" "outputs/stata/new_studies_to_code.xlsx", replace
local root "`c(pwd)'"
cd "outputs/stata"
do "`root'/code/alphas.do"
capture log close
clear all
do "`root'/code/alphas_reviewer_checks.do"
