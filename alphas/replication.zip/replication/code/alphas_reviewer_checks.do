* Time trends, benchmark sensitivity, and study influence.
* Run this file on the original 1,019 estimates. It does not add new studies.
* ivreg2 and winsor2 are the same commands used in alphas.do.


clear all
set more off
set linesize 180


* Working directory is set by the replication launcher.
capture mkdir "reviewer_checks"
capture log close
log using "reviewer_checks/reviewer_checks.log", text replace
import excel "alphas.xlsx", sheet("data") firstrow clear


* Winsorize once; use the same values in all models and study omissions.
winsor2 alpha, suffix(_w) cuts(1 99)
winsor2 se, suffix(_w) cuts(1 99)
generate double se_method_iv = se_w*method_iv
generate double data_year_c = year_data-1989
generate double pub_year_c = year_publication-2000
generate double data_year_c2 = data_year_c^2
generate double pub_year_c2 = pub_year_c^2

* Identify the studies contributing gross-return and bear-market estimates.
egen byte gross_study = max(depvar_gross_returns), by(study_id)
egen byte bear_study = max(market_bear), by(study_id)

* Keep these study characteristics for the omission results.
preserve
keep study_id study gross_study bear_study
duplicates drop
rename study_id omitted_study_id
save "reviewer_checks/study_names.dta", replace
restore

* Original Table 4 settings, evaluated at data year 2014.5 and publication year 2021.
* Variables not shown in lincom are set to zero: se_w, se_method_iv,
* data_cross_section, database_handcollect, model_1factor, model_3factor,
* model_4factor, model_7factor, model_asset_based, and unused strategy indicators.
* The pooled individual-funds mean is .1717369970559372.

postfile best_results byte scenario strategy_order double alpha se lower upper ///
    using "reviewer_checks/best_practice_sensitivity.dta", replace
postfile time_results byte scenario term_order double coefficient se pvalue ///
    using "reviewer_checks/time_coefficients.dta", replace

* 1. R1.1 / replace the logs with shifted calendar years.

ivreg2 alpha_w se_w se_method_iv depvar_individual_funds depvar_equalw_funds ///
    depvar_net_returns data_cross_section data_year_c database_default ///
    database_cst database_cisdm database_handcollect number_of_databases ///
    market_developed market_bull market_bear strategy_all ///
    strategy_equity strategy_events strategy_relative_value strategy_global ///
    strategy_fund_of_funds strategy_multi method_iv model_1factor ///
    model_3factor model_4factor model_7factor model_uncertainty ///
    model_asset_based survivorship_treated backfilling_treated pub_year_c ///
    citations impact_factor, cluster(study_id)
post time_results (3) (1) (_b[data_year_c]) (_se[data_year_c]) (2*normal(-abs(_b[data_year_c]/_se[data_year_c])))
post time_results (3) (2) (_b[pub_year_c]) (_se[pub_year_c]) (2*normal(-abs(_b[pub_year_c]/_se[pub_year_c])))
post time_results (3) (3) (.) (.) (.)
post time_results (3) (4) (.) (.) (.)

* All strategies
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_all*0.2384690873405299 + strategy_equity*0.224730127576055 + strategy_events*0.1108930323846909 ///
    + strategy_relative_value*0.09224730127576054 + strategy_global*0.1530912659470069 + strategy_fund_of_funds*0.06575073601570167 ///
    + strategy_multi*0.03925417075564279 + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (3) (1) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* All funds
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_all + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (3) (2) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Equity hedge
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_equity + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (3) (3) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Event driven
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_events + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (3) (4) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Relative value
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_relative_value + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (3) (5) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Global
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_global + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (3) (6) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Fund of funds
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_fund_of_funds + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (3) (7) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Multi-strategy
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_multi + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (3) (8) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Other
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + method_iv + model_uncertainty + survivorship_treated ///
    + backfilling_treated + pub_year_c*21 + citations*4.15016463231979 ///
    + impact_factor*18.151, level(95)
post best_results (3) (9) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* R1.1 / keep the shifted years and add their separate squares.

ivreg2 alpha_w se_w se_method_iv depvar_individual_funds depvar_equalw_funds ///
    depvar_net_returns data_cross_section data_year_c database_default ///
    database_cst database_cisdm database_handcollect number_of_databases ///
    market_developed market_bull market_bear strategy_all ///
    strategy_equity strategy_events strategy_relative_value strategy_global ///
    strategy_fund_of_funds strategy_multi method_iv model_1factor ///
    model_3factor model_4factor model_7factor model_uncertainty ///
    model_asset_based survivorship_treated backfilling_treated pub_year_c ///
    citations impact_factor data_year_c2 pub_year_c2, cluster(study_id)
post time_results (4) (1) (_b[data_year_c]) (_se[data_year_c]) (2*normal(-abs(_b[data_year_c]/_se[data_year_c])))
post time_results (4) (2) (_b[pub_year_c]) (_se[pub_year_c]) (2*normal(-abs(_b[pub_year_c]/_se[pub_year_c])))
post time_results (4) (3) (_b[data_year_c2]) (_se[data_year_c2]) (2*normal(-abs(_b[data_year_c2]/_se[data_year_c2])))
post time_results (4) (4) (_b[pub_year_c2]) (_se[pub_year_c2]) (2*normal(-abs(_b[pub_year_c2]/_se[pub_year_c2])))

* All strategies
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_all*0.2384690873405299 + strategy_equity*0.224730127576055 + strategy_events*0.1108930323846909 ///
    + strategy_relative_value*0.09224730127576054 + strategy_global*0.1530912659470069 + strategy_fund_of_funds*0.06575073601570167 ///
    + strategy_multi*0.03925417075564279 + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151 + data_year_c2*650.25 ///
    + pub_year_c2*441, level(95)
post best_results (4) (1) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* All funds
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_all + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151 + data_year_c2*650.25 ///
    + pub_year_c2*441, level(95)
post best_results (4) (2) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Equity hedge
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_equity + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151 + data_year_c2*650.25 ///
    + pub_year_c2*441, level(95)
post best_results (4) (3) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Event driven
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_events + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151 + data_year_c2*650.25 ///
    + pub_year_c2*441, level(95)
post best_results (4) (4) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Relative value
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_relative_value + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151 + data_year_c2*650.25 ///
    + pub_year_c2*441, level(95)
post best_results (4) (5) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Global
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_global + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151 + data_year_c2*650.25 ///
    + pub_year_c2*441, level(95)
post best_results (4) (6) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Fund of funds
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_fund_of_funds + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151 + data_year_c2*650.25 ///
    + pub_year_c2*441, level(95)
post best_results (4) (7) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Multi-strategy
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_multi + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + pub_year_c*21 ///
    + citations*4.15016463231979 + impact_factor*18.151 + data_year_c2*650.25 ///
    + pub_year_c2*441, level(95)
post best_results (4) (8) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Other
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_year_c*25.5 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + method_iv + model_uncertainty + survivorship_treated ///
    + backfilling_treated + pub_year_c*21 + citations*4.15016463231979 ///
    + impact_factor*18.151 + data_year_c2*650.25 + pub_year_c2*441, level(95)
post best_results (4) (9) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* 2. R1.5 / logarithmic benchmark.

ivreg2 alpha_w se_w se_method_iv depvar_individual_funds depvar_equalw_funds ///
    depvar_net_returns data_cross_section data_midyear database_default ///
    database_cst database_cisdm database_handcollect number_of_databases ///
    market_developed market_bull market_bear strategy_all ///
    strategy_equity strategy_events strategy_relative_value strategy_global ///
    strategy_fund_of_funds strategy_multi method_iv model_1factor ///
    model_3factor model_4factor model_7factor model_uncertainty ///
    model_asset_based survivorship_treated backfilling_treated publication_year ///
    citations impact_factor, cluster(study_id)
post time_results (1) (1) (_b[data_midyear]) (_se[data_midyear]) (2*normal(-abs(_b[data_midyear]/_se[data_midyear])))
post time_results (1) (2) (_b[publication_year]) (_se[publication_year]) (2*normal(-abs(_b[publication_year]/_se[publication_year])))
post time_results (1) (3) (.) (.) (.)
post time_results (1) (4) (.) (.) (.)

* All strategies
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_all*0.2384690873405299 + strategy_equity*0.224730127576055 + strategy_events*0.1108930323846909 ///
    + strategy_relative_value*0.09224730127576054 + strategy_global*0.1530912659470069 + strategy_fund_of_funds*0.06575073601570167 ///
    + strategy_multi*0.03925417075564279 + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (1) (1) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* All funds
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_all + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (1) (2) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Equity hedge
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_equity + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (1) (3) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Event driven
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_events + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (1) (4) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Relative value
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_relative_value + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (1) (5) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Global
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_global + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (1) (6) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Fund of funds
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_fund_of_funds + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (1) (7) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Multi-strategy
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_multi + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423 ///
    + citations*4.15016463231979 + impact_factor*18.151, level(95)
post best_results (1) (8) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Other
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + method_iv + model_uncertainty + survivorship_treated ///
    + backfilling_treated + publication_year*3.044522437723423 + citations*4.15016463231979 ///
    + impact_factor*18.151, level(95)
post best_results (1) (9) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* R1.5 / re-estimate without citations and impact factor.

ivreg2 alpha_w se_w se_method_iv depvar_individual_funds depvar_equalw_funds ///
    depvar_net_returns data_cross_section data_midyear database_default ///
    database_cst database_cisdm database_handcollect number_of_databases ///
    market_developed market_bull market_bear strategy_all ///
    strategy_equity strategy_events strategy_relative_value strategy_global ///
    strategy_fund_of_funds strategy_multi method_iv model_1factor ///
    model_3factor model_4factor model_7factor model_uncertainty ///
    model_asset_based survivorship_treated backfilling_treated publication_year, cluster(study_id)
post time_results (2) (1) (_b[data_midyear]) (_se[data_midyear]) (2*normal(-abs(_b[data_midyear]/_se[data_midyear])))
post time_results (2) (2) (_b[publication_year]) (_se[publication_year]) (2*normal(-abs(_b[publication_year]/_se[publication_year])))
post time_results (2) (3) (.) (.) (.)
post time_results (2) (4) (.) (.) (.)

* All strategies
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_all*0.2384690873405299 + strategy_equity*0.224730127576055 + strategy_events*0.1108930323846909 ///
    + strategy_relative_value*0.09224730127576054 + strategy_global*0.1530912659470069 + strategy_fund_of_funds*0.06575073601570167 ///
    + strategy_multi*0.03925417075564279 + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423, level(95)
post best_results (2) (1) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* All funds
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_all + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423, level(95)
post best_results (2) (2) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Equity hedge
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_equity + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423, level(95)
post best_results (2) (3) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Event driven
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_events + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423, level(95)
post best_results (2) (4) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Relative value
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_relative_value + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423, level(95)
post best_results (2) (5) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Global
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_global + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423, level(95)
post best_results (2) (6) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Fund of funds
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_fund_of_funds + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423, level(95)
post best_results (2) (7) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Multi-strategy
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + strategy_multi + method_iv + model_uncertainty ///
    + survivorship_treated + backfilling_treated + publication_year*3.044522437723423, level(95)
post best_results (2) (8) (r(estimate)) (r(se)) (r(lb)) (r(ub))

* Other
lincom _cons + depvar_individual_funds*0.1717369970559372 + depvar_equalw_funds*0.493621197252208 ///
    + depvar_net_returns + data_midyear*3.23867845216438 + database_default*0.5269872423945045 ///
    + database_cst*0.2512266928361138 + database_cisdm*0.1746810598626104 + number_of_databases*1.366045142296369 ///
    + market_developed*0.1373895976447498 + market_bull*0.03827281648675172 + market_bear*0.03827281648675172 ///
    + method_iv + model_uncertainty + survivorship_treated ///
    + backfilling_treated + publication_year*3.044522437723423, level(95)
post best_results (2) (9) (r(estimate)) (r(se)) (r(lb)) (r(ub))

postclose best_results
postclose time_results

* 4. R1.6 / R2.3. Omit one study using the nine-variable specification.
* Summarize the same omission estimates for all studies and contributing studies.
postfile study_results int omitted_study_id double net_b net_se net_p ///
    bear_b bear_se bear_p long observations ///
    using "reviewer_checks/leave_one_study_out.dta", replace

forvalues study = 1/74 {
    display "Omitting study " `study'

    quietly ivreg2 alpha_w depvar_net_returns data_midyear database_cisdm ///
        number_of_databases market_bear strategy_fund_of_funds model_1factor ///
        backfilling_treated publication_year if study_id!=`study', cluster(study_id)

    post study_results (`study') ///
        (_b[depvar_net_returns]) (_se[depvar_net_returns]) ///
        (2*normal(-abs(_b[depvar_net_returns]/_se[depvar_net_returns]))) ///
        (_b[market_bear]) (_se[market_bear]) ///
        (2*normal(-abs(_b[market_bear]/_se[market_bear]))) (e(N))
}
postclose study_results

use "reviewer_checks/leave_one_study_out.dta", clear
merge 1:1 omitted_study_id using "reviewer_checks/study_names.dta", nogen
sort omitted_study_id
save "reviewer_checks/leave_one_study_out.dta", replace
export delimited using "reviewer_checks/leave_one_study_out.csv", replace

postfile summary_results byte column str20 variable int omission_fits ///
    double minimum maximum max_pvalue int significant_fits ///
    long observations_min observations_max ///
    using "reviewer_checks/leave_one_study_out_summary.dta", replace

* Column 1: Net returns, contributing studies.
summarize net_b if gross_study==1, meanonly
scalar omission_min = r(min)
scalar omission_max = r(max)
scalar omission_fits = r(N)
summarize net_p if gross_study==1, meanonly
scalar omission_max_p = r(max)
count if gross_study==1 & net_p<.05
scalar omission_significant = r(N)
summarize observations if gross_study==1, meanonly
post summary_results (1) ("Net returns") (omission_fits) ///
    (omission_min) (omission_max) (omission_max_p) ///
    (omission_significant) (r(min)) (r(max))

* Column 2: Net returns, all studies.
summarize net_b, meanonly
scalar omission_min = r(min)
scalar omission_max = r(max)
scalar omission_fits = r(N)
summarize net_p, meanonly
scalar omission_max_p = r(max)
count if net_p<.05
scalar omission_significant = r(N)
summarize observations, meanonly
post summary_results (2) ("Net returns") (omission_fits) ///
    (omission_min) (omission_max) (omission_max_p) ///
    (omission_significant) (r(min)) (r(max))

* Column 3: Bear market, contributing studies.
summarize bear_b if bear_study==1, meanonly
scalar omission_min = r(min)
scalar omission_max = r(max)
scalar omission_fits = r(N)
summarize bear_p if bear_study==1, meanonly
scalar omission_max_p = r(max)
count if bear_study==1 & bear_p<.05
scalar omission_significant = r(N)
summarize observations if bear_study==1, meanonly
post summary_results (3) ("Bear market") (omission_fits) ///
    (omission_min) (omission_max) (omission_max_p) ///
    (omission_significant) (r(min)) (r(max))

* Column 4: Bear market, all studies.
summarize bear_b, meanonly
scalar omission_min = r(min)
scalar omission_max = r(max)
scalar omission_fits = r(N)
summarize bear_p, meanonly
scalar omission_max_p = r(max)
count if bear_p<.05
scalar omission_significant = r(N)
summarize observations, meanonly
post summary_results (4) ("Bear market") (omission_fits) ///
    (omission_min) (omission_max) (omission_max_p) ///
    (omission_significant) (r(min)) (r(max))

postclose summary_results

* Identify the studies whose omissions give the range endpoints.
summarize net_b, meanonly
list omitted_study_id study net_b gross_study if net_b==r(min) | net_b==r(max), noobs
summarize bear_b, meanonly
list omitted_study_id study bear_b bear_study if bear_b==r(min) | bear_b==r(max), noobs

* Retain the individual results when a coefficient is not significant at 5%.
list omitted_study_id study net_b net_p if net_p>=.05, noobs
list omitted_study_id study bear_b bear_p if bear_p>=.05, noobs

use "reviewer_checks/leave_one_study_out_summary.dta", clear
sort column
generate str40 coefficient_range = "[" + strtrim(string(minimum,"%9.3f")) ///
    + ", " + strtrim(string(maximum,"%9.3f")) + "]"
generate str8 study_omissions = strtrim(string(omission_fits,"%9.0f"))
save "reviewer_checks/leave_one_study_out_summary.dta", replace
export delimited using "reviewer_checks/leave_one_study_out_summary.csv", replace
list, noobs

scalar net_6_range = coefficient_range[1]
scalar net_74_range = coefficient_range[2]
scalar bear_4_range = coefficient_range[3]
scalar bear_74_range = coefficient_range[4]
scalar net_6_omissions = study_omissions[1]
scalar net_74_omissions = study_omissions[2]
scalar bear_4_omissions = study_omissions[3]
scalar bear_74_omissions = study_omissions[4]

* Table layout: four result columns, with no full-sample or median column.
postfile omission_table str20 indicator str40 net_6_studies str40 net_74_studies ///
    str40 bear_4_studies str40 bear_74_studies ///
    using "reviewer_checks/leave_one_study_out_table.dta", replace
post omission_table ("Net returns") (net_6_range) (net_74_range) ("") ("")
post omission_table ("Bear market") ("") ("") (bear_4_range) (bear_74_range)
post omission_table ("Controls") ("Yes") ("Yes") ("Yes") ("Yes")
post omission_table ("Studies omitted") (net_6_omissions) (net_74_omissions) ///
    (bear_4_omissions) (bear_74_omissions)
postclose omission_table
use "reviewer_checks/leave_one_study_out_table.dta", clear
export delimited using "reviewer_checks/leave_one_study_out_table.csv", replace
list, noobs abbreviate(20)

* R1.6 /  only add contributing-study counts to the existing Table 2.

import excel "alphas.xlsx", sheet("data") firstrow clear
generate byte method_noniv = (method_iv==0)
generate byte bias_treated = (survivorship_treated==1 | backfilling_treated==1)
generate byte bias_not_treated = (survivorship_treated==0 & backfilling_treated==0)
postfile count_results str32 variable long estimates int studies ///
    using "reviewer_checks/table2_study_counts.dta", replace

foreach variable in depvar_individual_funds depvar_equalw_funds depvar_valuew_funds ///
    depvar_net_returns depvar_gross_returns data_cross_section data_longitudal ///
    database_default database_cst database_cisdm database_handcollect database_other ///
    market_developed market_world market_bull market_bear ///
    strategy_all strategy_equity strategy_events strategy_relative_value ///
    strategy_global strategy_fund_of_funds strategy_multi strategy_other ///
    model_1factor model_3factor model_4factor model_7factor model_uncertainty ///
    model_asset_based model_other survivorship_treated backfilling_treated ///
    bias_not_treated bias_treated method_iv method_noniv {
    count if `variable'==1
    scalar category_estimates = r(N)
    egen byte study_tag = tag(study_id) if `variable'==1
    count if study_tag==1
    post count_results ("`variable'") (category_estimates) (r(N))
    drop study_tag
}
egen byte study_tag = tag(study_id)
count if study_tag==1
post count_results ("all_estimates") (_N) (r(N))
postclose count_results
use "reviewer_checks/table2_study_counts.dta", clear
export delimited using "reviewer_checks/table2_study_counts.csv", replace
list, noobs


* 3. Table R1: logarithmic, omitted-variable, linear, and quadratic benchmarks.
use "reviewer_checks/best_practice_sensitivity.dta", clear
generate str48 scenario_name = ""
replace scenario_name="Logarithmic time" if scenario==1
replace scenario_name="Without citations and impact factor" if scenario==2
replace scenario_name="Linear time" if scenario==3
replace scenario_name="Quadratic time" if scenario==4
label define strategy_label 1 "All strategies" 2 "All funds" 3 "Equity hedge" ///
    4 "Event driven" 5 "Relative value" 6 "Global" 7 "Fund of funds" ///
    8 "Multi-strategy" 9 "Other"
label values strategy_order strategy_label
decode strategy_order, generate(strategy)
sort strategy_order scenario
save "reviewer_checks/best_practice_sensitivity.dta", replace
export delimited using "reviewer_checks/best_practice_sensitivity.csv", replace
list scenario_name strategy alpha lower upper, noobs sepby(strategy_order)

keep strategy_order strategy scenario alpha lower upper
reshape wide alpha lower upper, i(strategy_order strategy) j(scenario)
export delimited using "reviewer_checks/appendix_sensitivity.csv", replace

use "reviewer_checks/time_coefficients.dta", clear
generate str48 scenario_name = ""
replace scenario_name="Logarithmic time" if scenario==1
replace scenario_name="Without citations and impact factor" if scenario==2
replace scenario_name="Linear time" if scenario==3
replace scenario_name="Quadratic time" if scenario==4
generate str24 term=""
replace term="Data-year term" if term_order==1
replace term="Publication-year term" if term_order==2
replace term="Data-year squared" if term_order==3
replace term="Publication-year squared" if term_order==4
sort scenario term_order
save "reviewer_checks/time_coefficients.dta", replace
export delimited using "reviewer_checks/time_coefficients.csv", replace
list scenario_name term coefficient se pvalue, noobs sepby(scenario)

* Notes for the two updated tables.
file open table_notes using "reviewer_checks/table_notes.txt", write text replace
file write table_notes "Table R1" _n
file write table_notes "Alphas are in monthly percentage points, with 95% confidence intervals in brackets. Estimates are obtained by ordinary least squares, with standard errors clustered by primary study. All benchmarks are evaluated at data year 2014.5 and publication year 2021. Columns (1) and (2) use logarithmic time variables; column (3) uses shifted calendar years, and column (4) adds their separate squares. Column (2) excludes citations and impact factor from the regression. The other columns retain the original maximum-value settings for these two variables. Other benchmark settings are unchanged." _n _n
file write table_notes "Leave-one-study-out results" _n
file write table_notes "Entries are the minimum and maximum coefficients across study omissions, in monthly percentage points; they are not confidence intervals. Each regression includes the nine explanatory variables reported in the right-hand panel of Table 3, with standard errors clustered by study. The targeted checks omit each of the six studies contributing gross-return estimates, or each of the four studies contributing bear-market estimates. The all-study checks omit each of the 74 studies. Each regression retains the observations from the remaining studies. Controls indicates that the other regressors in the nine-variable specification are included. Studies omitted reports the number of studies considered for omission; one study is excluded in each regression." _n
file close table_notes

********************************************************************************
* 5. Figure update: (R1.1 / R1.2).
* Additional input: new_studies_to_code.xlsx, sheet new_studies.

********************************************************************************

capture mkdir "reviewer_checks/figures"

* 1. Original sample: ONE observation per study, not per alpha estimate.
* Use the original, unwinsorized alpha, as in the original Figure 2.
* year_data is the untransformed representative year for an estimate.
* Take its median within each study, matching the original Figure 2 code.


import excel "alphas.xlsx", sheet("data") firstrow clear

collapse (median) alpha_plot=alpha plot_year=year_data ///
    (count) estimates_used=alpha, by(study_id study)
summarize plot_year, meanonly
scalar old_year_min = r(min)
scalar old_year_max = r(max)

generate byte sample_group = 0
generate str12 study_code = string(study_id)
generate str100 point_rule = "Median of the study's original alpha estimates"
label variable alpha_plot "Alpha (% per month)"
label variable plot_year "Representative data year"
sort study_id
save "reviewer_checks/figures/original_74_study_points.dta", replace
export delimited using "reviewer_checks/figures/original_74_study_points.csv", replace

* 2. Correct the MAIN Figure 2.
* Retain its original linear trend against calendar year.
* Both the scatter and the fitted line now give each study equal weight.
* All 74 study medians are plotted; no estimate-count weights are used.

regress alpha_plot plot_year
estimates store figure2_calendar_trend
twoway ///
    (scatter alpha_plot plot_year, msymbol(Oh) mcolor(navy) msize(*1)) ///
    (lfit alpha_plot plot_year, lcolor(black) lpattern(dash)), ///
    scheme(s2color) ///
    xtitle("Median year of data used by a study") ///
    ytitle("Median estimate of the alpha") ///
    ylabel(, glcolor(ltbluishgray)) ///
    graphregion(color(ltbluishgray)) ///
    legend(off) name(figure2_corrected, replace)
graph save "reviewer_checks/figures/F2_trend.gph", replace
graph export "reviewer_checks/figures/F2_trend.pdf", replace
graph export "reviewer_checks/figures/F2_trend.png", width(2400) replace

* 3. Read the NEW studies. Preserve the Excel values and coding comments.


import excel "new_studies_to_code.xlsx", sheet("new_studies") ///
    firstrow allstring case(lower) clear
destring alpha_monthly_pct se_monthly_pct t_stat start_year end_year, replace
generate str12 study_code = upper(strtrim(no))
generate double plot_year = (start_year+end_year)/2


* Keep usable estimates; select the requested portfolios.
drop if missing(alpha_monthly_pct, start_year, end_year)
drop if study_code == "2" & strpos(lower(comment), "value-weighted") > 0
drop if study_code == "5" & strpos(lower(comment), "nonsignator") == 0 & ///
    strpos(lower(comment), "non-signator") == 0

* One point per NEW study:
* - one available overall alpha: use it directly;
* - Chen: the EW all-funds alpha selected above;
* - Liang: the non-signatory portfolio selected above;
* - multiple group/strategy alphas without an overall result: their median.
* The last rule is a DESCRIPTIVE study summary, not an all-funds portfolio alpha.


collapse (median) alpha_plot=alpha_monthly_pct plot_year ///
    (count) estimates_used=alpha_monthly_pct ///
    (firstnm) start_year end_year fee_status=net_or_gross, by(study_code study)
replace fee_status = lower(strtrim(fee_status))
generate byte sample_group = 1
generate str100 point_rule = "Single coded overall alpha"
replace point_rule = "Equal-weighted all-funds alpha" if study_code == "2"
replace point_rule = "Non-signatory portfolio alpha" if study_code == "5"
replace point_rule = "NAHF baseline intercept from the COVID timing model" if study_code == "9"
replace point_rule = "Median of the coded group/strategy alphas; descriptive summary" ///
    if estimates_used > 1


generate str32 point_label = ""
replace point_label = "Ardia (2024)" if study_code == "1"
replace point_label = "Chen (2025)" if study_code == "2"
replace point_label = "Jorion (2021)" if study_code == "4"
replace point_label = "Liang (2022)" if study_code == "5"
replace point_label = "Platanakis (2025)" if study_code == "8"
replace point_label = "Ben Khelife (2022)" if study_code == "9"
replace point_label = "Grobys (2022)" if study_code == "10"
replace point_label = "Agarwal (2024; gross)" if study_code == "R4"

* Put labels in the clear area on the right, with short connecting lines.
generate double label_x = 2014.8
generate double label_line_x = 2014.5
generate double label_y = .
replace label_y = 0.61 if study_code == "1"
replace label_y = 0.27 if study_code == "2"
replace label_y = -0.17 if study_code == "4"
replace label_y = 0.10 if study_code == "5"
replace label_y = 0.95 if study_code == "8"
replace label_y = -0.34 if study_code == "9"
replace label_y = 0.44 if study_code == "10"
replace label_y = 0.78 if study_code == "R4"

label variable alpha_plot "Alpha (% per month)"
label variable plot_year "Middle year of the return-data period"
sort study_code
save "reviewer_checks/figures/new_study_points.dta", replace
export delimited using "reviewer_checks/figures/new_study_points.csv", replace
list study_code study alpha_plot plot_year estimates_used point_rule, noobs

* Summaries for the descriptive comparison and the response letter.
count
scalar new_study_count = r(N)
summarize alpha_plot, meanonly
scalar new_alpha_min = r(min)
scalar new_alpha_max = r(max)
summarize plot_year, meanonly
scalar new_midyear_min = r(min)
scalar new_midyear_max = r(max)
summarize end_year, meanonly
scalar new_endyear_min = r(min)
scalar new_endyear_max = r(max)
count if plot_year > old_year_max
scalar new_later_studies = r(N)


* 4. Fit the APPENDIX trend on the original 74 studies ONLY.


append using "reviewer_checks/figures/original_74_study_points.dta"
generate double log_year = ln(plot_year-1989)
regress alpha_plot log_year if sample_group == 0
estimates store appendix_log_trend
scalar prediction_t = invttail(e(df_r), .025)

* predict, stdf includes both fitted-mean uncertainty and residual variation.

predict double fitted_alpha, xb
predict double forecast_se, stdf
generate double pi_lower = fitted_alpha-prediction_t*forecast_se
generate double pi_upper = fitted_alpha+prediction_t*forecast_se
generate byte outside_pi = (alpha_plot < pi_lower | alpha_plot > pi_upper) ///
    if sample_group == 1
generate byte beyond_old_years = ///
    (plot_year < old_year_min | plot_year > old_year_max) if sample_group == 1
label variable beyond_old_years "Outside the current 74-study median-year range"

* These are individual-study, pointwise 95% prediction intervals.

preserve
keep if sample_group == 1
sort study_code
keep study_code study alpha_plot plot_year estimates_used point_rule ///
    fitted_alpha forecast_se pi_lower pi_upper outside_pi beyond_old_years ///
    fee_status point_label
save "reviewer_checks/figures/new_study_band_check.dta", replace
export delimited using "reviewer_checks/figures/new_study_band_check.csv", replace
list study_code alpha_plot plot_year pi_lower pi_upper outside_pi, noobs
restore

* Save all observed points before adding a dense grid for the smooth curve.
save "reviewer_checks/figures/figure_observed_points.dta", replace
summarize plot_year, meanonly
scalar grid_min = r(min)
scalar grid_max = r(max)


* Diagnostic files and the corrected original Figure 2 are already saved.
count if sample_group == 1 & outside_pi == 1
if r(N) > 0 {
    display as error "A new study point lies outside the 95% prediction interval."
    list study_code study alpha_plot plot_year pi_lower pi_upper ///
        if sample_group == 1 & outside_pi == 1, noobs
    display as error "Discuss these points before producing the appendix figure."
    log close
    exit 459
}

* Predict against calendar years across the observed old and new point range.

preserve
clear
set obs 501
generate double plot_year = grid_min+(grid_max-grid_min)*(_n-1)/500
generate double log_year = ln(plot_year-1989)
generate byte sample_group = 2
estimates restore appendix_log_trend
predict double fitted_alpha, xb
predict double forecast_se, stdf
generate double pi_lower = fitted_alpha-prediction_t*forecast_se
generate double pi_upper = fitted_alpha+prediction_t*forecast_se
save "reviewer_checks/figures/prediction_grid.dta", replace
restore
append using "reviewer_checks/figures/prediction_grid.dta"

* 5. Appendix figure: all observed points plus OLD-sample log trend and band.


twoway ///
    (rarea pi_lower pi_upper plot_year if sample_group == 2, ///
        sort fcolor(gs14) fintensity(100) lcolor(gs14) lwidth(vthin)) ///
    (line fitted_alpha plot_year if sample_group == 2, ///
        sort lcolor(black) lpattern(dash) lwidth(medthin)) ///
    (pcspike alpha_plot plot_year label_y label_line_x if sample_group == 1, ///
        lcolor(gs10) lwidth(vthin)) ///
    (scatter alpha_plot plot_year if sample_group == 0, ///
        msymbol(Oh) mcolor(navy) msize(*1)) ///
    (scatter alpha_plot plot_year if sample_group == 1 & fee_status == "net", ///
        msymbol(D) mcolor(maroon) msize(*1.1)) ///
    (scatter alpha_plot plot_year if sample_group == 1 & fee_status == "gross", ///
        msymbol(S) mcolor(forest_green) msize(*1.2)) ///
    (scatter label_y label_x if sample_group == 1 & fee_status == "net", ///
        msymbol(i) mlabel(point_label) mlabposition(3) mlabgap(0) ///
        mlabsize(vsmall) mlabcolor(maroon)) ///
    (scatter label_y label_x if sample_group == 1 & fee_status == "gross", ///
        msymbol(i) mlabel(point_label) mlabposition(3) mlabgap(0) ///
        mlabsize(vsmall) mlabcolor(forest_green)), ///
    scheme(s2color) ///
    xtitle("Representative year of data used by a study") ///
    ytitle("Estimate of the alpha") ///
    xlabel(1990(5)2020) xscale(range(1990 2020)) ///
    ylabel(-.5(.5)1.5, glcolor(ltbluishgray)) ///
    graphregion(color(ltbluishgray)) ///
    plotregion(color(white)) ///
    legend(order(4 "Original 74 studies" 5 "New studies: net" 6 "New study: gross") ///
        rows(1) position(6) size(small) region(lstyle(none))) ///
    xsize(7.5) ysize(5) ///
    name(appendix_new_studies, replace)

graph save "reviewer_checks/figures/appendix_new_studies_review.gph", replace
graph export "reviewer_checks/figures/appendix_new_studies_review.pdf", replace
graph export "reviewer_checks/figures/appendix_new_studies_review.png", width(2600) replace
save "reviewer_checks/figures/appendix_figure_data.dta", replace

display as text "Completed: corrected Figure 2 and appendix review figure."
display as text "F2_trend.pdf retains the original calendar-linear trend, with one point per study."
display as text "The appendix uses ln(year-1989), with predict, stdf and t(72) critical values."
display as text "See new_study_band_check.csv for study points and prediction intervals."
display as text "This is a descriptive comparison; the original meta-regressions are unchanged."
display as text "New studies = " new_study_count
display as text "Monthly alpha range = " new_alpha_min " to " new_alpha_max
display as text "Data midpoint range = " new_midyear_min " to " new_midyear_max
display as text "Data ending years = " new_endyear_min " to " new_endyear_max
display as text "Agarwal et al. (2024) uses gross returns and is plotted with a separate square marker."
display as text "Studies with data midpoints after 2012 = " new_later_studies
log close
