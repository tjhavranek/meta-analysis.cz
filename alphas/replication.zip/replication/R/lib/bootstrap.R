# Study bootstrap of the best-practice alpha: studies are resampled with
# replacement, the data are winsorized again, the BMA is re-estimated with a short
# chain and the best-practice alpha is evaluated at the fixed evaluation vectors.

study_ids <- sort(unique(alphas$study_id))
study_rows <- lapply(study_ids, function(id) which(alphas$study_id == id))

# Bootstrap sample b: the same 74-study draw for every specification.
sample_studies <- function(b) {
  set.seed(1000 + b)
  draw <- sample.int(length(study_ids), length(study_ids), replace = TRUE)
  d <- alphas[unlist(study_rows[draw]), , drop = FALSE]
  d$alpha_w <- winsorize(d$alpha)
  d$se_w <- winsorize(d$se)
  d$se_method_iv <- d$se_w * d$method_iv
  d
}

# Regressors that are constant or collinear in a bootstrap sample are dropped
# before the BMA; their coefficients are zero in that draw. The function returns
# the regressors to keep, those dropped, and whether each evaluation vector lies in
# the row space of the remaining design (support).
rank_info <- function(X, z) {
  X <- as.matrix(X)
  vars <- colnames(X)
  sds <- apply(X, 2, sd)
  varying <- which(sds > 1e-14)
  # pivoted QR of the standardized design with an intercept
  qr_design <- qr(cbind(1, scale(X[, varying, drop = FALSE])), tol = 1e-8)
  independent <- qr_design$pivot[seq_len(qr_design$rank)]
  keep <- varying[(seq_along(varying) + 1L) %in% independent]
  # support: projection of each standardized evaluation vector on the row space
  centre <- colMeans(X)
  spread <- sds
  spread[spread < 1e-14] <- 1
  standardize <- function(A) cbind(1, sweep(sweep(A, 2, centre), 2, spread, "/"))
  rows_qr <- qr(t(standardize(X)), tol = 1e-8)
  Q <- qr.Q(rows_qr)[, seq_len(rows_qr$rank), drop = FALSE]
  zz <- standardize(z)
  residual <- sqrt(rowSums((zz - zz %*% Q %*% t(Q))^2))
  list(keep = vars[sort(keep)], dropped = vars[setdiff(seq_along(vars), keep)],
       support = residual < 1e-8 * pmax(1, sqrt(rowSums(zz^2))))
}

# One bootstrap fit: draw b, specification spec.
boot_fit <- function(b, spec, burn = 1e5, iter = 3e5, nmodel = 5000) {
  d <- sample_studies(b)
  df <- design(d, spec)
  z <- vectors(spec, settings = spec == "log")
  ri <- rank_info(df[, -1], z)
  df <- df[, c("alpha_w", ri$keep), drop = FALSE]
  fit <- fit_chain(df, spec, seed = 500000 + 10000 * (match(spec, specs) - 1) + b,
                   burn = burn, iter = iter, nmodel = nmodel)
  estimate <- setNames(drop(predict(fit, z[, ri$keep, drop = FALSE], exact = TRUE)), rownames(z))
  list(b = b, spec = spec, N = nrow(df), dropped = ri$dropped, support = ri$support,
       estimate = estimate, retention = top_models(fit)$mass_share_mcmc)
}

# Percentile, basic and bias-corrected 95% intervals of the B draws in est (a
# B x rows matrix) around the full-sample posterior means in theta.
bootstrap_intervals <- function(est, theta) {
  B <- nrow(est)
  do.call(rbind, lapply(seq_len(ncol(est)), function(j) {
    v <- est[, j]
    th <- theta[j]
    q <- quantile(v, c(.025, .975), type = 7, names = FALSE)
    p0 <- (sum(v < th) + .5 * sum(v == th)) / B
    p0 <- min(max(p0, 1 / (2 * B)), 1 - 1 / (2 * B))
    prob <- pnorm(2 * qnorm(p0) + qnorm(c(.025, .975)))
    prob <- pmin(pmax(prob, 1 / (2 * B)), 1 - 1 / (2 * B))
    bc <- quantile(v, prob, type = 7, names = FALSE)
    data.frame(row = colnames(est)[j], B = B, mean = th, bootstrap_mean = mean(v),
               bootstrap_median = median(v), bias = mean(v) - th, bootstrap_sd = sd(v),
               boot_lo = q[1], boot_hi = q[2], basic_lo = 2 * th - q[2], basic_hi = 2 * th - q[1],
               bc_lo = bc[1], bc_hi = bc[2], fraction_negative = mean(v < 0))
  }))
}
