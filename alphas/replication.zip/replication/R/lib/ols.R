# OLS with standard errors clustered by study (HC0 sandwich, no small-sample
# adjustment, as ivreg2 ... cluster(study_id) in Stata).

suppressPackageStartupMessages(library(sandwich))

ols_cluster <- function(d, vars) {
  f <- lm(reformulate(vars, "alpha_w"), d)
  V <- vcovCL(f, cluster = d$study_id, type = "HC0", cadjust = FALSE)
  b <- coef(f); se <- sqrt(diag(V))
  data.frame(variable = names(b), coefficient = b, se = se, lo = b - 1.96 * se, hi = b + 1.96 * se,
             p = 2 * pnorm(-abs(b / se)), N = nrow(d), studies = length(unique(d$study_id)),
             row.names = NULL)
}
