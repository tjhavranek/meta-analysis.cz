# Data for the meta-regressions: the 1,019 alpha estimates, the 34 explanatory
# variables and the best-practice evaluation vectors.
#
# After sourcing this file the workspace holds
#   alphas         the sheet "data" of data/alphas.xlsx plus alpha_w, se_w, se_method_iv
#   regressors     the 34 regressors of Table 3, in table order
#   nine           the nine variables of the OLS specification in Table 3
#   labels         variable labels used in tables and figures
#   strategies     the nine rows of Table 4
#   strategy_vars  the seven strategy indicators
#   specs          the four time specifications of Table A2
#   means          sample means of the regressors
#   X0, SET        evaluation vectors of Table 4 (X0) and Table A5 (SET)
#   design(), vectors()   data and evaluation vectors for one specification
#   write_table()  CSV output

suppressPackageStartupMessages(library(readxl))

# Stata's winsor2 with cuts(1 99): percentiles by Stata's default definition
# (quantile type 2 in R), values outside replaced by the percentile.
winsorize <- function(x, low = 1, high = 99) {
  q <- quantile(x, c(low, high) / 100, type = 2, names = FALSE)
  pmax(pmin(x, q[2]), q[1])
}

regressors <- c(
  "se_w", "se_method_iv", "depvar_individual_funds", "depvar_equalw_funds",
  "depvar_net_returns", "data_cross_section", "data_midyear", "database_default",
  "database_cst", "database_cisdm", "database_handcollect", "number_of_databases",
  "market_developed", "market_bull", "market_bear", "strategy_all",
  "strategy_equity", "strategy_events", "strategy_relative_value", "strategy_global",
  "strategy_fund_of_funds", "strategy_multi", "method_iv", "model_1factor",
  "model_3factor", "model_4factor", "model_7factor", "model_uncertainty",
  "model_asset_based", "survivorship_treated", "backfilling_treated",
  "publication_year", "citations", "impact_factor")

nine <- c("depvar_net_returns", "data_midyear", "database_cisdm", "number_of_databases",
          "market_bear", "strategy_fund_of_funds", "model_1factor", "backfilling_treated",
          "publication_year")

labels <- c(
  "(Intercept)" = "Intercept",
  se_w = "Standard error (SE)", se_method_iv = "SE * IV method",
  depvar_individual_funds = "Individual funds", depvar_equalw_funds = "Equal-weighted funds",
  depvar_net_returns = "Net-of-fee returns", data_cross_section = "Cross-section data",
  data_midyear = "Data year", database_default = "Database: default",
  database_cst = "Database: CST", database_cisdm = "Database: CISDM",
  database_handcollect = "Database: hand-collected", number_of_databases = "Number of databases",
  market_developed = "Developed markets", market_bull = "Bull market", market_bear = "Bear market",
  strategy_all = "Strategy: all funds", strategy_equity = "Strategy: equity hedge",
  strategy_events = "Strategy: event driven", strategy_relative_value = "Strategy: relative value",
  strategy_global = "Strategy: global", strategy_fund_of_funds = "Strategy: fund of funds",
  strategy_multi = "Strategy: multi", method_iv = "IV method", model_1factor = "1-factor model",
  model_3factor = "3-factor model", model_4factor = "4-factor model", model_7factor = "7-factor model",
  model_uncertainty = "Modeling model uncertainty", model_asset_based = "Asset-based model",
  survivorship_treated = "Survivorship treated", backfilling_treated = "Backfilling treated",
  publication_year = "Publication year", citations = "Citations", impact_factor = "Impact factor")

strategies <- c("All strategies", "All funds", "Equity hedge", "Event driven", "Relative value",
                "Global", "Funds of funds", "Multistrategy", "Other")
specs <- c("log", "linear", "quad_hier", "nocit")

# ---- data ---------------------------------------------------------------------------
alphas <- as.data.frame(read_excel("data/alphas.xlsx", sheet = "data", .name_repair = "minimal"))
stopifnot(nrow(alphas) == 1019, length(unique(alphas$study_id)) == 74,
          !anyNA(alphas[, c("alpha", "se", regressors[-(1:2)])]))
alphas$alpha_w <- winsorize(alphas$alpha)
alphas$se_w <- winsorize(alphas$se)
alphas$se_method_iv <- alphas$se_w * alphas$method_iv
# data_midyear and publication_year are stored as ln(year_data - 1989) and
# ln(year_publication - 2000)
stopifnot(max(abs(alphas$data_midyear - log(alphas$year_data - 1989))) < 1e-8,
          max(abs(alphas$publication_year - log(alphas$year_publication - 2000))) < 1e-8)

# ---- evaluation vectors --------------------------------------------------------------
# Best practice: no publication bias (se_w = 0), net-of-fee returns, panel data,
# instrumental variables, model uncertainty treated, survivorship and backfilling
# treated, the latest data and publication years, the most cited study in the
# highest-ranked journal, no hand-collected data and no fixed factor model; sample
# means for the dependent-variable, database and market indicators and the number
# of databases. One row per strategy; the first row uses the sample shares of the
# strategies.
means <- colMeans(alphas[, regressors])
X0 <- matrix(0, length(strategies), length(regressors), dimnames = list(strategies, regressors))
X0[, c("depvar_net_returns", "method_iv", "model_uncertainty", "survivorship_treated",
       "backfilling_treated")] <- 1
at_mean <- c("depvar_individual_funds", "depvar_equalw_funds", "database_default",
             "database_cst", "database_cisdm", "number_of_databases", "market_developed",
             "market_bull", "market_bear")
X0[, at_mean] <- matrix(means[at_mean], nrow(X0), length(at_mean), byrow = TRUE)
X0[, "data_midyear"] <- log(max(alphas$year_data) - 1989)
X0[, "publication_year"] <- log(max(alphas$year_publication) - 2000)
X0[, "citations"] <- max(alphas$citations)
X0[, "impact_factor"] <- max(alphas$impact_factor)
strategy_vars <- grep("^strategy_", regressors, value = TRUE)
X0[1, strategy_vars] <- means[strategy_vars]
for (i in 1:7) X0[i + 1, strategy_vars[i]] <- 1

# Table A5: alternative settings S0-S8 for the all-strategies and funds-of-funds rows.
SET <- do.call(rbind, lapply(0:8, function(s) {
  z <- X0[c(1, 7), , drop = FALSE]
  if (s %in% c(1, 3, 4)) z[, "method_iv"] <- 0
  if (s %in% c(2, 3, 4)) z[, "model_uncertainty"] <- 0
  if (s %in% c(2, 3)) z[, "model_7factor"] <- 1
  if (s == 5) z[, c("citations", "impact_factor")] <-
    matrix(means[c("citations", "impact_factor")], 2, 2, byrow = TRUE)
  if (s == 6) z[, c("citations", "impact_factor")] <-
    matrix(apply(alphas[, c("citations", "impact_factor")], 2, median), 2, 2, byrow = TRUE)
  if (s == 7) z[, c("data_cross_section", "database_handcollect")] <-
    matrix(means[c("data_cross_section", "database_handcollect")], 2, 2, byrow = TRUE)
  if (s == 8) {
    v <- setdiff(regressors, c("se_w", "se_method_iv", "depvar_net_returns", "survivorship_treated",
                               "backfilling_treated", "data_midyear", "publication_year", strategy_vars))
    z[, v] <- matrix(means[v], 2, length(v), byrow = TRUE)
  }
  rownames(z) <- paste0("S", s, ":", rownames(z))
  z
}))

# Data (alpha_w first, then the regressors) for one time specification:
#   log        logarithms of the shifted years (Table 3)
#   linear     shifted calendar years
#   quad_hier  shifted years and their squares, with the hierarchical prior
#   nocit      log specification without citations and impact factor
design <- function(d, spec) {
  z <- d[, c("alpha_w", regressors)]
  if (spec %in% c("linear", "quad_hier")) {
    z$data_midyear <- d$year_data - 1989
    z$publication_year <- d$year_publication - 2000
  }
  if (spec == "quad_hier") {
    z$data_year_c2 <- z$data_midyear^2
    z$pub_year_c2 <- z$publication_year^2
  }
  if (spec == "nocit") z <- z[, !names(z) %in% c("citations", "impact_factor")]
  z
}

# Evaluation vectors for one specification; settings = TRUE appends the Table A5 rows.
vectors <- function(spec, settings = FALSE) {
  z <- if (settings) rbind(X0, SET) else X0
  if (spec %in% c("linear", "quad_hier")) {
    z[, "data_midyear"] <- max(alphas$year_data) - 1989
    z[, "publication_year"] <- max(alphas$year_publication) - 2000
  }
  if (spec == "quad_hier") {
    z <- cbind(z, data_year_c2 = z[, "data_midyear"]^2, pub_year_c2 = z[, "publication_year"]^2)
  }
  if (spec == "nocit") z <- z[, !colnames(z) %in% c("citations", "impact_factor"), drop = FALSE]
  z
}

write_table <- function(x, file) write.csv(x, file, row.names = FALSE, na = "")
