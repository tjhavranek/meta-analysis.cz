# Bayesian model averaging with BMS 0.3.5: model priors, seeded chains, pooling of
# chains, and the posterior of the best-practice alpha.
#
# Notation (Zeugner and Feldkircher 2015; BMS source): y and X are demeaned, g is the
# g-prior parameter (UIP: g = N), c = g/(1+g). Within model M with k regressors,
#   E(beta | M, y) = c * bhat,  Cov(beta | M, y) = S/(N-3) * c * (X_M'X_M)^-1,
#   S = yty * (1 - c * R2_M),
# and the fitted value x0'beta plus the intercept is Student t with N-1 degrees of
# freedom. The BMA posterior of the best-practice alpha is the mixture of these t
# distributions over the retained models, weighted by their exact posterior
# probabilities.

suppressPackageStartupMessages(library(BMS))
RNGkind("L'Ecuyer-CMRG", "Inversion", "Rejection")

# BMS::bms reseeds the random number generator from the clock. This copy omits that
# line, so that set.seed() before the call makes a chain reproducible.
bms_seeded <- local({
  src <- deparse(BMS::bms)
  hit <- grep("^    set.seed\\(as.numeric\\(Sys.time\\(\\)\\)\\)$", src)
  stopifnot(length(hit) == 1)
  f <- eval(parse(text = src[-hit]))
  environment(f) <- environment(BMS::bms)
  f
})

# ---- model priors --------------------------------------------------------------------
# Beta-binomial ("random") model prior with the hierarchy restriction of the quadratic
# specification: a squared year term can only enter together with its linear term.
# Models that violate the restriction have zero prior probability; the prior over
# model size is the beta-binomial prior of BMS with mean K/2, restricted to the
# admissible models.
hier_prior <- function(v, K) {
  pairs <- list(c("data_year_c2", "data_midyear"), c("pub_year_c2", "publication_year"))
  # polynomial product: counts of admissible models by size
  multiply <- function(a, b) {
    out <- numeric(length(a) + length(b) - 1)
    for (i in seq_along(a)) out[seq_along(b) + i - 1] <- out[seq_along(b) + i - 1] + a[i] * b
    out
  }
  counts <- 1
  handled <- character()
  for (pair in pairs) {
    present <- pair %in% v
    handled <- c(handled, pair[present])
    # admissible choices for the pair: neither term, the linear term alone, or both
    term <- if (all(present)) c(1, 1, 1) else if (present[2]) c(1, 1) else 1
    counts <- multiply(counts, term)
  }
  for (other in setdiff(v, handled)) counts <- multiply(counts, c(1, 1))
  counts <- c(counts, rep(0, length(v) + 1 - length(counts)))
  sizes <- 0:length(v)
  log_size_prior <- lbeta(sizes + 1, K - sizes + 1)
  size_dist <- counts * exp(log_size_prior)
  size_dist <- size_dist / sum(size_dist)
  child <- match(c("data_year_c2", "pub_year_c2"), v, nomatch = 0L)
  parent <- match(c("data_midyear", "publication_year"), v, nomatch = 0L)
  violates <- function(mdraw, i) child[i] > 0L && mdraw[child[i]] == 1 && (parent[i] == 0L || mdraw[parent[i]] == 0)
  list(mp.mode = "random_hierarchy", mp.msize = sum(sizes * size_dist), mp.Kdist = size_dist,
       pmp = function(ki, mdraw, ...) {
         if (violates(mdraw, 1) || violates(mdraw, 2)) return(-Inf)
         log_size_prior[ki + 1L]
       })
}

# Dilution prior (George 2010): prior model probability proportional to the
# determinant of the correlation matrix of the included regressors.
dilution_prior <- function(X) {
  R <- cor(X)
  ev <- pmax(eigen(R, symmetric = TRUE, only.values = TRUE)$values, 0)
  # coefficients of prod(1 + ev_i * t): the prior mass of each model size
  size_poly <- 1
  for (e in ev) size_poly <- c(size_poly, 0) + c(0, size_poly * e)
  list(mp.mode = "determinant_uniform", mp.msize = sum(ev / (1 + ev)), mp.Kdist = size_poly / sum(size_poly),
       pmp = function(ki, mdraw, ...) {
         if (ki < 2) return(0)
         included <- as.logical(mdraw)
         dd <- determinant(R[included, included, drop = FALSE], logarithm = TRUE)
         if (dd$sign <= 0 || !is.finite(dd$modulus)) return(-Inf)
         as.numeric(dd$modulus)
       })
}

# Model prior for a specification and prior arm (baseline, uniform, bric, dilution).
model_prior <- function(spec, X, arm = "baseline") {
  if (arm == "dilution") return(dilution_prior(X))
  if (arm == "uniform") return("uniform")
  if (spec == "quad_hier") return(hier_prior(colnames(X), K = ncol(X)))
  "random"
}

# ---- chains ---------------------------------------------------------------------------
# One birth-death MCMC chain. df: data from design(); start: starting model (a 0/1
# vector, or 0 for the null model); the g-prior is UIP except in the BRIC arm.
fit_chain <- function(df, spec, seed, burn, iter, nmodel, start = 0, arm = "baseline") {
  X <- as.matrix(df[, -1])
  g <- if (arm == "bric") max(nrow(df), ncol(X)^2) else nrow(df)
  set.seed(seed)
  bms_seeded(df, burn = burn, iter = iter, nmodel = nmodel, g = g,
             mprior = model_prior(spec, X, arm), mcmc = "bd", user.int = FALSE, start.value = start)
}

# The three chains of a specification start from the null model, from the nine
# variables of the OLS specification, and from the full model.
chain_start <- function(df, chain) {
  k <- ncol(df) - 1
  switch(chain, rep(0, k), as.numeric(names(df)[-1] %in% nine), rep(1, k))
}

chain_seed <- function(spec, arm, chain) {
  if (arm == "baseline") 202611060 + 10 * (match(spec, specs) - 1) + chain
  else 202611100 + 10 * match(arm, c("uniform", "bric", "dilution")) + chain
}

# ---- retained models ----------------------------------------------------------------
# Inclusion matrix (K x models), exact posterior model probabilities and the share
# of the MCMC mass that the retained models cover.
top_models <- function(fit) {
  incl <- fit$topmod$bool_binary()
  lik <- fit$topmod$lik()
  w <- exp(lik - max(lik))
  cnt <- fit$topmod$ncount()
  list(incl = incl, w = w / sum(w), ncount = cnt, nmodel = ncol(incl),
       mass_share_mcmc = sum(cnt) / fit$info$cumsumweights)
}

# Per-model posterior quantities: the location (m) and variance (vf) of the fitted
# value at each row of x0, the model sizes (k), the residual quantities S, and the
# posterior means and variances of the coefficients (bmean, bvar).
model_quantities <- function(fit, x0, tm = top_models(fit)) {
  Xd <- as.matrix(fit$arguments$X.data)
  y <- Xd[, 1]
  X <- Xd[, -1, drop = FALSE]
  N <- nrow(X)
  K <- ncol(X)
  g <- fit$gprior.info$g
  shrink <- g / (1 + g)
  xbar <- colMeans(X)
  ybar <- mean(y)
  Xc <- sweep(X, 2, xbar)
  yc <- y - ybar
  XtX <- crossprod(Xc)
  Xty <- drop(crossprod(Xc, yc))
  yty <- sum(yc^2)
  x0 <- as.matrix(x0)[, colnames(X), drop = FALSE]
  D <- t(x0) - xbar                      # evaluation vectors as deviations from the means
  M <- tm$nmodel
  m <- matrix(ybar, M, nrow(x0))
  vf <- matrix(NA_real_, M, nrow(x0))
  bmean <- matrix(0, K, M)
  bvar <- matrix(0, K, M)
  S <- numeric(M)
  k <- integer(M)
  for (j in seq_len(M)) {
    idx <- which(tm$incl[, j] == 1)
    k[j] <- length(idx)
    if (k[j] == 0) {
      S[j] <- yty
      leverage <- 0
    } else {
      XtXi <- chol2inv(chol(XtX[idx, idx, drop = FALSE]))
      bhat <- drop(XtXi %*% Xty[idx])
      S[j] <- yty - shrink * sum(Xty[idx] * bhat)
      Dj <- D[idx, , drop = FALSE]
      m[j, ] <- ybar + shrink * drop(crossprod(Dj, bhat))
      leverage <- colSums(Dj * (XtXi %*% Dj))
      bmean[idx, j] <- shrink * bhat
      bvar[idx, j] <- S[j] / (N - 3) * shrink * diag(XtXi)
    }
    vf[j, ] <- S[j] / (N - 3) * (1 / N + shrink * leverage)
  }
  colnames(m) <- colnames(vf) <- rownames(x0)
  list(m = m, vf = vf, S = S, k = k, bmean = bmean, bvar = bvar, tm = tm,
       N = N, K = K, shrink = shrink, yty = yty)
}

# Quantile of a mixture of t distributions (weights w, locations loc, scales sc).
mixture_quantile <- function(p, w, loc, sc, df) {
  bracket <- range(loc + sc * qt(p, df))
  if (diff(bracket) < 1e-13) return(mean(bracket))
  uniroot(function(q) sum(w * pt((q - loc) / sc, df)) - p, bracket, tol = 1e-11)$root
}

# Posterior mean, SD, 95% credible interval and P(alpha > 0) of the best-practice
# alpha at each row of z.
best_practice <- function(fit, z) {
  mq <- model_quantities(fit, z)
  w <- mq$tm$w
  df <- mq$N - 1
  sc <- sqrt(mq$vf * (mq$N - 3) / (mq$N - 1))
  mu <- colSums(w * mq$m)
  stopifnot(max(abs(mu - predict(fit, z, exact = TRUE))) < 1e-8)
  rows <- seq_len(nrow(z))
  data.frame(row = rownames(z), mean = mu,
             sd = sqrt(pmax(0, colSums(w * (mq$vf + mq$m^2)) - mu^2)),
             lo = sapply(rows, function(r) mixture_quantile(.025, w, mq$m[, r], sc[, r], df)),
             hi = sapply(rows, function(r) mixture_quantile(.975, w, mq$m[, r], sc[, r], df)),
             p_positive = colSums(w * pt(-mq$m / sc, df, lower.tail = FALSE)),
             row.names = NULL)
}

# Pool the three chains of a specification: the union of their retained models,
# with weights recomputed from the exact marginal likelihoods and the model prior.
pool_chains <- function(fits, spec) {
  fit <- do.call(BMS:::combine_chains, fits)
  if (spec == "quad_hier") {
    hp <- hier_prior(fit$reg.names, K = length(fit$reg.names))
    fit$mprior.info$mp.msize <- hp$mp.msize
    fit$mprior.info$mp.Kdist <- hp$mp.Kdist
  }
  z <- matrix(colMeans(as.matrix(fit$arguments$X.data)[, -1, drop = FALSE]), nrow = 1,
              dimnames = list("sample_mean", fit$reg.names))
  mq <- model_quantities(fit, z)
  tm <- mq$tm
  sse <- (mq$S - (1 - mq$shrink) * mq$yty) / mq$shrink
  stopifnot(all(sse > 0), !anyDuplicated(fit$topmod$bool()))
  log_prior <- vapply(seq_len(tm$nmodel), function(j) fit$mprior.info$pmp(ki = mq$k[j], mdraw = tm$incl[, j]), 0)
  lik <- fit$gprior.info$lprobcalc$just.loglik(ymy = sse, k = mq$k) + log_prior
  fit$topmod <- BMS:::topmod(nbmodels = tm$nmodel, nmaxregressors = mq$K, bbeta = TRUE, liks = lik,
                             ncounts = tm$ncount, modelbinaries = tm$incl, betas = mq$bmean,
                             betas2 = mq$bvar + mq$bmean^2, fixed_vector = fit$topmod$fixed_vector())
  fit
}

# Coefficient table of a fit: posterior inclusion probability, posterior mean and
# posterior SD of each regressor and the intercept.
coefficient_table <- function(fit) {
  ce <- coef(fit, exact = TRUE, order.by.pip = FALSE, include.constant = TRUE)
  data.frame(variable = rownames(ce), pip = ce[, "PIP"], post_mean = ce[, "Post Mean"],
             post_sd = ce[, "Post SD"], row.names = NULL)
}
