# Study bootstrap of the best-practice alphas: the bootstrap intervals of Tables 4,
# A2 and A5 and the interval comparison in the online appendix. Requires the
# best-practice tables written by run_bma.R. Run from the package root:
#   Rscript R/run_bootstrap.R          1,999 draws for each of the four specifications
#                                      (7,996 short chains; about a day on twelve cores)
#   Rscript R/run_bootstrap.R quick    20 draws with short chains, for checking the code
# Draws are saved in work/bootstrap and reused when the script is run again, so an
# interrupted run can be resumed.

source("R/lib/data.R")
source("R/lib/bma.R")
source("R/lib/bootstrap.R")
suppressPackageStartupMessages(library(parallel))

quick <- "quick" %in% commandArgs(trailingOnly = TRUE)
B <- if (quick) 20 else 1999
tables <- if (quick) "results_quick/tables" else "results/tables"
replicates <- if (quick) "results_quick/bootstrap" else "results/bootstrap"
draws <- if (quick) "work_quick/bootstrap" else "work/bootstrap"
for (d in c(tables, replicates, file.path(draws, specs))) dir.create(d, recursive = TRUE, showWarnings = FALSE)

# ---- draws ---------------------------------------------------------------------------------
tasks <- list()
for (b in seq_len(B)) for (spec in specs) {
  file <- file.path(draws, spec, sprintf("rep_%04d.rds", b))
  if (!file.exists(file)) tasks[[length(tasks) + 1]] <- list(b = b, spec = spec, file = file)
}
if (length(tasks)) {
  cat("Estimating", length(tasks), "bootstrap fits", format(Sys.time()), "\n")
  cl <- makeCluster(max(1, detectCores() - 2))
  clusterExport(cl, "quick")
  invisible(clusterEvalQ(cl, { source("R/lib/data.R"); source("R/lib/bma.R"); source("R/lib/bootstrap.R") }))
  invisible(parLapplyLB(cl, tasks, function(t) {
    r <- if (quick) boot_fit(t$b, t$spec, burn = 1e3, iter = 3e3, nmodel = 500) else boot_fit(t$b, t$spec)
    saveRDS(r, t$file)
    if (t$b %% 50 == 0) cat(t$spec, "draw", t$b, "done", format(Sys.time()), "\n")
  }, chunk.size = 1))
  stopCluster(cl)
}

# ---- intervals ------------------------------------------------------------------------------
results <- list()
diagnostics <- list()
for (spec in specs) {
  rr <- lapply(seq_len(B), function(b) readRDS(file.path(draws, spec, sprintf("rep_%04d.rds", b))))
  est <- do.call(rbind, lapply(rr, `[[`, "estimate"))
  support <- do.call(rbind, lapply(rr, `[[`, "support"))
  write_table(data.frame(b = seq_len(B), N = sapply(rr, `[[`, "N"), est, check.names = FALSE),
              file.path(replicates, paste0(spec, "_replicates.csv")))
  diagnostics[[spec]] <- data.frame(spec = spec, b = seq_len(B), N = sapply(rr, `[[`, "N"),
                                    dropped = sapply(rr, function(r) paste(r$dropped, collapse = ";")),
                                    retention = sapply(rr, `[[`, "retention"), unsupported = rowSums(!support))
  bp <- read.csv(file.path(tables, paste0("bma_", spec, "_best_practice.csv")))
  out <- bootstrap_intervals(est, bp$mean[match(colnames(est), bp$row)])
  out$credible_lo <- bp$lo[match(out$row, bp$row)]
  out$credible_hi <- bp$hi[match(out$row, bp$row)]
  out$unsupported <- colSums(!support)
  results[[spec]] <- data.frame(spec = spec, out)
}
write_table(do.call(rbind, diagnostics), file.path(tables, "bootstrap_diagnostics.csv"))
write_table(do.call(rbind, results), file.path(tables, "oa_bootstrap_intervals.csv"))

columns <- c("row", "mean", "boot_lo", "boot_hi", "credible_lo", "credible_hi")
log_rows <- results$log
write_table(log_rows[1:9, columns], file.path(tables, "table4.csv"))
a5 <- log_rows[-(1:9), columns]
a5 <- data.frame(setting = sub(":.*", "", a5$row), strategy = sub("^[^:]*:", "", a5$row), a5[, -1])
write_table(a5, file.path(tables, "tableA5.csv"))
write_table(do.call(rbind, lapply(specs, function(s) data.frame(spec = s, results[[s]][1:9, columns]))),
            file.path(tables, "tableA2.csv"))
cat("Bootstrap done", format(Sys.time()), "\n")
