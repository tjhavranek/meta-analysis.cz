# Frequentist results and the later-studies comparison. Run from the package root:
#   Rscript R/run_frequentist.R
# Writes to results/tables:
#   tableA1.csv, evaluation_vectors.csv   best-practice evaluation vectors (Table A1, Tables 4 and A5)
#   tableA4.csv, leave_one_study_out.csv   leave-one-study-out OLS (Table A4)
#   tableA6.csv                            CR2 inference for the OLS specifications (Table A6)
#   oa_database_checks.csv, database_combinations.csv   database checks (online appendix)
#   ols_best_practice.csv, ols_time_specifications.csv   full-variable OLS at the evaluation vectors
#   global_funds_quantiles.csv             quartiles of the global-fund alphas (Figure 5 text)
#   tableA3.csv, tableA3b.csv, study_points.csv, new_studies_band.csv
#                                          later studies (Tables A3 and A3b; Figure A2 is drawn in Stata)

source("R/lib/data.R")
source("R/lib/ols.R")
suppressPackageStartupMessages(library(clubSandwich))
tables <- "results/tables"
dir.create(tables, recursive = TRUE, showWarnings = FALSE)

# ---- evaluation vectors (Table A1) --------------------------------------------------
write_table(data.frame(variable = regressors, label = unname(labels[regressors]),
                       baseline = as.numeric(X0[1, ]), sample_mean = means,
                       sample_median = sapply(alphas[, regressors], median),
                       sample_max = sapply(alphas[, regressors], max)),
            file.path(tables, "tableA1.csv"))
write_table(data.frame(row = rownames(rbind(X0, SET)), rbind(X0, SET), check.names = FALSE),
            file.path(tables, "evaluation_vectors.csv"))

# ---- CR2 inference with Satterthwaite degrees of freedom (Table A6) -------------------
ten <- c(nine, "market_bull")
cr2 <- do.call(rbind, lapply(list(nine = nine, ten = ten), function(v) {
  f <- lm(reformulate(v, "alpha_w"), alphas)
  V <- vcovCR(f, cluster = alphas$study_id, type = "CR2")
  ct <- as.data.frame(coef_test(f, vcov = V, test = "Satterthwaite"))
  ci <- as.data.frame(conf_int(f, vcov = V, test = "Satterthwaite"))
  data.frame(spec = if (length(v) == 9) "nine" else "ten", variable = rownames(ct),
             coefficient = ct$beta, se = ct$SE, df = ct$df_Satt, lo = ci$CI_L, hi = ci$CI_U, p = ct$p_Satt)
}))
write_table(cr2, file.path(tables, "tableA6.csv"))

# ---- leave-one-study-out (Table A4) --------------------------------------------------
gross_study <- tapply(alphas$depvar_gross_returns == 1, alphas$study_id, any)
bull_study <- tapply(alphas$market_bull == 1, alphas$study_id, any)
bear_study <- tapply(alphas$market_bear == 1, alphas$study_id, any)
loso <- do.call(rbind, lapply(c("nine", "ten"), function(spec) {
  do.call(rbind, lapply(sort(unique(alphas$study_id)), function(id) {
    d <- alphas[alphas$study_id != id, ]
    r <- ols_cluster(d, if (spec == "nine") nine else ten)
    r <- r[r$variable %in% c("depvar_net_returns", "market_bull", "market_bear"), ]
    data.frame(spec = spec, omitted_study_id = id, omitted_study = alphas$study[match(id, alphas$study_id)],
               r[, c("variable", "coefficient", "se", "lo", "hi", "p", "N")],
               gross_contributor = gross_study[[as.character(id)]],
               bull_contributor = bull_study[[as.character(id)]],
               bear_contributor = bear_study[[as.character(id)]])
  }))
}))
write_table(loso, file.path(tables, "leave_one_study_out.csv"))
contributor <- c(depvar_net_returns = "gross_contributor", market_bull = "bull_contributor",
                 market_bear = "bear_contributor")
summary_rows <- list()
for (spec in c("nine", "ten")) for (v in names(contributor)) for (subset in c("all", "contributors")) {
  r <- loso[loso$spec == spec & loso$variable == v, ]
  if (subset == "contributors") r <- r[r[[contributor[[v]]]], ]
  if (!nrow(r)) next
  summary_rows[[length(summary_rows) + 1]] <-
    data.frame(spec = spec, variable = v, subset = subset, omissions = nrow(r),
               min = min(r$coefficient), max = max(r$coefficient), max_p = max(r$p),
               significant = sum(r$p < .05), N_min = min(r$N), N_max = max(r$N))
}
write_table(do.call(rbind, summary_rows), file.path(tables, "tableA4.csv"))

# ---- database checks (online appendix) -----------------------------------------------
dbvars <- c("database_default", "database_cst", "database_cisdm", "database_handcollect", "database_other")
key <- apply(alphas[, dbvars], 1, paste, collapse = "+")
combinations <- do.call(rbind, lapply(unique(key), function(k) {
  ix <- key == k
  data.frame(combination = k, alphas[which(ix)[1], dbvars], estimates = sum(ix),
             studies = length(unique(alphas$study_id[ix])),
             count_min = min(alphas$number_of_databases[ix]), count_max = max(alphas$number_of_databases[ix]),
             count_distinct = length(unique(alphas$number_of_databases[ix])))
}))
write_table(combinations, file.path(tables, "database_combinations.csv"))
alphas$count_cisdm <- alphas$number_of_databases * alphas$database_cisdm
db <- list(original = list(d = alphas, v = nine),
           no_cisdm = list(d = alphas[alphas$database_cisdm == 0, ], v = setdiff(nine, "database_cisdm")),
           count_interaction = list(d = alphas, v = c(nine, "count_cisdm")))
write_table(do.call(rbind, lapply(names(db), function(s) data.frame(spec = s, ols_cluster(db[[s]]$d, db[[s]]$v)))),
            file.path(tables, "oa_database_checks.csv"))

# ---- full-variable OLS at the evaluation vectors --------------------------------------
# The OLS counterpart of the best-practice alphas: the full-variable regression of
# each time specification, evaluated at the evaluation vectors, with study-clustered
# standard errors.
ols_at_vectors <- function(spec, z) {
  d <- design(alphas, spec)
  f <- lm(reformulate(colnames(z), "alpha_w"), d)
  V <- vcovCL(f, cluster = alphas$study_id, type = "HC0", cadjust = FALSE)
  L <- cbind("(Intercept)" = 1, z[, names(coef(f))[-1], drop = FALSE])
  est <- drop(L %*% coef(f))
  se <- sqrt(rowSums((L %*% V) * L))
  data.frame(spec = spec, row = rownames(z), estimate = est, se = se, lo = est - 1.96 * se, hi = est + 1.96 * se,
             row.names = NULL)
}
write_table(ols_at_vectors("log", rbind(X0, SET)), file.path(tables, "ols_best_practice.csv"))
write_table(do.call(rbind, lapply(specs, function(s) ols_at_vectors(s, vectors(s)))),
            file.path(tables, "ols_time_specifications.csv"))

# ---- global funds (Figure 5) ------------------------------------------------------------
ix <- tolower(trimws(alphas$country)) == "global funds" & alphas$alpha > -3 & alphas$alpha < 3
qu <- quantile(alphas$alpha[ix], c(.25, .5, .75), type = 2, names = FALSE)
write_table(data.frame(N = sum(ix), studies = length(unique(alphas$study_id[ix])), q25 = qu[1], median = qu[2], q75 = qu[3]),
            file.path(tables, "global_funds_quantiles.csv"))

# ---- later studies (Tables A3 and A3b) ------------------------------------------------
new <- as.data.frame(read_excel("data/new_studies.xlsx", sheet = "new_studies"))
ids <- unique(new$no)
retained <- ids[ids %in% new$no[!is.na(new$alpha_monthly_pct)]]
write_table(data.frame(no = ids, study = new$study[match(ids, new$no)],
                       screening = ifelse(ids %in% retained, "Retained", "Excluded"),
                       source_inspected = new$source_inspected[match(ids, new$no)]),
            file.path(tables, "tableA3b.csv"))
# One point per retained study: the overall alpha where the study reports one, the
# equal-weighted all-funds portfolio for Chen et al., the non-signatory portfolio
# for Liang et al., and the median across portfolios otherwise.
later <- do.call(rbind, lapply(retained, function(id) {
  r <- new[new$no == id & !is.na(new$alpha_monthly_pct), ]
  if (id == "2") r <- r[r$portfolio == "equal-weighted", ]
  if (id == "5") r <- r[grepl("non-signatories", r$portfolio), ]
  data.frame(no = id, study = r$study[1], alpha = median(r$alpha_monthly_pct),
             se = if (nrow(r) == 1) r$se_monthly_pct else NA_real_,
             estimates = nrow(r), portfolio = if (nrow(r) == 1) r$portfolio else "median across portfolios",
             start_year = min(r$start_year), end_year = max(r$end_year),
             plot_year = median((r$start_year + r$end_year) / 2), fee_status = r$net_or_gross[1],
             fee_inferred = grepl("inferred", r$note[1]), model = r$model[1], source = r$table_page[1])
}))
write_table(later, file.path(tables, "tableA3.csv"))
# Original studies: median alpha and median data year per study, logarithmic trend
# with a 95% prediction band (the curve and band of Figure A2).
original <- aggregate(cbind(alpha = alphas$alpha, plot_year = alphas$year_data), list(study_id = alphas$study_id), median)
original$log_year <- log(original$plot_year - 1989)
trend <- lm(alpha ~ log_year, original)
band <- predict(trend, data.frame(log_year = log(later$plot_year - 1989)), interval = "prediction")
band <- data.frame(later[, c("no", "study", "alpha", "plot_year")], fit = band[, 1], pi_lower = band[, 2], pi_upper = band[, 3])
band$outside <- band$alpha < band$pi_lower | band$alpha > band$pi_upper
write_table(band, file.path(tables, "new_studies_band.csv"))
write_table(original, file.path(tables, "study_points.csv"))
cat("Later studies:", nrow(later), " outside the prediction band:", sum(band$outside), "\n")
