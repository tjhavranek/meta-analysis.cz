# Bayesian model averaging: Tables 3 and 5, the credible intervals of Tables 4, A2
# and A5, the prior comparison (Figure 8, online appendix) and Figure 7.
# Run from the package root:
#   Rscript R/run_bma.R          full run: 21 chains of 7 million draws, about four
#                                hours on twelve cores, 2 GB of memory per worker
#   Rscript R/run_bma.R quick    chains one hundred times shorter, for checking the
#                                code; writes to results_quick/ and work_quick/
# Chains are saved in work/fits and reused when the script is run again.
#
# Seven fits are estimated: the four time specifications of Table A2 (log, linear,
# quad_hier, nocit) with the UIP g-prior and the random model prior, and the log
# specification under three alternative priors (uniform model prior, BRIC g-prior,
# dilution prior). Each fit pools three chains with different starting models.

source("R/lib/data.R")
source("R/lib/bma.R")
source("R/lib/ols.R")
suppressPackageStartupMessages(library(parallel))

quick <- "quick" %in% commandArgs(trailingOnly = TRUE)
shorten <- if (quick) 100 else 1
tables <- if (quick) "results_quick/tables" else "results/tables"
figures <- if (quick) "results_quick/figures" else "results/figures"
fits <- if (quick) "work_quick/fits" else "work/fits"
for (d in c(tables, figures, fits)) dir.create(d, recursive = TRUE, showWarnings = FALSE)

tags <- data.frame(tag = c(specs, "prior_uniform", "prior_bric", "prior_dilution"),
                   spec = c(specs, "log", "log", "log"),
                   arm = c(rep("baseline", 4), "uniform", "bric", "dilution"), stringsAsFactors = FALSE)

# ---- chains -----------------------------------------------------------------------------
tasks <- list()
for (i in seq_len(nrow(tags))) for (chain in 1:3) {
  file <- file.path(fits, sprintf("%s_chain%d.rds", tags$tag[i], chain))
  if (!file.exists(file)) {
    tasks[[length(tasks) + 1]] <- list(tag = tags$tag[i], spec = tags$spec[i], arm = tags$arm[i],
                                       chain = chain, file = file)
  }
}
if (length(tasks)) {
  cat("Estimating", length(tasks), "chains", format(Sys.time()), "\n")
  cl <- makeCluster(min(length(tasks), max(1, detectCores() - 2)))
  clusterExport(cl, "shorten")
  invisible(clusterEvalQ(cl, { source("R/lib/data.R"); source("R/lib/bma.R") }))
  invisible(parLapplyLB(cl, tasks, function(t) {
    df <- design(alphas, t$spec)
    fit <- fit_chain(df, t$spec, seed = chain_seed(t$spec, t$arm, t$chain),
                     burn = 1e6 / shorten, iter = 6e6 / shorten, nmodel = 5e5 / shorten,
                     start = chain_start(df, t$chain), arm = t$arm)
    saveRDS(fit, t$file)
    cat(t$tag, "chain", t$chain, "done", format(Sys.time()), "\n")
  }, chunk.size = 1))
  stopCluster(cl)
}

# ---- pooled fits, coefficient tables and best-practice alphas ---------------------------
chain_range <- function(x) max(apply(x, 1, function(v) diff(range(v))))
diagnostics <- list()
for (i in seq_len(nrow(tags))) {
  tag <- tags$tag[i]
  spec <- tags$spec[i]
  z <- vectors(spec, settings = spec == "log")
  chains <- lapply(1:3, function(chain) readRDS(file.path(fits, sprintf("%s_chain%d.rds", tag, chain))))
  fit <- pool_chains(chains, spec)
  saveRDS(fit, file.path(fits, paste0(tag, ".rds")))
  write_table(coefficient_table(fit), file.path(tables, paste0("bma_", tag, "_coefficients.csv")))
  bp <- best_practice(fit, z)
  bp$spec <- spec
  bp$arm <- tags$arm[i]
  write_table(bp, file.path(tables, paste0("bma_", tag, "_best_practice.csv")))
  # agreement of the three chains: range across chains of the PIPs and of the
  # best-practice means and interval endpoints
  pips <- sapply(chains, function(f) coef(f, exact = TRUE, order.by.pip = FALSE)[, "PIP"])
  bp_chains <- lapply(chains, best_practice, z = z)
  diagnostics[[tag]] <- data.frame(
    tag = tag,
    models_pooled = top_models(fit)$nmodel,
    models_per_chain = paste(sapply(chains, function(f) top_models(f)$nmodel), collapse = ";"),
    retention_min = min(sapply(chains, function(f) top_models(f)$mass_share_mcmc)),
    max_pip_range = chain_range(pips),
    max_mean_range = chain_range(sapply(bp_chains, `[[`, "mean")),
    max_endpoint_range = max(chain_range(sapply(bp_chains, `[[`, "lo")), chain_range(sapply(bp_chains, `[[`, "hi"))))
  cat(tag, ": ", top_models(fit)$nmodel, " models pooled\n", sep = "")
}
write_table(do.call(rbind, diagnostics), file.path(tables, "bma_chain_diagnostics.csv"))

# ---- Table 3: baseline BMA and the nine-variable OLS ------------------------------------
base <- readRDS(file.path(fits, "log.rds"))
t3 <- coefficient_table(base)
ols <- ols_cluster(alphas, nine)
ix <- match(t3$variable, ols$variable)
t3$ols_coefficient <- ols$coefficient[ix]
t3$ols_se <- ols$se[ix]
t3$ols_p <- ols$p[ix]
t3$label <- unname(labels[t3$variable])
write_table(t3, file.path(tables, "table3.csv"))

# ---- Table 5: economic significance -------------------------------------------------------
# Changes in alpha for a one-SD and a full-range change of each regressor, and the
# changes as a percentage of the all-strategies best-practice alpha.
bp_log <- read.csv(file.path(tables, "bma_log_best_practice.csv"))
ce <- t3[match(regressors, t3$variable), ]
t5 <- data.frame(variable = regressors, label = unname(labels[regressors]), coefficient = ce$post_mean,
                 pip = ce$pip, original_nine = regressors %in% nine,
                 sd = sapply(alphas[, regressors], sd), range = sapply(alphas[, regressors], function(x) diff(range(x))))
t5$sd_change <- t5$coefficient * t5$sd
t5$range_change <- t5$coefficient * t5$range
t5$sd_percent <- 100 * t5$sd_change / bp_log$mean[1]
t5$range_percent <- 100 * t5$range_change / bp_log$mean[1]
write_table(t5, file.path(tables, "table5.csv"))

# ---- prior comparison (Figure 8, online appendix) -----------------------------------------
priors <- c(baseline = "log", uniform = "prior_uniform", bric = "prior_bric", dilution = "prior_dilution")
prior_coefficients <- do.call(rbind, lapply(names(priors), function(p) {
  ce <- read.csv(file.path(tables, paste0("bma_", priors[p], "_coefficients.csv")))
  ce <- ce[ce$variable != "(Intercept)", ]
  data.frame(prior = p, variable = ce$variable, pip = ce$pip, mean = ce$post_mean, sd = ce$post_sd,
             conditional_mean = ce$post_mean / ce$pip)
}))
write_table(prior_coefficients, file.path(tables, "oa_prior_coefficients.csv"))
write_table(do.call(rbind, lapply(names(priors), function(p) {
  r <- read.csv(file.path(tables, paste0("bma_", priors[p], "_best_practice.csv")))[1:9, ]
  data.frame(prior = p, r[, c("row", "mean", "sd", "lo", "hi", "p_positive")])
})), file.path(tables, "oa_prior_best_practice.csv"))
# correlation of the variables outside the OLS specification with the nine inside it
R <- cor(alphas[, regressors])
others <- setdiff(regressors, nine)
write_table(data.frame(variable = others,
                       max_abs_correlation = sapply(others, function(v) max(abs(R[v, nine]))),
                       nearest_original_control = sapply(others, function(v) nine[which.max(abs(R[v, nine]))])),
            file.path(tables, "prior_correlation_screen.csv"))

# ---- Figures 7 and 8 -------------------------------------------------------------------------
base$reg.names <- unname(labels[base$reg.names])
draw7 <- function() {
  par(mar = c(2.5, 10.5, 0.5, 0.5))
  image(base, cex.axis = 0.7, do.par = FALSE, main = "", xlab = "")
}
pdf(file.path(figures, "F7_bma.pdf"), width = 6, height = 5.6)
draw7()
invisible(dev.off())
png(file.path(figures, "F7_bma.png"), width = 6, height = 5.6, units = "in", res = 450)
draw7()
invisible(dev.off())

pips <- sapply(names(priors), function(p) {
  r <- prior_coefficients[prior_coefficients$prior == p, ]
  setNames(r$pip, r$variable)[regressors]
})
pips <- pips[order(-pips[, "baseline"]), ]
draw8 <- function() {
  par(mar = c(8.2, 4, 0.5, 0.5))
  n <- nrow(pips)
  plot(NA, xlim = c(1, n), ylim = c(0, 1), xaxt = "n", xlab = "", ylab = "Posterior inclusion probability",
       las = 1, cex.axis = 0.75, cex.lab = 0.8)
  pch <- c(16, 1, 3, 2)
  col <- c("black", "seagreen3", "purple", "darkorange")
  for (j in 1:4) points(1:n, pips[, j], pch = pch[j], col = col[j], cex = 0.8)
  axis(1, at = 1:n, labels = unname(labels[rownames(pips)]), las = 2, cex.axis = 0.55)
  legend("topright", bty = "n", cex = 0.75, pch = pch, col = col,
         legend = c("UIP and random (baseline)", "UIP and uniform", "BRIC and random", "UIP and dilution"))
}
pdf(file.path(figures, "F8_comparison.pdf"), width = 7, height = 4)
draw8()
invisible(dev.off())
cat("BMA done", format(Sys.time()), "\n")
