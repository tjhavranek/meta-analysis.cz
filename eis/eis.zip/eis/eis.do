******************************************************************************
******************************************************************************
*PUBLICATION BIAS IN MEASURING INTERTEMPORAL SUBSTITUTION
******************************************************************************
******************************************************************************
*Stata 12.0
*February 6, 2013 

log using eis.log, replace
use eis.dta, clear
set more off
******************************************************************************
*DEFINITION OF VARIABLES
******************************************************************************
label variable impact "The recursive RePEc impact factor of the outlet"
label variable cits "The number of Google Scholar citations of the study "
label variable yearcits "The number of per-year citations of the study"
label variable pubyear "The year of publication of the study"
label variable micro "=1 if the coefficient comes from a micro-level estimation"
label variable panel "=1 if panel data are used"
label variable quasipan "=1 if quasipanel (synthetic cohort) data are used"
label variable seprisk "=1 if the estimation differentiates between EIS and the coefficient of relative risk aversion"
label variable sepdur "=1 if the model allows for nonseparability between durables and nondurables"
label variable seplab "=1 if the model allows for non-separabilities between consumption and labor supply"
label variable sepgov "=1 if the model allows for nonseparability between private and public consumption"
label variable inverse "=1 if the interest rate is the dependent variable in the estimation"
label variable secord "=1 if second-order approximation is used"
label variable exact "=1 if the exact Euler equation is estimated"
label variable yearfe "=1 if year dummies are included"
label variable totalc "=1 if total consumption is used in the estimation"
label variable food "=1 if food is used as a proxy for nondurables"
label variable tastes "The number of controls for taste shifters"
label variable ml "=1 if maximum likelihood methods are used for estimation"
label variable tsls "=1 if two-stage least squares are used for estimation"
label variable coint "=1 if cointegrating regression is used for estimation"
label variable ols "=1 if ordinary least squares are used for estimation"
label variable bayes "=1 if Bayesian methods are used for estimation"
label variable income "=1 if income is included in the specification"
label variable inflinst "=1 if lags of inflation are included among instruments"
label variable firstlag "=1 if the first lags of variables are included among instruments"
label variable stockhold "=1 if the estimate corresponds to the subsample of rich or strockholders"
label variable nonstock "=1 if the estimate is for non-stockholders or poor"
label variable habits "=1 if habits in consumption are assumed"
label variable irstock "=1 if the interest rate is measured as stock return"
label variable ircap "=1 if the interest rate is measured as the return on capital"
label variable country "The country for which the elasticity is estimated"
label variable annual "=1 if data frequency is annual"
label variable monthly "=1 if data frequency is monthly"
label variable start "The start of the data period"
label variable end "The end of the data period"
label variable startyear "The start year of the data period"
label variable endyear "The end year of the data period"
label variable avyear "The average year of the data period"
label variable years "The number of years of the data period used in the estimation"
label variable obs "The number of observations"
label variable csunits "The number of cross-sectional units used in the estimation (households, cohorts, countries)"
label variable periods "The number of time units used in the estimation"
label variable septrd "=1 if the model allows for nonseparability between tradables and nontradables"
label variable perstudy "The number of observations per study"

gen prec = 1/se
gen tstat = eis/se
gen lnobs=ln(obs)
gen lncsunits=ln(csunits)
gen lnpubyear=ln(pubyear)
gen lnyears = ln(years)
gen lnavyear = ln(avyear)
gen lnyearcits = ln(yearcits + 1)
gen lntastes = ln(tastes + 1)
gen noyearfe = 0
gen invsqrtnobs = 1/sqrt(obs)
gen sqrtnobs = sqrt(obs)
replace noyearfe = 1 if micro==1 & quasipan==0 & food==1 & yearfe==0
gen invperstudy = 1/perstudy
quietly tabulate idcountry, gen(countryd)
quietly tabulate idstudy, gen(studyd)
xtset idstudy
local rhsvars lncsunits lnpubyear lnyears lnavyear lnyearcits lntastes noyearfe micro quasipan sepdur  sepgov septrd seprisk habits inverse exact totalc food ml tsls ols income firstlag stockhold irstock ircap annual monthly top impact
foreach x of varlist `rhsvars' {
				gen `x'_se = `x' / se
}
local rhsvars_se lncsunits_se lnpubyear_se lnyears_se lnavyear_se lnyearcits_se lntastes_se noyearfe_se micro_se quasipan_se sepdur_se sepgov_se septrd_se seprisk_se habits_se inverse_se exact_se totalc_se food_se ml_se tsls_se ols_se income_se firstlag_se stockhold_se irstock_se ircap_se annual_se monthly_se top_se impact_se 
local studies studyd*
foreach x of varlist `studies' {
				egen av`x' = mean(`x')
				scalar scav`x' = av`x' in 1
}
drop avstudyd*
local countries countryd*
foreach x of varlist `countries' {
				egen av`x' = mean(`x')
				scalar scav`x' = av`x' in 1
}
drop avcountryd*
drop countryd20 countryd109 countryd113 countryd115 countryd9 countryd33 countryd114
bysort idstudy: egen eismed = median(eis)
bysort idstudy: egen precmed = median(prec)
bysort idstudy: egen tmed = median(tstat)
******************************************************************************
*SUMMARY STATISTICS AND PLOTS
******************************************************************************
centile eis, centile(1(1)99)
centile eismed if last==1, centile(1(1)99)
centile eis if micro==1, centile(1(1)99)
centile eis if top==1, centile(1(1)99)
sum eis if abs(eis)<10
sum eismed if last==1 & abs(eismed)<10
sum eis if abs(eis)<10 & micro==1
sum eis if abs(eis)<10 & top==1
sum eis if abs(eis)<10 & stockhold==1
centile tstat, centile(1(1)99)
sum eis se micro stockhold lncsunits lnyears lnavyear annual monthly seprisk habits sepdur sepgov septrd quasipan inverse firstlag noyearfe income lntastes totalc food irstock ircap exact ml tsls ols lnpubyear lnyearcits top impact
corr `rhsvars'
collin `rhsvars'

scatter prec eis if prec<25 & abs(eis)<5, msize(*.3) msymbol(Oh) saving(funnel_all, replace)
scatter precmed eismed if precmed<100 & abs(eismed)<5, msize(*.9) msymbol(Oh) saving(funnel_perstudy, replace)
hist tmed if abs(tmed)<5.5 & last==1, xlabel(-2(0.5)5) width(0.564) normal saving(hist_perstudy, replace)
hist tmed if tmed<2.8 & tmed>1.3 & last==1, xlabel(1.3(0.1)2.8) width(0.1) start(1.4) saving(hist_around2, replace)
******************************************************************************
*FUNNEL ASYMMETRY TESTS
******************************************************************************
eststo: xtreg tstat prec, fe vce(cluster idstudy)
eststo: xtreg tstat prec, be
eststo: reg tmed precmed if last==1, vce(robust)
eststo: xtreg tstat prec if micro==1, fe vce(cluster idstudy)
eststo: xtreg tstat prec if top==1, fe vce(cluster idstudy)
xtreg tstat prec if idcountry==112, fe vce(cluster idstudy)
xtreg tstat prec if idcountry==108, fe vce(cluster idstudy)
xtreg tstat prec if idcountry==61, fe vce(cluster idstudy)

constraint 1 scavstudyd1*studyd1 + scavstudyd2*studyd2 + scavstudyd3*studyd3 + scavstudyd4*studyd4 + scavstudyd5*studyd5 + scavstudyd6*studyd6 + scavstudyd7*studyd7 + scavstudyd8*studyd8 + scavstudyd9*studyd9 + scavstudyd10*studyd10 + scavstudyd11*studyd11 + scavstudyd12*studyd12 + scavstudyd13*studyd13 + scavstudyd14*studyd14 + scavstudyd15*studyd15 + scavstudyd16*studyd16 + scavstudyd17*studyd17 + scavstudyd18*studyd18 + scavstudyd19*studyd19 + scavstudyd20*studyd20 + scavstudyd21*studyd21 + scavstudyd22*studyd22 + scavstudyd23*studyd23 + scavstudyd24*studyd24 + scavstudyd25*studyd25 + scavstudyd26*studyd26 + scavstudyd27*studyd27 + scavstudyd28*studyd28 + scavstudyd29*studyd29 + scavstudyd30*studyd30 + scavstudyd31*studyd31 + scavstudyd32*studyd32 + scavstudyd33*studyd33 + scavstudyd34*studyd34 + scavstudyd35*studyd35 + scavstudyd36*studyd36 + scavstudyd37*studyd37 + scavstudyd38*studyd38 + scavstudyd39*studyd39 + scavstudyd40*studyd40 + scavstudyd41*studyd41 + scavstudyd42*studyd42 + scavstudyd43*studyd43 + scavstudyd44*studyd44 + scavstudyd45*studyd45 + scavstudyd46*studyd46 + scavstudyd47*studyd47 + scavstudyd48*studyd48 + scavstudyd49*studyd49 + scavstudyd50*studyd50 + scavstudyd51*studyd51 + scavstudyd52*studyd52 + scavstudyd53*studyd53 + scavstudyd54*studyd54 + scavstudyd55*studyd55 + scavstudyd56*studyd56 + scavstudyd57*studyd57 + scavstudyd58*studyd58 + scavstudyd59*studyd59 + scavstudyd60*studyd60 + scavstudyd61*studyd61 + scavstudyd62*studyd62 + scavstudyd63*studyd63 + scavstudyd64*studyd64 + scavstudyd65*studyd65 + scavstudyd66*studyd66 + scavstudyd67*studyd67 + scavstudyd68*studyd68 + scavstudyd69*studyd69 + scavstudyd70*studyd70 + scavstudyd71*studyd71 + scavstudyd72*studyd72 + scavstudyd73*studyd73 + scavstudyd74*studyd74 + scavstudyd75*studyd75 + scavstudyd76*studyd76 + scavstudyd77*studyd77 + scavstudyd78*studyd78 + scavstudyd79*studyd79 + scavstudyd80*studyd80 + scavstudyd81*studyd81 + scavstudyd82*studyd82 + scavstudyd83*studyd83 + scavstudyd84*studyd84 + scavstudyd85*studyd85 + scavstudyd86*studyd86 + scavstudyd87*studyd87 + scavstudyd88*studyd88 + scavstudyd89*studyd89 + scavstudyd90*studyd90 + scavstudyd91*studyd91 + scavstudyd92*studyd92 + scavstudyd93*studyd93 + scavstudyd94*studyd94 + scavstudyd95*studyd95 + scavstudyd96*studyd96 + scavstudyd97*studyd97 + scavstudyd98*studyd98 + scavstudyd99*studyd99 + scavstudyd100*studyd100 + scavstudyd101*studyd101 + scavstudyd102*studyd102 + scavstudyd103*studyd103 + scavstudyd104*studyd104 + scavstudyd105*studyd105 + scavstudyd106*studyd106 + scavstudyd107*studyd107 + scavstudyd108*studyd108 + scavstudyd109*studyd109 + scavstudyd110*studyd110 + scavstudyd111*studyd111 + scavstudyd112*studyd112 + scavstudyd113*studyd113 + scavstudyd114*studyd114 + scavstudyd115*studyd115 + scavstudyd116*studyd116 + scavstudyd117*studyd117 + scavstudyd118*studyd118 + scavstudyd119*studyd119 + scavstudyd120*studyd120 + scavstudyd121*studyd121 + scavstudyd122*studyd122 + scavstudyd123*studyd123 + scavstudyd124*studyd124 + scavstudyd125*studyd125 + scavstudyd126*studyd126 + scavstudyd127*studyd127 + scavstudyd128*studyd128 + scavstudyd129*studyd129 + scavstudyd130*studyd130 + scavstudyd131*studyd131 + scavstudyd132*studyd132 + scavstudyd133*studyd133 + scavstudyd134*studyd134 + scavstudyd135*studyd135 + scavstudyd136*studyd136 + scavstudyd137*studyd137 + scavstudyd138*studyd138 + scavstudyd139*studyd139 + scavstudyd140*studyd140 + scavstudyd141*studyd141 + scavstudyd142*studyd142 + scavstudyd143*studyd143 + scavstudyd144*studyd144 + scavstudyd145*studyd145 + scavstudyd146*studyd146 + scavstudyd147*studyd147 + scavstudyd148*studyd148 + scavstudyd149*studyd149 + scavstudyd150*studyd150 + scavstudyd151*studyd151 + scavstudyd152*studyd152 + scavstudyd153*studyd153 + scavstudyd154*studyd154 + scavstudyd155*studyd155 + scavstudyd156*studyd156 + scavstudyd157*studyd157 + scavstudyd158*studyd158 + scavstudyd159*studyd159 + scavstudyd160*studyd160 + scavstudyd161*studyd161 + scavstudyd162*studyd162 + scavstudyd163*studyd163 + scavstudyd164*studyd164 + scavstudyd165*studyd165 + scavstudyd166*studyd166 + scavstudyd167*studyd167 + scavstudyd168*studyd168 + scavstudyd169*studyd169 = 0

constraint 2 scavcountryd1*countryd1 + scavcountryd2*countryd2 + scavcountryd3*countryd3 + scavcountryd4*countryd4 + scavcountryd5*countryd5 + scavcountryd6*countryd6 + scavcountryd7*countryd7 + scavcountryd8*countryd8 + scavcountryd10*countryd10 + scavcountryd11*countryd11 + scavcountryd12*countryd12 + scavcountryd13*countryd13 + scavcountryd14*countryd14 + scavcountryd15*countryd15 + scavcountryd16*countryd16 + scavcountryd17*countryd17 + scavcountryd18*countryd18 + scavcountryd19*countryd19 + scavcountryd21*countryd21 + scavcountryd22*countryd22 + scavcountryd23*countryd23 + scavcountryd24*countryd24 + scavcountryd25*countryd25 + scavcountryd26*countryd26 + scavcountryd27*countryd27 + scavcountryd28*countryd28 + scavcountryd29*countryd29 + scavcountryd30*countryd30 + scavcountryd31*countryd31 + scavcountryd32*countryd32 + scavcountryd34*countryd34 + scavcountryd35*countryd35 + scavcountryd36*countryd36 + scavcountryd37*countryd37 + scavcountryd38*countryd38 + scavcountryd39*countryd39 + scavcountryd40*countryd40 + scavcountryd41*countryd41 + scavcountryd42*countryd42 + scavcountryd43*countryd43 + scavcountryd44*countryd44 + scavcountryd45*countryd45 + scavcountryd46*countryd46 + scavcountryd47*countryd47 + scavcountryd48*countryd48 + scavcountryd49*countryd49 + scavcountryd50*countryd50 + scavcountryd51*countryd51 + scavcountryd52*countryd52 + scavcountryd53*countryd53 + scavcountryd54*countryd54 + scavcountryd55*countryd55 + scavcountryd56*countryd56 + scavcountryd57*countryd57 + scavcountryd58*countryd58 + scavcountryd59*countryd59 + scavcountryd60*countryd60 + scavcountryd61*countryd61 + scavcountryd62*countryd62 + scavcountryd63*countryd63 + scavcountryd64*countryd64 + scavcountryd65*countryd65 + scavcountryd66*countryd66 + scavcountryd67*countryd67 + scavcountryd68*countryd68 + scavcountryd69*countryd69 + scavcountryd70*countryd70 + scavcountryd71*countryd71 + scavcountryd72*countryd72 + scavcountryd73*countryd73 + scavcountryd74*countryd74 + scavcountryd75*countryd75 + scavcountryd76*countryd76 + scavcountryd77*countryd77 + scavcountryd78*countryd78 + scavcountryd79*countryd79 + scavcountryd80*countryd80 + scavcountryd81*countryd81 + scavcountryd82*countryd82 + scavcountryd83*countryd83 + scavcountryd84*countryd84 + scavcountryd85*countryd85 + scavcountryd86*countryd86 + scavcountryd87*countryd87 + scavcountryd88*countryd88 + scavcountryd89*countryd89 + scavcountryd90*countryd90 + scavcountryd91*countryd91 + scavcountryd92*countryd92 + scavcountryd93*countryd93 + scavcountryd94*countryd94 + scavcountryd95*countryd95 + scavcountryd96*countryd96 + scavcountryd97*countryd97 + scavcountryd98*countryd98 + scavcountryd99*countryd99 + scavcountryd100*countryd100 + scavcountryd101*countryd101 + scavcountryd102*countryd102 + scavcountryd103*countryd103 + scavcountryd104*countryd104 + scavcountryd105*countryd105 + scavcountryd106*countryd106 + scavcountryd107*countryd107 + scavcountryd108*countryd108 + scavcountryd110*countryd110 + scavcountryd111*countryd111 + scavcountryd112*countryd112 + scavcountryd116*countryd116 + scavcountryd117*countryd117 + scavcountryd118*countryd118 + scavcountryd119*countryd119 + scavcountryd120*countryd120 = 0

quietly eststo: version 10.1: cnsreg tstat prec studyd* countryd*, constraint(1,2) vce(cluster idstudy)
esttab using fat.tex, se booktabs replace compress title(Funnel asymmetry test\label{tab:fat}) mtitles("FE" "BE" "Med" "IV" "Micro" "Top" "Country") addnote("Standard errors are clustered at the study level.") star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) label nonumber nogaps width(1\hsize)
eststo clear

xtivreg tstat (prec = invsqrtnobs), fe
ivregress 2sls tstat micro_se stockhold_se lncsunits_se lnyears_se lnavyear_se annual_se monthly_se seprisk_se habits_se sepdur_se sepgov_se septrd_se quasipan_se inverse_se firstlag_se noyearfe_se income_se lntastes_se totalc_se food_se irstock_se ircap_se exact_se ml_se tsls_se ols_se lnpubyear_se lnyearcits_se top_se impact_se (prec = invsqrtnobs)  [pweight=invperstudy], vce(cluster idstudy)
xtreg tstat sqrtnobs, fe vce(cluster idstudy)
reg tstat sqrtnobs micro_se stockhold_se lncsunits_se lnyears_se lnavyear_se annual_se monthly_se seprisk_se habits_se sepdur_se sepgov_se septrd_se quasipan_se inverse_se firstlag_se noyearfe_se income_se lntastes_se totalc_se food_se irstock_se ircap_se exact_se ml_se tsls_se ols_se lnpubyear_se lnyearcits_se top_se impact_se  [pweight=invperstudy], vce(cluster idstudy)
******************************************************************************
*EXPLAINING HETEROGENEITY
******************************************************************************
quietly eststo: reg tstat prec micro_se stockhold_se [pweight=invperstudy], vce(cluster idstudy)
lincom prec + micro_se + stockhold_se
quietly eststo: reg tstat prec micro_se stockhold_se seprisk_se habits_se sepdur_se sepgov_se septrd_se [pweight=invperstudy], vce(cluster idstudy)
test seprisk_se habits_se sepdur_se sepgov_se septrd_se
quietly eststo: reg tstat prec micro_se stockhold_se lncsunits_se lnyears_se lnavyear_se annual_se monthly_se seprisk_se habits_se sepdur_se sepgov_se septrd_se [pweight=invperstudy], vce(cluster idstudy)
test lncsunits_se lnyears_se lnavyear_se annual_se monthly_se
quietly eststo: reg tstat prec micro_se stockhold_se lncsunits_se lnyears_se lnavyear_se annual_se monthly_se seprisk_se habits_se sepdur_se sepgov_se septrd_se quasipan_se inverse_se firstlag_se noyearfe_se income_se lntastes_se [pweight=invperstudy], vce(cluster idstudy)
test quasipan_se inverse_se firstlag_se noyearfe_se income_se lntastes_se
quietly eststo: reg tstat prec micro_se stockhold_se lncsunits_se lnyears_se lnavyear_se annual_se monthly_se seprisk_se habits_se sepdur_se sepgov_se septrd_se quasipan_se inverse_se firstlag_se noyearfe_se income_se lntastes_se totalc_se food_se irstock_se ircap_se [pweight=invperstudy], vce(cluster idstudy)
test totalc_se food_se irstock_se ircap_se
quietly eststo: reg tstat prec micro_se stockhold_se lncsunits_se lnyears_se lnavyear_se annual_se monthly_se seprisk_se habits_se sepdur_se sepgov_se septrd_se quasipan_se inverse_se firstlag_se noyearfe_se income_se lntastes_se totalc_se food_se irstock_se ircap_se exact_se ml_se tsls_se ols_se [pweight=invperstudy], vce(cluster idstudy)
test exact_se ml_se tsls_se ols_se
quietly eststo: reg tstat prec micro_se stockhold_se lncsunits_se lnyears_se lnavyear_se annual_se monthly_se seprisk_se habits_se sepdur_se sepgov_se septrd_se quasipan_se inverse_se firstlag_se noyearfe_se income_se lntastes_se totalc_se food_se irstock_se ircap_se exact_se ml_se tsls_se ols_se lnpubyear_se lnyearcits_se top_se impact_se [pweight=invperstudy], vce(cluster idstudy)
test lnpubyear_se lnyearcits_se top_se impact_se
esttab using het.tex, se booktabs replace compress title(Explaining heterogeneity\label{tab:het}) addnote("Standard errors are clustered at the study level.") star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) label nogaps width(1\hsize)
eststo clear

foreach x of varlist `rhsvars' {
				egen aver`x' = mean(`x')
				scalar scav`x' = aver`x' in 1
}
drop aver*
foreach x of varlist `rhsvars' {
				egen max`x' = max(`x')
				scalar scmax`x' = max`x' in 1
}
drop max*
foreach x of varlist `rhsvars' {
				egen min`x' = min(`x')
				scalar scmin`x' = min`x' in 1
}
drop min*

lincom prec + micro_se + stockhold_se + scmaxlncsunits*lncsunits_se + scmaxlnyears*lnyears_se + scmaxlnavyear*lnavyear_se + scavannual*annual_se + scavmonthly*monthly_se + seprisk_se + scavhabits*habits_se + sepdur_se + scavsepgov*sepgov_se + scavseptrd*septrd_se + scavquasipan*quasipan_se + 0*inverse_se + 0*firstlag_se + 0*noyearfe_se + scavincome*income_se + scavlntastes*lntastes_se + 0*totalc_se + 0*food_se + 0*irstock_se + ircap_se + exact_se + 0*ml_se + 0*tsls_se + 0*ols_se + scavlnpubyear*lnpubyear_se + scmaxlnyearcits*lnyearcits_se + top_se + scmaximpact*impact_se
******************************************************************************
*HEDGES' TEST FOR PUBLICATION BIAS
******************************************************************************
global t1=invnormal(1-.5*.01)
global t2=invnormal(1-.5*.05)
global t3=invnormal(1-.5*.10)
dis %8.3f $t1 %8.3f $t2 %8.3f $t3

gen group=1
replace group=2 if tstat<$t1
replace group=3 if tstat<$t2
replace group=4 if tstat<$t3

program hedges1
         version 12.0
         args todo b lnf
         tempvar theta1 sigma l eta
         mleval `theta1' = `b', eq(1)
         mleval `sigma'=`b', eq(2)

         gen double `eta'=sqrt(se*se+`sigma'*`sigma')

         quietly gen double `l' = -ln(`eta')-.5*(($ML_y1-`theta1')/`eta')^2
         mlsum `lnf' = `l'
end

program hedges2
         version 12.0
         args todo b lnf
         tempvar theta1 sigma l lg lgg g1 g2 g3 g4 eta
         mleval `theta1' = `b', eq(1)
         mleval `sigma'=`b', eq(2)
         mleval `g2'=`b', eq(3)
         mleval `g3'=`b', eq(4)
         mleval `g4'=`b', eq(5)

         gen double `eta'=sqrt(se*se+`sigma'*`sigma')
         gen double `g1'=1
         quietly gen double `lg'=`g1' if group==1
         quietly replace `lg'=(1-`g2') if group==2
         quietly replace `lg'=(1-`g3') if group==3
         quietly replace `lg'=(1-`g4') if group==4
         quietly gen double `lgg'=`g1'*(1-normal(($t1*se-`theta1')/`eta'))
         quietly replace `lgg'=`lgg'+(1-`g2')*(normal(($t1*se-`theta1')/`eta')-normal(($t2*se-`theta1')/`eta'))
         quietly replace `lgg'=`lgg'+(1-`g3')*(normal(($t2*se-`theta1')/`eta')-normal(($t3*se-`theta1')/`eta'))
         quietly replace `lgg'=`lgg'+(1-`g4')*(normal(($t3*se-`theta1')/`eta'))
         quietly gen double `l' =-ln(`eta')-.5*(($ML_y1-`theta1')/`eta')^2+ln(`lg')-ln(`lgg')
         mlsum `lnf' = `l'
end

ml model d0 hedges1 (equation:eis = ) (sigma:)
ml maximize
gen ll1=e(ll)
ml model d0 hedges2 (equation:eis = ) (sigma:)(g2:)(g3:)(g4:)
ml maximize
gen ll2=e(ll)
ml model d0 hedges1 (equation:eis = micro stockhold lncsunits lnyears lnavyear annual monthly seprisk habits sepdur sepgov septrd quasipan inverse firstlag noyearfe income lntastes totalc food irstock ircap exact ml tsls ols lnpubyear lnyearcits top impact) (sigma:)
ml maximize
gen ll3=e(ll)
ml model d0 hedges2 (equation:eis = micro stockhold lncsunits lnyears lnavyear annual monthly seprisk habits sepdur sepgov septrd quasipan inverse firstlag noyearfe income lntastes totalc food irstock ircap exact ml tsls ols lnpubyear lnyearcits top impact) (sigma:)(g2:)(g3:)(g4:)
ml maximize
gen ll4=e(ll)
gen lldiff12=2*abs(ll1-ll2)
display chi2tail(3, lldiff12)
gen lldiff34=2*abs(ll3-ll4)
display chi2tail(3, lldiff34)
******************************************************************************
*BAYESIAN MODEL AVERAGING
******************************************************************************
*//Switch to R

*library(BMS)

*//Data
*//load data: the first column is the response variable, other columns explanatory variables.
*dataeis=read.table("clipboard-512", sep="\t", header=TRUE)

*//Estimation
*eis = bms(dataeis, burn=100000000, iter=200000000, g="UIP", mprior="uniform", nmodel=5000, mcmc="bd", user.int=FALSE)

*//Diagnostics
*plot(eis)
*summary(eis)

*//Results
*coef(eis, order.by.pip = F, exact=T, include.constant=T)
*image(eis[1:5000], cex.axis=0.7, order.by.pip = T, yprop2pip=F)
******************************************************************************
*FUNNEL PLOT OF THE ESTIMATES OF PUBLICATION BIAS
******************************************************************************
*Switch to Stata, load estimates of publication bias and their standard errors
*scatter prec bias, msize(*1.5) msymbol(Oh)
*graph twoway (scatter tstat prec, msize(*1.5) msymbol(Oh))  (lfit tstat prec)
******************************************************************************
window manage close graph
log close
exit, clear
******************************************************************************
******************************************************************************
