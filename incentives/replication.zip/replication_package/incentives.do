/**************************************************************************************
Replication script: 
Financial Incentives and Performance: A Meta-Analysis of Experiments in Economics

Authors: Cala, Havranek, Irsova, Matousek, Luskova, Novak | v1.4
Last updated: 2025-12-16

Purpose: Replicates main-text and appendix results (distributions, heterogeneity,
publication-bias analyses).
Project page: https://meta-analysis.cz/incentives/

Inputs:  incentives.xlsx (sheet "data")
Outputs: incentives.log; .gph graphs; .tex tables; .csv/.xlsx exports for R

Requirements: Stata 15+
***************************************************************************************/

set more off
set varabbrev off
capture log close _all

* set up output folders
local OUT_RESULTS "results"
local OUT_AUX     "auxiliaries"
capture mkdir "`OUT_RESULTS'"
capture mkdir "`OUT_AUX'"

* install or update required packages
foreach pkg in winsor2 ivreg2 boottest estout moremata avar ranktest twostepweakiv {
    cap which `pkg'
    if _rc cap ssc install `pkg', replace
}
cap which collin
if _rc di as txt "Note: 'collin' not found; collinearity diagnostics will be skipped."

cap confirm file "incentives.xlsx"
if _rc {
    di as err "ERROR: Run this do-file from the replication_package folder (the one containing incentives.xlsx)."
    exit 601
}

log using `OUT_RESULTS'/incentives.log, replace

***************************************************************************************
***************************************************************************************
***************************************************************************************
***************************  1. Baseline PCC/CD dataset   *****************************
*************************************(1,252 nobs)**************************************
***************************************************************************************
***************************************************************************************

*======================================================================================
* 1.1 Load data and set panel structure
*======================================================================================

import excel "incentives.xlsx", sheet("data") firstrow clear
xtset study_id

*======================================================================================
* 1.2 Data preparation (baseline PCC dataset)
*======================================================================================
* Keep only top journals without working papers

drop if include == 2 
drop if bma == 0
drop if missing(include)

winsor2 pcc, suffix(_w) cuts(1 99)
winsor2 se_pcc, suffix(_w) cuts(1 99)
gen precision_pcc = 1/se_pcc
gen precision_w = 1/se_pcc_w
gen tstat_w = t_adjusted
gen effect_negative=0
gen inv_sample_size = 1/sqrt(observations)
replace effect_negative=1 if effect_positive==0
gen developing_country=0
replace developing_country=1 if developed_country==0
gen other_method2=0
replace other_method2=1 if (mean_method==1 | other_method==1)
gen se_control = se_pcc_w * control_zero
gen impact_factor = ln(study_impact)
gen citations = ln(study_citations / (2025 - publication_year))
gen data_avgyear = ln(data_year)
gen n_obs = ln(observations)
bys study_id: gen weight = 1 / _N
bys study_id: egen n_pref = total(preferred == 1)
gen weight_pref = 1/n_pref if preferred == 1
bys experiment_id: gen weight_exp = 1 / _N
bys experiment_id: egen n_exp_pref = total(preferred == 1)
winsor2 n_obs, suffix(_w) cuts(1 99)
winsor2 cohens_d, suffix(_w) cuts(1 99)
winsor2 se_cohens_d, suffix(_w) cuts(1 99)
gen precision_cohens_d = 1/se_cohens_d
gen precision_cohens_d_w = 1/se_cohens_d_w
gen tstat_cohens_d = cohens_d/se_cohens_d
gen tstat_cohens_d_w = cohens_d_w/se_cohens_d_w

*======================================================================================
* 1.3 Summary statistics and correlations
*======================================================================================

* Table 1: Subsets of the literature yield similar results
mean pcc_w 
mean pcc_w if preferred==1
mean pcc_w if preferred==0
mean pcc_w if effect_gpa==1
mean pcc_w if effect_charity==1
mean pcc_w if effect_game==1 
mean pcc_w if effect_work==1 
mean pcc_w if effect_positive==1 
mean pcc_w if effect_positive==0
mean pcc_w if task_app==1 
mean pcc_w if task_napp==1  
mean pcc_w if task_cog==1  
mean pcc_w if task_man==1
mean pcc_w if perf_quan==1  
mean pcc_w if perf_qual==1  
mean pcc_w if reward_scaled>=0.5
mean pcc_w if reward_scaled<0.5
mean pcc_w if framing_pos==1  
mean pcc_w if framing_neg==1  
mean pcc_w if all_paid==1  
mean pcc_w if reward_own==1  
mean pcc_w if reward_else==1  
mean pcc_w if control_zero==1  
mean pcc_w if control_nonzero==1 
mean pcc_w if mot_alt==1  
mean pcc_w if mot_rec==1  
mean pcc_w if mot_fai==1  
mean pcc_w if mot_mon==1   
mean pcc_w if location_lab==1  
mean pcc_w if location_field==1  
mean pcc_w if crowding_out==1  
mean pcc_w if subject_st==1  
mean pcc_w if subject_emp==1  
mean pcc_w if subject_mix==1  
mean pcc_w if male>0.5
mean pcc_w if male==0.5   
mean pcc_w if male<0.5  
mean pcc_w if developed_country==1  
mean pcc_w if developed_country==0
mean pcc_w if ols_method==1  
mean pcc_w if logit_method==1  
mean pcc_w if probit_method==1  
mean pcc_w if tobit_method==1  
mean pcc_w if fe_method==1  
mean pcc_w if re_method==1  
mean pcc_w if did_method==1  
mean pcc_w if (other_method==1|mean_method==1)
mean pcc_w if data_cross==1  
mean pcc_w if data_panel==1  
mean pcc_w [aweight=weight]
mean pcc_w [aweight=weight] if preferred==1
mean pcc_w [aweight=weight] if preferred==0
mean pcc_w [aweight=weight] if effect_gpa==1
mean pcc_w [aweight=weight] if effect_charity==1
mean pcc_w [aweight=weight] if effect_game==1 
mean pcc_w [aweight=weight] if effect_work==1 
mean pcc_w [aweight=weight] if effect_positive==1 
mean pcc_w [aweight=weight] if effect_positive==0
mean pcc_w [aweight=weight] if task_app==1 
mean pcc_w [aweight=weight] if task_napp==1  
mean pcc_w [aweight=weight] if task_cog==1  
mean pcc_w [aweight=weight] if task_man==1
mean pcc_w [aweight=weight] if perf_quan==1  
mean pcc_w [aweight=weight] if perf_qual==1    
mean pcc_w [aweight=weight] if reward_scaled>=0.5
mean pcc_w [aweight=weight] if reward_scaled<0.5
mean pcc_w [aweight=weight] if framing_pos==1  
mean pcc_w [aweight=weight] if framing_neg==1  
mean pcc_w [aweight=weight] if all_paid==1  
mean pcc_w [aweight=weight] if reward_own==1  
mean pcc_w [aweight=weight] if reward_else==1  
mean pcc_w [aweight=weight] if control_zero==1  
mean pcc_w [aweight=weight] if control_nonzero==1  
mean pcc_w [aweight=weight] if mot_alt==1  
mean pcc_w [aweight=weight] if mot_rec==1  
mean pcc_w [aweight=weight] if mot_fai==1  
mean pcc_w [aweight=weight] if mot_mon==1  
mean pcc_w [aweight=weight] if location_lab==1  
mean pcc_w [aweight=weight] if location_field==1  
mean pcc_w [aweight=weight] if crowding_out==1  
mean pcc_w [aweight=weight] if subject_st==1  
mean pcc_w [aweight=weight] if subject_emp==1  
mean pcc_w [aweight=weight] if subject_mix==1  
mean pcc_w [aweight=weight] if male>0.5
mean pcc_w [aweight=weight] if male==0.5   
mean pcc_w [aweight=weight] if male<0.5  
mean pcc_w [aweight=weight] if developed_country==1  
mean pcc_w [aweight=weight] if developed_country==0
mean pcc_w [aweight=weight] if ols_method==1  
mean pcc_w [aweight=weight] if logit_method==1  
mean pcc_w [aweight=weight] if probit_method==1  
mean pcc_w [aweight=weight] if tobit_method==1  
mean pcc_w [aweight=weight] if fe_method==1  
mean pcc_w [aweight=weight] if re_method==1  
mean pcc_w [aweight=weight] if did_method==1  
mean pcc_w [aweight=weight] if (other_method==1|mean_method==1)
mean pcc_w [aweight=weight] if data_cross==1  
mean pcc_w [aweight=weight] if data_panel==1  

* Table 3: Description and summary statistics of regression variables
sum pcc_w se_pcc_w, detail
sum pcc_w se_pcc_w preferred effect_gpa effect_charity effect_game effect_work effect_positive effect_negative task_app task_napp task_cog task_man perf_quan perf_qual reward_scaled framing_pos framing_neg all_paid reward_own reward_else control_zero control_nonzero mot_alt mot_rec mot_fai mot_mon location_lab location_field crowding_out subject_st subject_emp subject_mix male mid_age data_avgyear developed_country developing_country ols_method logit_method probit_method tobit_method fe_method re_method did_method other_method2 data_cross data_panel impact_factor citations
correlate pcc_w se_pcc_w preferred effect_gpa effect_charity effect_game effect_work effect_positive effect_negative task_app task_napp task_cog task_man perf_quan perf_qual reward_scaled framing_pos framing_neg all_paid reward_own reward_else control_zero  control_nonzero mot_alt mot_rec mot_fai mot_mon location_lab location_field crowding_out subject_st subject_emp subject_mix male mid_age data_avgyear developed_country developing_country ols_method logit_method probit_method tobit_method fe_method re_method did_method other_method2 data_cross data_panel impact_factor citations if bma==1
sum pcc_w se_pcc_w preferred effect_gpa effect_charity effect_game effect_work effect_positive effect_negative task_app task_napp task_cog task_man perf_quan perf_qual reward_scaled framing_pos framing_neg all_paid reward_own reward_else control_zero control_nonzero mot_alt mot_rec mot_fai mot_mon location_lab location_field crowding_out subject_st subject_emp subject_mix male mid_age data_avgyear developed_country developing_country ols_method logit_method probit_method tobit_method fe_method re_method did_method other_method2 data_cross data_panel impact_factor citations if bma==1

*======================================================================================
* 1.4 Figures: heterogeneity and distributions
*======================================================================================

* Figure 1: Heterogeneity in the literature
bysort study_id: egen pcc_med = median(pcc_w)
bysort study_id: egen midyear_med = median(data_year)
graph twoway (scatter pcc_med midyear_med, msize(*1) msymbol(Oh) yline(1, lpattern(dott)) ylabel( ,glcolor(ltbluishgray)) graphregion(color(ltbluishgray))) (lfit pcc_w midyear_med, lcolor(bluishgray) lpattern(dash)), xtitle("Median year of data used by a study") ytitle("Median partial correlation coefficient") legend(off) saving(`OUT_RESULTS'/trend, replace)

* Figure 2: Small positive estimates are most common
histogram pcc if pcc>-0.4 & pcc<0.6, bin(60) fcolor(gs14) lstyle(thin) frequency xtitle("Partial correlation coefficient") xline(0.051, lcolor(red)) xline(0, lcolor(bluishgray)) xlabel(-0.4 -0.2 0 0.051 0.2 0.4 0.6) ylabel( ,glcolor(ltbluishgray)) graphregion(color(ltbluishgray)) saving(`OUT_RESULTS'/histogram, replace)

* Figure 3: Results differ both across and within studies
graph hbox pcc if pcc>-0.4 & pcc<0.6, over(study,label(grid) sort(midyear_med)) xsize(2.6) ysize(4) scale(0.55) yline(0, lcolor (bluishgray)) box(1,lcolor(black) fcolor(none)) marker(1,msymbol(circle_hollow) mcolor(gs12)) ytitle("Partial correlation coefficient") ylabel(, nogrid) saving(`OUT_RESULTS'/studies, replace) 

* Figure 4: Few prima facie patterns in the data
twoway(hist pcc if ols_method==1 & pcc>-0.4 & pcc<0.6, bin(70) freq fcolor(navy) lcolor(navy) legend(label(1 "Method: OLS")))  (hist pcc if pcc>-0.4 & pcc<0.6 & (probit_method==1 | logit_method==1), bin(60) gap(20) freq lcolor(gs12) fcolor(gs12) legend(label(2 "Method: probit & logit"))), xlabel(-0.4 -0.2 0 0.2 0.4 0.6) legend(ring(0) position(2) bmargin(medium) rows(2) region(lstyle(none))) xtitle("Partial correlation coefficient") xline(0, lcolor(bluishgray)) saving(`OUT_RESULTS'/pattern1, replace)
twoway(hist pcc if pcc>-0.4 & pcc<0.6 & control_zero==1, bin(55) gap(2) freq fcolor(navy) lcolor(navy) legend(label(1 "Control: no incentive"))) (hist pcc if control_nonzero==1 & pcc>-0.4 & pcc<0.6, bin(60) gap(10) freq fcolor(gs12) lcolor(gs12) legend(label(2 "Baseline: some incentive"))), legend(ring(0) position(2) bmargin(medium) rows(2) region(lstyle(none))) xtitle("Partial correlation coefficient") xlabel(-0.4 -0.2 0 0.2 0.4 0.6) xline(0, lcolor(bluishgray)) saving(`OUT_RESULTS'/pattern2, replace)
twoway(hist pcc if developed_country==1 & pcc>-0.4 & pcc<0.6, bin(60) freq fcolor(navy) lcolor(navy) legend(label(1 "Developed country")))(hist pcc if developed_country==0 & pcc>-0.4 & pcc<0.6, bin(60) gap(10) freq fcolor(gs12) lcolor(gs12) legend(label(2 "Developing country"))) , legend(ring(0) position(2) bmargin(medium) rows(2) region(lstyle(none))) xtitle("Partial correlation coefficient") xlabel(-0.4 -0.2 0 0.2 0.4 0.6) xline(0, lcolor(bluishgray)) saving(`OUT_RESULTS'/pattern3, replace)
twoway(hist pcc if location_field==1 & pcc>-0.4 & pcc<0.6, bin(60) gap(10) freq fcolor(gs12) lcolor(gs12) legend(label(1 "Field experiment")))(hist pcc if crowding_out==1 & pcc>-0.4 & pcc<0.6, bin(60) gap(10) freq fcolor(cranberry) lcolor(cranberry) legend(label(2 "Crowding-out theory")))(hist pcc if location_lab==1 & pcc>-0.4 & pcc<0.6, bin(60) freq fcolor(navy) lcolor(navy) legend(label(3 "Laboratory experiment"))) , legend(ring(0) position(2) bmargin(medium) rows(3) region(lstyle(none))) xtitle("Partial correlation coefficient") xlabel(-0.4 -0.2 0 0.2 0.4 0.6) xline(0, lcolor(bluishgray)) saving(`OUT_RESULTS'/pattern4, replace)
twoway(hist pcc if subject_st==1 & pcc>-0.4 & pcc<0.6, bin(60) gap(10) freq fcolor(gs12) lcolor(gs12) legend(label(1 "Subjects: students")))(hist pcc if subject_mix==1 & pcc>-0.4 & pcc<0.6, bin(60) freq fcolor(navy) lcolor(navy) legend(label(2 "Subjects: general population")))(hist pcc if subject_emp==1 & pcc>-0.4 & pcc<0.6, bin(60) gap(10) freq fcolor(cranberry) lcolor(cranberry) legend(label(3 "Subject: employees"))) , legend(ring(0) position(2) bmargin(medium) rows(3) region(lstyle(none))) xtitle("Partial correlation coefficient") xlabel(-0.4 -0.2 0 0.2 0.4 0.6) xline(0, lcolor(bluishgray)) saving(`OUT_RESULTS'/pattern5, replace)
twoway(hist pcc if framing_pos==1 & pcc>-0.4 & pcc<0.6, bin(65) freq fcolor(navy) lcolor(navy) legend(label(1 "Positive framing"))) (hist pcc if framing_neg==1 & pcc>-0.4 & pcc<0.6, bin(40) freq fcolor(cranberry) lcolor(cranberry) legend(label(2 "Negative framing"))), legend(ring(0) position(2) bmargin(medium) rows(2) region(lstyle(none))) xtitle("Partial correlation coefficient") xlabel(-0.4 -0.2 0 0.2 0.4 0.6) xline(0, lcolor(bluishgray)) saving(`OUT_RESULTS'/pattern6, replace)
twoway(kdensity pcc if mot_alt==1 & pcc>-0.4 & pcc<0.6, legend(label(1 "Motivation: altruism")))(kdensity pcc if mot_rec==1 & pcc>-0.4 & pcc<0.6, legend(label(2 "Motivation: reciprocity")))(kdensity pcc if mot_fai==1 & pcc>-0.4 & pcc<0.6, legend(label(3 "Motivation: fairness")))(kdensity pcc if mot_mon==1 & pcc>-0.4 & pcc<0.6, legend(label(4 "Motivation: money"))), legend(ring(0) position(2) bmargin(medium) rows(4) region(lstyle(none))) xtitle("Partial correlation coefficient") ytitle("Kernel density (PCC)") xlabel(-0.4 -0.2 0 0.2 0.4 0.6) xline(0, lcolor(bluishgray)) saving(`OUT_RESULTS'/pattern7, replace)
twoway(kdensity pcc if effect_gpa==1 & pcc>-0.4 & pcc<0.6, legend(label(1 "Effect: grades")))(kdensity pcc if effect_charity==1 & pcc>-0.4 & pcc<0.6, legend(label(2 "Effect: charity")))(kdensity pcc if effect_game==1 & pcc>-0.4 & pcc<0.6, legend(label(3 "Effect: game")))(kdensity pcc if effect_work==1 & pcc>-0.4 & pcc<0.6, legend(label(4 "Effect: work"))), legend(ring(0) position(2) bmargin(medium) rows(4) region(lstyle(none))) xtitle("Partial correlation coefficient") ytitle("Kernel density (PCC)") xlabel(-0.4 -0.2 0 0.2 0.4 0.6) xline(0, lcolor(bluishgray)) saving(`OUT_RESULTS'/pattern8, replace)

* Figure B1: No systematic differences in results across countries
graph hbox pcc if pcc>-0.4 & pcc<0.6, over(country,label(grid)) xsize(6) ysize(5) scale(0.8) yline(0, lcolor (bluishgray)) box( 1,lcolor(black) fcolor(none)) marker(1,msymbol(circle_hollow) mcolor(gs12)) ytitle("Partial correlation coefficient") ylabel(, nogrid) saving(`OUT_RESULTS'/countries, replace) 

* Figure B3: The distribution of t-statistics peaks at zero
histogram t_adjusted if t_adjusted<15 & t_adjusted>-15, bin(38) fcolor(gs14) lstyle(thin) frequency xtitle("Reported t-statistics") xline(-1.96 0 1.96, lcolor(red)) xlabel(-5 -1.96 0 1.96 5 10 15) ylabel( ,glcolor(ltbluishgray)) graphregion(color(ltbluishgray)) saving(`OUT_RESULTS'/caliper, replace)

*======================================================================================
* 1.5 Publication bias: funnel plots
*======================================================================================

sum pcc precision_pcc

* Figure 5: Funnel plots consistent with modest publication bias
twoway scatter  precision_pcc pcc if precision_pcc<600 & pcc>-0.4 & pcc<0.6, ytitle("Precision of the partial correlation coefficient (1/SE)") ylabel( ,glcolor(ltbluishgray)) xtitle("Partial correlation coefficient") xline(0, lpattern(solid) lcolor (bluishgray)) xlabel(0 , add) msymbol(smcircle_hollow) graphregion(color(ltbluishgray)) saving(`OUT_RESULTS'/funnel, replace)
twoway scatter  precision_pcc pcc if precision_pcc<600 & pcc>-0.4 & pcc<0.6 & preferred==1, ytitle("Precision of the partial correlation coefficient (1/SE)") ylabel( ,glcolor(ltbluishgray)) xtitle("Partial correlation coefficient") xline(0, lpattern(solid) lcolor (bluishgray)) xlabel(0 , add) msymbol(smcircle_hollow) graphregion(color(ltbluishgray)) saving(`OUT_RESULTS'/funnel_pref, replace)

*======================================================================================
* 1.6 Publication bias: FAT-PET, TOP10, WAAP, endogenous kink
*======================================================================================
* Table 2: Most techniques suggest signiffcant publication bias, small corrected effect
* Table B3: Publication bias tests for the baseline dataset (Cohen's d) 
* Table B6: Publication bias tests for the baseline dataset (no winsorizing)

xtset study_id

*-------------------------------------------------------------------------------------*
* endogenous kink function
*-------------------------------------------------------------------------------------*
capture program drop ek_kink
program define ek_kink, rclass
    syntax varlist(min=2 max=2 numeric) [if] [in], LABEL(string)

    marksample touse
    tokenize `varlist'
    local y  `1'
    local se `2'
    tempvar bs sebs ones sebs2 wis bs_sebs ones_sebs sebs_a1 pubbias
    quietly {
        count if `touse'
        local M = r(N)
        if `M' == 0 {
            exit 2000
        }
        // Copy variables for this subsample
        gen `bs'   = `y'  if `touse'
        gen `sebs' = `se' if `touse'
        gen `ones' = 1    if `touse'
        // Moments and weights
        summarize `sebs' if `touse'
        local se_min = r(min)
        local se_max = r(max)
        gen `sebs2'     = `sebs'^2 if `touse'
        gen `wis'       = `ones'/`sebs2' if `touse'
        gen `bs_sebs'   = `bs'/`sebs'    if `touse'
        gen `ones_sebs' = `ones'/`sebs'  if `touse'
        summarize `wis' if `touse'
        local wis_sum = r(sum)
        // PET vs PEESE part (same logic as in your original script)
        regress `bs_sebs' `ones_sebs' `ones' if `touse', noc
        local t1_linreg = _b[`ones_sebs'] / _se[`ones_sebs']
        local b_lin     = _b[`ones_sebs']
        local Q1_lin    = e(rss)

        regress `bs_sebs' `ones_sebs' `sebs' if `touse', noc
        local b_sq  = _b[`ones_sebs']
        local Q1_sq = e(rss)

        local abs_t1 = abs(`t1_linreg')
        if `abs_t1' > invt(`M' - 2, 0.975) {
            local combreg = `b_sq'
            local Q1      = `Q1_sq'
        }
        else {
            local combreg = `b_lin'
            local Q1      = `Q1_lin'
        }

        local sigh2hat = max(0, `M' * ((`Q1'/(`M' - e(df_m) - 1)) - 1) / `wis_sum')
        local sighhat  = sqrt(`sigh2hat')

        if `combreg' > 1.96*`sighhat' {
            local a1 = (`combreg' - 1.96*`sighhat') * ///
                       (`combreg' + 1.96*`sighhat') / (2*1.96*`combreg')
        }
        else {
            local a1 = 0
        }
        // Defaults
        local b0_ek  .
        local b1_ek  .
        local sd0_ek .
        local sd1_ek .
        // EK regression: mirror of your rename+regress block
        if `a1' > `se_min' & `a1' < `se_max' {
            gen `sebs_a1' = `sebs' - `a1' if `touse' & `sebs' > `a1'
            replace `sebs_a1' = 0 if `touse' & `sebs' <= `a1'
            gen `pubbias' = `sebs_a1'/`sebs' if `touse'

            // bs/se = alpha1*(1/se) + delta*(se-a1)/se + e
            regress `bs_sebs' `ones_sebs' `pubbias' if `touse', noc
            local b0_ek  = _b[`ones_sebs']
            local b1_ek  = _b[`pubbias']
            local sd0_ek = _se[`ones_sebs']
            local sd1_ek = _se[`pubbias']
        }
        else if `a1' < `se_min' {
            // Here ones acts as pub_bias
            regress `bs_sebs' `ones_sebs' `ones' if `touse', noc
            local b0_ek  = _b[`ones_sebs']
            local b1_ek  = _b[`ones']
            local sd0_ek = _se[`ones_sebs']
            local sd1_ek = _se[`ones']
        }
        else if `a1' > `se_max' {
            // No publication bias term
            regress `bs_sebs' `ones_sebs' if `touse', noc
            local b0_ek  = _b[`ones_sebs']
            local sd0_ek = _se[`ones_sebs']
        }
    }
    // print the result
    di as text "--------------------------------------------------"
    di as text "Endogenous kink – `label'"
    di as text "  N                        = " %9.0f `M'
    di as text "  a1 (kink)                = " %9.4f `a1'
    di as text "  alpha1 (mean effect)     = " %9.4f `b0_ek'
    di as text "  SE(alpha1)               = " %9.4f `sd0_ek'
    di as text "  delta (publication bias) = " %9.4f `b1_ek'
    di as text "  SE(delta)                = " %9.4f `sd1_ek'

    return scalar N         = `M'
    return scalar a1        = `a1'
    return scalar alpha1    = `b0_ek'
    return scalar se_alpha1 = `sd0_ek'
    return scalar delta     = `b1_ek'
    return scalar se_delta  = `sd1_ek'
end

*-------------------------------------------------------------------------------------*
* Table 2: winsorized baseline 
*-------------------------------------------------------------------------------------*
* Panel A/C
		eststo clear
		eststo: ivreg2 pcc_w se_pcc_w, cluster(study_id)
		  boottest se_pcc_w, nograph
		  boottest _cons, nograph 
		eststo: xtreg pcc_w se_pcc_w, fe vce(cluster study_id)
		  boottest se_pcc_w, nograph
		eststo: xtreg pcc_w se_pcc_w, be
		eststo: ivreg2 pcc_w se_pcc_w [pweight=weight], cluster (study_id)
		  boottest se_pcc_w, nograph
		  boottest _cons, nograph
		eststo: ivreg2 tstat_w precision_w, cluster (study_id)
		  boottest precision_w, nograph
		  boottest _cons, nograph
		eststo: ivreg2 pcc_w (se_pcc_w = inv_sample_size), cluster (study_id) first		
		  boottest se_pcc_w, nograph
		  boottest _cons, nograph
		  twostepweakiv 2sls pcc_w (se_pcc_w = inv_sample_size), cluster(study_id)
		esttab using `OUT_RESULTS'/tab_pcc_baseline.tex, se booktabs replace compress title(FAT-PET all\label{tab:fatpet}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) width(\textwidth) nonumbers mtitles("OLS" "FE" "BE" "Study" "Precision" "IV") label
		eststo clear
* Panel B
		summarize precision_w, detail
		gen top10bound = r(p90)
		summarize pcc_w precision_w if precision_w > top10bound
		summarize pcc_w [aweight=1/(se_pcc_w*se_pcc_w)]
		gen waapbound = abs(r(mean))/2.8
		reg tstat_w precision_w if se_pcc_w < waapbound, noconstant
		ek_kink pcc_w se_pcc_w, label("PCC baseline winsorized")

*-------------------------------------------------------------------------------------*
* Table B3: Publication bias tests for the baseline dataset (Cohen's d) 
*-------------------------------------------------------------------------------------*
* Panel A/C
		eststo clear
        eststo: ivreg2 cohens_d_w se_cohens_d_w, cluster(study_id)
		  boottest se_cohens_d_w, nograph
          boottest _cons, nograph
		eststo: xtreg cohens_d_w se_cohens_d_w, fe vce(cluster study_id)
		  boottest se_cohens_d_w, nograph
		eststo: xtreg cohens_d_w se_cohens_d_w, be
		eststo: ivreg2 cohens_d_w se_cohens_d_w [pweight=weight], cluster (study_id)
		  boottest se_cohens_d_w, nograph
          boottest _cons, nograph
		eststo: ivreg2 tstat_cohens_d_w precision_cohens_d_w, cluster (study_id)
		  boottest precision_cohens_d_w, nograph
          boottest _cons, nograph
		eststo: ivreg2 cohens_d_w (se_cohens_d_w = inv_sample_size), cluster (study_id) first
		  boottest se_cohens_d_w, nograph
          boottest _cons, nograph
		  twostepweakiv 2sls cohens_d_w (se_cohens_d_w = inv_sample_size), cluster(study_id)
		esttab using `OUT_RESULTS'/tab_cd_baseline.tex, se booktabs replace compress title(FAT-PET Cohen's D\label{tab:fatpet_cd}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) width(\textwidth) nonumbers mtitles("OLS" "FE" "BE" "Study" "Precision" "IV") label
		eststo clear
* Panel B
		summarize precision_cohens_d_w, detail
		gen top10bound_cd = r(p90)
		summarize cohens_d_w precision_cohens_d_w if precision_cohens_d_w > top10bound_cd
		summarize cohens_d_w [aweight=1/(se_cohens_d_w*se_cohens_d_w)]
		gen waapbound_cd = abs(r(mean))/2.8
		reg tstat_cohens_d_w precision_cohens_d_w if se_cohens_d_w < waapbound_cd, noconstant
		ek_kink cohens_d_w se_cohens_d_w, label("Cohen's d baseline winsorized")

*-------------------------------------------------------------------------------------*
* Table B6: unwinsorized baseline
*-------------------------------------------------------------------------------------*
* Panel A/C
		eststo: ivreg2 pcc se_pcc, cluster(study_id)
		  boottest se_pcc, nograph
		  boottest _cons, nograph 
		eststo: xtreg pcc se_pcc, fe vce(cluster study_id)
		  boottest se_pcc, nograph
		eststo: xtreg pcc se_pcc, be
		eststo: ivreg2 pcc se_pcc [pweight=weight], cluster (study_id)
		  boottest se_pcc, nograph
		  boottest _cons, nograph
		eststo: ivreg2 t_adjusted precision_pcc, cluster (study_id)
		  boottest precision_pcc, nograph
		  boottest _cons, nograph
		eststo: ivreg2 pcc (se_pcc = inv_sample_size), cluster (study_id) first		
		  boottest se_pcc, nograph
		  boottest _cons, nograph
		  twostepweakiv 2sls pcc (se_pcc = inv_sample_size), cluster(study_id)
		esttab using `OUT_RESULTS'/tab_pcc_baseline_unwinsorized.tex, se booktabs replace compress title(FAT-PET all\label{tab:fatpet}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) width(\textwidth) nonumbers mtitles("OLS" "FE" "BE" "Study" "Precision" "IV") label
		eststo clear
* Panel B
		summarize precision_pcc, detail
		gen top10bound_unw = r(p90)
		summarize pcc precision_pcc if precision_pcc > top10bound_unw
		summarize pcc [aweight=1/(se_pcc*se_pcc)]
		gen waapbound_unwin = abs(r(mean))/2.8
		reg t_adjusted precision_pcc if se_pcc_w < waapbound_unwin, noconstant
		ek_kink pcc se_pcc, label("PCC baseline unwinsorized")	
		
*======================================================================================
* 1.7 Publication bias: caliper test
*======================================================================================
* Table B1: Tests based on the distribution of t-statistics and p-values, Panel A

* caliper for tstat below -1.96
generate significant = 0
replace significant = 1 if tstat_w < -1.96
reg significant if tstat_w > -2.01 & tstat_w < -1.91
 lincom _cons - 0.5
reg significant if tstat_w > -2.06 & tstat_w < -1.86
 lincom _cons - 0.5
reg significant if tstat_w > -2.11 & tstat_w < -1.81
 lincom _cons - 0.5

*caliper for tstat above 1.96 
generate significant2 = 0
replace significant2 = 1 if tstat_w > 1.96
reg significant2 if tstat_w < 2.01 & tstat_w > 1.91 
 lincom _cons - 0.5
reg significant2 if tstat_w < 2.06 & tstat_w > 1.86
 lincom _cons - 0.5
reg significant2 if tstat_w < 2.11 & tstat_w > 1.81 
 lincom _cons - 0.5

*caliper for positive estimates
generate positive = 0
replace positive = 1 if tstat_w > 0 
reg positive if tstat_w > -0.05 & tstat_w < 0.05
 lincom _cons - 0.5
reg positive if tstat_w > -0.10 & tstat_w < 0.10
 lincom _cons - 0.5
reg positive if tstat_w > -0.15 & tstat_w < 0.15
 lincom _cons - 0.5

*======================================================================================
* 1.8 Exports for R (p-uniform*, stem-based, selection model, p-hacking)
*======================================================================================

* p-uniform* + stem-based: pcc
preserve
*   bysort study_id: egen pcc_med  = median(pcc)
    bysort study_id: egen se_med   = median(se_pcc)
    bysort study_id: egen t_med    = median(t_adjusted)
    gen variance_med = se_med^2
    bysort study_id: egen pcc_medw = median(pcc_w)
    bysort study_id: egen se_medw  = median(se_pcc_w)
    bysort study_id: egen t_medw   = median(tstat_w)
    gen variance_medw = se_medw^2
    collapse (lastnm) pcc_med pcc_medw se_med se_medw variance_med variance_medw t_med t_medw ///
            (p50) nobs_med = n_obs, by(study_id)
    export delimited using "`OUT_AUX'/pcc_puniform.csv", replace
restore

* p-uniform* + stem-based: cd
preserve
	bysort study_id: egen cd_med = median(cohens_d)
	bysort study_id: egen se_med = median(se_cohens_d)
	bysort study_id: egen t_med = median(tstat_cohens_d)
	gen variance_med = se_med^2
	bysort study_id: egen cd_medw = median(cohens_d_w)
	bysort study_id: egen se_medw = median(se_cohens_d_w)
	bysort study_id: egen t_medw = median(tstat_cohens_d_w)
	gen variance_medw = se_medw^2
	collapse (lastnm) cd_med cd_medw se_med se_medw variance_med variance_medw t_med t_medw (p50) nobs_med=n_obs, by(study_id)
	export delimited using "`OUT_AUX'/cd_puniform.csv", replace
restore

* selection model: pcc winsorized
preserve
    keep pcc_w se_pcc_w
    order pcc_w se_pcc_w
    outfile using "`OUT_AUX'/pcc_ak.csv", comma replace
restore

* selection model: pcc unwinsorized
preserve
    keep pcc se_pcc
    order pcc se_pcc
    outfile using "`OUT_AUX'/pcc_ak_now.csv", comma replace
restore

* selection model: cd
preserve
		keep cohens_d_w se_cohens_d_w
		order cohens_d_w se_cohens_d_w
		outfile using "`OUT_AUX'/cd_ak.csv", comma replace
restore

* p-hacking pcc
preserve
    gen t_abs = abs(t_adjusted)
    gen ptop  = 2*(1 - normal(t_abs))
    drop if ptop > 1
    gen id = study_id
    keep id t_adjusted t_abs ptop
    export delimited using "`OUT_AUX'/elliott.csv", replace
restore

*======================================================================================
* 1.9 Heterogeneity: exports + collinearity checks
*======================================================================================

correlate pcc_w se_pcc_w preferred se_control effect_gpa effect_charity effect_game effect_positive task_app perf_quan task_cog reward_scaled framing_pos all_paid reward_own control_zero mot_alt mot_rec mot_fai location_lab crowding_out subject_st subject_emp male mid_age data_avgyear developed_country ols_method logit_method probit_method tobit_method fe_method re_method did_method data_cross impact_factor citations
cap which collin
if !_rc {
collin pcc_w se_pcc_w preferred se_control effect_gpa effect_charity effect_game effect_positive task_app perf_quan task_cog reward_scaled framing_pos all_paid reward_own control_zero mot_alt mot_rec mot_fai location_lab crowding_out subject_st subject_emp male mid_age data_avgyear developed_country ols_method logit_method probit_method tobit_method fe_method re_method did_method data_cross impact_factor citations
collin pcc_w se_pcc_w preferred effect_positive task_app perf_quan task_cog framing_pos control_zero mot_alt location_lab crowding_out male probit_method tobit_method fe_method re_method data_cross
}
else di as txt "Skipping 'collin' (not installed)."



keep study_id pcc_w se_pcc_w preferred se_control effect_gpa effect_charity effect_game effect_work effect_positive task_app task_napp task_cog task_man perf_quan perf_qual reward_scaled framing_pos framing_neg all_paid reward_own reward_else control_zero mot_alt mot_rec mot_fai mot_mon location_lab location_field crowding_out subject_st subject_emp subject_mix male female mid_age data_avgyear developed_country ols_method logit_method probit_method tobit_method fe_method re_method did_method other_method2 data_cross data_panel impact_factor citations
order study_id pcc_w se_pcc_w preferred se_control effect_gpa effect_charity effect_game effect_work effect_positive task_app task_napp perf_quan perf_qual task_cog task_man reward_scaled framing_pos framing_neg all_paid reward_own reward_else control_zero mot_alt mot_rec mot_fai mot_mon location_lab location_field crowding_out subject_st subject_emp subject_mix male female mid_age data_avgyear developed_country ols_method logit_method probit_method tobit_method fe_method re_method did_method other_method2 data_cross data_panel impact_factor citations
export delimited using "`OUT_AUX'/incentives_4R.csv", replace

*======================================================================================
* 1.10 Best-practice predictions (lincom blocks)
*======================================================================================
* Table 5: Effects implied for different contexts

set more off
local variables pcc_w se_pcc_w preferred effect_gpa effect_charity effect_game effect_positive task_app perf_quan task_cog reward_scaled framing_pos all_paid reward_own control_zero mot_alt mot_rec mot_fai location_lab crowding_out subject_st subject_emp male mid_age data_avgyear developed_country ols_method logit_method probit_method tobit_method fe_method re_method did_method data_cross impact_factor citations
foreach x of varlist `variables' {
sum  `x' 
local m`x' =r(mean)  
local min`x' =r(min)
local max`x' =r(max)
}
ivreg2 pcc_w se_pcc_w preferred effect_gpa effect_charity effect_game effect_positive task_app perf_quan task_cog reward_scaled framing_pos all_paid reward_own control_zero mot_alt mot_rec mot_fai location_lab crowding_out subject_st subject_emp male mid_age data_avgyear developed_country ols_method logit_method probit_method tobit_method fe_method re_method did_method data_cross impact_factor citations, cluster(study_id)
*Overall
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Effect: grades
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*1+effect_charity*0+effect_game*0+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Effect: charity
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*0+effect_charity*1+effect_game*0+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Effect: game
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*0+effect_charity*0+effect_game*1+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Task: appealing
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*1+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Task: unappealing
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*0+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Task: cognitive
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*1+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Task: manual
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*0+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Performance: quantitative
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*1+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Performance: qualitative
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*0+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Positive framing
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*1+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Negative framing
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*0+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Laboratory experiment
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*1+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Field experiment
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*0+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Subjects: students
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*1+subject_emp*0+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Subjects: employees
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*0+subject_emp*1+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Subjects: mixed
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*`mreward_own'+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*0+subject_emp*1+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Individual reward
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*1+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Group reward
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*`meffect_gpa'+effect_charity*`meffect_charity'+effect_game*`meffect_game'+effect_positive*`meffect_positive'+task_app*`mtask_app'+perf_quan*`mperf_quan'+task_cog*`mtask_cog'+reward_scaled*`mreward_scaled'+framing_pos*`mframing_pos'+all_paid*`mall_paid'+reward_own*0+control_zero*`mcontrol_zero'+mot_alt*`mmot_alt'+mot_rec*`mmot_rec'+mot_fai*`mmot_fai'+location_lab*`mlocation_lab'+crowding_out*`mcrowding_out'+subject_st*`msubject_st'+subject_emp*`msubject_emp'+male*`mmale'+mid_age*`mmid_age'+data_avgyear*`maxdata_avgyear'+developed_country*`mdeveloped_country'+ols_method*`mols_method'+logit_method*`mlogit_method'+probit_method*`mprobit_method'+tobit_method*`mtobit_method'+fe_method*`mfe_method'+re_method*`mre_method'+did_method*`mdid_method'+data_cross*`mdata_cross'+impact_factor*`maximpact_factor'+citations*`maxcitations'
*Takahashi et al. (2016)
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*0+effect_charity*0+effect_game*1+effect_positive*0+task_app*1+perf_quan*1+task_cog*1+reward_scaled*0.202+framing_pos*1+all_paid*0+reward_own*1+control_zero*1+mot_alt*0+mot_rec*0+mot_fai*0+location_lab*1+crowding_out*1+subject_st*1+subject_emp*0+male*0.5+mid_age*2.996+data_avgyear*7.607+developed_country*1+ols_method*0+logit_method*0+probit_method*0+tobit_method*1+fe_method*0+re_method*0+did_method*0+data_cross*1+impact_factor*1.926+citations*1.386
*Lazear (2000)
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*0+effect_charity*0+effect_game*0+effect_positive*1+task_app*0+perf_quan*1+task_cog*0+reward_scaled*0.600+framing_pos*1+all_paid*0+reward_own*1+control_zero*0+mot_alt*0+mot_rec*0+mot_fai*0+location_lab*0+crowding_out*1+subject_st*0+subject_emp*1+male*0.63+mid_age*3.332+data_avgyear*7.598+developed_country*1+ols_method*1+logit_method*0+probit_method*0+tobit_method*0+fe_method*0+re_method*0+did_method*0+data_cross*0+impact_factor*4.367+citations*5.106
*Angrist & Lavy (2009)
lincom _cons+se_pcc_w*0+preferred*1+effect_gpa*1+effect_charity*0+effect_game*0+effect_positive*1+task_app*0+perf_quan*0+task_cog*1+reward_scaled*1.168+framing_pos*1+all_paid*0+reward_own*1+control_zero*1+mot_alt*0+mot_rec*0+mot_fai*0+location_lab*0+crowding_out*0+subject_st*1+subject_emp*0+male*0.5+mid_age*2.862+data_avgyear*7.601+developed_country*1+ols_method*0.5+logit_method*0.5+probit_method*0+tobit_method*0+fe_method*0+re_method*0+did_method*0+data_cross*1+impact_factor*4.367+citations*3.660

***************************************************************************************
***************************************************************************************
***************************************************************************************
***************************  2. Expanded PCC/CD dataset   *****************************
*************************************(1,785 nobs)**************************************
***************************************************************************************
***************************************************************************************

clear
set more off

*======================================================================================
* 2.1 Load data and set panel structure
*======================================================================================

import excel "incentives.xlsx", sheet("data") firstrow clear
xtset study_id

*======================================================================================
* 2.2 Data preparation
*======================================================================================
* Keep all observations (including working papers)

drop if include == 2
drop if missing(include)
winsor2 pcc, suffix(_w) cuts(1 99)
winsor2 se_pcc, suffix(_w) cuts(1 99)
gen precision_pcc = 1/se_pcc
gen precision_w = 1/se_pcc_w
gen tstat_w = t_adjusted
winsor2 cohens_d, suffix(_w) cuts(1 99)
winsor2 se_cohens_d, suffix(_w) cuts(1 99)
gen precision_cohens_d = 1/se_cohens_d
gen precision_cohens_d_w = 1/se_cohens_d_w
gen tstat_cohens_d = cohens_d/se_cohens_d
gen tstat_cohens_d_w = cohens_d_w/se_cohens_d_w
gen effect_negative=0
gen inv_sample_size = 1/sqrt(observations)
gen n_obs = ln(observations)
winsor2 n_obs, suffix(_w) cuts(1 99)
replace effect_negative=1 if effect_positive==0
bys study_id: gen weight = 1 / _N
bys experiment_id: gen weight_exp = 1 / _N
bys study_id: egen n_pref = total(preferred == 1)
gen weight_pref = 1/n_pref if preferred == 1

*======================================================================================
* 2.3 Summary statistics
*======================================================================================
* Table B2: Summary statistics for Cohen's d (expanded dataset)

sum cohens_d_w se_cohens_d_w, detail
mean cohens_d_w
mean cohens_d_w if preferred==1
mean cohens_d_w [aweight=weight]
mean cohens_d_w [aweight=weight] if preferred==1

*======================================================================================
* 2.4 Figures: distributions
*======================================================================================

* Figure B3: The distribution of t-statistics peaks at zero
histogram t_adjusted if t_adjusted<20 & t_adjusted>-10, bin(50) fcolor(gs14) lstyle(thin) frequency xtitle("Reported t-statistics") xline(-1.96 0 1.96, lcolor(red)) xlabel(-10 -5 -1.96 0 1.96 5 10 15 20) ylabel( ,glcolor(ltbluishgray)) graphregion(color(ltbluishgray)) saving(`OUT_RESULTS'/caliper_cd, replace) 

* Figure B4: Distribution of estimates and heterogeneity
histogram cohens_d if cohens_d>-0.6 & cohens_d<1, bin(60) fcolor(gs14) lstyle(thin) frequency xtitle("Cohen's d") xline(0.090, lcolor(red)) xlabel(-0.6 -0.4 -0.2 0 0.090 0.2 0.4 0.6 0.8 1.0) ylabel( ,glcolor(ltbluishgray)) graphregion(color(ltbluishgray)) saving(`OUT_RESULTS'/histogram_cd, replace) 
bysort study_id: egen midyear_med = median(data_year)
graph hbox cohens_d if cohens_d>-0.6 & cohens_d<1, over(study,label(grid) sort(midyear_med)) xsize(2.6) ysize(5) scale(0.7) yline(0, lcolor (bluishgray)) box(1,lcolor(black) fcolor(none)) marker(1,msymbol(circle_hollow) mcolor(gs12)) ytitle("Cohen's d") ylabel(, nogrid) saving(`OUT_RESULTS'/studies_cd, replace) 

*======================================================================================
* 2.5 Publication bias: funnel plot
*======================================================================================

sum cohens_d precision_cohens_d

* Figure B5: Funnel plot for the expanded dataset
twoway scatter precision_cohens_d cohens_d if precision_cohens_d<400 & cohens_d>-0.6 & cohens_d<1, ytitle("Precision of the Cohen's d (1/SE)") ylabel( ,glcolor(ltbluishgray)) xtitle("Cohen's d") xline(0, lpattern(solid) lcolor (bluishgray)) xline(0.090, lpattern(solid) lcolor(red) lwidth(medium)) xlabel(-0.6 -0.4 -0.2 0 0.090 0.2 0.4 0.6 0.8 1.0 , add) msymbol(smcircle_hollow) graphregion(color(ltbluishgray)) saving(`OUT_RESULTS'/funnel_cd, replace)

*======================================================================================
* 2.6 Publication bias: FAT-PET, TOP10, WAAP, endogenous kink
*======================================================================================
* Table B4: Publication bias tests for the expanded dataset (Cohen's d)
* Table B5: Publication bias tests for the expanded dataset (partial correlation coefficients)
* Table B7: Publication bias tests for the expanded dataset (no winsorizing)
* Table B8: Publication bias tests accounting for interdependence

xtset study_id

*-------------------------------------------------------------------------------------*
* endogenous kink function
*-------------------------------------------------------------------------------------*
capture program drop ek_kink
program define ek_kink, rclass
    syntax varlist(min=2 max=2 numeric) [if] [in], LABEL(string)

    marksample touse
    tokenize `varlist'
    local y  `1'
    local se `2'
    tempvar bs sebs ones sebs2 wis bs_sebs ones_sebs sebs_a1 pubbias
    quietly {
        count if `touse'
        local M = r(N)
        if `M' == 0 {
            exit 2000
        }
        // Copy variables for this subsample
        gen `bs'   = `y'  if `touse'
        gen `sebs' = `se' if `touse'
        gen `ones' = 1    if `touse'
        // Moments and weights
        summarize `sebs' if `touse'
        local se_min = r(min)
        local se_max = r(max)
        gen `sebs2'     = `sebs'^2 if `touse'
        gen `wis'       = `ones'/`sebs2' if `touse'
        gen `bs_sebs'   = `bs'/`sebs'    if `touse'
        gen `ones_sebs' = `ones'/`sebs'  if `touse'
        summarize `wis' if `touse'
        local wis_sum = r(sum)
        // PET vs PEESE part (same logic as in your original script)
        regress `bs_sebs' `ones_sebs' `ones' if `touse', noc
        local t1_linreg = _b[`ones_sebs'] / _se[`ones_sebs']
        local b_lin     = _b[`ones_sebs']
        local Q1_lin    = e(rss)

        regress `bs_sebs' `ones_sebs' `sebs' if `touse', noc
        local b_sq  = _b[`ones_sebs']
        local Q1_sq = e(rss)

        local abs_t1 = abs(`t1_linreg')
        if `abs_t1' > invt(`M' - 2, 0.975) {
            local combreg = `b_sq'
            local Q1      = `Q1_sq'
        }
        else {
            local combreg = `b_lin'
            local Q1      = `Q1_lin'
        }

        local sigh2hat = max(0, `M' * ((`Q1'/(`M' - e(df_m) - 1)) - 1) / `wis_sum')
        local sighhat  = sqrt(`sigh2hat')

        if `combreg' > 1.96*`sighhat' {
            local a1 = (`combreg' - 1.96*`sighhat') * ///
                       (`combreg' + 1.96*`sighhat') / (2*1.96*`combreg')
        }
        else {
            local a1 = 0
        }
        // Defaults
        local b0_ek  .
        local b1_ek  .
        local sd0_ek .
        local sd1_ek .
        // EK regression: mirror of your rename+regress block
        if `a1' > `se_min' & `a1' < `se_max' {
            gen `sebs_a1' = `sebs' - `a1' if `touse' & `sebs' > `a1'
            replace `sebs_a1' = 0 if `touse' & `sebs' <= `a1'
            gen `pubbias' = `sebs_a1'/`sebs' if `touse'

            // bs/se = alpha1*(1/se) + delta*(se-a1)/se + e
            regress `bs_sebs' `ones_sebs' `pubbias' if `touse', noc
            local b0_ek  = _b[`ones_sebs']
            local b1_ek  = _b[`pubbias']
            local sd0_ek = _se[`ones_sebs']
            local sd1_ek = _se[`pubbias']
        }
        else if `a1' < `se_min' {
            // Here ones acts as pub_bias
            regress `bs_sebs' `ones_sebs' `ones' if `touse', noc
            local b0_ek  = _b[`ones_sebs']
            local b1_ek  = _b[`ones']
            local sd0_ek = _se[`ones_sebs']
            local sd1_ek = _se[`ones']
        }
        else if `a1' > `se_max' {
            // No publication bias term
            regress `bs_sebs' `ones_sebs' if `touse', noc
            local b0_ek  = _b[`ones_sebs']
            local sd0_ek = _se[`ones_sebs']
        }
    }
    // print the result
    di as text "--------------------------------------------------"
    di as text "Endogenous kink – `label'"
    di as text "  N                        = " %9.0f `M'
    di as text "  a1 (kink)                = " %9.4f `a1'
    di as text "  alpha1 (mean effect)     = " %9.4f `b0_ek'
    di as text "  SE(alpha1)               = " %9.4f `sd0_ek'
    di as text "  delta (publication bias) = " %9.4f `b1_ek'
    di as text "  SE(delta)                = " %9.4f `sd1_ek'

    return scalar N         = `M'
    return scalar a1        = `a1'
    return scalar alpha1    = `b0_ek'
    return scalar se_alpha1 = `sd0_ek'
    return scalar delta     = `b1_ek'
    return scalar se_delta  = `sd1_ek'
end

*-------------------------------------------------------------------------------------*
* Table B4: winsorized expanded Cohen's d 
*-------------------------------------------------------------------------------------*
* Panel A/C
		eststo clear
        eststo: ivreg2 cohens_d_w se_cohens_d_w, cluster(study_id)
		  boottest se_cohens_d_w, nograph
          boottest _cons, nograph
		eststo: xtreg cohens_d_w se_cohens_d_w, fe vce(cluster study_id)
		  boottest se_cohens_d_w, nograph
		eststo: xtreg cohens_d_w se_cohens_d_w, be
		eststo: ivreg2 cohens_d_w se_cohens_d_w [pweight=weight], cluster (study_id)
		  boottest se_cohens_d_w, nograph
          boottest _cons, nograph
		eststo: ivreg2 tstat_cohens_d_w precision_cohens_d_w, cluster (study_id)
		  boottest precision_cohens_d_w, nograph
          boottest _cons, nograph
		eststo: ivreg2 cohens_d_w (se_cohens_d_w = inv_sample_size), cluster (study_id) first
		  boottest se_cohens_d_w, nograph
          boottest _cons, nograph
		  twostepweakiv 2sls cohens_d_w (se_cohens_d_w = inv_sample_size), cluster(study_id)
		esttab using `OUT_RESULTS'/tab_cd_full.tex, se booktabs replace compress title(FAT-PET Cohen's D\label{tab:fatpet_cd}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) width(\textwidth) nonumbers mtitles("OLS" "FE" "BE" "Study" "Precision" "IV") label
		eststo clear
* Panel B
		summarize precision_cohens_d_w, detail
		gen top10bound_cd = r(p90)
		summarize cohens_d_w precision_cohens_d_w if precision_cohens_d_w > top10bound_cd
		summarize cohens_d_w [aweight=1/(se_cohens_d_w*se_cohens_d_w)]
		gen waapbound_cd = abs(r(mean))/2.8
		reg tstat_cohens_d_w precision_cohens_d_w if se_cohens_d_w < waapbound_cd, noconstant
		ek_kink cohens_d_w se_cohens_d_w, label("Cohen's d expanded winsorized")
		
*-------------------------------------------------------------------------------------*
* Table B5: winsorized expanded PCC 
*-------------------------------------------------------------------------------------*
* Panel A/C
		eststo clear
		eststo: ivreg2 pcc_w se_pcc_w, cluster(study_id)
		  boottest se_pcc_w, nograph
		  boottest _cons, nograph 
		eststo: xtreg pcc_w se_pcc_w, fe vce(cluster study_id)
		  boottest se_pcc_w, nograph
		eststo: xtreg pcc_w se_pcc_w, be
		eststo: ivreg2 pcc_w se_pcc_w [pweight=weight], cluster (study_id)
		  boottest se_pcc_w, nograph
		  boottest _cons, nograph
		eststo: ivreg2 tstat_w precision_w, cluster (study_id)
		  boottest precision_w, nograph
		  boottest _cons, nograph
		eststo: ivreg2 pcc_w (se_pcc_w = inv_sample_size), cluster (study_id) first		
		  boottest se_pcc_w, nograph
		  boottest _cons, nograph
		  twostepweakiv 2sls pcc_w (se_pcc_w = inv_sample_size), cluster(study_id)
		esttab using `OUT_RESULTS'/tab_pcc_full.tex, se booktabs replace compress title(FAT-PET all\label{tab:fatpet}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) width(\textwidth) nonumbers mtitles("OLS" "FE" "BE" "Study" "Precision" "IV") label
		eststo clear
* Panel B
		summarize precision_w, detail
		gen top10bound = r(p90)
		summarize pcc_w precision_w if precision_w > top10bound
		summarize pcc_w [aweight=1/(se_pcc_w*se_pcc_w)]
		gen waapbound = abs(r(mean))/2.8
		reg tstat_w precision_w if se_pcc_w < waapbound, noconstant
		ek_kink pcc_w se_pcc_w, label("PCC expanded winsorized")


*-------------------------------------------------------------------------------------*
* Table B7: unwinsorized expanded Cohen's d
*-------------------------------------------------------------------------------------*
* Panel A/C
		eststo: ivreg2 cohens_d se_cohens_d, cluster(study_id)
		  boottest se_cohens_d, nograph
		  boottest _cons, nograph
		eststo: xtreg cohens_d se_cohens_d, fe vce(cluster study_id)
		  boottest se_cohens_d, nograph
		eststo: xtreg cohens_d se_cohens_d, be
		eststo: ivreg2 cohens_d se_cohens_d [pweight=weight], cluster (study_id)
		  boottest se_cohens_d, nograph
		  boottest _cons, nograph
		eststo: ivreg2 tstat_cohens_d precision_cohens_d, cluster (study_id)
		  boottest precision_cohens_d, nograph
		  boottest _cons, nograph
		eststo: ivreg2 cohens_d (se_cohens_d = inv_sample_size), cluster (study_id) first
		  boottest se_cohens_d, nograph
		  boottest _cons, nograph
		  twostepweakiv 2sls cohens_d (se_cohens_d = inv_sample_size), cluster(study_id)		
		esttab using `OUT_RESULTS'/tab_cd_full_unwinsorized.tex, se booktabs replace compress title(FAT-PET Cohen's D unwinsorized\label{tab:fatpet_cd_unw}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) width(\textwidth) nonumbers mtitles("OLS" "FE" "BE" "Study" "Precision" "IV") label
		eststo clear
* Panel B
		summarize precision_cohens_d, detail
		gen top10bound_cd_unwin = r(p90)
		summarize cohens_d precision_cohens_d if precision_cohens_d > top10bound_cd_unwin
		summarize cohens_d [aweight=1/(se_cohens_d*se_cohens_d)]
		gen waapbound_cd_unwin = abs(r(mean))/2.8
		reg tstat_cohens_d precision_cohens_d if se_cohens_d < waapbound_cd_unwin, noconstant
		ek_kink cohens_d se_cohens_d, label("Cohen's d expanded unwinsorized")

*-------------------------------------------------------------------------------------*
* Table B8: accounting for interdependence
*-------------------------------------------------------------------------------------*
* Panel B: Published estimates
		eststo: ivreg2 cohens_d_w se_cohens_d_w, cluster(study_id)
		  boottest se_cohens_d_w, nograph
		  boottest _cons, nograph
		eststo: ivreg2 cohens_d_w se_cohens_d_w [pweight=weight], cluster (study_id)
		  boottest se_cohens_d_w, nograph
		  boottest _cons, nograph
		eststo: xtreg cohens_d_w se_cohens_d_w, be
		eststo: ivreg2 cohens_d_w se_cohens_d_w [pweight=weight_exp], cluster (study_id)
		  boottest se_cohens_d_w, nograph
		  boottest _cons, nograph
		xtset experiment_id
		eststo: xtreg cohens_d_w se_cohens_d_w, be
		esttab using `OUT_RESULTS'/tab_cd_experiment_pub.tex, se booktabs replace compress title(FAT-PET Cohen's D All\label{tab:fatpet_cd_all}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) width(\textwidth) nonumbers mtitles("OLS" "Study" "BE Study" "Experiment" "BE Experiment") label
		xtset study_id
		eststo clear	
* Panel C: Preferred published estimates
		eststo: ivreg2 cohens_d_w se_cohens_d_w if preferred==1, cluster(study_id)
		  boottest se_cohens_d_w, nograph
		  boottest _cons, nograph
		eststo: ivreg2 cohens_d_w se_cohens_d_w [pweight=weight_pref] if preferred==1, cluster (study_id)
		  boottest se_cohens_d_w, nograph
		  boottest _cons, nograph
		eststo: xtreg cohens_d_w se_cohens_d_w if preferred==1, be
		eststo: ivreg2 cohens_d_w se_cohens_d_w [pweight=weight_exp] if preferred==1, cluster (study_id)
		  boottest se_cohens_d_w, nograph
		  boottest _cons, nograph
		xtset experiment_id
		eststo: xtreg cohens_d_w se_cohens_d_w if preferred==1, be
		esttab using `OUT_RESULTS'/tab_cd_experiment_pubpref.tex, se booktabs replace compress title(FAT-PET Cohen's D Preferred\label{tab:fatpet_cd_pref}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) width(\textwidth) nonumbers mtitles("OLS" "Study" "BE Study" "Experiment" "BE Experiment") label
		xtset study_id
		eststo clear

*======================================================================================
* 2.7 Exports for R (p-uniform* and p-hacking)
*======================================================================================

* p-uniform* + stem-based: pcc
preserve
    bysort study_id: egen pcc_med  = median(pcc)
    bysort study_id: egen se_med   = median(se_pcc)
    bysort study_id: egen t_med    = median(t_adjusted)
    gen variance_med = se_med^2
    bysort study_id: egen pcc_medw = median(pcc_w)
    bysort study_id: egen se_medw  = median(se_pcc_w)
    bysort study_id: egen t_medw   = median(tstat_w)
    gen variance_medw = se_medw^2
    collapse (lastnm) pcc_med pcc_medw se_med se_medw variance_med variance_medw t_med t_medw ///
            (p50) nobs_med = n_obs, by(study_id)
    export delimited using "`OUT_AUX'/pcc_puniform_full.csv", replace
restore

* p-uniform* + stem-based: cd
preserve
	bysort study_id: egen cd_med = median(cohens_d)
	bysort study_id: egen se_med = median(se_cohens_d)
	bysort study_id: egen t_med = median(tstat_cohens_d)
	gen variance_med = se_med^2
	bysort study_id: egen cd_medw = median(cohens_d_w)
	bysort study_id: egen se_medw = median(se_cohens_d_w)
	bysort study_id: egen t_medw = median(tstat_cohens_d_w)
	gen variance_medw = se_medw^2
	collapse (lastnm) cd_med cd_medw se_med se_medw variance_med variance_medw t_med t_medw (p50) nobs_med=n_obs, by(study_id)
	export delimited using "`OUT_AUX'/cd_puniform_full.csv", replace
restore

* selection model: pcc
preserve
    keep pcc_w se_pcc_w
    order pcc_w se_pcc_w
    outfile using "`OUT_AUX'/pcc_ak_full.csv", comma replace
restore


* selection model: cd
preserve
		keep cohens_d_w se_cohens_d_w
		order cohens_d_w se_cohens_d_w
		outfile using "`OUT_AUX'/cd_ak_full.csv", comma replace
restore

* p-hacking 
preserve
	gen t_abs = abs(tstat_cohens_d)
	gen ptop = 2*(1 - normal(t_abs))
	drop if ptop > 1
	gen id = study_id
	keep id tstat_cohens_d t_abs ptop
	export delimited using "`OUT_AUX'/elliott_full.csv", replace
restore

***************************************************************************************
***************************************************************************************
***************************************************************************************
**********************  3. Working papers (without journals)   ************************
**************************************(408 nobs)***************************************
***************************************************************************************
***************************************************************************************

clear
set more off

*======================================================================================
* 3.1 Load data and set panel structure
*======================================================================================

import excel "incentives.xlsx", sheet("data") firstrow clear
xtset study_id

*======================================================================================
* 3.2 Data preparation
*======================================================================================
* Only working papers are included

drop if include == 1
drop if missing(include)
winsor2 pcc, suffix(_w) cuts(1 99)
winsor2 se_pcc, suffix(_w) cuts(1 99)
winsor2 cohens_d, suffix(_w) cuts(1 99)
winsor2 se_cohens_d, suffix(_w) cuts(1 99)
gen n_obs = ln(observations)
gen precision_pcc = 1/se_pcc
gen precision_w = 1/se_pcc_w
gen tstat_w = t_adjusted
gen precision_cohens_d = 1/se_cohens_d
gen precision_cohens_d_w = 1/se_cohens_d_w
gen tstat_cohens_d_w = cohens_d_w/se_cohens_d_w
gen effect_negative=0
gen inv_sample_size = 1/sqrt(observations)
replace effect_negative=1 if effect_positive==0
bys study_id: gen weight = 1 / _N
winsor2 n_obs, suffix(_w) cuts(1 99)

*======================================================================================
* 3.3 Summary statistics
*======================================================================================

* Table B2: Summary statistics for Cohen's d (expanded dataset and working papers)
sum cohens_d_w se_cohens_d_w, detail
mean cohens_d_w
mean cohens_d_w if preferred==1
mean cohens_d_w [aweight=weight]
mean cohens_d_w [aweight=weight] if preferred==1

*======================================================================================
* 3.4 Figures: distributions
*======================================================================================

*Figure B6: Histogram for working papers
histogram pcc if pcc>-0.4 & pcc<0.6, bin(60) fcolor(gs14) lstyle(thin) frequency xtitle("Partial correlation coefficient") xline(0.052, lcolor(red)) xlabel(-0.4 -0.2 0 0.052 0.2 0.4 0.6) ylabel( ,glcolor(ltbluishgray)) graphregion(color(ltbluishgray)) saving(`OUT_RESULTS'/histogram_wp, replace)

*======================================================================================
* 3.5 Publication bias: funnel plot
*======================================================================================

sum pcc precision_pcc
sum cohens_d precision_cohens_d

*Figure B7: Funnel plot for working papers
twoway scatter  precision_pcc pcc if precision_pcc<200 & pcc>-0.4 & pcc<0.6, ytitle("Precision of the partial correlation coefficient (1/SE)") ylabel( ,glcolor(ltbluishgray)) xtitle("Partial correlation coefficient") xline(0, lpattern(solid) lcolor (bluishgray)) xline(0.052, lpattern(solid) lcolor (red)) xlabel(0 0.052 , add) msymbol(smcircle_hollow) graphregion(color(ltbluishgray)) saving(`OUT_RESULTS'/funnel_wo, replace)

*======================================================================================
* 3.6 Publication bias: FAT-PET, TOP10, WAAP, endogenous kink
*======================================================================================
* Table B9: Publication bias tests for working papers 

xtset study_id

*-------------------------------------------------------------------------------------*
* endogenous kink function
*-------------------------------------------------------------------------------------*
capture program drop ek_kink
program define ek_kink, rclass
    syntax varlist(min=2 max=2 numeric) [if] [in], LABEL(string)

    marksample touse
    tokenize `varlist'
    local y  `1'
    local se `2'
    tempvar bs sebs ones sebs2 wis bs_sebs ones_sebs sebs_a1 pubbias
    quietly {
        count if `touse'
        local M = r(N)
        if `M' == 0 {
            exit 2000
        }
        // Copy variables for this subsample
        gen `bs'   = `y'  if `touse'
        gen `sebs' = `se' if `touse'
        gen `ones' = 1    if `touse'
        // Moments and weights
        summarize `sebs' if `touse'
        local se_min = r(min)
        local se_max = r(max)
        gen `sebs2'     = `sebs'^2 if `touse'
        gen `wis'       = `ones'/`sebs2' if `touse'
        gen `bs_sebs'   = `bs'/`sebs'    if `touse'
        gen `ones_sebs' = `ones'/`sebs'  if `touse'
        summarize `wis' if `touse'
        local wis_sum = r(sum)
        // PET vs PEESE part (same logic as in your original script)
        regress `bs_sebs' `ones_sebs' `ones' if `touse', noc
        local t1_linreg = _b[`ones_sebs'] / _se[`ones_sebs']
        local b_lin     = _b[`ones_sebs']
        local Q1_lin    = e(rss)

        regress `bs_sebs' `ones_sebs' `sebs' if `touse', noc
        local b_sq  = _b[`ones_sebs']
        local Q1_sq = e(rss)

        local abs_t1 = abs(`t1_linreg')
        if `abs_t1' > invt(`M' - 2, 0.975) {
            local combreg = `b_sq'
            local Q1      = `Q1_sq'
        }
        else {
            local combreg = `b_lin'
            local Q1      = `Q1_lin'
        }

        local sigh2hat = max(0, `M' * ((`Q1'/(`M' - e(df_m) - 1)) - 1) / `wis_sum')
        local sighhat  = sqrt(`sigh2hat')

        if `combreg' > 1.96*`sighhat' {
            local a1 = (`combreg' - 1.96*`sighhat') * ///
                       (`combreg' + 1.96*`sighhat') / (2*1.96*`combreg')
        }
        else {
            local a1 = 0
        }
        // Defaults
        local b0_ek  .
        local b1_ek  .
        local sd0_ek .
        local sd1_ek .
        // EK regression: mirror of your rename+regress block
        if `a1' > `se_min' & `a1' < `se_max' {
            gen `sebs_a1' = `sebs' - `a1' if `touse' & `sebs' > `a1'
            replace `sebs_a1' = 0 if `touse' & `sebs' <= `a1'
            gen `pubbias' = `sebs_a1'/`sebs' if `touse'

            // bs/se = alpha1*(1/se) + delta*(se-a1)/se + e
            regress `bs_sebs' `ones_sebs' `pubbias' if `touse', noc
            local b0_ek  = _b[`ones_sebs']
            local b1_ek  = _b[`pubbias']
            local sd0_ek = _se[`ones_sebs']
            local sd1_ek = _se[`pubbias']
        }
        else if `a1' < `se_min' {
            // Here ones acts as pub_bias
            regress `bs_sebs' `ones_sebs' `ones' if `touse', noc
            local b0_ek  = _b[`ones_sebs']
            local b1_ek  = _b[`ones']
            local sd0_ek = _se[`ones_sebs']
            local sd1_ek = _se[`ones']
        }
        else if `a1' > `se_max' {
            // No publication bias term
            regress `bs_sebs' `ones_sebs' if `touse', noc
            local b0_ek  = _b[`ones_sebs']
            local sd0_ek = _se[`ones_sebs']
        }
    }
    // print the result
    di as text "--------------------------------------------------"
    di as text "Endogenous kink – `label'"
    di as text "  N                        = " %9.0f `M'
    di as text "  a1 (kink)                = " %9.4f `a1'
    di as text "  alpha1 (mean effect)     = " %9.4f `b0_ek'
    di as text "  SE(alpha1)               = " %9.4f `sd0_ek'
    di as text "  delta (publication bias) = " %9.4f `b1_ek'
    di as text "  SE(delta)                = " %9.4f `sd1_ek'

    return scalar N         = `M'
    return scalar a1        = `a1'
    return scalar alpha1    = `b0_ek'
    return scalar se_alpha1 = `sd0_ek'
    return scalar delta     = `b1_ek'
    return scalar se_delta  = `sd1_ek'
end

*-------------------------------------------------------------------------------------*
* Table B9: working papers
*-------------------------------------------------------------------------------------*
* Panel A/C
		eststo clear
		eststo: ivreg2 pcc_w se_pcc_w
		  boottest se_pcc_w, nograph
		  boottest _cons, nograph 
		eststo: xtreg pcc_w se_pcc_w, fe 
		  boottest se_pcc_w, nograph
		eststo: xtreg pcc_w se_pcc_w, be
		eststo: ivreg2 pcc_w se_pcc_w [pweight=weight]
		  boottest se_pcc_w, nograph
		  boottest _cons, nograph
		eststo: ivreg2 tstat_w precision_w
		  boottest precision_w, nograph
		  boottest _cons, nograph
		eststo: ivreg2 pcc_w (se_pcc_w = inv_sample_size), cluster (study_id) first		
		  boottest se_pcc_w, nograph
		  boottest _cons, nograph
		  twostepweakiv 2sls pcc_w (se_pcc_w = inv_sample_size), cluster(study_id)
		esttab using `OUT_RESULTS'/tab_wp_pcc.tex, se booktabs replace compress title(FAT-PET all\label{tab:fatpet}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) width(\textwidth) nonumbers mtitles("OLS" "FE" "BE" "Study" "Precision") label
		eststo clear
* Panel B
		summarize precision_w, detail
		gen top10bound_wp = r(p90)
		summarize pcc_w precision_w if precision_w > top10bound_wp
		ek_kink pcc_w se_pcc_w, label("PCC working papers")

*======================================================================================
* 3.7 Exports for R (p-uniform*, stem-based, selection model, p-hacking)
*======================================================================================

* p-uniform* + stem-based: study-level collapse
preserve
		bysort study_id: egen pcc_med  = median(pcc)
		bysort study_id: egen se_med   = median(se_pcc)
		bysort study_id: egen t_med    = median(t_adjusted)
		gen variance_med = se_med^2
		bysort study_id: egen pcc_medw = median(pcc_w)
		bysort study_id: egen se_medw  = median(se_pcc_w)
		bysort study_id: egen t_medw   = median(tstat_w)
		gen variance_medw = se_medw^2
		collapse (lastnm) pcc_med pcc_medw se_med se_medw variance_med variance_medw t_med t_medw ///
				(p50) nobs_med = n_obs, by(study_id)
		export delimited using "`OUT_AUX'/wp_puniform.csv", replace
restore

* selection model
preserve
		keep pcc_w se_pcc_w
		order pcc_w se_pcc_w
		outfile using "`OUT_AUX'/wp_ak.csv", comma replace
restore
 
* p-hacking
preserve
		gen t_abs = abs(t_adjusted)
		gen ptop  = 2*(1 - normal(t_abs))
		drop if ptop > 1
		gen id = study_id
		keep id t_adjusted t_abs ptop
		export delimited using "`OUT_AUX'/elliott_wp.csv", replace
restore


***************************************************************************************
***************************************************************************************
***************************************************************************************
*******************  4. Full dataset without working papers   *************************
*************************************(2,193 nobs)**************************************
***************************************************************************************
***************************************************************************************

clear
set more off

*======================================================================================
* 4.1 Load data, prepare data and set panel structure
*======================================================================================

import excel "incentives.xlsx", sheet("data") firstrow clear
xtset study_id
drop if missing(include)
winsor2 cohens_d, suffix(_w) cuts(1 99)
winsor2 se_cohens_d, suffix(_w) cuts(1 99)
gen n_obs = ln(observations)
gen tstat_w = t_adjusted
gen precision_cohens_d = 1/se_cohens_d
gen precision_cohens_d_w = 1/se_cohens_d_w
gen tstat_cohens_d = cohens_d/se_cohens_d
gen tstat_cohens_d_w = cohens_d_w/se_cohens_d_w
bys study_id: gen weight = 1 / _N
bys experiment_id: gen weight_exp = 1 / _N

*======================================================================================
* 4.2 Publication bias tests accounting for interdependence
*======================================================================================

sum cohens_d_w se_cohens_d_w

*-------------------------------------------------------------------------------------*
* Table B8: accounting for interdependence
*-------------------------------------------------------------------------------------*
* Panel A: All estimates
		eststo: ivreg2 cohens_d_w se_cohens_d_w, cluster(study_id)
		  boottest se_cohens_d_w, nograph
		  boottest _cons, nograph
		eststo: ivreg2 cohens_d_w se_cohens_d_w [pweight=weight], cluster (study_id)
		  boottest se_cohens_d_w, nograph
		  boottest _cons, nograph
		eststo: xtreg cohens_d_w se_cohens_d_w, be
		eststo: ivreg2 cohens_d_w se_cohens_d_w [pweight=weight_exp], cluster (study_id)
		  boottest se_cohens_d_w, nograph
		  boottest _cons, nograph
		xtset experiment_id
		eststo: xtreg cohens_d_w se_cohens_d_w, be
		esttab using `OUT_RESULTS'/tab_cd_experiment_all.tex, se booktabs replace compress title(FAT-PET Cohen's D All\label{tab:fatpet_cd_all}) star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) width(\textwidth) nonumbers mtitles("OLS" "Study" "BE Study" "Experiment" "BE Experiment") label
		eststo clear	

log close

