set more off
clear
use "C:\Users\Mil��ek\Dropbox\bakalarka\data\metadata.dta", clear
set scheme s2mono

****data nactena


metatrim elasticity se
metatrim elasticity se if narrow == 1
metatrim elasticity se if broad ==1
