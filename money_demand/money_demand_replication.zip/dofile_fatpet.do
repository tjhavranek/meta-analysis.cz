set more off
clear
use "C:\Users\Mil��ek\Dropbox\bakalarka\data\metadata1806.dta", clear
set scheme s2mono
gen prec = 1/se
gen sqrtn=observ^(1/2)

drop if elasticity > 2.9868
drop if elasticity < -1.0839

drop if prec > 53.57375262

*vse
*FAT-PET cluster
eststo: regress tstat prec, vce(cluster idstudy)
*FAIVEHR - cluster
eststo: ivregress 2sls tstat (prec = sqrtn), vce(cluster idstudy) first

*narrow
*FAT-PET cluster
eststo: regress tstat prec if narrow == 1, vce(cluster idstudy)
*FAIVEHR - cluster
eststo: ivregress 2sls tstat (prec = sqrtn)if narrow == 1, vce(cluster idstudy) first

*broad
*narrow
*FAT-PET cluster
eststo: regress tstat prec if narrow == 0, vce(cluster idstudy)
*FAIVEHR - cluster
eststo: ivregress 2sls tstat (prec = sqrtn)if narrow == 0, vce(cluster idstudy) first

esttab using "C:\Users\Mil��ek\Dropbox\bakalarka\fatcut2.tex", se replace booktabs compress title(Test publika�n� selektivity - OLS\label{tab:fat}) mtitles("OLS" "IV" "OLS" "IV" "OLS" "IV") b(3) se(3) label nonumber nogaps scalars(r2) width(1\hsize)
eststo clear

*mixed effect
eststo: xtmixed tstat prec || idstudy:
eststo: xtmixed tstat prec || idauthor:
eststo: xtmixed tstat prec if narrow == 1|| idstudy:
eststo: xtmixed tstat prec if narrow == 1|| idauthor:
eststo: xtmixed tstat prec if narrow == 0|| idstudy:
eststo: xtmixed tstat prec if narrow == 0|| idauthor:
esttab using "C:\Users\Mil��ek\Dropbox\bakalarka\mixedstudyauthorcut2.tex", se replace booktabs compress title(Test publika�n� selektivity - Model sm�en�ch efekt�\label{tab:mixed}) mtitles("ME1" "ME2" "ME1" "ME2" "ME1" "ME2") b(3) se(3) label nonumber nogaps scalars(chi2_c) width(1\hsize)
eststo clear
