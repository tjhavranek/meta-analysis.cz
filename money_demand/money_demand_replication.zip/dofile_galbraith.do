
set more off
clear
use "C:\Users\Mil��ek\Dropbox\bakalarka\data\metadata.dta", clear
set scheme s2mono, permanently
gen prec=1/se
*drop if elasticity > 2.9868
*drop if elasticity < -1.0839
*drop if prec > 53.5737
gen statbroad = (elasticity - 0.9794)/se
twoway (scatter statbroad prec) if broad ==1 & prec < 200, xtitle(P�esnost odhadu - 1/se) ytitle(T-statistika pro odhad elasticity = 0.9794) yline(2, lp(dash)) yline(-2,lp(dash)) title(�irok� pen�ze) saving(galbbroad, replace)
gen statnarrow = (elasticity - 0.8061)/se
twoway (scatter statnarrow prec) if narrow ==1, xtitle(P�esnost odhadu - 1/se) ytitle(T-statistika pro odhad elasticity = 0.8061) yline(2, lp(dash)) yline(-2, lp(dash)) title(�zk� pen�ze) saving(galbnarrow, replace)
graph combine galbnarrow.gph galbbroad.gph
