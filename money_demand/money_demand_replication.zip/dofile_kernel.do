set more off
clear
use "C:\Users\Mil��ek\Dropbox\bakalarka\data\metadata.dta", clear
log using "C:\Users\Mil��ek\Dropbox\bakalarka\data\Logs\logsx.log"
set scheme s2mono
gen prec = 1/se
drop if elasticity > 2.9868
drop if elasticity < -1.0839
drop if prec > 53.57375262
kdensity elasticity if narrow == 1, normal normopts(lpattern(dot)) ytitle(Hustota) xtitle(Odhad d�chodov� elasticity) title(�zk� pen�ze) legend(off) saving(narrow, replace)
kdensity elasticity if broad == 1, normal normopts(lpattern(dot)) ytitle(Hustota) xtitle(Odhad d�chodov� elasticity) title(�irok� pen�ze) legend(off) saving(broad, replace)
graph combine narrow.gph broad.gph
