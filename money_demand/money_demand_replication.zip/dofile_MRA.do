clear
set more off
use "C:\Users\Mil��ek\Dropbox\bakalarka\data\metadata2706.dta", clear
set scheme s2mono

gen prec = 1/se
gen sqrtn=observ^(1/2)
*uprava datasetu
drop if elasticity > 2.9868
drop if elasticity < -1.0839
drop if prec > 53.57375262
*uprava promennych




gen avgyear=((syear+eyear)/2)-2000
gen studyage=2012-yearpub+0.5
gen citations=cit/studyage
replace yearpub=yearpub-2000
gen bothr = 0
replace bothr = 1 if shortr == 1 & longr==1

gen nonOECD = 0
replace nonOECD = 1 if  oecd==0
gen usa_ca = 0
replace usa_ca = 1 if usa==1
replace usa_ca=1 if ca==1
gen eu_ch = 0
replace eu_ch =1 if eu==1
replace eu_ch = 1 if ch==1

*vyhodim nepotrebne
drop  idofobserv
drop cit
drop  m0
drop narrow
drop gdp
drop  price
drop  syear
drop smonth
drop eyear
drop emonth
drop  annual
drop  midyear
drop ts
drop  knell
drop  ols
drop oecd
drop usa
drop multieu
drop  eu
drop emu
drop de
drop gb
drop  ca
drop  fr
drop nl
drop  ru
drop  ch
drop studyage
drop sqrtn
drop shortr
rename observ nobs

gen broad_se = broad/se
*38 moder�torsk�ch promennych do jedne
local allvariables  yearpub nom m1 m2 m2m mzm m3 m3h m4 cons index exp bothr longr inf otherr wealth inovation substitution othervar otherdummy quarter month nobs years pd cs ardl joh dols fmols methodoth avgyear citations nonOECD usa_ca eu_ch
*podeleni vsech odchylkou
foreach x of varlist `allvariables' {
gen `x'_se = `x' /se
}
*MRA
*37 prommenych, cluster se by idstudy, agregaty
eststo: reg tstat prec  m1_se m2_se m2m_se mzm_se m3_se m3h_se m4_se nom_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se quarter_se month_se pd_se cs_se nobs_se years_se avgyear_se  nonOECD_se usa_ca_se eu_ch_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se, vce(cluster idstudy)
*37 prommenych, cluster se by idstudy, broad
eststo: reg tstat prec broad_se nom_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se quarter_se month_se pd_se cs_se nobs_se years_se avgyear_se  nonOECD_se usa_ca_se eu_ch_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se, vce(cluster idstudy)
*37 promennych, mixed idstudy, agregaty
eststo: xtmixed tstat prec  m1_se m2_se m2m_se mzm_se m3_se m3h_se m4_se nom_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se quarter_se month_se pd_se cs_se nobs_se years_se avgyear_se  nonOECD_se usa_ca_se eu_ch_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se ||idstudy:
*37 prommenych, mixed idstudy, broad
eststo: xtmixed tstat prec broad_se nom_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se quarter_se month_se pd_se cs_se nobs_se years_se avgyear_se  nonOECD_se usa_ca_se eu_ch_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se ||idstudy:
esttab using "C:\Users\Mil��ek\Dropbox\bakalarka\mragenera3006.tex", se replace booktabs compress title(Heterogenita d�chodov� elasticity - obecn� model\label{tab:mrageneral}) mtitles("OLS" "OLS" "ME" "ME") b(3) se(3) label nonumber nogaps scalars(r2 chi2_c) width(1\hsize)
eststo clear

*testy
test ( m1_se m2_se m2m_se mzm_se m3_se m3h_se m4_se)
test ( m2_se m2m_se mzm_se m3_se m3h_se m4_se)
test ( cons_se index_se exp_se)
test ( bothr_se inf_se longr_se otherr_se)
test ( wealth_se inovation_se substitution_se othervar_se otherdummy_se)
test ( inovation_se substitution_se othervar_se otherdummy_se)
test ( quarter_se month_se)
test ( pd_se cs_se)
test ( cs_se pd_se  years_se nobs_se month_se quarter_se avgyear_se)
test ( nonOECD_se usa_ca_se eu_ch_se)
test ( methodoth_se fmols_se dols_se joh_se ardl_se)
test ( citations_se yearpub_se)

*Fixn� efekt, panelov� data
xtset idcountry
* 37 prom, agregaty
eststo: xtreg t prec  m1_se m2_se m2m_se mzm_se m3_se m3h_se m4_se nom_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se quarter_se month_se pd_se cs_se nobs_se years_se avgyear_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se, fe
* 37 prom, broad
eststo:xtreg tstat prec   broad_se nom_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se quarter_se month_se pd_se cs_se nobs_se years_se avgyear_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se, fe
*regrese s mixed effectem by idcountry 
eststo: xtmixed tstat prec  m1_se m2_se m2m_se mzm_se m3_se m3h_se m4_se nom_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se quarter_se month_se pd_se cs_se nobs_se years_se avgyear_se  ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se ||idcountry:
eststo: xtmixed tstat prec  broad_se nom_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se quarter_se month_se pd_se cs_se nobs_se years_se avgyear_se  ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se ||idcountry:
esttab using "C:\Users\Mil��ek\Dropbox\bakalarka\mrafixedcountry2.tex", se replace booktabs compress title(Heterogenita d�chodov� elasticity - fixn� efekt dle zem�\label{tab:mrafixed}) mtitles("FE" "FE" "ME" "ME") b(3) se(3) label nonumber nogaps scalars(r2 chi2_c) width(1\hsize)
eststo clear


*modely bez sedmi promennych - nom, frekvence, data, roky a nobs
*30 promennych, cluster se by idstudy, agregaty
eststo: reg tstat prec  m1_se m2_se m2m_se mzm_se m3_se m3h_se m4_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se  nonOECD_se usa_ca_se eu_ch_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se, vce(cluster idstudy)
*30 prommenych, cluster se by idstudy, broad
eststo: reg tstat prec broad_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se  nonOECD_se usa_ca_se eu_ch_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se, vce(cluster idstudy)
*30 promennych, mixed idstudy, agregaty
eststo: xtmixed tstat prec  m1_se m2_se m2m_se mzm_se m3_se m3h_se m4_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se  nonOECD_se usa_ca_se eu_ch_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se ||idstudy:
*30 prommenych, mixed idstudy, broad
eststo: xtmixed tstat prec broad_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se  nonOECD_se usa_ca_se eu_ch_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se ||idstudy:
esttab using "C:\Users\Mil��ek\Dropbox\bakalarka\mra30proOLSME.tex", se replace booktabs compress title(Heterogenita d�chodov� elasticity - obecn� model\label{tab:mrageneral}) mtitles("OLS" "ME" "OLS" "ME") b(3) se(3) label nonumber nogaps scalars(r2 chi2_c) width(1\hsize)
eststo clear

*Fixn� efekt, panelov� data, 30 prom
xtset idcountry
* 30 prom, agregaty
eststo: xtreg t prec  m1_se m2_se m2m_se mzm_se m3_se m3h_se m4_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se, fe
* 30 prom, broad
eststo:xtreg tstat prec   broad_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se, fe
*regrese s mixed effectem by idcountry 30 
eststo: xtmixed tstat prec  m1_se m2_se m2m_se mzm_se m3_se m3h_se m4_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se  ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se ||idcountry:
eststo: xtmixed tstat prec  broad_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se  ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se ||idcountry:
esttab using "C:\Users\Mil��ek\Dropbox\bakalarka\mrafixedcountry30feme.tex", se replace booktabs compress title(Heterogenita d�chodov� elasticity - fixn� efekt dle zem�\label{tab:mrafixed}) mtitles("FE" "FE" "ME" "ME") b(3) se(3) label nonumber nogaps scalars(r2 chi2_c) width(1\hsize)
eststo clear


*testy na 30
test ( m1_se m2_se m2m_se mzm_se m3_se m3h_se m4_se)
test ( m2_se m2m_se mzm_se m3_se m3h_se m4_se)
test ( cons_se index_se exp_se)
test ( bothr_se inf_se longr_se otherr_se)
test ( wealth_se inovation_se substitution_se othervar_se otherdummy_se)
test ( inovation_se substitution_se othervar_se otherdummy_se)
test ( nonOECD_se usa_ca_se eu_ch_se)
test ( methodoth_se fmols_se dols_se joh_se ardl_se)
test ( citations_se yearpub_se)

**v textu prace - 30 prom, broad, 4 metody
eststo: reg tstat prec broad_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se  nonOECD_se usa_ca_se eu_ch_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se, vce(cluster idstudy)
eststo: xtmixed tstat prec broad_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se  nonOECD_se usa_ca_se eu_ch_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se ||idstudy:
eststo:xtreg tstat prec   broad_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se, fe
eststo: xtmixed tstat prec  broad_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se  ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se ||idcountry:
esttab using "C:\Users\Mil��ek\Dropbox\bakalarka\mracut.tex", se replace booktabs compress title(Heterogenita d�chodov� elasticity - fixn� efekt dle zem�\label{tab:mrafixed}) mtitles("OLS" "ME1" "FE" "ME2") b(3) se(3) label nonumber nogaps scalars(r2 chi2_c) width(1\hsize)
eststo clear

**priloha - 30 prom, agregaty, 4 metody
eststo: reg tstat prec  m1_se m2_se m2m_se mzm_se m3_se m3h_se m4_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se  nonOECD_se usa_ca_se eu_ch_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se, vce(cluster idstudy)
eststo: xtmixed tstat prec  m1_se m2_se m2m_se mzm_se m3_se m3h_se m4_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se  nonOECD_se usa_ca_se eu_ch_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se ||idstudy:
eststo: xtreg t prec  m1_se m2_se m2m_se mzm_se m3_se m3h_se m4_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se, fe
eststo: xtmixed tstat prec  m1_se m2_se m2m_se mzm_se m3_se m3h_se m4_se cons_se index_se exp_se longr_se bothr_se inf_se otherr_se wealth_se inovation_se substitution_se othervar_se otherdummy_se avgyear_se  ardl_se joh_se dols_se fmols_se methodoth_se citations_se yearpub_se ||idcountry:
esttab using "C:\Users\Mil��ek\Dropbox\bakalarka\mraagreg.tex", se replace booktabs compress title(Heterogenita d�chodov� elasticity - fixn� efekt dle zem�\label{tab:mrafixed}) mtitles("OLS" "ME1" "FE" "ME2") b(3) se(3) label nonumber nogaps scalars(r2 chi2_c) width(1\hsize)
eststo clear

