set more off
clear
use "C:\Users\Mil��ek\Dropbox\bakalarka\data\metadata.dta", clear
*log using "C:\Users\Mil��ek\Dropbox\bakalarka\data\Logs\logs2.log"
set scheme s2mono
gen prec = 1/se
drop if elasticity > 20
drop if elasticity < -20
*whole dataset
twoway (scatter prec elasticity, msymbol(circle_hollow)), ytitle(P�esnost odhadu - 1/se) xtitle(Odhad d�chodov� elasticity) xline(1, lp(solid)) xline(0.9098, lp(dash))
*split - broad and narrow
twoway (scatter prec elasticity, msymbol(circle_hollow)) if narrow ==1, ytitle(P�esnost odhadu - 1/se) xtitle(Odhad d�chodov� elasticity) xline(1, lp(solid)) xline(0.8061, lp(dash)) title(�zk� pen�ze) saving(funnelnar2, replace)
twoway (scatter prec elasticity, msymbol(circle_hollow)) if broad ==1, ytitle(P�esnost odhadu - 1/se) xtitle(Odhad d�chodov� elasticity) xline(1, lp(solid)) title(�irok� pen�ze) saving(funnelbr2, replace)
graph combine funnelnar2.gph funnelbr2.gph
