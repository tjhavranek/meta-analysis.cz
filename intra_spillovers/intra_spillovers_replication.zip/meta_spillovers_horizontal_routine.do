set more off
use "C:\Papers\Spillovers_meta_analysis\New_Results\meta_spillovers_horizontal.dta", clear
log using "C:\Papers\Spillovers_meta_analysis\New_Results\program.log"
reg tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if abststat<8, vce(robust)
*RAMSEY
estat ovtest
*SHAPIRO-WILK
predict res, residual
swilk res
*COLLINEARITY
correlate ldf avgyr devg trans cs  growth industry secdum empl assets output
matrix c=r(C)
outtable using corr, mat(c)
collin ldf avgyr devg trans cs  growth industry secdum empl assets output
*OK without avgyr
collin ldf devg trans cs  growth industry secdum empl assets output
*NON-LINEAR RELATIONSHIPS
gen ldf2 = ldf^2
gen ldf3 = ldf^3
gen ldf4 = ldf^4
gen ldf5 = ldf^5
gen ldf6 = ldf^6
gen avgyr2 = avgyr^2
gen avgyr3 = avgyr^3
gen avgyr4 = avgyr^4
gen avgyr5 = avgyr^5
gen avgyr6 = avgyr^6
gen devg2 = devg^2
gen devg3 = devg^3
gen devg4 = devg^4
gen devg5 = devg^5
gen devg6 = devg^6
gen trans2 = trans^2
gen trans3 = trans^3
gen trans4 = trans^4
gen trans5 = trans^5
gen trans6 = trans^6
gen cs2 = cs^2
gen cs3 = cs^3
gen cs4 = cs^4
gen cs5 = cs^5
gen cs6 = cs^6
gen growth2 = growth^2
gen growth3 = growth^3
gen growth4 = growth^4
gen growth5 = growth^5
gen growth6 = growth^6
gen industry2 = industry^2
gen industry3 = industry^3
gen industry4 = industry^4
gen industry5 = industry^5
gen industry6 = industry^6
gen secdum2 = secdum^2
gen secdum3 = secdum^3
gen secdum4 = secdum^4
gen secdum5 = secdum^5
gen secdum6 = secdum^6
gen empl2 = empl^2
gen empl3 = empl^3
gen empl4 = empl^4
gen empl5 = empl^5
gen empl6 = empl^6
gen assets2 = assets^2
gen assets3 = assets^3
gen assets4 = assets^4
gen assets5 = assets^5
gen assets6 = assets^6
gen output2 = output^2
gen output3 = output^3
gen output4 = output^4
gen output5 = output^5
gen output6 = output^6
quietly reg ldf avgyr avgyr2 avgyr3 avgyr4 avgyr5 avgyr6 devg devg2 devg3 devg4 devg5 devg6 trans trans2 trans3 trans4 trans5 trans6 cs cs2 cs3 cs4 cs5 cs6 growth growth2 growth3 growth4 growth5 growth6 industry industry2 industry3 industry4 industry5 industry6 secdum secdum2 secdum3 secdum4 secdum5 secdum6 empl empl2 empl3 empl4 empl5 empl6 assets assets2 assets3 assets4 assets5 assets6 output output2 output3 output4 output5 output6
display "R2 = " e(r2)
quietly reg avgyr ldf ldf2 ldf3 ldf4 ldf5 ldf6 devg devg2 devg3 devg4 devg5 devg6 trans trans2 trans3 trans4 trans5 trans6 cs cs2 cs3 cs4 cs5 cs6 growth growth2 growth3 growth4 growth5 growth6 industry industry2 industry3 industry4 industry5 industry6 secdum secdum2 secdum3 secdum4 secdum5 secdum6 empl empl2 empl3 empl4 empl5 empl6 assets assets2 assets3 assets4 assets5 assets6 output output2 output3 output4 output5 output6
display "R2 = " e(r2)
quietly reg devg ldf ldf2 ldf3 ldf4 ldf5 ldf6 avgyr avgyr2 avgyr3 avgyr4 avgyr5 avgyr6 trans trans2 trans3 trans4 trans5 trans6 cs cs2 cs3 cs4 cs5 cs6 growth growth2 growth3 growth4 growth5 growth6 industry industry2 industry3 industry4 industry5 industry6 secdum secdum2 secdum3 secdum4 secdum5 secdum6 empl empl2 empl3 empl4 empl5 empl6 assets assets2 assets3 assets4 assets5 assets6 output output2 output3 output4 output5 output6
display "R2 = " e(r2)
quietly reg trans ldf ldf2 ldf3 ldf4 ldf5 ldf6 avgyr avgyr2 avgyr3 avgyr4 avgyr5 avgyr6 devg devg2 devg3 devg4 devg5 devg6 cs cs2 cs3 cs4 cs5 cs6 growth growth2 growth3 growth4 growth5 growth6 industry industry2 industry3 industry4 industry5 industry6 secdum secdum2 secdum3 secdum4 secdum5 secdum6 empl empl2 empl3 empl4 empl5 empl6 assets assets2 assets3 assets4 assets5 assets6 output output2 output3 output4 output5 output6
display "R2 = " e(r2)
quietly reg cs ldf ldf2 ldf3 ldf4 ldf5 ldf6 avgyr avgyr2 avgyr3 avgyr4 avgyr5 avgyr6 devg devg2 devg3 devg4 devg5 devg6 trans trans2 trans3 trans4 trans5 trans6 growth growth2 growth3 growth4 growth5 growth6 industry industry2 industry3 industry4 industry5 industry6 secdum secdum2 secdum3 secdum4 secdum5 secdum6 empl empl2 empl3 empl4 empl5 empl6 assets assets2 assets3 assets4 assets5 assets6 output output2 output3 output4 output5 output6
display "R2 = " e(r2)
quietly reg growth ldf ldf2 ldf3 ldf4 ldf5 ldf6 avgyr avgyr2 avgyr3 avgyr4 avgyr5 avgyr6 devg devg2 devg3 devg4 devg5 devg6 trans trans2 trans3 trans4 trans5 trans6 cs cs2 cs3 cs4 cs5 cs6 industry industry2 industry3 industry4 industry5 industry6 secdum secdum2 secdum3 secdum4 secdum5 secdum6 empl empl2 empl3 empl4 empl5 empl6 assets assets2 assets3 assets4 assets5 assets6 output output2 output3 output4 output5 output6
display "R2 = " e(r2)
quietly reg industry ldf ldf2 ldf3 ldf4 ldf5 ldf6 avgyr avgyr2 avgyr3 avgyr4 avgyr5 avgyr6 devg devg2 devg3 devg4 devg5 devg6 trans trans2 trans3 trans4 trans5 trans6 cs cs2 cs3 cs4 cs5 cs6 growth growth2 growth3 growth4 growth5 growth6 secdum secdum2 secdum3 secdum4 secdum5 secdum6 empl empl2 empl3 empl4 empl5 empl6 assets assets2 assets3 assets4 assets5 assets6 output output2 output3 output4 output5 output6
display "R2 = " e(r2)
quietly reg secdum ldf ldf2 ldf3 ldf4 ldf5 ldf6 avgyr avgyr2 avgyr3 avgyr4 avgyr5 avgyr6 devg devg2 devg3 devg4 devg5 devg6 trans trans2 trans3 trans4 trans5 trans6 cs cs2 cs3 cs4 cs5 cs6 growth growth2 growth3 growth4 growth5 growth6 industry industry2 industry3 industry4 industry5 industry6 empl empl2 empl3 empl4 empl5 empl6 assets assets2 assets3 assets4 assets5 assets6 output output2 output3 output4 output5 output6
display "R2 = " e(r2)
quietly reg empl ldf ldf2 ldf3 ldf4 ldf5 ldf6 avgyr avgyr2 avgyr3 avgyr4 avgyr5 avgyr6 devg devg2 devg3 devg4 devg5 devg6 trans trans2 trans3 trans4 trans5 trans6 cs cs2 cs3 cs4 cs5 cs6 growth growth2 growth3 growth4 growth5 growth6 industry industry2 industry3 industry4 industry5 industry6 secdum secdum2 secdum3 secdum4 secdum5 secdum6 assets assets2 assets3 assets4 assets5 assets6 output output2 output3 output4 output5 output6
display "R2 = " e(r2)
quietly reg assets ldf ldf2 ldf3 ldf4 ldf5 ldf6 avgyr avgyr2 avgyr3 avgyr4 avgyr5 avgyr6 devg devg2 devg3 devg4 devg5 devg6 trans trans2 trans3 trans4 trans5 trans6 cs cs2 cs3 cs4 cs5 cs6 growth growth2 growth3 growth4 growth5 growth6 industry industry2 industry3 industry4 industry5 industry6 secdum secdum2 secdum3 secdum4 secdum5 secdum6 empl empl2 empl3 empl4 empl5 empl6 output output2 output3 output4 output5 output6
display "R2 = " e(r2)
quietly reg output ldf ldf2 ldf3 ldf4 ldf5 ldf6 avgyr avgyr2 avgyr3 avgyr4 avgyr5 avgyr6 devg devg2 devg3 devg4 devg5 devg6 trans trans2 trans3 trans4 trans5 trans6 cs cs2 cs3 cs4 cs5 cs6 growth growth2 growth3 growth4 growth5 growth6 industry industry2 industry3 industry4 industry5 industry6 secdum secdum2 secdum3 secdum4 secdum5 secdum6 empl empl2 empl3 empl4 empl5 empl6 assets assets2 assets3 assets4 assets5 assets6
display "R2 = " e(r2)
*ALL1
*ALL OLS
eststo: quietly reg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output, vce(robust)
eststo: quietly reg  tstat ldf avgyr devg trans cs, vce(robust)
eststo: quietly reg  tstat growth industry secdum empl assets output, vce(robust)
eststo: quietly reg  tstat trans cs  growth industry empl output, vce(robust)
*ALL OLS, EXCLUDING OUTLIERS
eststo: quietly reg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if abststat<8, vce(robust)
eststo: quietly reg  tstat ldf avgyr devg trans cs if abststat<8, vce(robust)
estat ovtest
eststo: quietly reg  tstat growth industry secdum empl assets output if abststat<8, vce(robust)
estat ovtest
eststo: quietly reg  tstat trans cs  growth industry empl output if abststat<8, vce(robust)
estat ovtest
esttab using all1.tex, booktabs compress r2 title(Standard meta-regression, all studies\label{all1}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mgroups("OLS, including outliers" "OLS, excluding outliers", pattern(1 0 0 0 1 0 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) alignment(D{.}{.}{-1}) page(dcolumn) nomtitles nogaps
eststo clear
*ALL2
*ALL IRLS
eststo: quietly rreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output
eststo: quietly rreg  tstat ldf avgyr devg trans cs
eststo: quietly rreg  tstat growth industry secdum empl assets output
eststo: quietly rreg  tstat trans cs  growth industry empl output
*ALL MEDIAN REGRESSION
eststo: qreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output
eststo: qreg  tstat ldf avgyr devg trans cs
eststo: qreg  tstat growth industry secdum empl assets output
eststo: qreg  tstat trans cs  growth industry empl output
esttab using all2.tex, booktabs compress r2 title(Robust meta-regression, all studies\label{all2}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mgroups("IRLS" "Median regression", pattern(1 0 0 0 1 0 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) alignment(D{.}{.}{-1}) page(dcolumn) nomtitles nogaps
eststo clear
*ALL3
*ALL PANEL
xtset id
eststo: quietly xtreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output, re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat ldf avgyr devg trans cs, re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat growth industry secdum empl assets output, re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat trans cs  growth industry empl output, re vce(robust)
display "R2 overall = " e(r2_o)
*ALL PANEL, EXCLUDING OUTLIERS
eststo: quietly xtreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if abststat<8, re vce(robust)
*Breusch and Pagan Lagrangian multiplier test for random effects
xttest0
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat ldf avgyr devg trans cs if abststat<8, re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat growth industry secdum empl assets output if abststat<8, re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat trans cs  growth industry empl output if abststat<8, re vce(robust)
display "R2 overall = " e(r2_o)
esttab using all3.tex, booktabs compress r2 title(Panel meta-regression, all studies\label{all3}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mgroups("Random effects, including outliers" "Random effects, excluding outliers", pattern(1 0 0 0 1 0 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) alignment(D{.}{.}{-1}) page(dcolumn) nomtitles nogaps
eststo clear
*ALL4
*ALL eststo: quietly probit, POSIT
eststo: quietly probit posit ldf avgyr devg trans cs  growth industry secdum empl assets output
eststo: quietly probit posit ldf avgyr devg trans cs
eststo: quietly probit posit growth industry secdum empl assets output
eststo: quietly probit posit trans cs  growth industry empl assets output
*ALL eststo: quietly probit, SIGNIF
eststo: quietly probit signif ldf avgyr devg trans cs  growth industry secdum empl assets output
eststo: quietly probit signif ldf avgyr devg trans cs
eststo: quietly probit signif growth industry secdum empl assets output
eststo: quietly probit signif ldf avgyr cs secdum assets
esttab using all4.tex, booktabs compress pr2 title(Probability meta-regression, all studies\label{all4}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mgroups("Probit---POSIT, all observations" "Probit---SIGNIF, all observations", pattern(1 0 0 0 1 0 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) alignment(D{.}{.}{-1}) page(dcolumn) nomtitles nogaps
eststo clear
*BODYALL
eststo: quietly reg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if abststat<8, vce(robust)
eststo: quietly rreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output
eststo: quietly qreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output
eststo: quietly xtreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if abststat<8, re vce(robust)
eststo: quietly probit posit ldf avgyr devg trans cs  growth industry secdum empl assets output
esttab using bodyall.tex, booktabs compress r2 title(Summary of conducted meta-regressions, all studies\label{bodyall}) mtitles("OLS" "IRLS" "Median reg." "RE" "Probit") addnote("Note: OLS and RE computed excluding outliers, using heteroscedasticity robust (Huber-White sandwich est.) \emph{t} statistics") star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label alignment(D{.}{.}{-1}) page(dcolumn) nonumber nogaps
eststo clear
*CHOW TEST, OLD/NEW
generate newldf = new*ldf
generate newavgyr = new*avgyr
generate newdevg = new*devg
generate newtrans = new*trans
generate newcs = new*cs
generate newgrowth = new*growth
generate newindustry = new*industry
generate newsecdum = new*secdum
generate newempl = new*empl
generate newassets = new*assets
generate newoutput = new*output
quietly reg tstat ldf avgyr devg trans cs growth industry secdum empl assets output new newldf newavgyr newdevg newtrans newcs newgrowth newindustry newsecdum newempl newassets newoutput
test new newldf newavgyr newdevg newtrans newcs newgrowth newindustry newsecdum newempl newassets newoutput
*OLD1
*OLD OLS
eststo: quietly reg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if new==0, vce(robust)
eststo: quietly reg  tstat ldf avgyr devg trans cs if new==0, vce(robust)
eststo: quietly reg  tstat growth industry secdum empl assets output if new==0, vce(robust)
eststo: quietly reg  tstat trans cs industry empl output if new==0, vce(robust)
*OLD OLS, EXCLUDING OUTLIERS
eststo: quietly reg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if (abststat<8) & (new==0), vce(robust)
eststo: quietly reg  tstat ldf avgyr devg trans cs if (abststat<8) & (new==0), vce(robust)
eststo: quietly reg  tstat growth industry secdum empl assets output if (abststat<8) & (new==0), vce(robust)
eststo: quietly reg  tstat trans cs industry empl output if (abststat<8) & (new==0), vce(robust)
esttab using old1.tex, booktabs compress r2 title(Standard meta-regression, old studies\label{old1}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mgroups("OLS, including outliers" "OLS, excluding outliers", pattern(1 0 0 0 1 0 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) alignment(D{.}{.}{-1}) page(dcolumn) nomtitles nogaps
eststo clear
*OLD2
*OLD IRLS
eststo: quietly rreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if new==0
eststo: quietly rreg  tstat ldf avgyr devg trans cs if new==0
eststo: quietly rreg  tstat growth industry secdum empl assets output if new==0
eststo: quietly rreg  tstat trans cs industry empl output if new==0
*OLD MEDIAN REGRESSION
eststo: qreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if new==0
eststo: qreg  tstat ldf avgyr devg trans cs if new==0
eststo: qreg  tstat growth industry secdum empl assets output if new==0
eststo: qreg  tstat trans cs industry empl output if new==0
esttab using old2.tex, booktabs compress r2 title(Robust meta-regression, old studies\label{old2}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mgroups("IRLS" "Median regression", pattern(1 0 0 0 1 0 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) alignment(D{.}{.}{-1}) page(dcolumn) nomtitles nogaps
eststo clear
*OLD3
*OLD PANEL
eststo: quietly xtreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if new==0, re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat ldf avgyr devg trans cs if new==0, re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat growth industry secdum empl assets output if new==0, re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat trans cs industry empl output if new==0, re vce(robust)
display "R2 overall = " e(r2_o)
*OLD PANEL, EXCLUDING OUTLIERS
eststo: quietly xtreg  tstat ldf avgyr devg trans cs growth industry secdum empl assets output if (abststat<8) & (new==0), re vce(robust)
*Breusch and Pagan Lagrangian multiplier test for random effects
xttest0
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat ldf avgyr devg trans cs if (abststat<8) & (new==0), re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat growth industry secdum empl assets output if (abststat<8) & (new==0), re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat trans cs industry empl output if (abststat<8) & (new==0), re vce(robust)
display "R2 overall = " e(r2_o)
esttab using old3.tex, booktabs compress r2 title(Panel meta-regression, old studies\label{old3}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mgroups("Random effects, including outliers" "Random effects, excluding outliers", pattern(1 0 0 0 1 0 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) alignment(D{.}{.}{-1}) page(dcolumn) nomtitles nogaps
eststo clear
*OLD4
*OLD eststo: quietly probit, POSIT
eststo: quietly probit posit ldf avgyr devg trans cs  growth secdum empl assets output if new==0
eststo: quietly probit posit ldf avgyr devg trans cs if new==0
eststo: quietly probit posit growth secdum empl assets output if new==0
eststo: quietly probit posit ldf trans cs empl assets output if new==0
*OLD eststo: quietly probit, SIGNIF
eststo: quietly probit signif ldf avgyr devg trans cs  growth industry secdum empl assets output if new==0
eststo: quietly probit signif ldf avgyr devg trans cs if new==0
eststo: quietly probit signif growth industry secdum empl assets output if new==0
eststo: quietly probit signif devg trans cs industry secdum empl output if new==0
esttab using old4.tex, booktabs compress pr2 title(Probability meta-regression, old studies\label{old4}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mgroups("Probit---POSIT, all observations" "Probit---SIGNIF, all observations", pattern(1 0 0 0 1 0 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) alignment(D{.}{.}{-1}) page(dcolumn) nomtitles nogaps
eststo clear
*BODYOLD
eststo: quietly reg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if abststat<8 & new==0, vce(robust)
eststo: quietly rreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if new==0
eststo: quietly qreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if new==0
eststo: quietly xtreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if abststat<8 & new==0, re vce(robust)
eststo: quietly probit posit ldf avgyr devg trans cs  growth secdum empl assets output if new==0
esttab using bodyold.tex, booktabs compress r2 title(Summary of conducted meta-regressions, old studies\label{bodyold}) mtitles("OLS" "IRLS" "Median reg." "RE" "Probit") addnote("Note: OLS and RE computed excluding outliers, using heteroscedasticity robust (Huber-White sandwich est.) \emph{t} statistics") star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label alignment(D{.}{.}{-1}) page(dcolumn) nonumber nogaps
eststo clear
*NEW1
*NEW OLS
eststo: quietly reg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if new==1, vce(robust)
eststo: quietly reg  tstat ldf avgyr devg trans cs if new==1, vce(robust)
eststo: quietly reg  tstat growth industry secdum empl assets output if new==1, vce(robust)
eststo: quietly reg  tstat ldf avgyr trans cs  growth industry secdum empl assets if new==1, vce(robust)
*NEW OLS, EXCLUDING OUTLIERS
eststo: quietly reg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if (abststat<8) & (new==1), vce(robust)
eststo: quietly reg  tstat ldf avgyr devg trans cs if (abststat<8) & (new==1), vce(robust)
eststo: quietly reg  tstat growth industry secdum empl assets output if (abststat<8) & (new==1), vce(robust)
eststo: quietly reg  tstat ldf avgyr trans cs  growth industry secdum empl assets if (abststat<8) & (new==1), vce(robust)
esttab using new1.tex, booktabs compress r2 title(Standard meta-regression, new studies\label{new1}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mgroups("OLS, including outliers" "OLS, excluding outliers", pattern(1 0 0 0 1 0 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) alignment(D{.}{.}{-1}) page(dcolumn) nomtitles nogaps
eststo clear
*NEW2
*NEW IRLS
eststo: quietly rreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if new==1
eststo: quietly rreg  tstat ldf avgyr devg trans cs if new==1
eststo: quietly rreg  tstat growth industry secdum empl assets output if new==1
eststo: quietly rreg  tstat ldf avgyr cs  growth industry secdum if new==1
*NEW MEDIAN REGRESSION
eststo: qreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if new==1
eststo: qreg  tstat ldf avgyr devg trans cs if new==1
eststo: qreg  tstat growth industry secdum empl assets output if new==1
eststo: qreg  tstat ldf avgyr cs  growth industry secdum if new==1
esttab using new2.tex, booktabs compress r2 title(Robust meta-regression, new studies\label{new2}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mgroups("IRLS" "Median regression", pattern(1 0 0 0 1 0 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) alignment(D{.}{.}{-1}) page(dcolumn) nomtitles nogaps
eststo clear
*NEW3
*NEW PANEL
eststo: quietly xtreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if new==1, re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat ldf avgyr devg trans cs if new==1, re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat growth industry secdum empl assets output if new==1, re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat ldf avgyr cs industry secdum empl if new==1, re vce(robust)
display "R2 overall = " e(r2_o)
*NEW PANEL, EXCLUDING OUTLIERS
eststo: quietly xtreg  tstat ldf avgyr devg trans cs growth industry secdum empl assets output if (abststat<8) & (new==1), re vce(robust)
*Breusch and Pagan Lagrangian multiplier test for random effects
xttest0
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat ldf avgyr devg trans cs if (abststat<8) & (new==1), re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat growth industry secdum empl assets output if (abststat<8) & (new==1), re vce(robust)
display "R2 overall = " e(r2_o)
eststo: quietly xtreg  tstat ldf avgyr cs industry secdum empl if (abststat<8) & (new==1), re vce(robust)
display "R2 overall = " e(r2_o)
esttab using new3.tex, booktabs compress r2 title(Panel meta-regression, new studies\label{new3}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mgroups("Random effects, including outliers" "Random effects, excluding outliers", pattern(1 0 0 0 1 0 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) alignment(D{.}{.}{-1}) page(dcolumn) nomtitles nogaps
eststo clear
*NEW4
*NEW eststo: quietly probit, POSIT
eststo: quietly probit posit ldf avgyr trans cs  growth industry secdum empl assets output if new==1
eststo: quietly probit posit ldf avgyr devg trans cs if new==1
eststo: quietly probit posit growth industry secdum empl assets output if new==1
eststo: quietly probit posit ldf trans cs industry empl assets output if new==1
*NEW eststo: quietly probit, SIGNIF
eststo: quietly probit signif ldf avgyr devg trans cs  growth industry secdum empl assets output if new==1
eststo: quietly probit signif ldf avgyr devg trans cs if new==1
eststo: quietly probit signif growth industry secdum empl assets output if new==1
eststo: quietly probit signif ldf avgyr devg trans cs industry secdum if new==1
esttab using new4.tex, booktabs compress pr2 title(Probability meta-regression, new studies\label{new4}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mgroups("Probit---POSIT, all observations" "Probit---SIGNIF, all observations", pattern(1 0 0 0 1 0 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) alignment(D{.}{.}{-1}) page(dcolumn) nomtitles nogaps
eststo clear
*BODYNEW
eststo: quietly reg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if abststat<8 & new==1, vce(robust)
eststo: quietly rreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if new==1
eststo: quietly qreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if new==1
eststo: quietly xtreg  tstat ldf avgyr devg trans cs  growth industry secdum empl assets output if abststat<8 & new==1, re vce(robust)
eststo: quietly probit posit ldf avgyr trans cs  growth industry secdum empl assets output if new==1
esttab using bodynew.tex, booktabs compress r2 title(Summary of conducted meta-regressions, new studies\label{bodynew}) mtitles("OLS" "IRLS" "Median reg." "RE" "Probit") addnote("Note: OLS and RE computed excluding outliers, using heteroscedasticity robust (Huber-White sandwich est.) \emph{t} statistics") star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label alignment(D{.}{.}{-1}) page(dcolumn) nonumber nogaps
eststo clear
*BIAS
*ALL OLS, BIAS
eststo: quietly reg  abststat lsrdf avgyr devg trans cs  growth industry secdum empl assets output, vce(robust)
test (lsrdf=1)
eststo: quietly reg  abststat lsrdf avgyr devg trans cs, vce(robust)
test (lsrdf=1)
eststo: quietly reg  abststat lsrdf growth industry secdum empl assets output, vce(robust)
test (lsrdf=1)
eststo: quietly reg  abststat lsrdf trans cs  growth industry empl output, vce(robust)
test (lsrdf=1)
*ALL OLS, EXCLUDING OUTLIERS, BIAS
eststo: quietly reg  abststat lsrdf avgyr devg trans cs  growth industry secdum empl assets output if abststat<8, vce(robust)
test (lsrdf=1)
eststo: quietly reg  abststat lsrdf avgyr devg trans cs if abststat<8, vce(robust)
test (lsrdf=1)
eststo: quietly reg  abststat lsrdf growth industry secdum empl assets output if abststat<8, vce(robust)
test (lsrdf=1)
eststo: quietly reg  abststat lsrdf trans cs  growth industry empl output if abststat<8, vce(robust)
test (lsrdf=1)
esttab using bias.tex, booktabs compress r2 ar2 title(Test of publication bias, all studies\label{bias}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mgroups("OLS, including outliers" "OLS, excluding outliers", pattern(1 0 0 0 1 0 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) alignment(D{.}{.}{-1}) page(dcolumn) nomtitles nogaps
eststo clear
*BIAS (FAT-PET)
set scheme s2mono, permanently
xtset id
eststo: quietly reg tstat prec, vce(robust)
eststo: quietly rreg tstat prec
eststo: quietly xtreg tstat prec, vce(robust)
esttab using bias_new.tex, replace booktabs compress r2 title(Alternative test for publication bias\label{tab:bias_new}) mtitles("OLS" "IRLS" "RE") addnote("Note: OLS and RE computed using heteroscedasticity robust (Huber-White sandwich est.) \emph{t} statistics") star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label alignment(D{.}{.}{-1}) page(dcolumn) nonumber nogaps
eststo clear
twoway (scatter prec r)
graph save Graph "C:\Papers\Horizontal_Spillovers\Revision_data\funnel.gph", replace
end