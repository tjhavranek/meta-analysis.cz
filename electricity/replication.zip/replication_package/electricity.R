########################################################################################
# Replication script (full, single file)
# Electricity demand has not become more price-responsive despite ninety years of
# technological change
#
# Authors: Peter Kudela, Tomas Havranek, Zuzana Irsova, Anna Kudelova, Vojtech Sikl | v1.9s
# Last updated: 2026-07-21
# Project page: https://meta-analysis.cz/electricity
#
# Purpose: Reproduces every table and figure in the paper. This single file
#          merges the four analysis scripts -- the headline pipeline (identification
#          ladder, horizon path, two-clock calendar-time test, summary statistics),
#          the publication-bias battery, the Bayesian model averaging appendix, and
#          the database-clustering robustness check. Each part is self-contained and
#          re-reads the frozen electricity.xlsx, so parts may be run independently.
#
# Inputs:  electricity.xlsx (sheet "data") -- the frozen dataset (462 studies,
#          4,720 own-price elasticity estimates)
# Outputs: tables/ and figures/ folders, plus three plain-text result summaries:
#          results_headline.txt, results_model_averaging.txt, results_database_clustering.txt
#
# Requirements: R 4.6.0; required packages readxl, sandwich, lmtest, BMS, metafor,
#               ggplot2, patchwork, scales, ragg, jsonlite. Optional (used only for
#               specific estimators, skipped with a message if absent): AER (MAIVE),
#               puniform (p-uniform*), phacking (RTMA), rstudioapi (RStudio path).
#
# Note: the paper's electricity.tex already has all tables inlined, so it compiles
#       WITHOUT running this script; this script is for replication / verification.
# Run from this folder:  Rscript electricity.R
########################################################################################


# ######################################################################
# PART 1 of 4 - HEADLINE PIPELINE (identification ladder, horizon path, two-clock trend, summary stats; main-text tables + figs 1-6)
# ######################################################################

suppressPackageStartupMessages({
  library(readxl); library(sandwich); library(lmtest); library(jsonlite)
  library(ggplot2); library(patchwork); library(ragg); library(scales)
})

# Resolve paths relative to this script (mirrors Python BASE = __file__.parent),
# so the pipeline runs correctly from any working directory.
# --- locate this script's own folder and run from there (Rscript, source(), or RStudio) ---
.find_base <- function() {
  a <- commandArgs(FALSE); f <- a[grep("^--file=", a)]
  if (length(f)) return(dirname(normalizePath(sub("^--file=", "", f[1]))))          # Rscript
  for (i in rev(seq_len(sys.nframe()))) if (!is.null(sys.frame(i)$ofile))              # source()
    return(dirname(normalizePath(sys.frame(i)$ofile)))
  if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {  # RStudio editor
    p <- tryCatch(rstudioapi::getSourceEditorContext()$path, error = function(e) "")
    if (length(p) && nzchar(p)) return(dirname(normalizePath(p)))
  }
  getwd()                                                                             # fallback
}
BASE <- .find_base(); setwd(BASE)

INPUT <- file.path(BASE, "electricity.xlsx")
d <- as.data.frame(read_excel(INPUT, sheet = "data"))
d <- d[is.finite(d$effect), ]

wins <- function(x, p = 0.01) {
  q <- quantile(x, c(p, 1 - p), na.rm = TRUE)
  pmin(pmax(x, q[1]), q[2])
}

# base sample: usable SE
b <- d[is.finite(d$se) & d$se > 0, ]
b$effect_w <- wins(b$effect); b$se_w <- wins(b$se)
b$effect_M <- as.numeric(as.character(b$effect_M)); b$in_M_pool <- as.numeric(as.character(b$in_M_pool))

# BASELINE headline = enlarged Marshallian-equivalent pool: native-M + Slutsky-converted Hicksian
# (effect_M precomputed in xlsx: per-estimate own eta, s=0.04, no imputation); real SE only (drop Cao imputed).
H <- b[b$in_M_pool %in% 1 & b$formula %in% 1 & is.finite(b$effect_M) & b$se_source != "imputed_uniform_t", ]
H$effect_w <- wins(H$effect_M)

# pure-Marshallian robustness (native-M only); MH alias = baseline enlarged pool
s_budget <- 0.04
eta_med <- median(as.numeric(as.character(b$income_elasticity)), na.rm = TRUE)
H_native <- H[H$effect_M_source == "native_M", ]
MH <- H

# rung groups
rgroup <- function(r) ifelse(is.na(r), NA,
  ifelse(r <= 3, "design", ifelse(r == 4, "iv", ifelse(r == 5, "fe", "naive"))))
b$rg <- rgroup(b$rung); H$rg <- rgroup(H$rung); MH$rg <- rgroup(MH$rung)

# time axis
for (nm in c("b", "H", "MH")) {
  x <- get(nm)
  x$midyear <- ifelse(is.na(x$data_midyear), x$publication_year - 3, x$data_midyear)
  assign(nm, x)
}

# ---------------------------------------------------------------- helpers
clfit <- function(f, dat) {
  m <- lm(f, data = dat)
  list(m = m, ct = coeftest(m, vcov = vcovCL(m, cluster = dat$study_id, type = "HC1")))
}
fatpet <- function(sub) {
  r <- clfit(effect_w ~ se_w, sub)
  c(pet = r$ct[1, 1], pet_se = r$ct[1, 2], pet_p = r$ct[1, 4],
    fat = r$ct[2, 1], fat_p = r$ct[2, 4], n = nrow(sub), k = length(unique(sub$study_id)))
}
peese <- function(sub) { sub$se2 <- sub$se_w^2; clfit(effect_w ~ se2, sub)$ct[1, 1] }
pwmean <- function(sub) { w <- 1 / sub$se_w^2; sum(sub$effect_w * w) / sum(w) }
waap <- function(sub) {
  mu <- abs(fatpet(sub)["pet"])
  ap <- sub[sub$se_w <= mu / 2.8, ]
  if (nrow(ap) < 5) return(c(NA, nrow(ap)))
  w <- 1 / ap$se_w^2; c(sum(ap$effect_w * w) / sum(w), nrow(ap))
}
top10 <- function(sub) {
  t <- sub[order(sub$se_w), ][1:max(floor(nrow(sub) * .1), 5), ]
  w <- 1 / t$se_w^2; sum(t$effect_w * w) / sum(w)
}
battery <- function(sub) {
  fp <- fatpet(sub); wa <- waap(sub)
  list(n = fp[["n"]], k = fp[["k"]], mean = mean(sub$effect_w), pw = pwmean(sub),
       median = median(sub$effect_w), pet = fp[["pet"]], pet_se = fp[["pet_se"]],
       fat = fp[["fat"]], fat_p = fp[["fat_p"]], peese = peese(sub),
       waap = wa[1], waap_n = wa[2], top10 = top10(sub))
}
mods <- c("residential_demand","industrial_demand","average_price","panel_data",
          "cross_section_data","loc_usa","loc_europe","demographics_control",
          "income_control","doublelog_function")

R <- list(pipeline = "electricity.R", input = INPUT,
          eta_median = eta_med,
          counts = list(all_estimates = nrow(d), all_studies = length(unique(d$study_id)),
                        with_se = nrow(b), head = nrow(H),
                        head_studies = length(unique(H$study_id)),
                        head_sr = sum(H$short_run == 1, na.rm = TRUE),
                        head_ir = sum(H$intermediate_run == 1, na.rm = TRUE),
                        head_lr = sum(H$long_run == 1, na.rm = TRUE),
                        mh = nrow(MH), mh_studies = length(unique(MH$study_id)),
                        median_midyear = median(b$data_midyear, na.rm = TRUE),
                        slutsky_median_shift = s_budget * eta_med))

# ============================================================ 1. LADDER
SR <- H[H$short_run == 1, ]
ladder <- list()
for (hz in c("SR", "LR", "IR")) {
  sub <- switch(hz, SR = SR, LR = H[H$long_run == 1, ], IR = H[H$intermediate_run == 1, ])
  sub <- sub[!is.na(sub$rg), ]
  rows <- list()
  for (g in c("design", "iv", "fe", "naive")) {
    ss <- sub[sub$rg == g, ]
    rows[[g]] <- if (nrow(ss) >= 8 && length(unique(ss$study_id)) >= 2) {
      fp <- fatpet(ss)
      list(n = nrow(ss), k = fp[["k"]], raw = mean(ss$effect_w), pw = pwmean(ss),
           pet = fp[["pet"]], pet_se = fp[["pet_se"]])
    } else list(n = nrow(ss), k = length(unique(ss$study_id)),
                raw = if (nrow(ss)) mean(ss$effect_w) else NA)
  }
  # adjusted ladder: one regression, moderators at means, naive reference
  sub$g_design <- as.numeric(sub$rg == "design")
  sub$g_iv <- as.numeric(sub$rg == "iv"); sub$g_fe <- as.numeric(sub$rg == "fe")
  for (m in mods) sub[[m]][is.na(sub[[m]])] <- 0
  f <- as.formula(paste("effect_w ~ se_w + g_design + g_iv + g_fe +", paste(mods, collapse = "+")))
  r <- clfit(f, sub); ct <- r$ct; p <- ct[, 1]; se_ <- ct[, 2]
  mbar <- sapply(mods, function(m) mean(sub[[m]]))
  basel <- p[["(Intercept)"]] + sum(p[mods] * mbar)
  adj <- c(naive = basel, design = basel + p[["g_design"]],
           iv = basel + p[["g_iv"]], fe = basel + p[["g_fe"]])
  adjse <- c(naive = se_[["(Intercept)"]],
             design = sqrt(se_[["(Intercept)"]]^2 + se_[["g_design"]]^2),
             iv = sqrt(se_[["(Intercept)"]]^2 + se_[["g_iv"]]^2),
             fe = sqrt(se_[["(Intercept)"]]^2 + se_[["g_fe"]]^2))
  for (g in names(rows)) { rows[[g]]$adj <- adj[[g]]; rows[[g]]$adj_se <- adjse[[g]] }
  rows[["_reg"]] <- list(design_coef = p[["g_design"]], design_p = ct["g_design", 4],
                         iv_coef = p[["g_iv"]], iv_p = ct["g_iv", 4],
                         fe_coef = p[["g_fe"]], fe_p = ct["g_fe", 4],
                         n = nrow(sub), k = length(unique(sub$study_id)))
  ladder[[hz]] <- rows
}
R$ladder <- ladder

# within-study contrasts
ws <- do.call(rbind, lapply(split(b[!is.na(b$rung), ], b$study_id[!is.na(b$rung)]), function(g) {
  rs <- sort(unique(g$rung))
  if (length(rs) < 2) return(NULL)
  data.frame(study = g$study_name[1], clean_rung = rs[1], dirty_rung = rs[length(rs)],
             contrast = mean(g$effect_w[g$rung == rs[1]]) - mean(g$effect_w[g$rung == rs[length(rs)]]))
}))
R$within_study <- list(n_studies = nrow(ws), mean = mean(ws$contrast),
                       share_positive = mean(ws$contrast > 0),
                       t_paired = mean(ws$contrast) / (sd(ws$contrast) / sqrt(nrow(ws))))

# ============================================================ 2. BATTERY
bat <- list()
for (hz in c("SR", "IR", "LR")) {
  sub <- switch(hz, SR = SR, IR = H[H$intermediate_run == 1, ], LR = H[H$long_run == 1, ])
  bat[[hz]] <- list(all = battery(sub))
  for (g in c("design", "iv", "fe", "naive")) {
    ss <- sub[sub$rg == g & !is.na(sub$rg), ]
    if (nrow(ss) >= 30 && length(unique(ss$study_id)) >= 5) bat[[hz]][[g]] <- battery(ss)
  }
}
bat$SR_marginal <- battery(SR[SR$marginal_price == 1 & !is.na(SR$marginal_price), ])
bat$SR_average  <- battery(SR[SR$average_price == 1 & !is.na(SR$average_price), ])
bat$MH_SR <- battery(MH[MH$short_run == 1, ]); bat$MH_LR <- battery(MH[MH$long_run == 1, ])
pref <- SR[SR$preferred == 1 & !is.na(SR$preferred), ]
if (nrow(pref) >= 30) bat$SR_preferred <- battery(pref)
srn <- SR[is.finite(SR$n_obs) & SR$n_obs > 0, ]
mn <- lm(effect_w ~ se_w, data = srn, weights = n_obs)
ctn <- coeftest(mn, vcov = vcovCL(mn, cluster = srn$study_id, type = "HC1"))
bat$SR_nweighted_pet <- list(pet = ctn[1, 1], pet_se = ctn[1, 2], n = nrow(srn))
R$battery <- bat

# ============================================================ 2b. HELD-OUT ROBUSTNESS (App. robustness, tab:heldout)
# The Marshallian-equivalent estimation sample H is 3,324 of the 4,720 usable-SE corpus b; characterize
# the 1,396 held out (raw effect, all horizons pooled) to show the restriction is scale comparability, not selection.
b$inH <- b$in_M_pool %in% 1 & b$formula %in% 1 & is.finite(b$effect_M) & b$se_source != "imputed_uniform_t"
b$inH[is.na(b$inH)] <- FALSE
b$heldgrp <- ifelse(b$inH, "baseline",
             ifelse(!(b$in_M_pool %in% 1), "not_marshallian",
             ifelse(!(b$formula %in% 1), "inverted_formula",
             ifelse(b$se_source %in% "imputed_uniform_t", "imputed_se", "other"))))
.hostat <- function(s) {
  o <- list(n = nrow(s), k = length(unique(s$study_id)), mean = mean(s$effect_w), median = median(s$effect_w))
  if (length(unique(s$study_id)) >= 2) { fp <- fatpet(s); o$pet <- fp[["pet"]]; o$pet_se <- fp[["pet_se"]]; o$fat <- fp[["fat"]] }
  o }
R$heldout <- list(baseline = .hostat(b[b$heldgrp == "baseline", ]),
                  not_marshallian = .hostat(b[b$heldgrp == "not_marshallian", ]),
                  inverted_formula = .hostat(b[b$heldgrp == "inverted_formula", ]),
                  imputed_se = .hostat(b[b$heldgrp == "imputed_se", ]),
                  all_held = .hostat(b[!b$inH, ]), full_corpus = .hostat(b))
b$held <- as.numeric(!b$inH)
.hm <- lm(effect_w ~ se_w * held, b); .hct <- coeftest(.hm, vcov = vcovCL(.hm, cluster = b$study_id, type = "HC1"))
R$heldout$pooled <- list(level = .hct["held", 1], level_p = .hct["held", 4], slope = .hct["se_w:held", 1], slope_p = .hct["se_w:held", 4])

# ============================================================ 3. HORIZON PATH + ERAS
erabin <- function(y) ifelse(y <= 1975, "<=1975", ifelse(y <= 1990, "1976-90",
                     ifelse(y <= 2005, "1991-05", ">=2006")))
H$era <- erabin(H$midyear)
path <- list()
for (hz in c("SR", "IR", "LR")) {
  flag <- switch(hz, SR = "short_run", IR = "intermediate_run", LR = "long_run")
  sub <- H[H[[flag]] == 1, ]
  fp <- fatpet(sub)
  e <- list(pet = fp[["pet"]], pet_se = fp[["pet_se"]], n = fp[["n"]], k = fp[["k"]],
            raw = mean(sub$effect_w))
  for (er in c("<=1975", "1976-90", "1991-05", ">=2006")) {
    ss <- sub[sub$era == er & !is.na(sub$era), ]
    e[[er]] <- if (nrow(ss) >= 25 && length(unique(ss$study_id)) >= 5) {
      f2 <- fatpet(ss); list(pet = f2[["pet"]], pet_se = f2[["pet_se"]], n = f2[["n"]], k = f2[["k"]])
    } else list(n = nrow(ss), k = length(unique(ss$study_id)))
  }
  path[[hz]] <- e
}
R$horizon_path <- path
R$lr_sr_ratio <- path$LR$pet / path$SR$pet

# ============================================================ 4. TWO CLOCKS + DECADES
tc <- list()
for (hz in c("SR", "IR", "LR")) {
  flag <- switch(hz, SR = "short_run", IR = "intermediate_run", LR = "long_run")
  sub <- H[H[[flag]] == 1 & is.finite(H$midyear), ]
  sub$dy <- (sub$midyear - mean(sub$midyear)) / 10
  sub$py <- (sub$publication_year - mean(sub$publication_year)) / 10
  sp <- list()
  ct <- clfit(effect_w ~ se_w + dy, sub)$ct
  sp$data_only <- list(trend = ct["dy", 1], se = ct["dy", 2], p = ct["dy", 4])
  ct <- clfit(effect_w ~ se_w + dy + py, sub)$ct
  sp$two_clocks <- list(data = ct["dy", 1], data_se = ct["dy", 2], data_p = ct["dy", 4],
                        pub = ct["py", 1], pub_se = ct["py", 2], pub_p = ct["py", 4])
  sub$g_design <- as.numeric(sub$rg == "design"); sub$g_design[is.na(sub$g_design)] <- 0
  sub$g_iv <- as.numeric(sub$rg == "iv"); sub$g_iv[is.na(sub$g_iv)] <- 0
  sub$g_fe <- as.numeric(sub$rg == "fe"); sub$g_fe[is.na(sub$g_fe)] <- 0
  for (m in mods) sub[[m]][is.na(sub[[m]])] <- 0
  f <- as.formula(paste("effect_w ~ se_w + dy + py + g_design + g_iv + g_fe +",
                        paste(mods, collapse = "+")))
  ct <- clfit(f, sub)$ct
  sp$full <- list(data = ct["dy", 1], data_se = ct["dy", 2], data_p = ct["dy", 4],
                  pub = ct["py", 1], pub_se = ct["py", 2], pub_p = ct["py", 4],
                  n = nrow(sub), k = length(unique(sub$study_id)))
  # within-country: identify the data-vintage trend off within-country variation only (add country fixed effects)
  sub$cty <- factor(sub$country)
  ctw <- clfit(as.formula(paste("effect_w ~ se_w + dy + py + g_design + g_iv + g_fe +",
                                paste(mods, collapse = "+"), "+ cty")), sub)$ct
  sp$within <- list(data = ctw["dy", 1], data_se = ctw["dy", 2], data_p = ctw["dy", 4],
                    pub = ctw["py", 1], pub_se = ctw["py", 2], pub_p = ctw["py", 4],
                    n_country = nlevels(sub$cty))
  ct <- clfit(effect_w ~ dy, sub)$ct
  sp$raw <- list(trend = ct["dy", 1], se = ct["dy", 2], p = ct["dy", 4])
  sub$dy2 <- sub$dy^2
  ct <- clfit(effect_w ~ se_w + dy + dy2, sub)$ct
  sp$quad <- list(lin = ct["dy", 1], lin_p = ct["dy", 4], sq = ct["dy2", 1], sq_p = ct["dy2", 4])
  sp$span_years <- diff(range(sub$midyear))
  tc[[hz]] <- sp
}
R$two_clocks <- tc

dec <- list(SR = list(), LR = list())
SRm <- SR[is.finite(SR$midyear), ]
bins <- list(c(0,1970,"<1970"), c(1970,1980,"1970s"), c(1980,1990,"1980s"),
             c(1990,2000,"1990s"), c(2000,2010,"2000s"), c(2010,2030,"2010s+"))
for (bn in bins) {
  ss <- SRm[SRm$midyear >= as.numeric(bn[1]) & SRm$midyear < as.numeric(bn[2]), ]
  if (nrow(ss) >= 25 && length(unique(ss$study_id)) >= 5) {
    f2 <- fatpet(ss)
    dec$SR[[length(dec$SR)+1]] <- list(era = bn[3], pet = f2[["pet"]], pet_se = f2[["pet_se"]],
                                       n = f2[["n"]], k = f2[["k"]])
  }
}
LRm <- H[H$long_run == 1 & is.finite(H$midyear), ]
for (bn in list(c(0,2000,"<2000"), c(2000,2010,"2000s"), c(2010,2030,"2010s+"))) {
  ss <- LRm[LRm$midyear >= as.numeric(bn[1]) & LRm$midyear < as.numeric(bn[2]), ]
  if (nrow(ss) >= 25 && length(unique(ss$study_id)) >= 5) {
    f2 <- fatpet(ss)
    dec$LR[[length(dec$LR)+1]] <- list(era = bn[3], pet = f2[["pet"]], pet_se = f2[["pet_se"]],
                                       n = f2[["n"]], k = f2[["k"]])
  }
}
R$decades <- dec

# ============================================================ 5. TOU + NEW REGIME + BOUND
SR$tou <- SR$time_of_use_tariff; SR$tou[is.na(SR$tou)] <- 0
ct <- clfit(effect_w ~ se_w + tou, SR)$ct
R$tou <- list(coef = ct["tou", 1], se = ct["tou", 2], p = ct["tou", 4],
              n_tou = sum(SR$tou), n = nrow(SR))
newreg <- list()
cells <- list(post2005 = SR[SR$midyear >= 2005, ], tou = SR[SR$tou == 1, ],
              experiments = SR[SR$rg == "design" & !is.na(SR$rg), ],
              marginal = SR[SR$marginal_price == 1 & !is.na(SR$marginal_price), ], full = SR)
for (k2 in names(cells)) {
  ss <- cells[[k2]]
  if (nrow(ss) >= 25 && length(unique(ss$study_id)) >= 5) {
    f2 <- fatpet(ss)
    newreg[[k2]] <- list(pet = f2[["pet"]], pet_se = f2[["pet_se"]], n = f2[["n"]], k = f2[["k"]])
  }
}
R$new_regime <- newreg

tr <- tc$SR$full
ci_lo <- tr$data - 1.96 * tr$data_se
R$bound <- list(sr_level = path$SR$pet, trend = tr$data,
                ci = c(ci_lo, tr$data + 1.96 * tr$data_se),
                envelope_3dec = abs(min(ci_lo, 0)) * 3,
                required_doubling = abs(path$SR$pet),
                share = abs(min(ci_lo, 0)) * 3 / abs(path$SR$pet))

# ============================================================ 5b. THIN-CELL WILD BOOTSTRAP + CALIPER
# Wild cluster bootstrap (Cameron-Gelbach-Miller): valid inference when clusters (studies) are few.
# Restricted Rademacher weights for the p-value, unrestricted percentile-t for the CI; signs
# enumerated exactly when G<=13. Validated against the design-cell FAT-slope bootstrap already in the paper.
.crv <- function(X, u, cl) { XtXi <- solve(crossprod(X)); M <- matrix(0, ncol(X), ncol(X))
  for (g in levels(cl)) { Xi <- X[cl == g, , drop = FALSE]; s <- crossprod(Xi, u[cl == g]); M <- M + tcrossprod(s) }
  G <- nlevels(cl); n <- nrow(X); k <- ncol(X); ((G/(G-1)) * ((n-1)/(n-k))) * XtXi %*% M %*% XtXi }
.wcb <- function(sub, which = "(Intercept)", B = 9999) {
  X <- model.matrix(~ se_w, sub); y <- sub$effect_w; cl <- factor(sub$study_id); G <- nlevels(cl); j <- match(which, colnames(X))
  bb <- coef(lm.fit(X, y)); u <- as.numeric(y - X %*% bb); se <- sqrt(diag(.crv(X, u, cl))); t0 <- bb[j]/se[j]
  Xr <- X[, -j, drop = FALSE]; br <- coef(lm.fit(Xr, y)); ur <- as.numeric(y - Xr %*% br); yr <- as.numeric(Xr %*% br)
  sv <- if (G <= 13) as.matrix(expand.grid(rep(list(c(-1, 1)), G))) else matrix(sample(c(-1, 1), B * G, TRUE), B, G)
  idx <- split(seq_len(nrow(X)), cl); tR <- tU <- numeric(nrow(sv))
  for (i in seq_len(nrow(sv))) { w <- numeric(nrow(X)); for (g in seq_len(G)) w[idx[[g]]] <- sv[i, g]
    yR <- yr + w * ur; bR <- coef(lm.fit(X, yR)); tR[i] <- bR[j] / sqrt(.crv(X, as.numeric(yR - X %*% bR), cl)[j, j])
    yU <- as.numeric(X %*% bb) + w * u; bU <- coef(lm.fit(X, yU)); tU[i] <- (bU[j] - bb[j]) / sqrt(.crv(X, as.numeric(yU - X %*% bU), cl)[j, j]) }
  q <- quantile(tU, c(.025, .975))
  list(coef = bb[j], se = se[j], p = mean(abs(tR) >= abs(t0)), ci_lo = bb[j] - q[2] * se[j], ci_hi = bb[j] - q[1] * se[j],
       G = G, n = nrow(X), reps = nrow(sv)) }
set.seed(20260722)
LRm2 <- H[H$long_run == 1 & is.finite(H$midyear), ]
R$wcb <- list(design_sr_mean = .wcb(SR[SR$rg == "design" & !is.na(SR$rg), ]),
              lr_2010s_mean  = .wcb(LRm2[LRm2$midyear >= 2010, ]))

# Caliper test (Gerber-Malhotra): excess mass of |t| just above vs below the 1.96 significance threshold.
.caliper <- function(sub, z = 1.96, h = 0.20) { tt <- abs(sub$effect_w / sub$se_w)
  below <- sum(tt >= z - h & tt < z); above <- sum(tt >= z & tt < z + h); n <- below + above
  list(below = below, above = above, share_above = if (n) above / n else NA,
       p = if (n) binom.test(above, n, 0.5)$p.value else NA, h = h) }
R$caliper <- list(all = .caliper(H), observational = .caliper(SR[SR$rg != "design" | is.na(SR$rg), ]),
                  design = .caliper(SR[SR$rg == "design" & !is.na(SR$rg), ]),
                  all_h010 = .caliper(H, h = 0.10), all_h030 = .caliper(H, h = 0.30))

# ============================================================ 5b. PURE-MARSHALLIAN ROBUSTNESS (App C)
# native-M only (no Slutsky conversion), winsorized WITHIN the restricted sample,
# so the App-C robustness numbers trace to this pipeline rather than a side script.
PM <- b[b$effect_M_source == "native_M" & b$formula %in% 1 &
        b$se_source != "imputed_uniform_t" & is.finite(b$effect_M), ]
PM$effect_w <- wins(PM$effect_M); PM$se_w <- wins(PM$se)
PM$rg <- rgroup(PM$rung)
pm <- list(n = nrow(PM), k = length(unique(PM$study_id)),
           sr_n = sum(PM$short_run == 1, na.rm = TRUE),
           lr_n = sum(PM$long_run == 1, na.rm = TRUE))
for (hz in c("SR", "LR")) {
  sub <- PM[PM[[if (hz == "SR") "short_run" else "long_run"]] == 1, ]
  fp <- fatpet(sub)
  pm[[hz]] <- list(pet = fp[["pet"]], pet_se = fp[["pet_se"]], fat_p = fp[["fat_p"]],
                   n = fp[["n"]], k = fp[["k"]])
}
{ sub <- PM[PM$long_run == 1 & !is.na(PM$rg), ]
  sub$g_design <- as.numeric(sub$rg == "design"); sub$g_iv <- as.numeric(sub$rg == "iv"); sub$g_fe <- as.numeric(sub$rg == "fe")
  for (m in mods) sub[[m]][is.na(sub[[m]])] <- 0
  r <- clfit(as.formula(paste("effect_w ~ se_w + g_design + g_iv + g_fe +", paste(mods, collapse = "+"))), sub)
  p <- r$ct[, 1]; mbar <- sapply(mods, function(m) mean(sub[[m]])); basel <- p[["(Intercept)"]] + sum(p[mods] * mbar)
  pm$lr_ladder <- list(naive = basel, iv = basel + p[["g_iv"]], fe = basel + p[["g_fe"]], design = basel + p[["g_design"]]) }
R$robust_pureM <- pm
cat(sprintf("PureM n=%d k=%d | SR PET %.4f (se %.4f) | LR PET %.4f (se %.4f) | LR ladder IV %.3f FE %.3f naive %.3f\n",
            pm$n, pm$k, pm$SR$pet, pm$SR$pet_se, pm$LR$pet, pm$LR$pet_se, pm$lr_ladder$iv, pm$lr_ladder$fe, pm$lr_ladder$naive))

# ============================================================ 6b. TEX TABLES
# Main-text tables, written from this R port so the pipeline (not a hand-edit)
# sets their widths: the battery spans the full page, two-clocks is 30% wider,
# and the ladder keeps its natural width.
TAB <- file.path(BASE, "tables"); dir.create(TAB, showWarnings = FALSE, recursive = TRUE)
.cm <- function(x) formatC(x, format = "d", big.mark = ",")
.wa <- function(x) if (is.finite(x)) sprintf("$%.3f$", x) else "--"

# Table 2: short-run elasticity by identification tier (natural width)
{ r <- ladder$SR
  nm <- c(design = "Design-based (RCT/nat.~exp./DID)", iv = "Instrumented (IV/GMM)",
          fe = "Panel FE / structural", naive = "Naive")
  L <- c("\\begin{tabular}{lccccc}", "\\toprule",
         "Tier & $N$ & Studies & Unadjusted & Adjusted & 95\\% CI \\\\ \\midrule")
  for (g in c("design", "iv", "fe", "naive")) { x <- r[[g]]
    ci <- sprintf("[%.2f, %.2f]", x$adj - 1.96 * x$adj_se, x$adj + 1.96 * x$adj_se)
    L <- c(L, sprintf("%s & %s & %d & $%.3f$ & $%.3f$ & %s \\\\", nm[[g]], .cm(x$n), x$k, x$raw, x$adj, ci)) }
  writeLines(c(L, "\\bottomrule", "\\end{tabular}"), file.path(TAB, "tab_ladder.tex")) }

# Table 3: publication-bias battery by horizon and tier (FULL PAGE WIDTH)
{ L <- c("\\begin{tabular*}{\\textwidth}{@{\\extracolsep{\\fill}}lccccccc@{}}", "\\toprule",
         "Sample & $N$ & Studies & Mean & PW & PET & PEESE & WAAP \\\\ \\midrule")
  row <- function(name, x) sprintf("%s & %s & %d & $%.3f$ & $%.3f$ & $%.3f$ & $%.3f$ & %s \\\\",
                                   name, .cm(x$n), x$k, x$mean, x$pw, x$pet, x$peese, .wa(x$waap))
  hzlab <- c(LR = "Long-run elasticities (full sample)", IR = "Intermediate elasticities (full sample)",
             SR = "Short-run elasticities (full sample)")
  for (hz in c("LR", "IR", "SR")) L <- c(L, row(hzlab[[hz]], bat[[hz]]$all))
  L <- c(L, "\\addlinespace")
  glab <- c(design = "Short-run, design-based", iv = "Short-run, instrumented (IV)",
            fe = "Short-run, panel FE / structural", naive = "Short-run, naive")
  for (g in c("design", "iv", "fe", "naive")) if (!is.null(bat$SR[[g]])) L <- c(L, row(glab[[g]], bat$SR[[g]]))
  L <- c(L, row("Short-run, marginal price", bat$SR_marginal), row("Short-run, average price", bat$SR_average))
  if (!is.null(bat$SR_preferred)) L <- c(L, row("Short-run, preferred only", bat$SR_preferred))
  writeLines(c(L, "\\bottomrule", "\\end{tabular*}"), file.path(TAB, "tab_battery.tex")) }

# Table 5: two clocks -- trend per decade of data and of publication (30% WIDER)
{ L <- c("\\begin{tabular*}{0.95\\textwidth}{@{\\extracolsep{\\fill}}lcc@{}}", "\\toprule",
         " & Data clock & Publication clock \\\\", "\\midrule")
  specs <- list(c("data_only", "Data clock only"), c("two_clocks", "Two clocks"), c("full", "Two clocks + composition"), c("within", "\\hspace{0.5cm}$+$ country fixed effects"))
  hzs <- list(c("SR", "Short run"), c("IR", "Intermediate run"), c("LR", "Long run"))
  for (hi in seq_along(hzs)) { hz <- hzs[[hi]][1]
    L <- c(L, sprintf("\\multicolumn{3}{@{}l}{\\emph{%s}} \\\\", hzs[[hi]][2]))
    for (sp in specs) { x <- tc[[hz]][[sp[1]]]
      cells <- if (sp[1] == "data_only") c(sprintf("$%.3f$ ($%.3f$)", x$trend, x$se), "--")
               else c(sprintf("$%.3f$ ($%.3f$)", x$data, x$data_se), sprintf("$%.3f$ ($%.3f$)", x$pub, x$pub_se))
      L <- c(L, paste0(sp[2], " & ", paste(cells, collapse = " & "), " \\\\")) }
    if (hi < length(hzs)) L <- c(L, "\\addlinespace") }
  writeLines(c(L, "\\bottomrule", "\\end{tabular*}"), file.path(TAB, "tab_twoclocks.tex")) }
# Tables A2/A3: summary statistics by subsample (Appendix A), short run & long run
.summ <- function(sub) {
  n <- nrow(sub); if (n < 1) return(NULL)
  x <- sub$effect_w; w <- 1 / sub$se_w^2
  um <- mean(x); use <- if (n >= 2) sd(x) / sqrt(n) else NA_real_
  wm <- sum(w * x) / sum(w); wse <- sqrt(1 / sum(w))
  list(n = n, k = length(unique(sub$study_id)),
       um = um, ulo = um - 1.96 * use, uhi = um + 1.96 * use,
       wm = wm, wlo = wm - 1.96 * wse, whi = wm + 1.96 * wse)
}
summary_table <- function(S, file) {
  ind  <- function(col) { v <- S[[col]]; S[!is.na(v) & v == 1, ] }
  tier <- function(g)   S[!is.na(S$rg) & S$rg == g, ]
  ci   <- function(lo, hi) if (is.finite(lo)) sprintf("$[%.2f,\\,%.2f]$", lo, hi) else "--"
  rowf <- function(lab, sub) { z <- .summ(sub); if (is.null(z)) return(NULL)
    sprintf("%s & %s & %d & $%.2f$ & %s & $%.2f$ & %s \\\\",
            lab, .cm(z$n), z$k, z$um, ci(z$ulo, z$uhi), z$wm, ci(z$wlo, z$whi)) }
  hsp <- function(s) paste0("\\hspace{1em}", s)
  blk <- function(title, ...) { rows <- Filter(Negate(is.null), list(...))
    if (!length(rows)) return(character(0))
    c("\\addlinespace", sprintf("\\multicolumn{7}{@{}l}{\\emph{%s}} \\\\", title), unlist(rows)) }
  subcty <- S[rowSums(cbind(S$regional_data, S$city_data, S$disaggregated_data) == 1, na.rm = TRUE) > 0, ]
  L <- c("\\begin{tabular*}{\\textwidth}{@{\\extracolsep{\\fill}}l rr rc rc@{}}", "\\toprule",
         " & & & \\multicolumn{2}{c}{Unweighted} & \\multicolumn{2}{c}{Weighted} \\\\",
         "\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}",
         "Subsample & $N$ & Studies & Mean & 95\\% CI & Mean & 95\\% CI \\\\", "\\midrule",
         rowf("All estimates", S),
         blk("Identification tier",
             rowf(hsp("Design-based (tiers 1--3)"), tier("design")),
             rowf(hsp("Instrumented (IV)"),         tier("iv")),
             rowf(hsp("Panel FE / structural"),     tier("fe")),
             rowf(hsp("Naive"),                     tier("naive"))),
         blk("Demand sector",
             rowf(hsp("Residential"), ind("residential_demand")),
             rowf(hsp("Industrial"),  ind("industrial_demand")),
             rowf(hsp("Commercial"),  ind("commercial_demand"))),
         blk("Data structure",
             rowf(hsp("Time-series"),   ind("time_series_data")),
             rowf(hsp("Cross-section"), ind("cross_section_data")),
             rowf(hsp("Panel"),         ind("panel_data"))),
         blk("Price measurement",
             rowf(hsp("Average price"),  ind("average_price")),
             rowf(hsp("Marginal price"), ind("marginal_price"))),
         blk("Tariff regime",
             rowf(hsp("Time-of-use"),      ind("time_of_use_tariff")),
             rowf(hsp("Increasing-block"), ind("increasing_tariff")),
             rowf(hsp("Decreasing-block"), ind("decreasing_tariff"))),
         blk("Geographic aggregation",
             rowf(hsp("Country-level"), ind("country_data")),
             rowf(hsp("Sub-country level"), subcty)),
         blk("Region",
             rowf(hsp("United States"), ind("loc_usa")),
             rowf(hsp("Europe"),        ind("loc_europe")),
             rowf(hsp("Other"),         ind("loc_other"))))
  writeLines(c(L, "\\bottomrule", "\\end{tabular*}"), file.path(TAB, file))
}
summary_table(SR,                    "tab_summary_sr.tex")
summary_table(H[H$long_run == 1, ],  "tab_summary_lr.tex")

cat("TABLES OK (R) ->", TAB, "\n")

# ============================================================ 7. FIGURES
# Elegant, print-ready figures in a restrained blue/grey palette (Arial),
# matching the house style of the companion returns-to-schooling paper.
# Vector PDF (cairo, fonts embedded) + high-res PNG (ragg) for each exhibit.
FIG <- file.path(BASE, "figures"); dir.create(FIG, showWarnings = FALSE, recursive = TRUE)

FAM    <- "Arial"
BLUE   <- "#2F5F8F"   # primary steel blue  (points, lines, bars)
BLUE_D <- "#21496F"   # deep blue           (emphasis, outlines)
BLUE_L <- "#6E93B7"   # light steel blue    (secondary reference)
GREY   <- "#7D7D7D"   # medium grey         (secondary series)
GREY_D <- "#4D4D4D"   # dark grey           (body text)
GREY_M <- "#9AA0A6"   # mid grey            (zero / reference rules)
GRID   <- "#E7E9EC"   # hairline gridlines
AXIS   <- "#8A9099"   # axis lines & ticks
BAND   <- "#DCE4EC"   # pale blue shading

theme_paper <- function(base_size = 11) {
  theme_minimal(base_size = base_size, base_family = FAM) +
    theme(
      text             = element_text(colour = GREY_D),
      plot.background  = element_rect(fill = "white", colour = NA),
      panel.background = element_rect(fill = "white", colour = NA),
      panel.grid.minor = element_blank(),
      panel.grid.major = element_line(colour = GRID, linewidth = 0.35),
      axis.line        = element_line(colour = AXIS, linewidth = 0.35),
      axis.ticks       = element_line(colour = AXIS, linewidth = 0.35),
      axis.ticks.length= unit(3, "pt"),
      axis.text        = element_text(colour = GREY_D, size = rel(0.92)),
      axis.title       = element_text(colour = "#1A1A1A"),
      axis.title.x     = element_text(margin = margin(t = 7)),
      axis.title.y     = element_text(margin = margin(r = 7)),
      plot.title       = element_text(colour = "#1A1A1A", size = rel(1.02), margin = margin(b = 6)),
      legend.position  = "top",
      legend.title     = element_blank(),
      legend.text      = element_text(colour = "#1A1A1A", size = rel(0.90)),
      legend.key       = element_blank(),
      legend.margin    = margin(1, 1, 1, 1),
      plot.margin      = margin(10, 14, 8, 10)
    )
}
save_fig <- function(p, name, w, h) {
  try(ggsave(file.path(FIG, paste0(name, ".pdf")), p, width = w, height = h, device = cairo_pdf), silent = FALSE)
  try(ggsave(file.path(FIG, paste0(name, ".png")), p, width = w, height = h, dpi = 320,
             device = ragg::agg_png, background = "white"), silent = FALSE)
}

# --- F1: the corpus -- estimates over data years, shaded by identification rung
lev1 <- c("naive", "fe", "iv", "design")
lab1 <- c(naive  = "Naive",
          fe     = "Panel FE / structural",
          iv     = "IV / GMM",
          design = "Design-based (RCT / nat. exp. / DID)")
pal1 <- c(naive = "#C4CCD3", fe = "#93A3B0", iv = "#5B7E9E", design = BLUE)
bb   <- b[!is.na(b$midyear) & !is.na(b$rg), ]
bb   <- bb[order(match(bb$rg, lev1)), ]                    # design drawn last (on top)
bb$rgf <- factor(bb$rg, levels = lev1, labels = lab1[lev1])
f1 <- ggplot(bb, aes(midyear, effect, colour = rgf)) +   # raw effect; outliers clipped by coord_cartesian below (not winsorized)
  geom_hline(yintercept = 0, linetype = "dotted", colour = GREY_M, linewidth = 0.35) +
  geom_point(size = 0.85, alpha = 0.42, stroke = 0) +
  geom_point(data = bb[bb$rg == "design", ], size = 1.5, alpha = 0.95, stroke = 0) +
  scale_colour_manual(values = setNames(unname(pal1[lev1]), lab1[lev1])) +
  scale_x_continuous(breaks = seq(1940, 2020, 20)) +
  coord_cartesian(ylim = c(-2.5, 1)) +
  guides(colour = guide_legend(override.aes = list(alpha = 1, size = 2.5), nrow = 1)) +
  labs(x = "Mid-year of data used", y = "Reported price elasticity") +
  theme_paper() +
  theme(panel.grid.major.x = element_blank(),
        legend.position = "inside",
        legend.position.inside = c(0.5, 0.02),
        legend.justification = c(0.5, 0),
        legend.direction = "horizontal",
        legend.background = element_rect(fill = alpha("white", 0.65), colour = NA),
        legend.margin = margin(2, 4, 2, 4))
save_fig(f1, "fig1_corpus", 8.2, 4.3)

# --- F2: within-study rung contrasts (cleaner minus dirtier design)
ws2 <- ws[order(ws$contrast), ]
.tiernm <- function(r) ifelse(r <= 3, "design-based", ifelse(r == 4, "instrumented", ifelse(r == 5, "structural", "naive")))
ws2$lab <- sprintf("%s  (%s vs. %s)", ws2$study, .tiernm(ws2$clean_rung), .tiernm(ws2$dirty_rung))
ws2$y   <- seq_len(nrow(ws2))
mc <- mean(ws$contrast)
f2 <- ggplot(ws2, aes(contrast, y)) +
  geom_vline(xintercept = 0,  linetype = "dotted", colour = GREY_M, linewidth = 0.4) +
  geom_vline(xintercept = mc, colour = BLUE, linewidth = 0.8) +
  geom_point(shape = 21, fill = "white", colour = BLUE_D, size = 2, stroke = 0.7) +
  annotate("text", x = mc - 0.04, y = nrow(ws2), label = sprintf("mean %+.2f", mc),
           colour = BLUE, size = 3, hjust = 1, vjust = 0.5, family = FAM) +
  scale_y_continuous(breaks = ws2$y, labels = ws2$lab,
                     expand = expansion(add = c(0.6, 0.5))) +
  labs(x = "Within-study contrast: cleaner-tier minus dirtier-tier elasticity", y = NULL) +
  theme_paper() +
  theme(panel.grid.major.y = element_blank(),
        axis.text.y = element_text(size = rel(0.95)))
save_fig(f2, "fig2_withinstudy", 7.2, max(3.4, 0.30 * nrow(ws2)))

# --- F3: the adjusted ladder (money figure) -- SR elasticity by rung, 95% CI
lev3 <- c("naive", "fe", "iv", "design")
lab3 <- c(naive  = "Naive",
          fe     = "Panel FE / structural",
          iv     = "Instrumented (IV / GMM)",
          design = "Design-based (RCT / nat. exp. / DID)")
LS <- ladder$SR
d3 <- data.frame(g   = lev3,
                 est = sapply(lev3, function(g) LS[[g]]$adj),
                 se  = sapply(lev3, function(g) LS[[g]]$adj_se),
                 n   = sapply(lev3, function(g) LS[[g]]$n))
d3$y <- factor(lab3[d3$g], levels = lab3[c("design", "iv", "fe", "naive")])  # naive on top
f3 <- ggplot(d3, aes(est, y)) +
  geom_vline(xintercept = 0, linetype = "dotted", colour = GREY_M, linewidth = 0.4) +
  geom_segment(aes(x = est - 1.96 * se, xend = est + 1.96 * se, y = y, yend = y),
               colour = BLUE, linewidth = 1.0, lineend = "round") +
  geom_point(size = 3.2, colour = BLUE) +
  geom_text(aes(label = sprintf("%.3f  (n = %s)", est, formatC(n, big.mark = ",", format = "d"))),
            vjust = -1.2, size = 2.95, colour = GREY_D, family = FAM) +
  scale_x_continuous(expand = expansion(mult = c(0.10, 0.10))) +
  labs(x = "Adjusted short-run elasticity  (SE = 0, moderators at means; 95% CI)", y = NULL) +
  theme_paper() +
  theme(panel.grid.major.y = element_blank())
save_fig(f3, "fig3_ladder", 7.4, 2.6)

# --- F4: the adjustment path -- elasticity by horizon, with Deryugina benchmark
sers <- c("Literature, bias-corrected (SR / IR / LR)",
          "Deryugina et al. (2020) within-study path")
d4  <- data.frame(x = c(1, 3.5, 10),
                  pet = c(path$SR$pet, path$IR$pet, path$LR$pet),
                  se  = c(path$SR$pet_se, path$IR$pet_se, path$LR$pet_se),
                  series = sers[1])
d4d <- data.frame(x = c(0.5, 2), pet = c(-0.09, -0.27), series = sers[2])
d4$series  <- factor(d4$series,  levels = sers)   # keep literature first in the legend
d4d$series <- factor(d4d$series, levels = sers)
f4 <- ggplot() +
  geom_hline(yintercept = 0, linetype = "dotted", colour = GREY_M, linewidth = 0.35) +
  geom_segment(data = d4, aes(x = x, xend = x, y = pet - 1.96 * se, yend = pet + 1.96 * se),
               colour = BLUE, linewidth = 0.7) +
  geom_line(data = d4d, aes(x, pet, colour = series, linetype = series), linewidth = 0.9) +
  geom_line(data = d4,  aes(x, pet, colour = series, linetype = series), linewidth = 0.9) +
  geom_point(data = d4d, aes(x, pet, colour = series, shape = series), size = 2.7) +
  geom_point(data = d4,  aes(x, pet, colour = series, shape = series), size = 2.9) +
  scale_colour_manual(values = setNames(c(BLUE, GREY), sers), limits = sers) +
  scale_shape_manual(values  = setNames(c(16, 15), sers), limits = sers) +
  scale_linetype_manual(values = setNames(c("solid", "dashed"), sers), limits = sers) +
  scale_x_log10(breaks = c(0.5, 1, 2, 3.5, 10), labels = c("6m", "1y", "2y", "2–5y", "10y+")) +
  guides(colour = guide_legend(nrow = 2)) +
  labs(x = "Adjustment horizon", y = "Price elasticity") +
  theme_paper() +
  theme(legend.position = "inside",
        legend.position.inside = c(0.98, 0.98),
        legend.justification = c(1, 1),
        legend.background = element_rect(fill = alpha("white", 0.7), colour = NA),
        legend.margin = margin(2, 5, 2, 5))
save_fig(f4, "fig4_horizon", 6.8, 3.9)

# --- Appendix fig: the adjustment path as a continuous illustrative curve.
# A textbook partial-adjustment path pinned to the corrected SR (-0.16 at t=1yr) and LR (-0.38)
# anchors; the median dynamic-model speed (Dahl 2011) and the Deryugina et al. (2020) natural
# experiment are overlaid, NOT fitted. Uses only reported numbers, not the dataset.
RUST   <- "#9A3B32"
mi_eLR <- -0.38                        # corrected long-run asymptote
mi_lam <- -log(1 - 0.16 / 0.38)        # speed set so the path reaches -0.16 at one year
mi_t     <- seq(0, 8, length.out = 400)
mi_curve <- data.frame(t = mi_t, e = mi_eLR * (1 - exp(-mi_lam * mi_t)))
mi_half  <- log(2) / mi_lam
mi_sr    <- data.frame(t = 1, e = -0.16)
mi_der   <- data.frame(t = c(0.5, 2.0), e = c(-0.09, -0.27))   # Deryugina et al. (2020)
fmi <- ggplot() +
  geom_hline(yintercept = 0,      linetype = "dotted", colour = GREY_M, linewidth = 0.35) +
  geom_hline(yintercept = mi_eLR, linetype = "dashed", colour = BLUE,   linewidth = 0.35) +
  annotate("text", x = 8, y = mi_eLR + 0.013, label = "corpus long run  −0.38",
           hjust = 1, vjust = 0, size = 3.1, colour = BLUE, family = FAM) +
  geom_line(data = mi_curve, aes(t, e), colour = BLUE, linewidth = 0.9) +
  annotate("segment", x = mi_half, xend = mi_half, y = 0,
           yend = mi_eLR * (1 - exp(-mi_lam * mi_half)),
           colour = GREY_M, linewidth = 0.3, linetype = "dotted") +
  annotate("text", x = mi_half + 0.1, y = -0.005,
           label = paste0("half the long-run response in ≈", sprintf("%.1f", mi_half),
                          " yr\n(Dahl 2011 median: ~1.5 yr)"),
           hjust = 0, vjust = 1, size = 2.9, colour = GREY_D, family = FAM, lineheight = 0.95) +
  geom_line(data = mi_der, aes(t, e), colour = RUST, linewidth = 0.5, linetype = "dashed") +
  geom_point(data = mi_der, aes(t, e), colour = RUST, fill = "white", shape = 21,
             size = 2.3, stroke = 0.9) +
  annotate("text", x = 2.15, y = -0.275, label = "Deryugina et al. (2020),\nsingle natural experiment",
           hjust = 0, vjust = 1, size = 3.0, colour = RUST, family = FAM, lineheight = 0.95) +
  geom_point(data = mi_sr, aes(t, e), colour = BLUE, size = 2.6) +
  annotate("text", x = 1.13, y = -0.16, label = "corpus short run  −0.16",
           hjust = 0, vjust = -0.6, size = 3.1, colour = BLUE, family = FAM) +
  scale_x_continuous(breaks = seq(0, 8, 2), expand = expansion(mult = c(0.012, 0.02))) +
  scale_y_continuous(breaks = seq(0, -0.4, -0.1)) +
  coord_cartesian(xlim = c(0, 8), ylim = c(-0.42, 0.035)) +
  labs(x = "Time to adjust (years)", y = "Own-price elasticity",
       subtitle = "Illustrative partial-adjustment path pinned to the corpus short- and long-run anchors; external speeds overlaid, not fitted") +
  theme_paper() +
  theme(plot.subtitle = element_text(colour = GREY_D, size = rel(0.80), margin = margin(b = 8)))
save_fig(fmi, "metairf_illustrative", 7.6, 3.6)

# --- F5: bias-corrected elasticity by decade of data (short & long run)
toDF <- function(lst) do.call(rbind, lapply(lst, function(r)
  data.frame(era = r$era, pet = r$pet, se = r$pet_se, n = r$n)))
d5 <- rbind(cbind(toDF(dec$SR), panel = "Short run"),
            cbind(toDF(dec$LR), panel = "Long run"))
d5$era   <- factor(d5$era, levels = c("<1970","1970s","1980s","1990s","<2000","2000s","2010s+"))
d5$panel <- factor(d5$panel, levels = c("Short run", "Long run"))
f5 <- ggplot(d5, aes(era, pet)) +
  geom_hline(yintercept = 0, linetype = "dotted", colour = GREY_M, linewidth = 0.35) +
  geom_segment(aes(x = era, xend = era, y = pet - 1.96 * se, yend = pet + 1.96 * se),
               colour = BLUE, linewidth = 0.7) +
  geom_point(colour = BLUE, size = 2.7) +
  facet_wrap(~panel, scales = "free_x", axes = "all_y") +
  labs(x = "Mid-year of data (decade bin)", y = "Bias-corrected elasticity") +
  theme_paper() +
  theme(panel.grid.major.x = element_blank(),
        panel.spacing = unit(18, "pt"),
        strip.text = element_text(colour = "#1A1A1A", size = rel(1.0), margin = margin(b = 5)))
save_fig(f5, "fig5_decades", 8, 3.4)

# --- F6: the new-regime check -- technology-rich cells are the least elastic
lev6 <- c("full", "post2005", "tou", "experiments", "marginal")
lab6 <- c(full = "Full SR sample", post2005 = "Data 2005 +", tou = "TOU-tagged",
          experiments = "Experiments", marginal = "Marginal price")
d6 <- data.frame(k   = lev6,
                 est = sapply(lev6, function(k) newreg[[k]]$pet),
                 se  = sapply(lev6, function(k) newreg[[k]]$pet_se))
d6$y <- factor(lab6[d6$k], levels = rev(lab6[lev6]))       # full sample on top
band <- data.frame(xmin = -0.10, xmax = -0.02, lab = "Faruqui–Sergici pilot range")
refl <- data.frame(x = -0.075, lab = "Kahn–Lang et al. pilot mean")
f6 <- ggplot(d6, aes(est, y)) +
  geom_rect(data = band, inherit.aes = FALSE,
            aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf, fill = lab), alpha = 0.6) +
  geom_vline(data = refl, aes(xintercept = x, colour = lab), linetype = "dashed", linewidth = 0.7) +
  geom_vline(xintercept = 0, linetype = "dotted", colour = GREY_M, linewidth = 0.4) +
  geom_segment(aes(x = est - 1.96 * se, xend = est + 1.96 * se, y = y, yend = y),
               colour = BLUE, linewidth = 1.0, lineend = "round") +
  geom_point(size = 3.1, colour = BLUE) +
  scale_fill_manual(values  = setNames(BAND,  band$lab)) +
  scale_colour_manual(values = setNames(BLUE_L, refl$lab)) +
  annotate("text", x = -0.075, y = Inf, vjust = 1.4, hjust = 1.12,
           label = "-0.075", colour = BLUE_D, size = 2.8, family = FAM) +
  labs(x = "Bias-corrected short-run elasticity  (95% CI)", y = NULL) +
  theme_paper() +
  theme(panel.grid.major.y = element_blank(),
        legend.position = "bottom", legend.justification = "left")
save_fig(f6, "fig6_newregime", 6.9, 2.7)

# --- Appendix A: distribution of the estimates (short run & long run); RAW values, axes trimmed
XLO_D <- -2.5; XHI_D <- 1                        # viewing window; outliers trimmed from view only, kept in the mean
distdf <- rbind(
  data.frame(e = SR$effect_M,                   panel = "Short-run estimates"),
  data.frame(e = H[H$long_run == 1, ]$effect_M, panel = "Long-run estimates"))
distdf$panel <- factor(distdf$panel, levels = c("Short-run estimates", "Long-run estimates"))
distm <- do.call(rbind, lapply(levels(distdf$panel), function(p)
  data.frame(panel = factor(p, levels = levels(distdf$panel)),
             m = mean(distdf$e[distdf$panel == p]))))          # simple mean over ALL raw estimates
distvis <- distdf[distdf$e >= XLO_D & distdf$e <= XHI_D, ]     # histogram computed over the window only
fdist <- ggplot(distvis, aes(e)) +
  geom_histogram(bins = 45, fill = "#C7D2DD", colour = "white", linewidth = 0.15) +
  geom_vline(data = distm, aes(xintercept = m), colour = BLUE, linewidth = 0.8) +
  geom_text(data = distm, aes(x = m, y = Inf, label = sprintf("mean %.2f", m)),
            colour = BLUE, hjust = 1.12, vjust = 1.7, size = 3, family = FAM) +
  facet_wrap(~ panel, scales = "free_y") +
  coord_cartesian(xlim = c(XLO_D, XHI_D)) +
  labs(x = "Own-price elasticity of electricity demand", y = "Frequency") +
  theme_paper() +
  theme(panel.grid.major.x = element_blank(),
        panel.spacing = unit(16, "pt"),
        strip.text = element_text(colour = "#1A1A1A", size = rel(1.0), margin = margin(b = 5)))
save_fig(fdist, "fig_dist_estimates", 8, 3.2)

cat("FIGURES OK (R) -> ", FIG, "\n")

# ---- write a plain-text results summary (one "result = value" per line) ----
.fmt_leaf <- function(v) paste(format(v, trim = TRUE, digits = 6, scientific = FALSE), collapse = ", ")
flatten_results <- function(x, prefix = "") {
  if (is.data.frame(x) || is.matrix(x)) {
    rn <- rownames(x); if (is.null(rn)) rn <- as.character(seq_len(nrow(x)))
    cn <- colnames(x); if (is.null(cn)) cn <- as.character(seq_len(ncol(x)))
    o <- character(0)
    for (i in seq_len(nrow(x))) for (j in seq_len(ncol(x)))
      o <- c(o, sprintf("%s.%s.%s = %s", prefix, rn[i], cn[j], .fmt_leaf(x[i, j])))
    o
  } else if (is.list(x)) {
    nms <- names(x); if (is.null(nms)) nms <- as.character(seq_along(x))
    unlist(lapply(seq_along(x), function(k)
      flatten_results(x[[k]], if (prefix == "") nms[k] else paste0(prefix, ".", nms[k]))))
  } else sprintf("%s = %s", prefix, .fmt_leaf(x))
}
writeLines(c(
  "HEADLINE RESULTS - electricity price-elasticity meta-analysis",
  "Auto-generated by electricity.R from electricity.xlsx. One 'result = value' per line;",
  "the dotted names show where each number sits (e.g. counts.head, ladder.SR.design.pet).",
  "For context see the paper (electricity.pdf); this file is not needed to compile it.",
  paste(rep("-", 80), collapse = ""), "",
  flatten_results(R)),
  file.path(BASE, "results_headline.txt"))
cat("PIPELINE OK (R)\n")
cat(sprintf("SR PET %.4f | LR PET %.4f | trend(full) %+.4f (p=%.3f) | TOU %+.4f (p=%.5f) | bound share %.3f\n",
            path$SR$pet, path$LR$pet, tr$data, tr$data_p, R$tou$coef, R$tou$p, R$bound$share))


# ######################################################################
# PART 2 of 4 - PUBLICATION-BIAS FULL BATTERY (App. 'the full battery'; funnel figure)
# (verbatim from pubbias.R)
# ######################################################################

# =====================================================================
# pubbias.R  --  "Publication bias: the full battery" appendix for the
# electricity meta-analysis (returns-paper Appendix D style).
#
# Produces, all from the frozen electricity.xlsx (sheet "data"):
#   * a two-panel funnel plot (short run | long run), RAW (non-winsorized)
#     estimates, each panel marking the 1%-winsorized simple mean
#       figures/fig_funnels.pdf (+png)
#   * four two-part publication-bias battery tables, each part = Panel A
#     (linear FAT-PET: OLS/FE/RE/Study/Precision), Panel B (nonlinear:
#     PEESE/WAAP/Top 10%/STEM), Panel C (robust: MAIVE / p-uniform*):
#       tables/tab_pb_horizon.tex  (Part 1 short run  | Part 2 long run)
#       tables/tab_pb_tier1.tex    (Part 1 Naive      | Part 2 Panel FE / structural)
#       tables/tab_pb_tier2.tex    (Part 1 IV/GMM     | Part 2 Design-based)
#       tables/tab_pb_price.tex    (Part 1 TOU-tagged | Part 2 Marginal price)
#
# Estimators ported from the returns-paper lab template (methods.R; STEM is
# Furukawa's, verbatim). Battery uses the 1%-winsorized effect and SE, as
# throughout the paper. The funnel plot uses raw (un-winsorized) values.
# =====================================================================
suppressPackageStartupMessages({
  library(readxl); library(sandwich); library(lmtest); library(metafor)
  library(ggplot2); library(patchwork)
})
ok_aer  <- requireNamespace("AER", quietly = TRUE)
ok_puni <- requireNamespace("puniform", quietly = TRUE)
ok_ph   <- requireNamespace("phacking", quietly = TRUE)   # RTMA (Mathur & VanderWeele)

BASE <- .find_base(); setwd(BASE)
TAB  <- file.path(BASE, "tables");  dir.create(TAB, showWarnings = FALSE)
FIG  <- file.path(BASE, "figures"); dir.create(FIG, showWarnings = FALSE)
num  <- function(x) suppressWarnings(as.numeric(as.character(x)))

# ------------------------------------------------------------------ load + samples
d <- as.data.frame(read_excel(file.path(BASE, "electricity.xlsx"), sheet = "data"))
d <- d[is.finite(num(d$effect)), ]
d$effect <- num(d$effect); d$se <- num(d$se); d$n_obs <- num(d$n_obs)
wins <- function(x, p = 0.01) { q <- quantile(x, c(p, 1 - p), na.rm = TRUE); pmin(pmax(x, q[1]), q[2]) }
b <- d[is.finite(d$se) & d$se > 0, ]
b$effect_w <- wins(b$effect); b$se_w <- wins(b$se)
# BASELINE headline = enlarged Marshallian-equivalent pool: native-M + Slutsky-converted Hicksian
# (effect_M precomputed in the xlsx: per-estimate own eta, s=0.04, no imputation); real SE only (drop Cao imputed).
H <- b[num(b$in_M_pool) == 1 & num(b$formula) == 1 & is.finite(num(b$effect_M)) &
       b$se_source != "imputed_uniform_t" & !is.na(b$formula), ]
H$effect_w <- wins(num(H$effect_M))
rg <- function(r) ifelse(is.na(r), NA, ifelse(r <= 3, "design", ifelse(r == 4, "iv", ifelse(r == 5, "fe", "naive"))))
H$rg <- rg(H$rung)
SR <- H[num(H$short_run) == 1 & !is.na(H$short_run), ]
LR <- H[num(H$long_run)  == 1 & !is.na(H$long_run), ]
onef <- function(s, col) s[num(s[[col]]) == 1 & !is.na(s[[col]]), ]

# ================================================================== ESTIMATORS
# ---- STEM (Furukawa), ported verbatim from the lab template -----------------
variance_b <- function(se, sigma) { N <- length(se); Y <- numeric(N); pw <- 1/(se^2 + sigma^2)
  for (i in 1:N) Y[i] <- 1/sum(pw[1:i]); Y }
variance_0 <- function(n_stem, beta, se, beta_mean) {
  w <- 1/(se[1:n_stem]^2); tw <- sum(w)
  Y1 <- (t(w) %*% (beta[1:n_stem] - beta_mean)^2) - (n_stem - 1)
  Y2 <- tw - (t(w) %*% w)/tw; pmax(0, Y1/Y2) }
weighted_mean <- function(beta, se, sigma) { N <- length(beta); Y <- numeric(N); pw <- 1/(se^2 + sigma^2)
  for (i in 1:N) Y[i] <- beta[1:i] %*% pw[1:i] / sum(pw[1:i]); Y }
weighted_mean_squared <- function(beta, se, sigma) { N <- length(beta); Y <- numeric(N)
  w <- 1/(se^2 + sigma^2); wb <- w * beta; W <- w %o% w; WB <- wb %o% wb
  for (i in 2:N) { Y1 <- sum(WB[1:i,1:i]) - sum(wb[1:i]^2); Y2 <- sum(W[1:i,1:i]) - sum(w[1:i]^2); Y[i] <- Y1/Y2 }; Y }
stem_compute <- function(beta, se, sigma0) { N <- length(beta)
  Eb_all <- weighted_mean(beta, se, sigma0); Eb_lto <- weighted_mean(beta[2:N], se[2:N], sigma0)
  Eb_sq <- weighted_mean_squared(beta[2:N], se[2:N], sigma0); MSE_orig <- Eb_sq - 2*beta[1]*Eb_lto
  Var_all <- variance_b(se, sigma0); n_min <- 3; MSE <- MSE_orig[(n_min-1):(N-1)]
  Bias <- MSE - Var_all[n_min:N]; n_stem <- which.min(MSE) + (n_min-1)
  beta_stem <- Eb_all[n_stem]; se_stem <- Var_all[n_stem]^0.5; sigma_stem <- sqrt(variance_0(N, beta, se, beta_stem))
  list(estimates = cbind(beta_stem, se_stem, sigma_stem, n_stem), MSE = rbind(MSE, Var_all[n_min:N], Bias[(n_min-1):(N-1)])) }
stem_converge <- function(initial_sigma, beta_sorted, se_sorted, param) {
  cnt <- 0; tol <- param[1]; maxc <- param[2]; sigma0 <- initial_sigma
  repeat { out <- stem_compute(beta_sorted, se_sorted, sigma0); sigma <- out$estimates[3]; cnt <- cnt + 1
    if (abs(sigma0 - sigma) < tol || cnt > maxc) break; sigma0 <- sigma }
  list(estimates = c(out$estimates, cnt), MSE = out$MSE) }
stem <- function(beta, se, param = c(1e-4, 1e3)) { N <- length(beta)
  max_sigma <- sqrt(variance_0(N, beta, se, mean(beta)))
  dd <- cbind(beta, se); dd <- dd[order(dd[,2]), ]; bs <- dd[,1]; ss <- dd[,2]
  omax <- stem_converge(max_sigma, bs, ss, param); Y <- omax$estimates
  list(estimate = Y[1], se = Y[2], n_stem = Y[4]) }

# ---- Linear FAT-PET family (OLS/FE/RE/Study/Precision) ----------------------
.coef_row <- function(m, n) { b <- coef(m); v <- sqrt(diag(vcov(m)))
  list(pet = b[1], pet_se = v[1], fat = b[2], fat_se = v[2], n = n) }
# two-way (study x database) clustered covariance; blank database ids fall back to a
# per-study proxy so the second clustering dimension never introduces NA clusters.
.twoway <- function(m, sid, dbid) {
  db <- as.character(dbid); miss <- is.na(db) | db == ""; db[miss] <- paste0("s", sid[miss])
  tryCatch(sandwich::vcovCL(m, cluster = data.frame(study = factor(sid), db = factor(db)), type = "HC1"),
           error = function(z) tryCatch(sandwich::vcovCL(m, cluster = factor(sid), type = "HC1"), error = function(z2) vcov(m)))
}
fat_pet_battery <- function(effect, se, sid, dbid) {
  k <- !is.na(effect) & !is.na(se) & se > 0; e <- effect[k]; s <- se[k]; sid <- sid[k]; dbid <- dbid[k]; n <- sum(k)
  out <- list()
  out$OLS <- .coef_row(lm(e ~ s), n)
  out$FE  <- .coef_row(lm(e ~ s, weights = 1/s^2), n)
  out$RE  <- tryCatch({ fit <- metafor::rma(yi = e, sei = s, mods = ~ s, method = "DL")
    list(pet = fit$b[1], pet_se = fit$se[1], fat = fit$b[2], fat_se = fit$se[2], n = n) },
    error = function(err) out$FE)
  ag <- aggregate(cbind(e, s) ~ sid, FUN = median)
  out$Study <- .coef_row(lm(e ~ s, data = ag), nrow(ag))
  out$Precision <- .coef_row(lm(e ~ s, weights = 1/s), n)
  # two-way (study x database) clustered SEs for OLS/FE/Precision (RE keeps metafor's, Study already study-level)
  df <- data.frame(e = e, s = s, sid = sid, dbid = dbid)
  for (sc in c("OLS", "FE", "Precision")) {
    w <- switch(sc, OLS = NULL, FE = 1/s^2, Precision = 1/s)
    m <- if (is.null(w)) lm(e ~ s, data = df) else lm(e ~ s, data = df, weights = w)
    V <- .twoway(m, df$sid, df$dbid)
    sev <- sqrt(diag(V)); out[[sc]]$pet_se <- sev[1]; out[[sc]]$fat_se <- sev[2]
  }
  out
}
# PEESE / WAAP / Top-10% match the main-text battery's definitions in
# electricity.R so the appendix agrees with the body: PEESE is the intercept of the
# UNWEIGHTED quadratic (study-clustered SE); WAAP uses the OLS-PET benchmark; Top-10%
# is the precision-weighted mean of the count-based most-precise decile.
pb_peese <- function(effect, se, sid, dbid) { k <- !is.na(effect) & !is.na(se) & se > 0
  e <- effect[k]; s <- se[k]; sid <- sid[k]; dbid <- dbid[k]
  m <- lm(e ~ I(s^2)); V <- .twoway(m, sid, dbid)
  list(est = coef(m)[1], se = sqrt(diag(V))[1], n = sum(k)) }
pb_waap <- function(effect, se) { k <- !is.na(effect) & !is.na(se) & se > 0; e <- effect[k]; s <- se[k]
  pet <- abs(coef(lm(e ~ s))[1]); adq <- s <= pet/2.8
  if (sum(adq) < 5) return(list(est = NA, se = NA, n_adequate = sum(adq)))
  ea <- e[adq]; sa <- s[adq]; w <- 1/sa^2; est <- sum(ea*w)/sum(w)
  list(est = est, se = sqrt(1/sum(w)), n_adequate = sum(adq)) }
pb_top10 <- function(effect, se) { k <- !is.na(effect) & !is.na(se) & se > 0; e <- effect[k]; s <- se[k]
  o <- order(s); m <- max(floor(length(s) * 0.1), 5); sel <- o[1:m]
  w <- 1/s[sel]^2; list(est = sum(e[sel]*w)/sum(w), se = sqrt(1/sum(w)), n_top = m) }

# ---- MAIVE (PEESE variant: variance instrumented by inverse sample size) -----
maive_one <- function(s) {
  o <- list(est = NA, se = NA, F = NA, n = NA)
  sm <- s[is.finite(s$n_obs) & s$n_obs > 0, ]; if (nrow(sm) < 10) return(o)
  cap <- quantile(sm$se_w, 0.99, na.rm = TRUE); sm <- sm[sm$se_w <= cap, ]
  sm$var <- sm$se_w^2; sm$inv_n <- 1/sm$n_obs; n_mv <- nrow(sm)
  if (ok_aer) return(tryCatch({
    m  <- AER::ivreg(effect_w ~ var | inv_n, data = sm)
    s2 <- summary(m, vcov = sandwich::sandwich, diagnostics = TRUE); cf <- s2$coefficients
    Fs <- tryCatch(s2$diagnostics["Weak instruments", "statistic"], error = function(z) NA)
    list(est = cf[1,1], se = cf[1,2], F = Fs, n = n_mv) }, error = function(z) o))
  # manual 2SLS fallback (point estimate + first-stage F)
  tryCatch({ fs <- lm(var ~ inv_n, data = sm); vhat <- fitted(fs)
    Fs <- summary(fs)$fstatistic[1]; ss <- lm(sm$effect_w ~ vhat)
    list(est = coef(ss)[1], se = sqrt(diag(vcov(ss)))[1], F = Fs, n = n_mv) }, error = function(z) o)
}
# ---- p-uniform* (van Aert) on study medians ---------------------------------
puni_one <- function(ag) {
  o <- list(est = NA, se = NA)
  if (!ok_puni || nrow(ag) < 4) return(o)
  tryCatch({ pu <- puniform::puni_star(yi = ag$e, vi = ag$s^2, side = "left")   # negative elasticities
    list(est = pu$est, se = (pu$ci.ub - pu$ci.lb)/(2*1.96)) }, error = function(z) o)
}
# ---- EK: Bom & Rachinger (2019) endogenous-kink meta-regression --------------
# WLS regression of the effect on max(0, SE - a1); the kink point a1 = |b0|/1.96 is
# iterated to convergence. b0 (intercept) is the effect beyond bias; the slope is the
# selection term. Study-clustered SEs. Works on the signed effect (negative elasticities).
pb_ek <- function(effect, se, sid, dbid) {
  k <- !is.na(effect) & !is.na(se) & se > 0; e <- effect[k]; s <- se[k]; sid <- sid[k]; dbid <- dbid[k]
  b0 <- weighted.mean(e, 1/s^2); x <- pmax(0, s - abs(b0)/1.959964)
  for (it in 1:200) { x <- pmax(0, s - abs(b0)/1.959964)
    b0n <- unname(coef(lm(e ~ x, weights = 1/s^2))[1])
    if (!is.finite(b0n) || abs(b0n - b0) < 1e-9) { b0 <- b0n; break }; b0 <- b0n }
  df <- data.frame(e = e, x = x, sid = sid, dbid = dbid); m <- lm(e ~ x, data = df, weights = 1/s^2)
  V <- .twoway(m, df$sid, df$dbid)
  sev <- sqrt(diag(V))
  list(pet = coef(m)[1], pet_se = sev[1], fat = coef(m)[2], fat_se = sev[2], n = sum(k))
}
# ---- Selection model: metafor step-function (Vevea-Hedges) selection model ---
# One-sided step at p=0.025 (favouring significant negative estimates). This is the
# available selection-model correction (the exact Andrews-Kasy needs the GitHub-only
# `metastudies` package, absent here).
pb_selmodel <- function(effect, se) {
  k <- !is.na(effect) & !is.na(se) & se > 0; e <- effect[k]; s <- se[k]
  tryCatch({ res <- metafor::rma(yi = e, sei = s, method = "ML")
    sm <- metafor::selmodel(res, type = "stepfun", alternative = "less", steps = 0.025)
    list(est = unname(sm$beta[1]), se = unname(sm$se[1])) },
    error = function(z) list(est = NA, se = NA))
}
# ---- RTMA: Mathur & VanderWeele right-truncated MA via phacking (study medians)
# Suppressed when unidentified: over-corrects past the naive mean or MCMC does not
# converge. In this literature the affirmative (significant, correctly-signed) share is
# high, so RTMA is not identified (it over-corrects upward, e.g. to +0.26 short run).
pb_rtma <- function(ag, naive_mean) {
  if (!ok_ph || nrow(ag) < 15) return(list(est = NA, unstable = TRUE))
  tryCatch({
    invisible(utils::capture.output(suppressWarnings(suppressMessages(
      fit <- phacking::phacking_meta(yi = ag$e, vi = ag$s^2, favor_positive = FALSE, parallelize = FALSE)))))
    mu <- fit$stats[fit$stats$param == "mu", ]
    est <- as.numeric(mu$median); rhat <- as.numeric(mu$r_hat)
    list(est = est, unstable = !is.finite(est) || !is.finite(rhat) || rhat > 1.05 || est > naive_mean)
  }, error = function(z) list(est = NA, unstable = TRUE))
}

# ================================================================== BATTERY
battery_full <- function(s) {
  e <- s$effect_w; v <- s$se_w; sid <- s$study_id; dbid <- s$iddatabase
  ag <- aggregate(cbind(e, s = v) ~ sid, FUN = median)
  o <- list(n = nrow(s), n_stud = nrow(ag))
  o$lin  <- fat_pet_battery(e, v, sid, dbid)
  o$peese <- tryCatch(pb_peese(e, v, sid, dbid), error = function(z) list(est = NA, se = NA, n = NA))
  o$waap  <- tryCatch(pb_waap(e, v),  error = function(z) list(est = NA, se = NA, n_adequate = NA))
  o$top10 <- tryCatch(pb_top10(e, v), error = function(z) list(est = NA, se = NA, n_top = NA))
  o$stem  <- tryCatch({ x <- stem(ag$e, ag$s); list(est = x$estimate, se = x$se) },
                      error = function(z) list(est = NA, se = NA))
  o$maive <- maive_one(s)
  # MAIVE is only credibly identified with an adequate first stage; suppress the
  # point estimate (keep the F) when the inverse-sample-size instrument is weak.
  if (!is.finite(o$maive$F) || o$maive$F < 10) { o$maive$est <- NA; o$maive$se <- NA }
  o$puni  <- puni_one(ag)
  o$ek     <- tryCatch(pb_ek(e, v, sid, dbid), error = function(z) list(pet=NA, pet_se=NA, fat=NA, fat_se=NA, n=NA))
  o$selmod <- pb_selmodel(e, v)
  o
}

# ------------------------------------------------------------------ formatting
p3  <- function(x) ifelse(is.na(x) | !is.finite(x), "", formatC(x, format = "f", digits = 3))
se3 <- function(x) ifelse(is.na(x) | !is.finite(x), "", sprintf("(%s)", formatC(x, format = "f", digits = 3)))
# significance stars from a coefficient and its standard error (two-sided normal): *** 1%, ** 5%, * 10%
.star <- function(coef, se) { if (!is.finite(coef) || !is.finite(se) || se <= 0) return("")
  p <- 2 * pnorm(-abs(coef / se)); if (p < 0.01) "$^{***}$" else if (p < 0.05) "$^{**}$" else if (p < 0.10) "$^{*}$" else "" }
p3s <- function(coef, se) ifelse(is.na(coef) | !is.finite(coef), "", paste0(formatC(coef, format = "f", digits = 3), .star(coef, se)))
nf  <- function(x) ifelse(is.na(x) | !is.finite(x), "", format(round(x), big.mark = ",", trim = TRUE))
row5 <- function(cells) paste(cells, collapse = " & ")

battery_part <- function(o, partno, title) {
  L <- o$lin; cols <- c("OLS", "FE", "RE", "Study", "Precision")
  maive_F <- if (is.na(o$maive$F)) "" else if (o$maive$F < 0.5) "$<1$" else formatC(o$maive$F, format = "f", digits = 0, big.mark = ",")
  # Observations report the full sample (all estimates enter each test; internal subsetting is a method detail).
  nfull <- nf(o$n)
  c(sprintf("\\multicolumn{6}{@{}l}{\\textbf{Part %d: %s}}\\\\", partno, title),
    "\\midrule",
    "\\multicolumn{6}{@{}l}{\\emph{Panel A: Linear techniques}}\\\\", "\\addlinespace[2pt]",
    paste0(" & ", row5(cols), "\\\\"), "\\midrule",
    paste0("Publication bias & ", row5(sapply(cols, function(c) p3s(L[[c]]$fat, L[[c]]$fat_se))), "\\\\"),
    paste0("\\emph{\\hspace{2mm}(Standard error)} & ", row5(se3(sapply(cols, function(c) L[[c]]$fat_se))), "\\\\"),
    "\\addlinespace[2pt]",
    paste0("Effect beyond bias & ", row5(sapply(cols, function(c) p3s(L[[c]]$pet, L[[c]]$pet_se))), "\\\\"),
    paste0("\\emph{\\hspace{2mm}(Constant)} & ", row5(se3(sapply(cols, function(c) L[[c]]$pet_se))), "\\\\"),
    "\\addlinespace[2pt]",
    paste0("Observations & ", row5(rep(nfull, 5)), "\\\\"), "\\midrule",
    "\\multicolumn{6}{@{}l}{\\emph{Panel B: Nonlinear techniques}}\\\\", "\\addlinespace[2pt]",
    " & Top 10\\% & WAAP & PEESE & STEM & EK\\\\", "\\midrule",
    paste0("Effect beyond bias & ", row5(c(p3s(o$top10$est,o$top10$se), p3s(o$waap$est,o$waap$se), p3s(o$peese$est,o$peese$se), p3s(o$stem$est,o$stem$se), p3s(o$ek$pet,o$ek$pet_se))), "\\\\"),
    paste0(" & ", row5(c(se3(o$top10$se), se3(o$waap$se), se3(o$peese$se), se3(o$stem$se), se3(o$ek$pet_se))), "\\\\"),
    "\\addlinespace[2pt]",
    paste0("Observations & ", row5(rep(nfull, 5)), "\\\\"), "\\midrule",
    "\\multicolumn{6}{@{}l}{\\emph{Panel C: Endogeneity- and selection-robust techniques}}\\\\", "\\addlinespace[2pt]",
    " & & & p-uniform* & MAIVE & Selection \\\\", "\\midrule",
    paste0("Effect beyond bias & ", row5(c("", "", p3s(o$puni$est,o$puni$se), p3s(o$maive$est,o$maive$se), p3s(o$selmod$est,o$selmod$se))), "\\\\"),
    paste0(" & ", row5(c("", "", se3(o$puni$se), se3(o$maive$se), se3(o$selmod$se))), "\\\\"),
    "\\addlinespace[2pt]",
    paste0("First-stage \\emph{F} (MAIVE) & ", row5(c("", "", "", maive_F, "")), "\\\\"),
    paste0("Observations & ", row5(c("", "", nfull, nfull, nfull)), "\\\\"))
}

NOTE <- paste0("\\emph{Notes:} Publication-bias--corrected mean price elasticity from each estimator, ",
  "on the 1\\%-winsorized headline sample. \\emph{Panel A} is the FAT-PET meta-regression $\\varepsilon_{is}=",
  "\\varepsilon_{0}+\\gamma\\,SE(\\varepsilon_{is})+u_{is}$: ``Publication bias'' is the slope $\\gamma$ and ",
  "``Effect beyond bias'' the intercept $\\varepsilon_{0}$ (each coefficient's standard error below it); the ",
  "columns are OLS unweighted, FE inverse-variance weighted, RE random effects (DerSimonian--Laird), Study one ",
  "median estimate per study, and Precision inverse-SE weighted. Standard errors are two-way clustered by study ",
  "and by underlying database wherever a regression is estimated (OLS, FE, Precision, PEESE, and EK); RE reports the ",
  "DerSimonian--Laird standard error and the study-level techniques are already one observation per study. \\emph{Panel B}: PEESE \\citep{stanley2014meta}, WAAP \\citep{ioannidis2017power}, the ",
  "top-10\\% estimator, STEM \\citep{furukawa2019publication}, and EK, the endogenous-kink meta-regression of Bom and ",
  "Rachinger (2019) whose kink point $a_1=|\\varepsilon_0|/1.96$ is iterated to convergence. \\emph{Panel C}: MAIVE \\citep{irsova2023spurious} ",
  "instruments the estimate variance with the inverse sample size (top 1\\% of SEs dropped) and is reported ",
  "only where the first-stage instrument is adequate ($F\\ge10$; otherwise only the $F$ is shown); ",
  "$p$-uniform* \\citep{van2021correcting} works from study medians. ``Selection'' is a step-function selection ",
  "model (a Vevea--Hedges / Andrews--Kasy-type maximum-likelihood correction with a cut at the one-sided 2.5\\% ",
  "threshold). ``Observations'' is ",
  "the number of estimates in the sample, all of which enter every test; the study-level techniques (Study, ",
  "STEM, $p$-uniform*) then aggregate them to one value per study, and WAAP and the top-10\\% estimator average a ",
  "precision-selected subset of the same estimates. $^{***}$, $^{**}$, and $^{*}$ denote statistical significance at the 1\\%, 5\\%, and 10\\% level.")

write_pb_table <- function(file, caption, label, parts) {
  body <- character(0)
  for (i in seq_along(parts)) {
    body <- c(body, "\\toprule", battery_part(parts[[i]]$o, i, parts[[i]]$title))
    if (i < length(parts)) body <- c(body, "\\addlinespace[2pt]", "\\addlinespace[2pt]")
  }
  out <- c("% AUTO-GENERATED by pubbias.R",
    "\\begin{singlespace}\\footnotesize\\renewcommand{\\arraystretch}{0.9}\\setlength{\\tabcolsep}{4pt}",
    "\\begin{longtable}{@{}>{\\raggedright\\arraybackslash}p{\\dimexpr\\linewidth-2.2cm*5-\\tabcolsep*10\\relax}*{5}{>{\\centering\\arraybackslash}p{2.2cm}}@{}}",
    sprintf("\\caption{%s}\\label{%s}\\\\", caption, label),
    "\\endfirsthead",
    sprintf("\\multicolumn{6}{@{}l}{\\emph{\\autoref{%s} continued}}\\\\", label),
    "\\endhead",
    "\\midrule\\multicolumn{6}{r}{\\scriptsize\\emph{Continued on next page}}\\\\", "\\endfoot",
    "\\bottomrule",
    sprintf("\\multicolumn{6}{@{}>{\\scriptsize}p{\\linewidth}@{}}{%s}\\\\", NOTE),
    "\\endlastfoot",
    body,
    "\\end{longtable}", "\\end{singlespace}")
  writeLines(out, file)
}

# ------------------------------------------------------------------ 4 tables
cat("Computing batteries...\n")
B <- list(
  SR     = battery_full(SR),
  LR     = battery_full(LR),
  naive  = battery_full(SR[SR$rg == "naive"  & !is.na(SR$rg), ]),
  fe     = battery_full(SR[SR$rg == "fe"     & !is.na(SR$rg), ]),
  iv     = battery_full(SR[SR$rg == "iv"     & !is.na(SR$rg), ]),
  design = battery_full(SR[SR$rg == "design" & !is.na(SR$rg), ]),
  tou    = battery_full(onef(SR, "time_of_use_tariff")),
  marg   = battery_full(onef(SR, "marginal_price")))

write_pb_table(file.path(TAB, "tab_pb_horizon.tex"),
  "Publication-bias battery: short-run and long-run elasticities", "tab:pbhorizon",
  list(list(o = B$SR, title = "Short-run elasticities"), list(o = B$LR, title = "Long-run elasticities")))
write_pb_table(file.path(TAB, "tab_pb_tier1.tex"),
  "Publication-bias battery: naive and panel fixed-effects tiers", "tab:pbtier1",
  list(list(o = B$naive, title = "Naive"), list(o = B$fe, title = "Panel FE / structural")))
write_pb_table(file.path(TAB, "tab_pb_tier2.tex"),
  "Publication-bias battery: instrumented and design-based tiers", "tab:pbtier2",
  list(list(o = B$iv, title = "Instrumented (IV/GMM)"), list(o = B$design, title = "Design-based (RCT/nat.\\ exp./DID)")))
write_pb_table(file.path(TAB, "tab_pb_price.tex"),
  "Publication-bias battery: time-of-use and marginal-price subsamples", "tab:pbprice",
  list(list(o = B$tou, title = "Time-of-use tariff"), list(o = B$marg, title = "Marginal price")))

# ================================================================== FUNNEL FIGURE
FAM <- "Arial"; BLUE <- "#2F5F8F"; BLUE_D <- "#21496F"; GREY_M <- "#9AA0A6"; GRID <- "#E7E9EC"; AXIS <- "#8A9099"; GREY_D <- "#4D4D4D"
theme_paper <- function(base_size = 11) theme_minimal(base_size = base_size, base_family = FAM) +
  theme(text = element_text(colour = GREY_D), plot.background = element_rect(fill = "white", colour = NA),
        panel.background = element_rect(fill = "white", colour = NA), panel.grid.minor = element_blank(),
        panel.grid.major = element_line(colour = GRID, linewidth = 0.35),
        axis.line = element_line(colour = AXIS, linewidth = 0.35), axis.ticks = element_line(colour = AXIS, linewidth = 0.35),
        axis.text = element_text(colour = GREY_D, size = rel(0.9)), axis.title = element_text(colour = "#1A1A1A"),
        plot.title = element_text(colour = "#1A1A1A", size = rel(1.0), hjust = 0.5, margin = margin(b = 5)),
        plot.margin = margin(8, 12, 6, 8))
funnel_panel <- function(s, title) {
  df <- data.frame(effect = num(s$effect_M), prec = 1/s$se)  # RAW Marshallian-basis estimates, no winsorization
  df <- df[is.finite(df$effect) & is.finite(df$prec), ]
  wmean <- mean(wins(num(s$effect_M)))                       # simple 1%-winsorized mean
  ggplot(df, aes(effect, prec)) +
    geom_vline(xintercept = 0, linetype = "dotted", colour = GREY_M, linewidth = 0.35) +
    geom_point(size = 0.8, alpha = 0.35, stroke = 0, colour = BLUE) +
    geom_vline(xintercept = wmean, colour = BLUE_D, linetype = "dashed", linewidth = 0.7) +
    annotate("text", x = wmean, y = Inf, vjust = 1.4, hjust = -0.06,
             label = sprintf("winsorized mean %.3f", wmean), colour = BLUE_D, size = 2.9, family = FAM) +
    scale_y_log10() +
    coord_cartesian(xlim = c(-1.5, 0.8)) +
    labs(title = title, x = "Reported price elasticity (raw)", y = "Precision  (1 / SE, log scale)") +
    theme_paper()
}
fp <- funnel_panel(SR, "Short run") + funnel_panel(LR, "Long run")
ggsave(file.path(FIG, "fig_funnels.pdf"), fp, width = 8.4, height = 3.9, device = cairo_pdf)
ggsave(file.path(FIG, "fig_funnels.png"), fp, width = 8.4, height = 3.9, dpi = 300, bg = "white")

# ------------------------------------------------------------------ report
cat("\n================= PUBLICATION-BIAS BATTERY =================\n")
cat(sprintf("AER(MAIVE)=%s  puniform=%s\n", ok_aer, ok_puni))
for (nm in names(B)) { o <- B[[nm]]
  cat(sprintf("%-7s n=%4d k=%3d | OLS-PET %s FE-PET %s RE-PET %s | PEESE %s WAAP %s Top10 %s STEM %s | MAIVE %s(F=%s) puni %s\n",
    nm, o$n, o$n_stud, p3(o$lin$OLS$pet), p3(o$lin$FE$pet), p3(o$lin$RE$pet),
    p3(o$peese$est), p3(o$waap$est), p3(o$top10$est), p3(o$stem$est),
    p3(o$maive$est), if (is.na(o$maive$F)) "NA" else formatC(o$maive$F, format="f", digits=0), p3(o$puni$est))) }
cat("Funnel: SR winsorized mean", sprintf("%.3f", mean(wins(SR$effect))),
    "| LR", sprintf("%.3f", mean(wins(LR$effect))), "\n")
cat("DONE pubbias.R\n")


# ######################################################################
# PART 3 of 4 - BAYESIAN MODEL AVERAGING appendix + best-practice-by-country
# (verbatim from bma.R)
# ######################################################################

# =====================================================================
# bma.R  --  Heterogeneity: Bayesian model averaging for the electricity
#            meta-analysis (returns-paper "Appendix E" style).
#
# Produces, all from the frozen electricity.xlsx (sheet "data"):
#   * three variable-definition + summary-statistics tables
#       tables/tab_vardefs_{all,sr,lr}.tex           (body rows for a longtable)
#   * three BMA result tables, each = BMA (UIP g-prior, dilution)
#       | OLS two-way clustered (study x database) | FMA (smoothed-AIC)
#       tables/tab_bma_{all,sr,lr}.tex
#   * prior-robustness table (four g-prior x model-prior specs)
#       tables/tab_bma_robustness.tex
#   * model-averaging diagnostics  tables/tab_bma_diag.tex
#   * model-inclusion figures  figures/bma_incl_{all,sr,lr}.pdf(+png)
#   * regressor correlation matrix  figures/bma_corr_all.pdf(+png)
#   * best-practice, country-by-country prediction (SR & LR), predicted
#     from the integrated OLS with country-level moderators set to each
#     country's own level:  figures/bma_bestpractice_countries.pdf(+png)
#     and tables/tab_bestpractice_countries.tex
#   * plain-text results summary  results_model_averaging.txt
#
# DV  = 1%-winsorized price elasticity (effect_w); publication-bias term
#       = 1%-winsorized standard error (se_w). Moderators, references,
#       log flags and best-practice values follow the var_list sheet.
# =====================================================================
suppressPackageStartupMessages({
  library(readxl); library(BMS); library(sandwich); library(jsonlite); library(ggplot2)
})
set.seed(20240616)
FAST <- nzchar(Sys.getenv("BMA_FAST"))   # smoke-test mode: tiny MCMC, validates plumbing only

BASE <- .find_base(); setwd(BASE)
TAB  <- file.path(BASE, "tables");  dir.create(TAB, showWarnings = FALSE)
FIG  <- file.path(BASE, "figures"); dir.create(FIG, showWarnings = FALSE)
INPUT <- file.path(BASE, "electricity.xlsx")
RES <- list()

# ------------------------------------------------------------------ helpers
num  <- function(x) suppressWarnings(as.numeric(as.character(x)))
wins <- function(x, p = 0.01) { q <- quantile(x, c(p, 1 - p), na.rm = TRUE); pmin(pmax(x, q[1]), q[2]) }
impute_median <- function(x) { x <- num(x); x[!is.finite(x)] <- median(x[is.finite(x)], na.rm = TRUE); x }
ltx <- function(x) { x <- gsub("\\\\", "\\\\textbackslash{}", x)
  for (ch in c("&","%","#","_")) x <- gsub(ch, paste0("\\", ch), x, fixed = TRUE); x }
fmtn <- function(x) { if (!is.finite(x)) return("--"); ax <- abs(x)
  if (ax >= 10000) format(round(x), big.mark = ",", scientific = FALSE, trim = TRUE)
  else if (ax >= 100) sprintf("%.0f", x) else sprintf("%.2f", x) }
f3   <- function(x) if (!is.finite(x)) "--" else sprintf("%.3f", x)

# ------------------------------------------------------------------ load
d <- as.data.frame(read_excel(INPUT, sheet = "data"))
d <- d[is.finite(num(d$effect)), ]
d$effect <- num(d$effect); d$se <- num(d$se)
b <- d[is.finite(d$se) & d$se > 0, ]
b$effect_w <- wins(b$effect); b$se_w <- wins(b$se)
# BASELINE headline = enlarged Marshallian-equivalent pool (native-M + Slutsky-converted Hicksian, effect_M); real SE only.
H <- b[num(b$in_M_pool) == 1 & num(b$formula) == 1 & is.finite(num(b$effect_M)) & b$se_source != "imputed_uniform_t", ]
H$effect_w <- wins(num(H$effect_M))
H <- H[is.finite(H$effect_w) & is.finite(H$se_w), ]
pub_min <- min(num(H$publication_year), na.rm = TRUE)

# derived / transformed columns (scale-laden moderators enter in logs)
H$study_size <- log(num(H$n_obs))                       # log number of observations
H$data_span  <- log1p(num(H$data_period))               # log(1 + years covered)
H$pub_year_l <- log(num(H$publication_year) - pub_min + 1)
H$impact_l   <- log1p(num(H$impact_factor))
H$citations_l<- log1p(num(H$citations))
# identification tier from the six-rung ladder: design-based (1-3), instrumented (4),
# panel FE / structural (5), naive (6). Unclassified rungs fall into the reference baseline.
.rg <- num(H$rung)
H$tier_design     <- as.numeric(!is.na(.rg) & .rg <= 3)
H$tier_iv         <- as.numeric(!is.na(.rg) & .rg == 4)
H$tier_structural <- as.numeric(!is.na(.rg) & .rg == 5)
H$tier_naive      <- as.numeric(!is.na(.rg) & .rg == 6)
H$converted       <- as.integer(H$effect_M_source == "slutsky_H_s0.04")   # =1 if Slutsky-converted from a Hicksian estimate
# population / income already stored in logs in the source file

RES$counts <- list(all = nrow(d), with_se = nrow(b), head = nrow(H),
                   head_studies = length(unique(H$study_id)),
                   sr = sum(num(H$short_run) == 1, na.rm = TRUE),
                   ir = sum(num(H$intermediate_run) == 1, na.rm = TRUE),
                   lr = sum(num(H$long_run) == 1, na.rm = TRUE),
                   countries = length(unique(H$country)), databases = length(unique(H$iddatabase)))

# ------------------------------------------------------------------ variable spec
# role: "lead" (effect/se), "mod" (enters BMA), "ref" (reference; summary only)
S <- function(col, lab, cat, role = "mod", desc = "") list(col = col, lab = lab, cat = cat, role = role, desc = desc)
spec <- list(
  S("effect_w","Price elasticity","Effect and precision","lead",
    "The own-price elasticity of electricity demand (1\\%-winsorized), the response variable."),
  S("se_w","Standard error","Effect and precision","lead",
    "The standard error of the elasticity estimate (1\\%-winsorized); its coefficient measures publication selection."),
  # -- horizon --
  S("short_run","Short run","Horizon","mod","=1 if the estimate is a short-run (within about one year) elasticity."),
  S("long_run","Long run","Horizon","mod","=1 if the estimate is a long-run (beyond about five years; capital fully adjusted) elasticity."),
  S("intermediate_run","Intermediate run","Horizon","ref","=1 if the estimate is an intermediate-run (about 2--5 years) elasticity (reference category)."),
  # -- estimate provenance (Marshallian harmonization) --
  S("converted","Converted from Hicksian","Estimate type","mod","=1 if the estimate is a compensated (Hicksian) own-price elasticity converted to a Marshallian footing via the Slutsky relation $\\varepsilon_M=\\varepsilon_H-s\\eta$; =0 for a directly reported Marshallian estimate. Controls for any residual difference between the converted and the directly reported evidence."),
  # -- identification tier (the six-rung ladder, grouped) --
  S("tier_design","Design-based","Identification","mod","=1 if a design-based strategy identifies the price response: a randomized or mandated pricing experiment, a natural experiment, or a difference-in-differences design (tiers 1--3)."),
  S("tier_iv","Instrumented","Identification","mod","=1 if the price is instrumented (IV, two- or three-stage least squares, or GMM; tier 4)."),
  S("tier_structural","Panel FE / structural","Identification","mod","=1 if identification rests on panel fixed effects or a structural demand system, without instrumentation (tier 5)."),
  S("tier_naive","Naive","Identification","ref","=1 if a naive regression with no price-identification strategy is used (tier 6; the reference category, which also absorbs estimates whose strategy could not be classified)."),
  # -- aggregation --
  S("country_data","Aggregation: country","Estimate aggregation","mod","=1 if the data are aggregated to the country (or larger) level."),
  S("disaggregated_data","Aggregation: micro","Estimate aggregation","mod","=1 if the data are micro (household, plant or firm-level)."),
  S("regional_data","Aggregation: region","Estimate aggregation","ref","=1 if the data are aggregated to a sub-country region or city (reference category)."),
  # -- sector --
  S("residential_demand","Residential demand","Sector","mod","=1 if the estimate refers to residential electricity demand."),
  S("industrial_demand","Industrial demand","Sector","mod","=1 if the estimate refers to industrial electricity demand."),
  S("commercial_demand","Commercial demand","Sector","ref","=1 if the estimate refers to commercial or mixed demand (reference category)."),
  # -- data characteristics --
  S("time_series_data","Time-series data","Data characteristics","mod","=1 if the study uses time-series data."),
  S("cross_section_data","Cross-section data","Data characteristics","mod","=1 if the study uses cross-sectional data."),
  S("panel_data","Panel data","Data characteristics","ref","=1 if the study uses panel data (reference category)."),
  S("yearly_granularity","Yearly data","Data characteristics","mod","=1 if the data are of yearly frequency."),
  S("monthly_granularity","Sub-yearly data","Data characteristics","ref","=1 if the data are of monthly or quarterly frequency (reference category)."),
  S("data_span","Data span","Data characteristics","mod","The logarithm of one plus the number of years the dataset covers."),
  S("study_size","Study size","Data characteristics","mod","The logarithm of the number of observations used in the estimation."),
  # -- price and tariff --
  S("average_price","Average price","Price and tariff","mod","=1 if the price is measured as average price (revenue over quantity)."),
  S("marginal_price","Marginal price","Price and tariff","mod","=1 if the price is measured as marginal price."),
  S("other_price","Other price","Price and tariff","ref","=1 if another price concept is used (lump-sum, Shin, undefined; reference category)."),
  S("increasing_tariff","Increasing-block tariff","Price and tariff","mod","=1 if an increasing-block tariff is in force."),
  S("decreasing_tariff","Decreasing-block tariff","Price and tariff","mod","=1 if a decreasing-block tariff is in force."),
  S("time_of_use_tariff","Time-of-use tariff","Price and tariff","mod","=1 if a time-of-use rate (different unit prices by time block) is used."),
  S("flat_tariff","Flat tariff","Price and tariff","ref","=1 if a flat tariff is in force (reference category)."),
  # -- demand controls --
  S("demographics_control","Control: demographics","Demand controls","mod","=1 if the demand equation controls for demographic variation."),
  S("temperature_control","Control: temperature","Demand controls","mod","=1 if the demand equation controls for temperature or degree-days."),
  S("stock_control","Control: appliance stock","Demand controls","mod","=1 if the demand equation controls for the stock of electrical appliances."),
  S("fuels_control","Control: other fuels","Demand controls","mod","=1 if the demand equation controls for prices of substitute fuels."),
  # -- model and estimator --
  S("reduced_form","Reduced form","Model specification","mod","=1 if a single-equation reduced-form model is estimated."),
  S("structural_form","Structural form","Model specification","ref","=1 if a structural (multi-equation) model is estimated (reference category)."),
  S("static_model","Static model","Model specification","mod","=1 if the model is static (no lagged demand)."),
  S("dynamic_model","Dynamic model","Model specification","ref","=1 if the model is dynamic, with lagged adjustment (reference category)."),
  S("ARDL","ARDL","Model specification","mod","=1 if an autoregressive distributed-lag (partial-adjustment) model is used."),
  S("LE","Lagged endogenous","Model specification","mod","=1 if a lagged-endogenous model is used."),
  S("linear_function","Linear demand","Model specification","mod","=1 if the demand function is linear."),
  S("doublelog_function","Double-log demand","Model specification","mod","=1 if the demand function is double-logarithmic."),
  S("semilog_function","Semi-log demand","Model specification","ref","=1 if the demand function is semi-logarithmic or Box-Cox (reference category)."),
  # -- geography and context --
  S("loc_usa","United States","Geography and context","mod","=1 if the estimate is for the United States."),
  S("loc_europe","Europe","Geography and context","mod","=1 if the estimate is for a European country."),
  S("loc_other","Other country","Geography and context","ref","=1 if the estimate is for a country outside the US and Europe (reference category)."),
  S("daylight_hours","Daylight hours","Geography and context","mod","The average length of the longest day for the country under examination."),
  S("population","Population","Geography and context","mod","The logarithm of the population of the country or entity."),
  # -- publication --
  S("pub_year_l","Publication year","Publication characteristics","mod","The logarithm of one plus the number of years since the earliest study in the sample."),
  S("impact_l","Impact factor","Publication characteristics","mod","The logarithm of one plus the journal's RePEc recursive impact factor; 0 for unpublished work."),
  S("citations_l","Citations","Publication characteristics","mod","The logarithm of one plus the study's mean annual Google Scholar citation count.")
)
# best-practice (bpe) rule per moderator column (from var_list): "mean" | "0" | "max"
bpe_rule <- c(se_w="0", impact_l="max", citations_l="max")   # everything else defaults to "mean"

col_ok <- function(s) s$col %in% names(H)
spec   <- Filter(col_ok, spec)
mods   <- Filter(function(s) s$role == "mod", spec)
mod_cols <- vapply(mods, function(s) s$col, "")
mod_labs <- vapply(mods, function(s) s$lab, "")

# ------------------------------------------------------------------ 1. VARDEFS + SUMMARY
cats_order <- unique(vapply(spec, function(s) s$cat, ""))
build_vardefs <- function(mask, file) {
  out <- character(0); firstcat <- TRUE
  for (cn in cats_order) {
    members <- Filter(function(s) s$cat == cn, spec)
    rows <- character(0)
    for (s in members) {
      x <- num(H[[s$col]])[mask]; if (all(!is.finite(x))) next
      ind <- if (firstcat) "" else "\\hspace{0.4cm}"
      lab <- if (s$role == "ref") paste0(s$lab, "") else s$lab
      rows <- c(rows, sprintf("%s%s & %s & %s & %s \\\\", ind, ltx(lab), s$desc,
                              fmtn(mean(x, na.rm = TRUE)), fmtn(sd(x, na.rm = TRUE))))
    }
    if (!length(rows)) next
    if (firstcat) { firstcat <- FALSE; out <- c(out, rows) }
    else out <- c(out, "\\midrule", sprintf("\\multicolumn{4}{@{}l}{\\emph{%s}}\\\\", cn), rows)
  }
  writeLines(c("% AUTO-GENERATED by bma.R", out), file)
}
mSR <- num(H$short_run) == 1 & !is.na(H$short_run)
mLR <- num(H$long_run)  == 1 & !is.na(H$long_run)
build_vardefs(rep(TRUE, nrow(H)), file.path(TAB, "tab_vardefs_all.tex"))
build_vardefs(mSR,               file.path(TAB, "tab_vardefs_sr.tex"))
build_vardefs(mLR,               file.path(TAB, "tab_vardefs_lr.tex"))

# ------------------------------------------------------------------ design builder
build_design <- function(mask) {
  X <- data.frame(Effect = H$effect_w, `Standard error` = H$se_w, check.names = FALSE)
  for (i in seq_along(mod_cols)) X[[mod_labs[i]]] <- impute_median(H[[mod_cols[i]]])
  X   <- X[mask, , drop = FALSE]
  sid <- as.character(H$study_id[mask]); dbid <- as.character(H$iddatabase[mask])
  # missing/blank database ids fall back to a per-study proxy so two-way clustering has no NA clusters
  dbid[is.na(dbid) | dbid == ""] <- paste0("s", sid[is.na(dbid) | dbid == ""])
  sid[is.na(sid) | sid == ""]    <- paste0("row", which(is.na(sid) | sid == ""))
  ok  <- is.finite(X$Effect) & is.finite(X$`Standard error`)
  X <- X[ok, ]; sid <- sid[ok]; dbid <- dbid[ok]
  keep <- vapply(X, function(c) length(unique(c)) > 1, TRUE)   # drop constants
  list(X = X[, keep, drop = FALSE], sid = sid, dbid = dbid, n = sum(ok))
}
run_bms <- function(X, g = "UIP", mp = "dilut", burn = 1e5, iter = 1e6) { set.seed(20240616)
  if (FAST) { burn <- 1000; iter <- 4000 }
  bms(X, burn = burn, iter = iter, g = g, mprior = mp, nmodel = 5000, mcmc = "bd", user.int = FALSE) }

# OLS with two-way (study x database) clustered covariance
freq_ols <- function(X, sid, dbid) {
  Xo <- X; orig <- names(X); names(Xo) <- make.names(orig); names(Xo)[1] <- "Y"
  fit <- lm(Y ~ ., data = Xo)
  V  <- sandwich::vcovCL(fit, cluster = data.frame(s = factor(sid), d = factor(dbid)))
  co <- coef(fit); se <- sqrt(diag(V)); tp <- 2 * pt(abs(co / se), df = fit$df.residual, lower.tail = FALSE)
  map <- c("(Intercept)", make.names(orig[-1])); disp <- c("(Intercept)", orig[-1])
  out <- data.frame(label = disp, coef = NA_real_, se = NA_real_, p = NA_real_)
  for (i in seq_along(map)) if (map[i] %in% names(co)) { out$coef[i] <- co[map[i]]; out$se[i] <- se[map[i]]; out$p[i] <- tp[map[i]] }
  list(tab = out, fit = fit, V = V)
}

# Frequentist model averaging: smoothed-AIC weights over the BMS top-model set
fma_saic <- function(fit_bms, X) {
  tm <- topmodels.bma(fit_bms)
  regs <- names(X)[-1]; incl <- tm[regs, , drop = FALSE] != 0
  Xo <- X; names(Xo) <- make.names(names(X)); names(Xo)[1] <- "Y"
  rn <- make.names(regs)
  aic <- rep(NA_real_, ncol(incl)); betas <- matrix(0, length(regs) + 1, ncol(incl),
             dimnames = list(c("(Intercept)", regs), NULL))
  disp_of <- setNames(c("(Intercept)", regs), c("(Intercept)", rn))   # safe name -> display name
  for (m in seq_len(ncol(incl))) {
    sel <- rn[incl[, m]]
    fml <- if (length(sel)) as.formula(paste("Y ~", paste(sel, collapse = "+"))) else as.formula("Y ~ 1")
    fm  <- lm(fml, data = Xo); aic[m] <- AIC(fm)
    cf  <- coef(fm)                                   # named by safe names; aliased terms are NA
    for (nmc in names(cf)) if (is.finite(cf[[nmc]]) && nmc %in% names(disp_of)) betas[disp_of[[nmc]], m] <- cf[[nmc]]
  }
  w <- exp(-0.5 * (aic - min(aic, na.rm = TRUE))); w <- w / sum(w, na.rm = TRUE)
  coef_fma <- as.numeric(betas %*% w)
  wt_fma   <- as.numeric(rbind(1, incl) %*% w)   # inclusion weight (intercept always in)
  data.frame(label = c("(Intercept)", regs), coef = coef_fma, weight = wt_fma)
}

# ------------------------------------------------------------------ 2. THREE BMA MODELS
run_one <- function(mask, tag) {
  bd <- build_design(mask); X <- bd$X
  cat(sprintf("  [%s] N=%d, regressors=%d ... ", tag, bd$n, ncol(X) - 1)); t0 <- Sys.time()
  fit <- run_bms(X)
  cm  <- coef(fit, order.by.pip = FALSE, exact = TRUE, include.constant = TRUE)
  ols <- freq_ols(X, bd$sid, bd$dbid)
  fma <- fma_saic(fit, X)
  cat(sprintf("done (%.0fs)\n", as.numeric(difftime(Sys.time(), t0, units = "secs"))))
  list(fit = fit, cm = cm, ols = ols, fma = fma, X = X, sid = bd$sid, dbid = bd$dbid,
       n = bd$n, nstud = length(unique(bd$sid)), ndb = length(unique(bd$dbid)))
}
cat("Running BMA models...\n")
m_all <- run_one(rep(TRUE, nrow(H)), "all")
m_sr  <- run_one(mSR, "sr")
m_lr  <- run_one(mLR, "lr")

# ------------------------------------------------------------------ 3. THREE-BLOCK TABLES (BMA | OLS 2-way | FMA)
three_block <- function(M, file) {
  cm <- M$cm; ols <- M$ols$tab; fma <- M$fma
  g  <- function(rn, cc) if (rn %in% rownames(cm)) f3(cm[rn, cc]) else "--"
  go <- function(rn, cc) { i <- match(rn, ols$label); if (is.na(i) || !is.finite(ols[[cc]][i])) "--" else f3(ols[[cc]][i]) }
  gf <- function(rn, cc) { i <- match(rn, fma$label); if (is.na(i) || !is.finite(fma[[cc]][i])) "--" else f3(fma[[cc]][i]) }
  row <- function(disp, rn) sprintf("%s & %s & %s & %s & & %s & %s & %s & & %s & %s \\\\",
      disp, g(rn,"Post Mean"), g(rn,"Post SD"), g(rn,"PIP"),
      go(rn,"coef"), go(rn,"se"), go(rn,"p"), gf(rn,"coef"), gf(rn,"weight"))
  out <- c("\\begin{tabular*}{\\hsize}{@{\\hskip\\tabcolsep\\extracolsep\\fill}l*{10}{c}@{}}", "\\toprule",
    " & \\multicolumn{3}{c}{Bayesian model averaging} & & \\multicolumn{3}{c}{OLS, two-way clustered} & & \\multicolumn{2}{c}{FMA}\\\\",
    " & \\multicolumn{3}{c}{(UIP $g$-prior, dilution)} & & \\multicolumn{3}{c}{(study $\\times$ database)} & & \\multicolumn{2}{c}{(smoothed AIC)}\\\\",
    "\\cmidrule(lr){2-4}\\cmidrule(lr){6-8}\\cmidrule(lr){10-11}",
    " & P.\\ mean & P.\\ SD & PIP & & Coef. & SE & $p$ & & Coef. & Wt.\\\\", "\\midrule",
    row("Constant", "(Intercept)"),
    row("Standard error", "Standard error"))
  last <- ""
  for (s in mods) { if (!(s$lab %in% rownames(cm))) next
    if (s$cat != last) { out <- c(out, "\\midrule", sprintf("\\multicolumn{11}{@{}l}{\\emph{%s}}\\\\", s$cat)); last <- s$cat }
    out <- c(out, row(paste0("\\hspace{0.4cm}", ltx(s$lab)), s$lab)) }
  out <- c(out, "\\midrule",
    sprintf("Observations & %s & & & & %s & & & & %s & \\\\", format(M$n, big.mark=","), format(M$n, big.mark=","), format(M$n, big.mark=",")),
    sprintf("Studies / databases & %d\\,/\\,%d & & & & & & & & & \\\\", M$nstud, M$ndb),
    "\\bottomrule", "\\end{tabular*}")
  writeLines(c("% AUTO-GENERATED by bma.R", out), file)
}
three_block(m_all, file.path(TAB, "tab_bma_all.tex"))
three_block(m_sr,  file.path(TAB, "tab_bma_sr.tex"))
three_block(m_lr,  file.path(TAB, "tab_bma_lr.tex"))

# ------------------------------------------------------------------ 4. PRIOR ROBUSTNESS (integrated)
gg <- function(cm, r, c) if (r %in% rownames(cm)) f3(cm[r, c]) else "--"
ord <- rownames(m_all$cm)[order(-m_all$cm[, "PIP"])]; ord <- ord[ord != "(Intercept)"]
specs4 <- list(c("UIP","dilut"), c("UIP","uniform"), c("BRIC","random"), c("HQ","dilut"))
rco <- lapply(specs4, function(s) coef(run_bms(m_all$X, g = s[1], mp = s[2], burn = 1e5, iter = 1e6),
             order.by.pip = FALSE, exact = TRUE, include.constant = TRUE))
rbody <- vapply(ord, function(r) sprintf("%s & %s \\\\", ltx(r),
  paste(vapply(rco, function(cm) paste(gg(cm,r,"Post Mean"), gg(cm,r,"PIP"), sep = " & "), ""), collapse = " & ")), "")
writeLines(c("% AUTO-GENERATED by bma.R",
  "\\begin{tabular*}{\\hsize}{@{\\hskip\\tabcolsep\\extracolsep\\fill}l*{8}{c}@{}}", "\\toprule",
  paste0("Variable & ", paste(sprintf("\\multicolumn{2}{c}{%s}", c("A","B","C","D")), collapse = " & "), " \\\\"),
  paste(sprintf("\\cmidrule(lr){%d-%d}", seq(2, by = 2, length.out = 4), seq(3, by = 2, length.out = 4)), collapse = " "),
  paste0(" & ", paste(rep("Mean & PIP", 4), collapse = " & "), " \\\\"), "\\midrule",
  rbody, "\\bottomrule", "\\end{tabular*}"), file.path(TAB, "tab_bma_robustness.tex"))

# ------------------------------------------------------------------ 5. DIAGNOSTICS
diag_row <- function(M, tag) { pip <- coef(M$fit, exact = TRUE)[, "PIP"]
  s <- tryCatch(summary(M$fit), error = function(e) NULL)
  pull <- function(nm) if (!is.null(s) && nm %in% names(s)) suppressWarnings(as.numeric(gsub("[^0-9.eE+-]", "", s[nm]))) else NA
  data.frame(tag = tag, n = M$n, emodel = sum(pip), visited = pull("No. models visited"),
             corr = pull("Corr PMP"), shrink = tryCatch(M$fit$gprior.info$shrinkage.moment[1], error = function(e) NA)) }
dg <- rbind(diag_row(m_all,"Integrated"), diag_row(m_sr,"Short run"), diag_row(m_lr,"Long run"))
big <- function(x) ifelse(!is.finite(x), "--", format(round(x), big.mark = ",", scientific = FALSE, trim = TRUE))
f2  <- function(x) ifelse(!is.finite(x), "--", sprintf("%.2f", x))
dl  <- sprintf("%s & %s & %s & %s & %s & %s \\\\", dg$tag, big(dg$n), f2(dg$emodel), big(dg$visited), f2(dg$corr), f2(dg$shrink))
writeLines(c("% AUTO-GENERATED by bma.R", "\\begin{tabular}{lccccc}", "\\toprule",
  "Model & Obs. & E[model size] & Models visited & Corr PMP & Shrinkage \\\\", "\\midrule", dl,
  "\\bottomrule", "\\end{tabular}"), file.path(TAB, "tab_bma_diag.tex"))

# ------------------------------------------------------------------ 6. FIGURES: inclusion + correlation
incl_plot <- function(fit, stem) {
  # v1.7: larger variable-name fonts (cex.axis 0.7 -> 1.15) + wider left margin,
  # so the labels stay readable at the 0.49\textwidth size used in the paper.
  draw <- function() image(fit, yprop2pip = FALSE, order.by.pip = TRUE, do.grid = TRUE, do.axis = TRUE,
                           cex.axis = 1.15, col = c("grey78", "steelblue"), main = "", xlab = "")
  pdf(paste0(stem, ".pdf"), width = 7.2, height = 8.2); par(mar = c(4, 11, 1, 1)); draw(); dev.off()
  png(paste0(stem, ".png"), width = 7.2, height = 8.2, units = "in", res = 130); par(mar = c(4, 11, 1, 1)); draw(); dev.off()
}
incl_plot(m_all$fit, file.path(FIG, "bma_incl_all"))
incl_plot(m_sr$fit,  file.path(FIG, "bma_incl_sr"))
incl_plot(m_lr$fit,  file.path(FIG, "bma_incl_lr"))

corr_plot <- function(X, stem) {
  M <- suppressWarnings(cor(X[, -1, drop = FALSE], use = "pairwise.complete.obs"))
  nb <- ncol(M); pal <- colorRampPalette(c("#3b3b3b", "white", "#2166ac"))(100)
  draw <- function() { par(mar = c(0.4, 10.5, 10.5, 0.4))
    image(1:nb, 1:nb, t(M[nb:1, ]), col = pal, zlim = c(-1, 1), axes = FALSE, xlab = "", ylab = "")
    axis(3, at = 1:nb, labels = colnames(M), las = 2, cex.axis = 0.8, tick = FALSE, line = -0.5)   # v1.7: larger labels
    axis(2, at = 1:nb, labels = rev(colnames(M)), las = 2, cex.axis = 0.8, tick = FALSE, line = -0.5)
    abline(h = 0:nb + 0.5, v = 0:nb + 0.5, col = "grey88", lwd = 0.4)
    fmtc <- function(v) { if (abs(v) >= 0.995) return("1"); sub("^(-?)0[.]", "\\1.", sprintf("%.2f", v)) }
    for (i in 1:nb) for (j in 1:nb) { v <- M[i, j]
      if (i == j || abs(v) >= 0.15)
        text(j, nb - i + 1, fmtc(v), cex = 0.5, font = if (abs(v) >= 0.4 && i != j) 2 else 1,
             col = if (abs(v) > 0.55) "white" else "grey10") }
    box() }
  pdf(paste0(stem, ".pdf"), width = 8.6, height = 8.6); draw(); dev.off()
  png(paste0(stem, ".png"), width = 8.6, height = 8.6, units = "in", res = 120); draw(); dev.off()
}
corr_plot(m_all$X, file.path(FIG, "bma_corr_all"))

# ------------------------------------------------------------------ 7. BEST-PRACTICE, COUNTRY BY COUNTRY
# Predict from the integrated OLS (two-way clustered V). Country-level moderators
# (US/Europe, daylight, population) set to each country's own level; se=0; impact
# factor & citations at their 95th percentile (not max, to avoid outliers); identification best practice
# (Design-based=1; Instrumented/Structural=0; naive ref); demand controls=1; micro data (Aggregation: micro=1,
# country=0); all remaining moderators at sample means.
olsF <- m_all$ols$fit; V <- m_all$ols$V; beta <- coef(olsF)
Xd <- m_all$X; nm_disp <- names(Xd)[-1]; nm_safe <- make.names(nm_disp)
mean_vec <- sapply(Xd[, -1, drop = FALSE], mean)     # named by display label
q95for  <- c("Impact factor", "Citations"); zerofor <- c("Standard error")
onefor  <- c("Control: demographics", "Control: temperature", "Control: appliance stock", "Control: other fuels")
country_cols <- c("United States","Europe","Daylight hours","Population")

# per-country levels (headline sample), keep countries with enough estimates
Hh <- H[is.finite(H$effect_w), ]
cinfo <- do.call(rbind, lapply(split(seq_len(nrow(Hh)), Hh$country), function(ix) {
  data.frame(country = Hh$country[ix[1]], n = length(ix),
             usa = mean(num(Hh$loc_usa)[ix], na.rm = TRUE), eur = mean(num(Hh$loc_europe)[ix], na.rm = TRUE),
             day = mean(num(Hh$daylight_hours)[ix], na.rm = TRUE), pop = mean(num(Hh$population)[ix], na.rm = TRUE)) }))
cinfo <- cinfo[order(-cinfo$n), ]

profile <- function(row, horizon) {
  x <- setNames(rep(NA_real_, length(beta)), names(beta)); x["(Intercept)"] <- 1
  for (k in seq_along(nm_disp)) {
    lab <- nm_disp[k]; sn <- nm_safe[k]; val <- mean_vec[lab]
    if (lab %in% zerofor) val <- 0
    if (lab %in% q95for)  val <- as.numeric(quantile(Xd[[lab]], 0.95, na.rm = TRUE))  # 95th pct, not max (avoid a single outlier)
    if (lab == "United States")  val <- row$usa
    if (lab == "Europe")         val <- row$eur
    if (lab == "Daylight hours") val <- row$day
    if (lab == "Population")     val <- row$pop
    if (lab == "Short run") val <- if (horizon == "SR") 1 else 0
    if (lab == "Long run")  val <- if (horizon == "LR") 1 else 0
    if (lab == "Design-based") val <- 1                      # best practice: design-based / experimental identification
    if (lab %in% c("Instrumented", "Panel FE / structural")) val <- 0   # not IV, not structural (naive is the reference)
    if (lab %in% onefor) val <- 1                            # best practice: demand equation fully controlled
    if (lab == "Aggregation: micro")   val <- 1              # best practice: micro (household-level) data
    if (lab == "Aggregation: country") val <- 0
    x[sn] <- val
  }
  x <- x[names(beta)]; x[!is.finite(x)] <- 0; x
}
predict_bp <- function(row, horizon) { x <- profile(row, horizon)
  est <- sum(x * beta); v <- as.numeric(t(x) %*% V %*% x)
  c(est = est, lo = est - 1.96 * sqrt(v), hi = est + 1.96 * sqrt(v)) }

bp <- do.call(rbind, lapply(seq_len(nrow(cinfo)), function(i) {
  sr <- predict_bp(cinfo[i, ], "SR"); lr <- predict_bp(cinfo[i, ], "LR")
  data.frame(country = cinfo$country[i], n = cinfo$n[i],
             sr = sr["est"], sr_lo = sr["lo"], sr_hi = sr["hi"],
             lr = lr["est"], lr_lo = lr["lo"], lr_hi = lr["hi"]) }))
rownames(bp) <- NULL

# ---- appendix table: countries with >= 5 headline estimates, ordered alphabetically, no N ----
bp_tab <- bp[bp$n >= 5, ]
bp_tab <- bp_tab[order(bp_tab$country), ]
tl <- sprintf("%s & $%.3f$ & $[%.3f,\\,%.3f]$ & $%.3f$ & $[%.3f,\\,%.3f]$ \\\\",
              vapply(bp_tab$country, ltx, ""), bp_tab$sr, bp_tab$sr_lo, bp_tab$sr_hi,
              bp_tab$lr, bp_tab$lr_lo, bp_tab$lr_hi)
writeLines(c("% AUTO-GENERATED by bma.R", tl), file.path(TAB, "tab_bestpractice_countries.tex"))

# ---- figure: countries with >= 30 headline estimates, ranked by SR best practice ----
bp_fig <- bp[bp$n >= 30, ]; bp_fig <- bp_fig[order(bp_fig$sr), ]
bp_fig$country <- factor(bp_fig$country, levels = bp_fig$country)
long <- rbind(
  data.frame(country = bp_fig$country, horizon = "Short run", est = bp_fig$sr, lo = bp_fig$sr_lo, hi = bp_fig$sr_hi),
  data.frame(country = bp_fig$country, horizon = "Long run",  est = bp_fig$lr, lo = bp_fig$lr_lo, hi = bp_fig$lr_hi))
long$horizon <- factor(long$horizon, levels = c("Short run", "Long run"))
gp <- ggplot(long, aes(est, country, colour = horizon)) +
  geom_vline(xintercept = 0, colour = "grey70", linetype = "dotted", linewidth = 0.35) +
  geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y", width = 0, position = position_dodge(width = 0.55), linewidth = 0.5) +
  geom_point(position = position_dodge(width = 0.55), size = 1.7) +
  scale_colour_manual(values = c("Short run" = "#2F5F8F", "Long run" = "#4D4D4D"), name = NULL) +
  labs(x = "Best-practice price elasticity (SE = 0, country levels; 95% CI)", y = NULL) +
  theme_minimal(base_size = 11, base_family = "Arial") +
  theme(legend.position = "top",
        plot.background = element_rect(fill = "white", colour = NA),
        panel.background = element_rect(fill = "white", colour = NA),
        panel.grid.major.y = element_blank(), panel.grid.minor = element_blank(),
        panel.grid.major.x = element_line(colour = "#E7E9EC", linewidth = 0.3),
        axis.line = element_line(colour = "#8A9099", linewidth = 0.35),
        axis.ticks = element_line(colour = "#8A9099", linewidth = 0.35),
        axis.text = element_text(colour = "#4D4D4D"), axis.text.y = element_text(size = 9.5),
        axis.title = element_text(colour = "#1A1A1A"))
ggsave(file.path(FIG, "bma_bestpractice_countries.pdf"), gp, width = 6.6, height = 4.9, device = cairo_pdf)
ggsave(file.path(FIG, "bma_bestpractice_countries.png"), gp, width = 6.6, height = 4.9, dpi = 150, bg = "white")

# ------------------------------------------------------------------ dump + report
top_pip <- function(M) { cm <- M$cm; cm <- cm[rownames(cm) != "(Intercept)", ]
  head(rownames(cm)[order(-cm[, "PIP"])], 8) }
RES$bma <- list(
  all = list(n = m_all$n, studies = m_all$nstud, databases = m_all$ndb, top_pip = top_pip(m_all)),
  sr  = list(n = m_sr$n,  top_pip = top_pip(m_sr)),
  lr  = list(n = m_lr$n,  top_pip = top_pip(m_lr)),
  se_pip = list(all = m_all$cm["Standard error","PIP"], sr = m_sr$cm["Standard error","PIP"], lr = m_lr$cm["Standard error","PIP"]),
  se_mean = list(all = m_all$cm["Standard error","Post Mean"], sr = m_sr$cm["Standard error","Post Mean"], lr = m_lr$cm["Standard error","Post Mean"]))
RES$diag <- dg
RES$bestpractice <- list(n_countries_table = nrow(bp_tab), n_countries_fig = nrow(bp_fig),
  usa_sr = bp$sr[bp$country == "USA"], usa_lr = bp$lr[bp$country == "USA"],
  head = head(bp[order(-bp$n), c("country","n","sr","lr")], 12))
# ---- write a plain-text results summary (one "result = value" per line) ----
.fmt_leaf <- function(v) paste(format(v, trim = TRUE, digits = 6, scientific = FALSE), collapse = ", ")
flatten_results <- function(x, prefix = "") {
  if (is.data.frame(x) || is.matrix(x)) {
    rn <- rownames(x); if (is.null(rn)) rn <- as.character(seq_len(nrow(x)))
    cn <- colnames(x); if (is.null(cn)) cn <- as.character(seq_len(ncol(x)))
    o <- character(0)
    for (i in seq_len(nrow(x))) for (j in seq_len(ncol(x)))
      o <- c(o, sprintf("%s.%s.%s = %s", prefix, rn[i], cn[j], .fmt_leaf(x[i, j])))
    o
  } else if (is.list(x)) {
    nms <- names(x); if (is.null(nms)) nms <- as.character(seq_along(x))
    unlist(lapply(seq_along(x), function(k)
      flatten_results(x[[k]], if (prefix == "") nms[k] else paste0(prefix, ".", nms[k]))))
  } else sprintf("%s = %s", prefix, .fmt_leaf(x))
}
writeLines(c(
  "MODEL-AVERAGING (BMA) APPENDIX RESULTS - electricity price-elasticity meta-analysis",
  "Auto-generated by bma.R from electricity.xlsx. One 'result = value' per line;",
  "the dotted names show where each number sits (e.g. counts.head, bma.all.n).",
  "For context see the paper (electricity.pdf); this file is not needed to compile it.",
  paste(rep("-", 80), collapse = ""), "",
  flatten_results(RES)),
  file.path(BASE, "results_model_averaging.txt"))

cat("\n================= BMA SUMMARY =================\n")
cat(sprintf("Headline N=%d, studies=%d, databases=%d, countries=%d\n", nrow(H), RES$counts$head_studies, RES$counts$databases, RES$counts$countries))
cat(sprintf("SE (pub-bias) PIP  all/sr/lr = %.3f / %.3f / %.3f\n", RES$bma$se_pip$all, RES$bma$se_pip$sr, RES$bma$se_pip$lr))
cat(sprintf("SE (pub-bias) mean all/sr/lr = %.3f / %.3f / %.3f\n", RES$bma$se_mean$all, RES$bma$se_mean$sr, RES$bma$se_mean$lr))
cat("Top-PIP moderators (integrated): ", paste(RES$bma$all$top_pip, collapse = ", "), "\n")
cat(sprintf("Corr PMP all/sr/lr = %.2f / %.2f / %.2f\n", dg$corr[1], dg$corr[2], dg$corr[3]))
cat(sprintf("Best-practice USA  SR=%.3f  LR=%.3f\n", RES$bestpractice$usa_sr, RES$bestpractice$usa_lr))
cat(sprintf("Best-practice table: %d countries; figure: %d countries\n", nrow(bp_tab), nrow(bp_fig)))
cat("DONE bma.R\n")


# ######################################################################
# PART 4 of 4 - DATABASE-CLUSTERING ROBUSTNESS (main-text clustering footnote)
# (verbatim from dbcluster_maintext.R)
# ######################################################################

# =====================================================================
# dbcluster_maintext.R  --  database-clustering robustness for the MAIN TEXT
# Referee follow-up (2026-07-06). Mirrors electricity.R's data prep, winsor,
# H filter, ladder, headline PET and two-clock full spec EXACTLY, then
# re-computes the inference of the three load-bearing main-text objects under
#   (1) one-way study clustering  [the paper's headline]
#   (2) two-way (study x database) clustering  [the referee's ask, as in bma.R]
# Points are identical by construction; only the SEs / p-values change.
# Produces the numbers quoted in the clustering footnote of Section "Data".
# Run:  Rscript dbcluster_maintext.R   (reads ./electricity.xlsx, writes ./results_database_clustering.txt)
# =====================================================================
suppressPackageStartupMessages({ library(readxl); library(sandwich); library(lmtest) })

BASE <- .find_base(); setwd(BASE)
INPUT <- file.path(BASE, "electricity.xlsx")
d <- as.data.frame(read_excel(INPUT, sheet = "data")); d <- d[is.finite(d$effect), ]

wins <- function(x, p = 0.01) { q <- quantile(x, c(p, 1 - p), na.rm = TRUE); pmin(pmax(x, q[1]), q[2]) }
b <- d[is.finite(d$se) & d$se > 0, ]; b$effect_w <- wins(b$effect); b$se_w <- wins(b$se)
b$effect_M <- as.numeric(as.character(b$effect_M)); b$in_M_pool <- as.numeric(as.character(b$in_M_pool))
H <- b[b$in_M_pool %in% 1 & b$formula %in% 1 & is.finite(b$effect_M) & b$se_source != "imputed_uniform_t", ]
H$effect_w <- wins(H$effect_M)

# database id for the SECOND clustering dimension, EXACTLY as bma.R: missing/blank
# ids fall back to a per-STUDY proxy ("s"<study_id>) so 2-way clustering has no NA clusters.
H$dbid <- as.character(H$iddatabase)
miss <- is.na(H$dbid) | H$dbid == ""
H$dbid[miss] <- paste0("s", H$study_id[miss])

rgroup <- function(r) ifelse(is.na(r), NA, ifelse(r <= 3, "design", ifelse(r == 4, "iv", ifelse(r == 5, "fe", "naive"))))
H$rg <- rgroup(H$rung)
H$midyear <- ifelse(is.na(H$data_midyear), H$publication_year - 3, H$data_midyear)
mods <- c("residential_demand","industrial_demand","average_price","panel_data",
          "cross_section_data","loc_usa","loc_europe","demographics_control",
          "income_control","doublelog_function")

vc1 <- function(m, dat) vcovCL(m, cluster = dat$study_id, type = "HC1")
vc2 <- function(m, dat) vcovCL(m, cluster = dat[, c("study_id","dbid")], type = "HC1")
dual <- function(f, dat) { m <- lm(f, data = dat)
  list(m = m, ct1 = coeftest(m, vcov = vc1(m, dat)), ct2 = coeftest(m, vcov = vc2(m, dat))) }

out <- c(); add <- function(...) out <<- c(out, sprintf(...))

studies_per_db <- tapply(H$study_id, H$dbid, function(s) length(unique(s)))
shared <- studies_per_db[studies_per_db >= 2]
studies_in_shared <- unique(H$study_id[H$dbid %in% names(shared)])
add("== coverage / database-sharing structure ==")
add("H_estimates = %d ; H_studies = %d", nrow(H), length(unique(H$study_id)))
add("distinct data sources (databases incl. singletons) = %d", length(studies_per_db))
add("databases shared by >=2 studies = %d", length(shared))
add("studies sharing a database with another study = %d of %d",
    length(studies_in_shared), length(unique(H$study_id)))
add("max studies on any one database = %d", if (length(shared)) max(shared) else 1L)

SR <- H[H$short_run == 1, ]
r <- dual(effect_w ~ se_w, SR); pet <- r$ct1[1,1]; se1 <- r$ct1[1,2]; se2 <- r$ct2[1,2]
add("== (1) headline SR PET  effect_w ~ se_w ==")
add("PET = %.4f", pet)
add("study-clustered   : SE %.4f  95%% CI [%.3f, %.3f]  p %.3g", se1, pet-1.96*se1, pet+1.96*se1, r$ct1[1,4])
add("studyXdatabase 2wy: SE %.4f  95%% CI [%.3f, %.3f]  p %.3g", se2, pet-1.96*se2, pet+1.96*se2, r$ct2[1,4])

sub <- SR[!is.na(SR$rg), ]
sub$g_design <- as.numeric(sub$rg == "design"); sub$g_iv <- as.numeric(sub$rg == "iv"); sub$g_fe <- as.numeric(sub$rg == "fe")
for (m in mods) sub[[m]][is.na(sub[[m]])] <- 0
f <- as.formula(paste("effect_w ~ se_w + g_design + g_iv + g_fe +", paste(mods, collapse = "+")))
r <- dual(f, sub)
add("== (2) SR ladder contrasts (coef vs naive; design n=%d) ==", sum(sub$g_design))
for (g in c("g_design","g_iv","g_fe"))
  add("%-9s coef %+.4f | study p %.4f | 2wy p %.4f", g, r$ct1[g,1], r$ct1[g,4], r$ct2[g,4])

sub <- H[H$short_run == 1 & is.finite(H$midyear), ]
sub$dy <- (sub$midyear - mean(sub$midyear)) / 10
sub$py <- (sub$publication_year - mean(sub$publication_year)) / 10
sub$g_design <- as.numeric(sub$rg == "design"); sub$g_design[is.na(sub$g_design)] <- 0
sub$g_iv <- as.numeric(sub$rg == "iv"); sub$g_iv[is.na(sub$g_iv)] <- 0
sub$g_fe <- as.numeric(sub$rg == "fe"); sub$g_fe[is.na(sub$g_fe)] <- 0
for (m in mods) sub[[m]][is.na(sub[[m]])] <- 0
f <- as.formula(paste("effect_w ~ se_w + dy + py + g_design + g_iv + g_fe +", paste(mods, collapse = "+")))
r <- dual(f, sub)
add("== (3) two-clock FULL spec, data-clock trend 'dy' (per decade) ==")
add("dy coef %+.4f | study p %.3f | 2wy p %.3f", r$ct1["dy",1], r$ct1["dy",4], r$ct2["dy",4])

writeLines(c(
  "DATABASE-CLUSTERING ROBUSTNESS CHECK - electricity price-elasticity meta-analysis",
  "Auto-generated by dbcluster_maintext.R from electricity.xlsx. Compares the headline",
  "inferences under one-way (study) vs two-way (study x database) clustering.",
  "For context see the paper (electricity.pdf); this file is not needed to compile it.",
  paste(rep("-", 80), collapse = ""), "",
  out),
  file.path(BASE, "results_database_clustering.txt"))
cat(paste(out, collapse = "\n"), "\n")
