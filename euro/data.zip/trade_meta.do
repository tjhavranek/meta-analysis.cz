set more off
use "C:\European_Economic_Policies\Data_meta\trade_meta.dta", clear
log using "C:\European_Economic_Policies\Data_meta\trade_meta.log", replace
set scheme s2mono, permanently
******************************************************************************
*simple meta-analysis
******************************************************************************
*euro
rename study Study
gen gimpweur= impweur* gamma
gen ginfweur= infweur*gamma
gen gimpweurisi= impweur* refisiweur*gamma
gen gimpweurrep= impweur* refrepweur*gamma
gen ginfweurisi= infweur* refisiweur*gamma
gen ginfweurrep= infweur* refrepweur*gamma
metan gamma se if euro==1, lcols(Study) xlabel(-0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8) force astext(50)
graph save Graph "C:\European_Economic_Policies\Data_meta\tree_euro.gph", replace
metatrim gamma se if euro==1
metatrim gimpweur se if euro==1
metatrim ginfweur se if euro==1
metatrim gimpweurisi se if gimpweurisi!=0
metatrim gimpweurrep se if gimpweurrep!=0
metatrim ginfweurisi se if ginfweurisi!=0
metatrim ginfweurrep se if ginfweurrep!=0
metaninf gamma se if euro==1
metatrim gamma se if euro==1 & id!=31
metatrim gimpweur se if euro==1 & id!=31
drop gimpweur
drop ginfweur
drop gimpweurisi
drop gimpweurrep
drop ginfweurisi
drop ginfweurrep
******************************************************************************
*non-euro
gen gimpwnon= impwnon* gamma
gen ginfwnon= infwnon*gamma
gen gimpwnonisi= impwnon* refisiwnon*gamma
gen gimpwnonrep= impwnon* refrepwnon*gamma
gen ginfwnonisi= infwnon* refisiwnon*gamma
gen ginfwnonrep= infwnon* refrepwnon*gamma
metan gamma se if euro==0, lcols(Study) xlabel(-0.5, 0, 0.5, 1, 1.5, 2, 2.5) force astext(50)
graph save Graph "C:\European_Economic_Policies\Data_meta\tree_noneuro.gph", replace
metatrim gamma se if euro==0
metatrim gimpwnon se if euro==0
metatrim ginfwnon se if euro==0
metatrim gimpwnonisi se if gimpwnonisi!=0
metatrim gimpwnonrep se if gimpwnonrep!=0
metatrim ginfwnonisi se if ginfwnonisi!=0
metatrim ginfwnonrep se if ginfwnonrep!=0
metaninf gamma se if euro==0
metatrim gamma se if euro==0 & id!=22
drop gimpwnon
drop ginfwnon
drop gimpwnonisi
drop gimpwnonrep
drop ginfwnonisi
drop ginfwnonrep
******************************************************************************
*all
gen gimpwall= impwall* gamma
gen ginfwall= infwall*gamma
gen gimpwallisi= impwall* refisiwall*gamma
gen gimpwallrep= impwall* refrepwall*gamma
gen ginfwallisi= infwall* refisiwall*gamma
gen ginfwallrep= infwall* refrepwall*gamma
metan gamma se, lcols(Study) xlabel(-0.5, 0, 0.5, 1, 1.5, 2, 2.5) force astext(50)
graph save Graph "C:\European_Economic_Policies\Data_meta\tree_all.gph", replace
metatrim gamma se
metatrim gimpwall se
metatrim gimpwallrep se if gimpwallrep!=0
metaninf gamma se
metatrim gamma se if id!=31
metatrim gimpwall se if id!=31
drop gimpwall
drop ginfwall
drop gimpwallisi
drop gimpwallrep
drop ginfwallisi
drop ginfwallrep
drop impisi impwall impweur impwnon infisi infwall infweur infwnon refrep refrepwall refrepweur refrepwnon refisi refisiwall refisiweur refisiwnon
******************************************************************************
*publication bias & the true effect
******************************************************************************
*euro
gen prec=1/se
gen sqrtn=nobs^(1/2)
gen abst=abs(tstat)
gen logt=ln(abst)
gen logn=ln(nobs)
gen se2=se^2
twoway (scatter prec gamma) if euro==1
graph save Graph "C:\European_Economic_Policies\Data_meta\funnel_euro.gph", replace
gen tstateuro=(gamma - 0.05)/se
twoway (scatter tstateuro prec) if euro==1
graph save Graph "C:\European_Economic_Policies\Data_meta\galb_euro.gph", replace
drop tstateuro
eststo: reg tstat prec if euro==1, vce(robust)
predict res, residuals
sdtest res == 1.41421356 if euro==1
correl sqrtn prec if euro==1
drop res
rreg tstat prec if euro==1
eststo: ivregress 2sls tstat (prec = sqrtn) if euro==1, vce(robust) first
eststo: reg tstat sqrtn if euro==1, vce(robust)
esttab using eurobias.tex, booktabs replace compress scalars(rmse) width(1\hsize) title(Tests of publication bias, euro\label{tab:eurobias}) mtitles("FAT-PET" "FAIVEHR" "PROXY") addnote("Meta-response variable: tstat") star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label alignment(D{.}{.}{-1}) page(dcolumn) nonumber nogaps
eststo clear
eststo: reg logt logn if euro==1, vce(robust)
rreg logt logn if euro==1
reg gamma se2 if euro==1, vce(robust)
gen tstateuropets=(gamma - 1.785646*se2)/se
eststo: reg tstateuropets prec if euro==1, vce(robust) noconstant
drop  tstateuropets
reg abst prec if euro==1, vce(robust)
gen tstateuropet=(gamma - 3.811285*se)/se
eststo: reg tstateuropet prec if euro==1, vce(robust) noconstant
drop  tstateuropet
gen gammaeurocorr=gamma - 3.811285*se
twoway (scatter prec gammaeurocorr) if euro==1 &  abs(gammaeurocorr)<0.5
graph save Graph "C:\European_Economic_Policies\Data_meta\funnelcorr_euro.gph", replace
metatrim gammaeurocorr se
drop gammaeurocorr
esttab using eurote.tex, booktabs replace compress scalars(rmse) width(1\hsize) title(Tests of the true effect, euro\label{tab:eurote}) mtitles("MST" "PETS" "Corr.\ PET") addnote("Meta-response variable: logt for MST, tstat for PETS and Corr.\ PET") star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label alignment(D{.}{.}{-1}) page(dcolumn) nonumber nogaps
eststo clear
******************************************************************************
*non-euro
twoway (scatter prec gamma) if euro==0
graph save Graph "C:\European_Economic_Policies\Data_meta\funnel_noneuro.gph", replace
gen tstatnon=(gamma - 0.66)/se
twoway (scatter tstatnon prec) if euro==0
graph save Graph "C:\European_Economic_Policies\Data_meta\galb_noneuro.gph", replace
drop tstatnon
eststo: reg tstat prec if euro==0, vce(robust)
predict res, residuals
sdtest res == 1.41421356 if euro==0
correl sqrtn prec if euro==0
drop res
rreg tstat prec if euro==0
eststo: ivregress 2sls tstat (prec = sqrtn) if euro==0, vce(robust) first
eststo: reg tstat sqrtn if euro==0, vce(robust)
esttab using noneurobias.tex, booktabs replace compress scalars(rmse) width(1\hsize) title(Tests of publication bias, non-euro\label{tab:noneurobias}) mtitles("FAT-PET" "FAIVEHR" "PROXY") addnote("Meta-response variable: tstat") star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label alignment(D{.}{.}{-1}) page(dcolumn) nonumber nogaps
eststo clear
eststo: reg logt logn if euro==0, vce(robust)
rreg logt logn if euro==0
reg gamma se2 if euro==0, vce(robust)
gen tstatnonpets=(gamma - 0.0877557*se2)/se
eststo: reg tstatnonpets prec if euro==0, vce(robust) noconstant
drop  tstatnonpets
reg abst prec if euro==0, vce(robust)
gen tstatnonpet=(gamma - 1.808193*se)/se
eststo: reg tstatnonpet prec if euro==0, vce(robust) noconstant
drop  tstatnonpet
gen gammanoncorr=gamma -  1.808193*se
metatrim gammanoncorr se
drop gammanoncorr
esttab using noneurote.tex, booktabs replace compress scalars(rmse) width(1\hsize) title(Tests of the true effect, non-euro\label{tab:noneurote}) mtitles("MST" "PETS" "Corr.\ PET") addnote("Meta-response variable: logt for MST, tstat for PETS and Corr.\ PET") star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label alignment(D{.}{.}{-1}) page(dcolumn) nonumber nogaps
eststo clear
******************************************************************************
*all
twoway (scatter prec gamma)
graph save Graph "C:\European_Economic_Policies\Data_meta\funnel_all.gph", replace
gen tstatall=(gamma - 0.2)/se
twoway (scatter tstatall prec)
graph save Graph "C:\European_Economic_Policies\Data_meta\galb_all.gph", replace
drop tstatall
eststo: reg tstat prec, vce(robust)
predict res, residuals
sdtest res == 1.41421356
correl sqrtn prec
drop res
eststo: ivregress 2sls tstat (prec = sqrtn), vce(robust) first
eststo: reg tstat sqrtn, vce(robust)
esttab using allbias.tex, booktabs replace compress scalars(rmse) width(1\hsize) title(Tests of publication bias, all\label{tab:allbias}) mtitles("FAT-PET" "FAIVEHR" "PROXY") addnote("Meta-response variable: tstat") star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label alignment(D{.}{.}{-1}) page(dcolumn) nonumber nogaps
eststo clear
eststo: reg logt logn, vce(robust)
reg gamma se2, vce(robust)
gen tstatallpets=(gamma - 2.907055*se2)/se
eststo: reg tstatallpets prec, vce(robust) noconstant
drop  tstatallpets
reg abst prec, vce(robust)
gen tstatallpet=(gamma -  5.18296*se)/se
eststo: reg tstatallpet prec, vce(robust) noconstant
drop  tstatallpet
gen gammaallcorr=gamma -  5.18296*se
twoway (scatter prec gammaallcorr) if abs(gammaallcorr)<1
graph save Graph "C:\European_Economic_Policies\Data_meta\funnelcorr_all.gph", replace
metatrim gammaallcorr se
drop gammaallcorr
drop _LCI _UCI _WT
esttab using allte.tex, booktabs replace compress scalars(rmse) width(1\hsize) title(Tests of the true effect, all\label{tab:allte}) mtitles("MST" "PETS" "Corr.\ PET") addnote("Meta-response variable: logt for MST, tstat for PETS and Corr.\ PET") star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label alignment(D{.}{.}{-1}) page(dcolumn) nonumber nogaps
eststo clear
******************************************************************************
*Explanatory meta-regression
******************************************************************************
*MST (all)
correl logn woman usa repec topfive latex year year2 rose nitsch baldwin denardis taglioni tenreyro euro shortrun panel countries years postwar impact
reg logt logn  woman usa repec topfive latex year year2 rose nitsch baldwin denardis taglioni tenreyro euro shortrun panel countries years postwar impact, vce(robust)
eststo: reg logt logn rose baldwin taglioni euro shortrun countries, vce(robust)
collin logn rose baldwin taglioni euro shortrun countries
estat ovtest
predict res, residuals
sktest res
drop res
reg logt logn rose baldwin taglioni euro shortrun countries year year2, vce(robust)
test year year2
reg logt logn latex nitsch baldwin taglioni euro shortrun countries
collin logn latex nitsch baldwin taglioni euro shortrun countries
estat ovtest
whitetst
predict res, residuals
sktest res
drop res
reg logt logn latex nitsch baldwin taglioni euro shortrun countries year year2
test year year2
reg logt logn latex baldwin taglioni euro shortrun countries, vce(robust)
collin logn latex baldwin taglioni euro shortrun countries
estat ovtest
predict res, residuals
sktest res
drop res
rreg logt logn  woman usa repec topfive latex year year2 rose nitsch baldwin denardis taglioni tenreyro euro shortrun panel countries years postwar impact
eststo: rreg logt logn repec latex baldwin denardis tenreyro euro shortrun panel countries years
collin logn repec latex baldwin denardis tenreyro euro shortrun panel countries years
rreg logt logn repec latex baldwin denardis tenreyro euro shortrun panel countries years year year2
test year year2
******************************************************************************
*MST (non-euro)
correl logn woman usa repec topfive latex year year2 rose nitsch tenreyro shortrun panel countries years postwar impact if euro==0
reg logt logn woman usa repec topfive latex rose nitsch tenreyro shortrun panel countries years postwar impact if euro==0
eststo: reg logt logn latex rose nitsch shortrun panel years if euro==0, vce(robust)
collin logn latex rose nitsch shortrun panel years if euro==0
estat ovtest
predict res, residuals
sktest res if euro==0
drop res
rreg logt logn latex panel countries if euro==0
******************************************************************************
*MST (euro)
correl logn woman usa repec topfive latex year year2 baldwin denardis taglioni shortrun panel countries years impact if euro==1
reg logt logn woman usa repec topfive latex year year2 baldwin denardis taglioni shortrun panel countries years impact if euro==1, vce(robust)
eststo: reg logt logn topfive baldwin taglioni shortrun countries years if euro==1, vce(robust)
collin logn topfive baldwin taglioni shortrun countries years if euro==1
estat ovtest
predict res, residuals
sktest res if euro==1
drop res
rreg logt logn topfive latex baldwin denardis taglioni shortrun countries impact if euro==1
******************************************************************************
esttab using mst.tex, booktabs replace compress r2 ar2 width(1\hsize) title(Explanatory meta-regression analysis: multiple MST\label{tab:mst}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mtitles("OLS" "IRLS" "OLS" "OLS") addnote("meta-response variable: logt") mgroups("all studies" "non-Euro" "Eurozone", pattern(1 0 1 1) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) page(dcolumn) alignment(D{.}{.}{-1}) nonumber nogaps
eststo clear
******************************************************************************
*FIXED EFFECTS (all)
gen rose_se=rose/se
gen nitsch_se=nitsch/se
gen baldwin_se=baldwin/se
gen denardis_se=denardis/se
gen taglioni_se=taglioni/se
gen tenreyro_se=tenreyro/se
gen euro_se=euro/se
gen shortrun_se=shortrun/se
gen countries_se=countries/se
gen years_se=years/se
gen postwar_se=postwar/se
gen impact_se=impact/se
correl prec woman usa repec topfive latex panel year year2 rose_se nitsch_se baldwin_se denardis_se taglioni_se tenreyro_se euro_se shortrun_se countries_se years_se postwar_se impact_se
reg tstat prec woman usa repec topfive latex panel year year2 rose_se nitsch_se baldwin_se denardis_se taglioni_se tenreyro_se euro_se shortrun_se countries_se years_se postwar_se impact_se, vce(robust)
reg tstat prec panel rose_se nitsch_se baldwin_se denardis_se euro_se shortrun_se countries_se impact_se, vce(robust)
eststo: reg tstat prec panel rose_se nitsch_se baldwin_se denardis_se euro_se shortrun_se countries_se impact_se year year2, vce(robust)
test year year2
collin prec panel rose_se nitsch_se baldwin_se denardis_se euro_se shortrun_se countries_se impact_se year year2
estat ovtest
predict res, residuals
sktest res
sdtest res == 1
drop res
reg tstat prec rose_se nitsch_se baldwin_se denardis_se euro_se shortrun_se countries_se impact_se, vce(robust)
estat ovtest
collin prec rose_se nitsch_se baldwin_se denardis_se euro_se shortrun_se countries_se impact_se
predict res, residuals
sktest res
drop res
eststo: rreg tstat prec repec topfive latex panel year year2 rose_se nitsch_se tenreyro_se euro_se shortrun_se countries_se years_se
test year year2
predict res, residuals
sdtest res == 1
drop res
******************************************************************************
*FIXED EFFECTS (non-euro)
correl prec woman usa repec topfive latex panel year year2 rose_se nitsch_se tenreyro_se shortrun_se countries_se years_se postwar_se impact_se if euro==0
reg tstat prec woman usa repec topfive latex panel rose_se nitsch_se tenreyro_se shortrun_se countries_se years_se postwar_se impact_se if euro==0, vce(robust)
eststo: reg tstat prec latex panel tenreyro_se countries_se years_se postwar_se if euro==0, vce(robust)
collin prec latex panel tenreyro_se countries_se years_se postwar_se if euro==0
estat ovtest
predict res, residuals
sktest res if euro==0
sdtest res == 1 if euro==0
drop res
reg tstat prec latex panel tenreyro_se countries_se years_se postwar_se year year2 if euro==0, vce(robust)
test year year2
reg tstat prec panel rose_se countries_se year year2 if euro==0, vce(robust)
test year year2
collin prec panel rose_se countries_se year year2 if euro==0
estat ovtest
predict res, residuals
sktest res if euro==0
sdtest res == 1 if euro==0
drop res
rreg tstat prec woman usa repec topfive latex panel rose_se nitsch_se tenreyro_se shortrun_se countries_se years_se postwar_se impact_se if euro==0
rreg tstat prec usa repec topfive countries_se years_se if euro==0
predict res, residuals
sdtest res == 1 if euro==0
drop res
rreg tstat prec usa repec topfive countries_se years_se year year2 if euro==0
test year year2
******************************************************************************
*FIXED EFFECTS (euro)
correl prec woman usa repec topfive latex year year2 baldwin_se denardis_se taglioni_se shortrun_se panel countries_se years_se impact_se if euro==1
eststo: reg tstat prec baldwin_se denardis_se years_se impact_se if euro==1, vce(robust)
collin prec baldwin_se denardis_se years_se impact_se if euro==1
estat ovtest
predict res, residuals
sktest res if euro==1
sdtest res == 1 if euro==1
drop res
reg tstat prec baldwin_se denardis_se years_se impact_se year year2 if euro==1, vce(robust)
test year year2
rreg tstat prec woman usa repec topfive latex panel baldwin_se denardis_se taglioni_se shortrun_se countries_se years_se impact_se if euro==1
predict res, residuals
sdtest res == 1 if euro==1
******************************************************************************
esttab using fixed.tex, booktabs replace compress r2 ar2 scalars(rmse) width(1\hsize) title(Explanatory meta-regression analysis: fixed effects\label{tab:fixed}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label mtitles("OLS" "IRLS" "OLS" "OLS") addnote("meta-response variable: tstat") mgroups("all studies" "non-Euro" "Eurozone", pattern(1 0 1 1) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) page(dcolumn) alignment(D{.}{.}{-1}) nonumber nogaps
eststo clear
******************************************************************************
*RANDOM EFFECTS (all)
metareg gamma logn woman usa repec topfive latex year year2 rose nitsch baldwin denardis taglioni tenreyro euro shortrun panel countries years postwar impact, wsse(se)
metareg gamma year year2 rose tenreyro euro, wsse(se)
test year year2
metareg gamma rose tenreyro euro, wsse(se)
eststo: metareg gamma woman rose baldwin euro, wsse(se)
metareg gamma woman rose baldwin euro year year2, wsse(se)
test year year2
eststo: metareg gamma woman repec rose baldwin denardis tenreyro euro shortrun, wsse(se)
metareg gamma woman repec rose baldwin denardis tenreyro euro shortrun year year2, wsse(se)
test year year2
******************************************************************************
*RANDOM EFFECTS (non-euro)
metareg gamma logn woman usa repec topfive latex year year2 rose nitsch tenreyro shortrun panel countries years postwar impact if euro==0, wsse(se)
eststo: metareg gamma woman topfive nitsch panel if euro==0, wsse(se)
******************************************************************************
*RANDOM EFFECTS (euro)
metareg gamma logn woman usa repec topfive latex year year2 baldwin denardis taglioni shortrun panel countries years impact if euro==1, wsse(se)
eststo: metareg gamma logn usa topfive baldwin denardis taglioni shortrun years if euro==1, wsse(se)
******************************************************************************
esttab using random.tex, booktabs replace compress width(1\hsize) title(Explanatory meta-regression analysis: random effects\label{tab:random}) star(\sym{\dagger} 0.10 \sym{*} 0.05 \sym{**} 0.01) label addnote("meta-response variable: gamma") mgroups("all studies" "non-Euro" "Eurozone", pattern(1 0 1 1) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) page(dcolumn) alignment(D{.}{.}{-1}) nomtitles nogaps
eststo clear
******************************************************************************
end