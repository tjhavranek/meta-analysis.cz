rm(list=ls())
###################
# loading library #
###################
library(BMS)
library(foreign)

###################
# set directory   #
###################
setwd("C:\\CNB\\_Hampl\\BIS\\BMA\\")

#######################################
# Parameters for in-sample estimation #
#######################################
burn_       = 0.5e6
iter_       = 1e6
gprior      = "UIP"
modelprior  = "uniform"
order_PIP   = F
separator   = ";"

################
# loading data #
################
data_nw         = read.dta("spillovers.dta")

##############
# BMA estimation #
##############
BMA_nw  = bms(data_nw, burn=burn_,iter=iter_, g=gprior, mprior=modelprior, nmodel=5000, mcmc="bd", user.int=FALSE)
BMA_nw_res<-coef(BMA_nw,std.coefs=F, order.by.pip = order_PIP, exact=T,include.constant = T)
write.table(BMA_nw_res,"BMA_nw.csv",sep=separator)
image(BMA_nw, cex=0.6)
summary(BMA_nw)
plot(BMA_nw)


#Prior sensitivity
#BMA_ps1  = bms(data_nw, burn=burn_,iter=iter_, g="UIP", mprior="uniform", nmodel=5000, mcmc="bd", user.int=FALSE)
BMA_ps2  = bms(data_nw, burn=burn_,iter=iter_, g="BRIC", mprior="random", nmodel=5000, mcmc="bd", user.int=FALSE)
BMA_ps3  = bms(data_nw, burn=burn_,iter=iter_, g="hyper=BRIC", mprior="random", nmodel=5000, mcmc="bd", user.int=FALSE)

plotComp("UIP and Uniform"=BMA_nw,"BRIC and Random"=BMA_ps2,"HyperBRIC and Random"=BMA_ps3,add.grid=F,cex.xaxis=0.7)

#################################
# Mallows model averaging (FMA) #
#################################
library(xtable)
library(LowRankQP)
data_nw <-na.omit(data_nw)
x.data <- data_nw[,-1]
const_<-c(1)
x.data <-cbind(const_,x.data)
x <- sapply(1:ncol(x.data),function(i){x.data[,i]/max(x.data[,i])})   
scale.vector <- as.matrix(sapply(1:ncol(x.data),function(i){max(x.data[,i])}))        
Y <- as.matrix(data_nw[,1])
output.colnames <- colnames(x.data)
full.fit <- lm(Y~x-1)
beta.full <- as.matrix(coef(full.fit))
M <- k <- ncol(x)
n <- nrow(x)
beta <- matrix(0,k,M)
e <- matrix(0,n,M)
K_vector <- matrix(c(1:M))
var.matrix <- matrix(0,k,M)
bias.sq <- matrix(0,k,M)             
# MMA Estimator using orthogonalization 
  for(i in 1:M)
    {
        X <- as.matrix(x[,1:i])
        ortho <- eigen(t(X)%*%X)
        Q <- ortho$vectors ; lambda <- ortho$values 
        x.tilda <- X%*%Q%*%(diag(lambda^-0.5,i,i))
        beta.star <- t(x.tilda)%*%Y
        beta.hat <- Q%*%diag(lambda^-0.5,i,i)%*%beta.star
        beta[1:i,i] <- beta.hat
        e[,i] <- Y-x.tilda%*%as.matrix(beta.star)
        bias.sq[,i] <- (beta[,i]-beta.full)^2
        var.matrix.star <- diag(as.numeric(((t(e[,i])%*%e[,i])/(n-i))),i,i)
        var.matrix.hat <- var.matrix.star%*%(Q%*%diag(lambda^-1,i,i)%*%t(Q))
        var.matrix[1:i,i] <- diag(var.matrix.hat)
        var.matrix[,i] <- var.matrix[,i]+ bias.sq[,i]
      } # End loop over i
e_k <- e[,M]
sigma_hat <- as.numeric((t(e_k)%*%e_k)/(n-M))
G <- t(e)%*%e
a <- ((sigma_hat)^2)*K_vector
A <- matrix(1,1,M)
b <- matrix(1,1,1)
u <- matrix(1,M,1)
optim <- LowRankQP(Vmat=G,dvec=a,Amat=A,bvec=b,uvec=u,method="LU",verbose=FALSE)
weights <- as.matrix(optim$alpha)
beta.scaled <- beta%*%weights
final.beta <- beta.scaled/scale.vector
std.scaled <- sqrt(var.matrix)%*%weights
final.std <- std.scaled/scale.vector
results.reduced <- as.matrix(cbind(final.beta,final.std))
rownames(results.reduced) <- output.colnames; colnames(results.reduced) <- c("Coefficient", "Sd. Err")
MMA.fls <- round(results.reduced,4)
MMA.fls <- data.frame(MMA.fls)
t <- as.data.frame(MMA.fls$Coefficient/MMA.fls$Sd..Err)
MMA.fls$pv <-round( (1-apply(as.data.frame(apply(t,1,abs)), 1, pnorm))*2,3)
MMA.fls$names <- rownames(MMA.fls)
names <- c(colnames(data_nw))
names <- c(names,"const_")
MMA.fls <- MMA.fls[match(names, MMA.fls$names),]
MMA.fls$names <- NULL
MMA.fls

######################
# Save the workspace #
######################
save.image("results_spillovers.Rdata")

