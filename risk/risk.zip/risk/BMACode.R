rm(list=ls())

library("data.table")
library("BMS")
library("xlsx")
library("RStata")
library("stargazer")
library("readstata13")
library("foreign")
library("ggplot2")
library("reshape2")
library("corrplot")
library("installr")
library("puniform")
library("metafor")
library("dmetar")
library("haven")
library("tidyverse")
library("meta")

#Set directory
setwd("G:/My Drive/Risk Aversion/Code")


# Stata data for P-uniform* ####


# Median of all studies
data <- read_dta("pcurve_med.dta")
data <- na.omit(data)
puni_star(yi = data$rramed, vi = data$variancemed, side="right", method="ML",alpha = 0.1, control=list( max.iter=10000,tol=0.001,reps=10000, int=c(-2000,2000), verbose=TRUE))
# alternative
puni_star(tobs = data$tstatmed, ni = data$nobs_med, alpha = 0.1, side = "right", method = "ML", control=list(stval.tau=1, max.iter=10000,tol=0.001,reps=1000, int=c(0,2), verbose=TRUE))


## Economics journals
data <- read_dta("pcurve_med_econ.dta")
data <- na.omit(data)
puni_star(yi = data$rramec, vi = data$variancemec, side="right", method="ML",alpha = 0.1, control=list( max.iter=1000,tol=0.1,reps=10000, int=c(-2,2), verbose=TRUE))
# alternative
puni_star(tobs = data$tstatmec, ni = data$nobs_med, alpha = 0.1, side = "right", method = "ML", control=list(stval.tau=0.1, max.iter=10000,tol=0.001,reps=1000, int=c(0,2), verbose=TRUE))


## Finance journals
data <- read_dta("pcurve_med_fin.dta")
data <- na.omit(data)

puni_star(yi = data$rramfin, vi = data$variancemfin, side="right", method="ML",alpha = 0.05, control=list( max.iter=1000,tol=0.001,reps=10000, int=c(0,2), verbose=TRUE))
# alternative
puni_star(tobs = data$tstatmfin, ni = data$nobs_med, alpha = 0.05, side = "right", method = "ML", boot=TRUE,  control=list(stval.tau=0.1, max.iter=10000,tol=0.001,reps=1000, int=c(-20,20), verbose=FALSE))


#Stem method ####
source("stem_method.R") #https://github.com/Chishio318/stem-based_method

stem_data = read.dta13("stem_data.dta")

win <- stem_data[1:3]

# Mean values for the sample with combined standard errors 
mwin <-aggregate(cbind(win$rra_win, win$se_win), by=list(ID=win$idstudy), mean)
colnames(mwin) <- c("id","merra","mese")

# Stem
stem <- stem(mwin$merra, mwin$mese, param)
View(stem$estimates)





#### economics journals 

stem_data_econ  = read.dta13("stem_data_econ.dta")

econ <- stem_data_econ[1:3]

# Mean values for the sample with combined standard errors 
mecon <-aggregate(cbind(econ$rraec, econ$seec), by=list(ID=econ$idstudy), mean)
colnames(mecon) <- c("id","merra","mese")

# Stem
stemecon <- stem(mecon$merra, mecon$mese, param)
View(stemecon$estimates)


#### finance journals

stem_data_fin  = read.dta13("stem_data_fin.dta")

fin <- stem_data_fin[1:3]

# Mean values for the sample with combined standard errors 
mfin <- aggregate(cbind(fin$rrafin, fin$sefin), by=list(ID=fin$idstudy), mean)
colnames(mfin) <- c("id","merra","mese")

# Stem
stemfin <- stem(mfin$merra, mfin$mese, param)
View(stemfin$estimates)



##### Loading data for BMA ##### 
data_base     = read.dta13("bma_base.dta")


# Columns' names

colnames(data_base)  <- c("RRA", "Standard error", "Time span","Midpoint","Panel","Cross-section","Monthly", "Quarterly", "Annual", "US", "EU", "Asia", "Developing", "Other countries", 
                            "EZW", "Long-run risk", "Fixed IES", "Separate durability", "Total consumption", "NDS and others", "Exact Euler", "Second", "Human capital" ,"Stockholder","Non-stockholder", 
                            "Experimental", "Implied", "GMM","ML","OLS","Simulations","First lag", "Second lag", "Instrument", "Market return included","Consumption included", 
                            "Publication year", "Top journal","Economics journal","Finance journal", "Citations")



keep <- c("RRA", "Standard error","Time span","Midpoint","Panel","Cross-section", "Monthly", "Quarterly", "US", "EU", "Asia", "Developing",
          "EZW", "Long-run risk", "Fixed IES", "Separate durability", "Total consumption","Exact Euler", "Human capital", "Stockholder","Non-stockholder",
          "Experimental","Implied","GMM","Simulations","Second lag", "Market return included","Consumption included",
          "Publication year", "Top journal","Finance journal", "Citations")


df_base  <- data_base[keep]

## Correlation matrix

cormatd<-round(cor(subset(df_base, select= -RRA)),3)
cormatd[upper.tri(cormatd)] <- NA

#Heatmap
pdf("corrolation.pdf")

cor1<-corrplot(cormatd,method = "color", tl.col = "black", tl.cex=0.7, cl.cex=0.7,
               col = colorRampPalette(c("darkred","white","midnightblue"))(100), 
               number.digits = 2, number.cex = 0.35, addCoef.col = "black", type= "lower", tl.srt=45)

dev.off()









#####     B  M  A     #####




##Parameters for in-sample estimation

burn_       = 1e6
iter_       = 2e6
gprior      = "UIP"
modelprior  = "uniform"
order_PIP   = F
separator   = ","


# All studies - UIP and dilution 
BMA_dilut = bms(df_base, burn=1e5,iter=2e5, g="UIP", mprior="dilut", nmodel=10000, mcmc="bd", user.int=FALSE)
BMA_dil <- coef(BMA_dilut,std.coefs=F, order.by.pip = F, exact=T,include.constant = T)
write.table(BMA_dil,"BMA_dilut.csv",sep=separator)
image(BMA_dilut, cex=0.6, xlab="", main="")
summary(BMA_dilut)
plot(BMA_dilut)

#saving plots
pdf("bma_dilut.pdf")
image(BMA_dilut, cex=0.6, xlab="", main="", col=c("indianred","royalblue4"))
dev.off()

pdf("bma_dilut_pmp.pdf")
plot(BMA_dilut)
dev.off()



# All studies alternatives - BRIC and Random
BMA_briq = bms(df_base, burn=1e6,iter=2e6, g="BRIC", mprior="random", nmodel=10000, mcmc="bd", user.int=FALSE)
BMA_br <- coef(BMA_briq, std.coefs=F, order.by.pip = order_PIP, exact=F,include.constant = T)
write.table(BMA_br,"BMA_briq.csv",sep=separator)
image(BMA_briq, cex=0.6, xlab="", main="")
summary(BMA_briq)
plot(BMA_briq)

#saving plots
pdf("bma_briq.pdf")
image(BMA_briq, cex=0.6, xlab="", main="", col=c("indianred","royalblue4"))
dev.off()

pdf("bma_pmp_bric.pdf")
plot(BMA_briq)
dev.off()




## All studies alternatives - HQ and Random 
BMA_hq = bms(df_base, burn=1e6,iter=2e6, g="HQ", mprior="random", nmodel=10000, mcmc="bd", user.int=FALSE)
BMA_h<-coef(BMA_hq,std.coefs=F, order.by.pip = order_PIP, exact=F,include.constant = T)
write.table(BMA_h,"BMA_hq.csv",sep=separator)
image(BMA_hq, cex=0.6, xlab="", main="")
summary(BMA_hq)
plot(BMA_hq)

#saving plots
pdf("bma_hq.pdf")
image(BMA_hq, cex=0.6, xlab="", main="", col=c("indianred","royalblue4"))
dev.off()

pdf("bma_pmp_hq.pdf")
plot(BMA_hq)
dev.off()



## PIP across different priors

pdf("comb.pdf")
plotComp("UIP and Dilution"=BMA_dilut,"BRIC and Random"=BMA_briq,"HQ and Random"=BMA_hq, add.grid=F, cex.xaxis=0.6)
dev.off()





########### New test on AK 2019 ####

options(repos = c(skranz = 'https://skranz.r-universe.dev',
                  CRAN = 'https://cloud.r-project.org'))
install.packages('MetaStudies')

library(MetaStudies)



alldata= read.csv("ak-win.csv", header = FALSE)
colnames(alldata) = c("X","sigma")


econdata= read.csv("ak-econ.csv", header = FALSE)
colnames(econdata) = c("X","sigma")
econdata<- subset(econdata,X/sigma < 7)


findata= read.csv("ak-fin.csv", header = FALSE)
colnames(findata) = c("X","sigma")



# list of data sets
dd=vector(mode = "list", length = 3)
dd[[1]] <- alldata
dd[[2]] <- econdata
dd[[3]] <- findata




# list of results
resl = vector(mode = "list", length = 3)
i.cor = vector(mode = "list", length = 3)



for (i in 1:3) {
  ms = metastudies_estimation(X=dd[[i]]$X,sigma=dd[[i]]$sigma,model = "t",cutoffs = c(1.96,2.58),symmetric = TRUE)
  dat.log = ms$dat %>%
    filter(abs(X) >0, sigma >0) %>%
    mutate(X = log(abs(X)), sigma=log(sigma))
  i.cor[[i]] = cov.wt(dat.log[,1:2],1/dat.log$pub.prob, cor=TRUE)$cor[1,2]
  resl[[i]]=bootstrap_specification_tests(dd[[i]]$X, dd[[i]]$sigma, B = 500)
}

i.cor
resl




