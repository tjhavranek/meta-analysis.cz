clear all
use risk.dta
save risk.dta, replace
*data to panel
xtset idstudy

*log using rra.log, replace
*set more off

*ssc install fre
*ssc install ivreg2, replace
*ssc install estout
*ssc install winsor2
*ssc install ranktest
*ssc install outreg2
*ssc install boottest

********************************************************************************
****************************CALIBRATED RRA**************************************
********************************************************************************

sum rra if estimated==0, detail

gen crramean = r(mean)
gen crramedian = r(p50)


sum rra if estimated==1, detail
gen rramean = r(mean)
gen rramedian = r(p50)


********************************************************************************
************  Histograms for rra ***********************************************
********************************************************************************

*calibrated
local m1 = crramean
local m2 = crramedian
hist rra if rra<50 & rra>0 & estimated==0, scheme(white_tableau) width(.8) fcolor(gs11*.2) lcolor(black*.8) lstyle(thin)  frequency ytitle("Frequency", size(small)) xlabel(0(10)50, format(%9.0f) nogrid  labsize(small)) ylabel(0(20)80, format(%9.0f)  labsize(small))  xtitle("Calibrated-set RRA", size(small)) ///
saving(_hist_calib, replace) graphregion(color(white)) legend(off) /// 
addplot (scatteri 0 `m1' 80 `m1', color (navy8) lwidth(.15) c(1) m(i) || scatteri 0 `m2' 80 `m2', color (navy8) lpattern(dash) lwidth(0.15) c(1) m(i))
 graph use _hist_calib
graph export _hist_calib.pdf, replace


*calibrated & estimated  
local m1 = rramean
local m2 = crramean
twoway (hist rra if estimated==1  & rra<50 & rra>-10, scheme(white_tableau) width(1) freq color(navy8) lcolor(black) lwidth(vvvthin) ytitle("Frequency", size(small)) xlabel(-10(10)50, format(%9.0f) nogrid labsize(small)) ylabel(0(50)250, format(%9.0f)  labsize(small))  xtitle("RRA", size(small))) ///
(hist rra if estimated==0 & rra<50 & rra>-10, width(1) freq  color(gs12*.5) lcolor (black) lwidth(vvvthin)) (scatteri 0 `m2' 250 `m2', color (black) c(1) m(i) lwidth(0.15)) (scatteri 0 `m1' 250 `m1', color (black) lpattern(dash) lwidth(0.15) c(1) m(i))(scatteri  250 `m1' (8) "23.36", mlabcolor (black) msymbol(none) msize(small))  (scatteri 250 `m2' (8) "14.33",  mlabcolor (black) msymbol(none) msize(small)),  ///
xlabel(, format(%9.0f)) graphregion(color(white)) legend(size(small) order(2 "Calibrated-set" 1 "Estimated") bmargin(medium) ring(1) position(6) rows(1))  saving(_hist_estcalib, replace)
 *saving plot
graph use _hist_estcalib
graph export _hist_estcalib.pdf, replace


*calibrated & estimated 
local m1 = rramean
local m2 = crramean
twoway (hist rra if estimated==1  & rra<50 & rra>-10, scheme(white_tableau) width(.85) percent color(navy8) lcolor(black) lwidth(vvvthin) ytitle(" Relative frequency (%)", size(small)) xlabel(-10(10)50, format(%9.0f) nogrid labsize(small)) ylabel(0(5)25, format(%9.0f)  labsize(small))  xtitle("RRA", size(small))) ///
(hist rra if estimated==0 & rra<50 & rra>-10, width(.85) percent  color(gs12*.5) lcolor (black) lwidth(vvvthin)) (scatteri 0 `m2' 25 `m2', color (black) c(1) m(i) lwidth(0.15)) (scatteri 0 `m1' 25 `m1', color (black) lpattern(dash) lwidth(0.15) c(1) m(i))(scatteri  25 `m1' (8) "23.36", mlabcolor (black) msymbol(none) msize(small))  (scatteri 25 `m2' (8) "14.33",  mlabcolor (black) msymbol(none) msize(small)),  ///
xlabel(, format(%9.0f)) graphregion(color(white)) legend(size(small) order(2 "Calibrated-set" 1 "Estimated") bmargin(medium) ring(1) position(6) rows(1))  saving(_hist_estcalib_perc, replace)
 *saving plot
graph use _hist_estcalib_perc
graph export _hist_estcalib_perc.pdf, replace


*calibrated & estimated (economics)
twoway (hist rra if estimated==1  & finjournal==0 & rra<50 & rra>-10, scheme(white_tableau) width(.8) percent color(navy8) lcolor(black) lwidth(vvvthin) ytitle(" Relative frequency (%)", size(small)) xlabel(-10(10)50, format(%9.0f) nogrid labsize(small)) ylabel(0(5)35, format(%9.0f)  labsize(small))  xtitle("RRA", size(small))) ///
(hist rra if estimated==0 &  finjournal==0 &  rra<50 & rra>-10, width(.8) percent  color(gs12*.5) lcolor (black) lwidth(vvvthin)), ///
graphregion(color(white)) legend(size(small) order(2 "Calibrated-set" 1 "Estimated") bmargin(medium) ring(1) position(6) rows(1)) saving(_hist_estcalib_econperc, replace)
 *saving plot
graph use _hist_estcalib_econperc
graph export _hist_estcalib_econperc.pdf, replace


*calibrated & estimated (finance)
twoway (hist rra if estimated==0  & finjournal==1 & rra<50 & rra>-10, scheme(white_tableau) width(.9) percent color(gs12*.5) lcolor(black) lwidth(vvvthin) ytitle(" Relative frequency (%)", size(small)) xlabel(-10(10)50, format(%9.0f) nogrid labsize(small)) ylabel(0(5)20, format(%9.0f)  labsize(small))  xtitle("RRA", size(small))) ///
(hist rra if estimated==1 &  finjournal==1 &  rra<50 & rra>-10, width(.9) percent  color(navy8)  lcolor (black) lwidth(vvvthin)), ///
graphregion(color(white)) legend(size(small) order(1 "Calibrated-set" 2 "Estimated") bmargin(medium) ring(1) position(6) rows(1)) saving(_hist_estcalib_finperc, replace)
 *saving plot
graph use _hist_estcalib_finperc
graph export _hist_estcalib_finperc.pdf, replace


********************************************************************************
****************************Estimated RRA***************************************
********************************************************************************
drop if estimated==0 

drop estimated

save risk.dta, replace

use risk.dta, clear

********************************************************************************
*VARIABLES 
********************************************************************************

*Generating new variables from original SEs

replace se=0.0001 if se==0 
gen prec = 1/se
gen prec2 = 1/(se*se)
gen lnprec = ln(prec)
gen prec5= prec*.5

replace tstat = rra/se if tstat == . 
gen t_abs = abs(tstat)
replace t_abs = 0 if t_abs==.
gen pval = 2*(1 - normal(t_abs))

gen invperstudy = 1/perstudy

gen lnpyear = ln(pyear+1)

gen lntimespan = ln(timespan)

gen lnmidpoint = ln(midpoint+1)

gen lnyearcits = ln(yearcits+1)

gen lnobs = ln(obs)
gen invobs = 1/obs
gen invobs2 = invobs*invobs
gen obs2 = obs*obs
gen sqrtnobs = sqrt(obs)
gen invsqrtnobs = 1/sqrtnobs 



*Winsorizing original variables
winsor2 rra se, suffix(_win) cuts(10 90) label
gen tstat_win = rra_win/se_win
gen prec_win = 1/se_win
gen prec2_win = 1/(se_win*se_win)
gen lnprec_win = ln(prec_win)


egen study_mean = mean(rra), by(idstudy)
egen study_median = median(rra), by(idstudy)
egen study_prec_median = median(prec), by(idstudy)


*************************** SUMMARY STATISTICS *********************************
********************************************************************************

sum  se rra, d

sum rra se if finjournal==0, d

sum rra se if finjournal==1, d


**publication
sum rra if top == 1
gen topmean = r(mean)

sum rra if top == 0
gen ntopmean = r(mean)

sum rra if econjournal == 1
gen ecomean = r(mean)

sum rra if finjournal == 1
gen finmean = r(mean)



********************************************************************************
*Plots and graphs
********************************************************************************

*Boxplot of all studies
graph  hbox rra  if rra<50 & rra>0, over(paper, sort(paper)) scheme(white_tableau) box(1,lcolor(black) fcolor(gs6*.5)) marker(1,msymbol(circle_hollow) mcolor(gs5)) ytitle("RRA estimates") xsize(6) ysize(9) scale(.5) graphregion(color(white)) saving(_box, replace)
*saving plot
// graph use _box2
 graph export _box.pdf, replace


********************************PUBLICATION BIAS********************************
********************************************************************************

*Funnel plot of all estimates - Egger et al., 1997

gen precalt = prec if idstudy!=55
replace precalt = prec*0.01 if idstudy==55
replace precalt = prec*0.01 if prec<55 & prec>5 & rra<9 & rra>2

scatter precalt rra if rra<10 & rra>-10 & prec<100, scheme(white_tableau) msymbol(circle_hollow) xlabel(-10(5)10, format(%9.0f) nogrid labsize(small)) ///
xtitle("RRA",size(small)) ///
ytitle("Precision of estimates (1/SE)",size(small)) ///
ylabel(0(20)100, format(%9.0f)  labsize(small))   ///
legend(off) graphregion(color(white)) saving(_funnel_all2, replace) 
saving plot
graph export _funnel_all.pdf, replace


********************************************************************************
*FUNNEL ASYMMETRY TESTS - Publication bias 
********************************************************************************
*data to panel
xtset idstudy


***all

*WLS regresssion, non-weighted, clustered on study level only
eststo: ivreg2 tstat_win prec_win, cluster(idstudy)
boottest prec_win, nograph
boottest _cons, nograph

*FE regresssion, clustered on study level only
eststo: xtreg tstat_win prec_win, fe cluster(idstudy)

*BE regresssion
eststo: xtreg tstat_win prec_win, be

*Study, p-weighted by inverse of number per study estimates, clustered on study level only 
eststo: ivreg2 tstat_win prec_win [pweight=invperstudy], cluster(idstudy)
boottest prec_win, nograph
boottest _cons, nograph

*saving PET tests
esttab using wPET.tex, se booktabs replace compress title(Linear funnel asymmetry tests - PET /// \
	\label{tab: PET}) mtitles("WLS" "FE" "BE" "Study") /// \
	///addnote("Standard errors are clustered at the study level.") /// \
	star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) /// \
	label nonumber width(1\\hsize)
eststo clear


***economics journals 

*WLS regresssion, non-weighted, clustered on study level only
eststo: ivreg2 tstat_win prec_win if econjournal==1, cluster(idstudy)
boottest prec_win, nograph
boottest _cons, nograph

*FE regresssion, clustered on study level only
eststo: xtreg tstat_win prec_win if econjournal==1, fe cluster(idstudy)

*BE regresssion
eststo: xtreg tstat_win prec_win if econjournal==1, be

*Study, p-weighted by inverse of number per study estimates, clustered on study level only 
eststo: ivreg2 tstat_win prec_win [pweight=invperstudy] if econjournal==1, cluster(idstudy)
boottest prec_win, nograph
boottest _cons, nograph

*saving PET tests
esttab using wPETecon.tex, se booktabs replace compress title(Linear funnel asymmetry tests - PET /// \
	\label{tab: PET}) mtitles("WLS" "FE" "BE" "Study") /// \
	///addnote("Standard errors are clustered at the study level.") /// \
	star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) /// \
	label nonumber width(1\\hsize)
eststo clear


***finance journals 

*WLS regresssion, non-weighted, clustered on study level only
eststo: ivreg2 tstat_win prec_win if econjournal==0, cluster(idstudy)
boottest prec_win, nograph
boottest _cons, nograph

*FE regresssion, clustered on study level only
eststo: xtreg tstat_win prec_win if econjournal==0, fe cluster(idstudy)

*BE regresssion
eststo: xtreg tstat_win prec_win if econjournal==0, be

*Study, p-weighted by inverse of number per study estimates, clustered on study level only 
eststo: ivreg2 tstat_win prec_win [pweight=invperstudy] if econjournal==0, cluster(idstudy)
boottest prec_win, nograph
boottest _cons, nograph

*saving PET tests
esttab using wPETfin.tex, se booktabs replace compress title(Linear funnel asymmetry tests - PET /// \
	\label{tab: PET}) mtitles("WLS" "FE" "BE" "Study") /// \
	///addnote("Standard errors are clustered at the study level.") /// \
	star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) /// \
	label nonumber width(1\\hsize)
eststo clear


********************************************************************************
*Non-linear techniques - Publication bias
********************************************************************************

*****TOP 10 method - Stanley et al. 2010
summarize prec, detail
local top10bound1 = r(p90)
summarize rra prec if prec > `top10bound1'

summarize prec if prec!=., detail
local top10bound2 = r(p90)
summarize rra prec if prec > `top10bound2' & prec!=.



********************************************************************************
*****WAAP - Ioaninidis et al. 2017

*all
reg tstat_win prec_win, noconstant
local c = e(b)[1,1]
reg tstat_win prec_win if se<`c'/2.8, noconstant cluster(idstudy)


*econ journals 
reg tstat_win prec_win if econjournal == 1, noconstant
local c = e(b)[1,1]
reg tstat_win prec_win if econjournal ==1 & se<`c'/2.8, noconstant cluster(idstudy)

   
*finance journals
reg tstat_win prec_win if econjournal == 0, noconstant
local c = e(b)[1,1]
reg tstat_win prec_win if econjournal == 0 & se<`c'/2.8, noconstant cluster(idstudy)



********************************************************************************
*****Andrews & Kasy 2019
*https://maxkasy.github.io/home/metastudy

*all
outsheet rra_win se_win using ak-win.csv, comma replace 

*econ journals
outsheet rra_win se_win if econjournal == 1 using ak-econ.csv, comma replace

*finance journals
outsheet rra_win se_win if econjournal == 0 using ak-fin.csv, comma replace


********************************************************************************
*****Endogenous kink - Bom & Rachinger 2019

save risk.dta, replace


gen rraec = rra_win if econjournal == 1
gen seec = se_win if econjournal == 1
gen rrafin = rra_win if econjournal == 0
gen sefin = se_win if econjournal == 0 

save risk.dta.dta, replace

*all
quietly {

clear 
use risk.dta, replace
rename rra_win bs
rename se_win sebs
log using kink_win.log, text replace
 
gen ones=1
   
sum
local M=r(N)
sum sebs
local sebs_min=r(min)
local sebs_max=r(max)
  
gen sebs2=sebs^2
gen wis=ones/sebs2
gen bs_sebs=bs/sebs
gen ones_sebs=ones/sebs

gen bswis=bs*wis
sum wis
local wis_sum=r(sum)


* FAT-PET
regress bs_sebs ones_sebs ones,noc
local pet=_b[ones_sebs]
local t1_linreg = (_b[ones_sebs]/_se[ones_sebs])
local b_lin=_b[ones_sebs]
local Q1_lin = e(rss)
di `t1_linreg'
local abs_t1_linreg = abs(`t1_linreg')
di `abs_t1_linreg'


* PEESE
regress bs_sebs ones_sebs sebs,noc
local peese=_b[ones_sebs]
local b_sq=_b[ones_sebs]
local Q1_sq = e(rss)
di `Q1_sq'
 

* FAT-PET-PEESE

if `abs_t1_linreg' > invt(`M-2', 0.975) {
    local combreg=`b_sq'
	local Q1=`Q1_sq'
	}
else {
    local combreg=`b_lin'
	local Q1=`Q1_lin'
}

* estimation of random effects variance component
local sigh2hat=max(0,`M'*((`Q1'/(`M'-e(df_m)-1))-1)/`wis_sum') 
local sighhat=sqrt(`sigh2hat') 


* Cutoff value for EK
if `combreg'>1.96*`sighhat' {
    local a1=(`combreg'-1.96*`sighhat')*(`combreg'+1.96*`sighhat')/(2*1.96*`combreg')
}
else {
	local a1=0
	}
    
	
	rename bs bs_original
	rename bs_sebs bs
	rename ones_sebs constant
	rename ones pub_bias
	
	
    noisily: display "EK regression: "

if `a1'>`sebs_min' & `a1'<`sebs_max' {
    gen sebs_a1=sebs-`a1' if sebs>`a1'
	replace sebs_a1=0 if sebs<=`a1'
	gen pubbias=sebs_a1/sebs
	noisily regress bs constant pubbias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pubbias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pubbias]
}
else if `a1'<`sebs_min' {
    noisily regress bs constant pub_bias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pub_bias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pub_bias]
}
else if `a1'>`sebs_max' {
    noisily regress bs constant, noc
	local b0_ek=_b[constant]
	local sd0_ek=_se[constant]	
}
noisily: display "EK's mean effect estimate (alpha1) and standard error:"
noisily: di `b0_ek' 
noisily: di `sd0_ek' 
noisily: display "EK's publication bias estimate (delta) and standard error:"
noisily: di `b1_ek' 
noisily: di `sd1_ek' 

log close
}

rename bs_original rra_win
rename sebs se_win


*economics journals 
quietly {
clear 
use risk.dta, replace
rename rraec bs
rename seec sebs


log using kink_win.log, text replace
 
gen ones=1
   
sum
local M=r(N)
sum sebs
local sebs_min=r(min)
local sebs_max=r(max)
  
gen sebs2=sebs^2
gen wis=ones/sebs2
gen bs_sebs=bs/sebs
gen ones_sebs=ones/sebs

gen bswis=bs*wis
sum wis
local wis_sum=r(sum)


* FAT-PET
regress bs_sebs ones_sebs ones,noc
local pet=_b[ones_sebs]
local t1_linreg = (_b[ones_sebs]/_se[ones_sebs])
local b_lin=_b[ones_sebs]
local Q1_lin = e(rss)
di `t1_linreg'
local abs_t1_linreg = abs(`t1_linreg')
di `abs_t1_linreg'


* PEESE
regress bs_sebs ones_sebs sebs,noc
local peese=_b[ones_sebs]
local b_sq=_b[ones_sebs]
local Q1_sq = e(rss)
di `Q1_sq'
 

* FAT-PET-PEESE

if `abs_t1_linreg' > invt(`M-2', 0.975) {
    local combreg=`b_sq'
	local Q1=`Q1_sq'
	}
else {
    local combreg=`b_lin'
	local Q1=`Q1_lin'
}

* estimation of random effects variance component
local sigh2hat=max(0,`M'*((`Q1'/(`M'-e(df_m)-1))-1)/`wis_sum') 
local sighhat=sqrt(`sigh2hat') 


* Cutoff value for EK
if `combreg'>1.96*`sighhat' {
    local a1=(`combreg'-1.96*`sighhat')*(`combreg'+1.96*`sighhat')/(2*1.96*`combreg')
}
else {
	local a1=0
	}
    
	
	rename bs bs_original
	rename bs_sebs bs
	rename ones_sebs constant
	rename ones pub_bias
	
	
    noisily: display "EK regression: "

if `a1'>`sebs_min' & `a1'<`sebs_max' {
    gen sebs_a1=sebs-`a1' if sebs>`a1'
	replace sebs_a1=0 if sebs<=`a1'
	gen pubbias=sebs_a1/sebs
	noisily regress bs constant pubbias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pubbias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pubbias]
}
else if `a1'<`sebs_min' {
    noisily regress bs constant pub_bias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pub_bias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pub_bias]
}
else if `a1'>`sebs_max' {
    noisily regress bs constant, noc
	local b0_ek=_b[constant]
	local sd0_ek=_se[constant]	
}
noisily: display "EK's mean effect estimate (alpha1) and standard error:"
noisily: di `b0_ek' 
noisily: di `sd0_ek' 
noisily: display "EK's publication bias estimate (delta) and standard error:"
noisily: di `b1_ek' 
noisily: di `sd1_ek' 

log close
}

rename bs_original rraec
rename sebs seec


*finanace journals 
quietly {
clear 
use risk.dta, replace
rename rrafin bs
rename sefin sebs


log using kink_win.log, text replace
 
gen ones=1
   
sum
local M=r(N)
sum sebs
local sebs_min=r(min)
local sebs_max=r(max)
  
gen sebs2=sebs^2
gen wis=ones/sebs2
gen bs_sebs=bs/sebs
gen ones_sebs=ones/sebs

gen bswis=bs*wis
sum wis
local wis_sum=r(sum)


* FAT-PET
regress bs_sebs ones_sebs ones,noc
local pet=_b[ones_sebs]
local t1_linreg = (_b[ones_sebs]/_se[ones_sebs])
local b_lin=_b[ones_sebs]
local Q1_lin = e(rss)
di `t1_linreg'
local abs_t1_linreg = abs(`t1_linreg')
di `abs_t1_linreg'


* PEESE
regress bs_sebs ones_sebs sebs,noc
local peese=_b[ones_sebs]
local b_sq=_b[ones_sebs]
local Q1_sq = e(rss)
di `Q1_sq'
 

* FAT-PET-PEESE

if `abs_t1_linreg' > invt(`M-2', 0.975) {
    local combreg=`b_sq'
	local Q1=`Q1_sq'
	}
else {
    local combreg=`b_lin'
	local Q1=`Q1_lin'
}

* estimation of random effects variance component
local sigh2hat=max(0,`M'*((`Q1'/(`M'-e(df_m)-1))-1)/`wis_sum') 
local sighhat=sqrt(`sigh2hat') 


* Cutoff value for EK
if `combreg'>1.96*`sighhat' {
    local a1=(`combreg'-1.96*`sighhat')*(`combreg'+1.96*`sighhat')/(2*1.96*`combreg')
}
else {
	local a1=0
	}
    
	
	rename bs bs_original
	rename bs_sebs bs
	rename ones_sebs constant
	rename ones pub_bias
	
	
    noisily: display "EK regression: "

if `a1'>`sebs_min' & `a1'<`sebs_max' {
    gen sebs_a1=sebs-`a1' if sebs>`a1'
	replace sebs_a1=0 if sebs<=`a1'
	gen pubbias=sebs_a1/sebs
	noisily regress bs constant pubbias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pubbias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pubbias]
}
else if `a1'<`sebs_min' {
    noisily regress bs constant pub_bias, noc
	local b0_ek=_b[constant]
	local b1_ek=_b[pub_bias]
	local sd0_ek=_se[constant]
	local sd1_ek=_se[pub_bias]
}
else if `a1'>`sebs_max' {
    noisily regress bs constant, noc
	local b0_ek=_b[constant]
	local sd0_ek=_se[constant]	
}
noisily: display "EK's mean effect estimate (alpha1) and standard error:"
noisily: di `b0_ek' 
noisily: di `sd0_ek' 
noisily: display "EK's publication bias estimate (delta) and standard error:"
noisily: di `b1_ek' 
noisily: di `sd1_ek' 

log close
}

rename bs_original rrafin
rename sebs sefin


********************************************************************************
*****Stem-based method - Furukawa 2019 - Switch to the R-part of the code*******

*all
preserve
keep idstudy rra_win se_win
saveold stem_data, replace
restore

*economics journals 
preserve 
keep idstudy rraec seec 
drop if missing(seec)
save stem_data_econ.dta, replace
restore

*finanace journals 
preserve 
keep idstudy rrafin sefin
drop if missing(sefin)
save stem_data_fin.dta, replace
restore


********************************************************************************
* Publication bias - p-uniform* (van Aert & van Assen, 2019) - code for Stata & R
********************************************************************************

gen variance_win = se_win*se_win

*median 
bysort idstudy: egen variancemed = median(variance_win)
*bysort idstudy: egen tstat_med = median(tstatistics)
bysort idstudy: egen rramed = median(rra_win)
bysort idstudy: egen semed = median(se_win)
bysort idstudy: egen tstatmed = median(tstat_win)

preserve
collapse  (lastnm) rramed variancemed semed tstatmed  (p50) nobs_med=obs, by(idstudy)
save "pcurve_med.dta", replace
restore


* economics journals 
bysort idstudy: egen variancemec = median(variance_win) if econjournal == 1
bysort idstudy: egen rramec = median(rra_win)  if econjournal == 1
bysort idstudy: egen semec = median(se_win)  if econjournal == 1
bysort idstudy: egen tstatmec = median(tstat_win)  if econjournal == 1


preserve
collapse  (lastnm) rramec variancemec semec tstatmec  (p50) nobs_med=obs, by(idstudy)
save "pcurve_med_econ.dta", replace
restore


* finance journals 
bysort idstudy: egen variancemfin = median(variance_win) if econjournal == 0
bysort idstudy: egen rramfin = median(rra_win)  if econjournal == 0
bysort idstudy: egen semfin = median(se_win)  if econjournal == 0
bysort idstudy: egen tstatmfin = median(tstat_win)  if econjournal == 0


preserve
collapse  (lastnm) rramfin variancemfin semfin tstatmfin (p50) nobs_med=obs, by(idstudy)
save "pcurve_med_fin.dta", replace
restore


preserve 
keep rra_win variance_win se_win tstat_win obs
order rra_win variance_win se_win tstat_win obs
saveold pcurve_all.dta, replace
restore

********************************************************************************
*Regressing estimates on standard errors when p < 0.005 
********************************************************************************

***estimates with  p-val < 0.005

*OLS regresssion, non-weighted, clustered on study level only
eststo: ivreg2 rra_win se_win if tstat_win < -2.80 | tstat_win > 2.80, cluster(idstudy)
boottest se_win, nograph
boottest _cons, nograph

eststo: ivreg2 rra_win se_win if  tstat_win < -2.80 & econjournal==1 | tstat_win > 2.80 & econjournal==1, cluster(idstudy)
boottest se_win, nograph
boottest _cons, nograph

eststo: ivreg2 rra_win se_win if tstat_win < -2.80 & econjournal==0 | tstat_win > 2.80 & econjournal==0, cluster(idstudy)
boottest se_win, nograph
boottest _cons, nograph

eststo: ivreg2 rra_win se_win if tstat_win < -2.80  & top==1 | tstat_win > 2.80 & top==1, cluster(idstudy)
boottest se_win, nograph
boottest _cons, nograph

eststo: ivreg2 rra_win se_win if tstat_win < -2.80 & implied==1 | tstat_win > 2.80 & implied==1, cluster(idstudy)
boottest se_win, nograph
boottest _cons, nograph

eststo: ivreg2 rra_win se_win if  tstat_win < -2.80 & exp==1 | tstat_win > 2.80 & exp==1, cluster(idstudy)
boottest se_win, nograph
boottest _cons, nograph

eststo: ivreg2 rra_win se_win if tstat_win < -2.80 & us==1 | tstat_win > 2.80 & us==1, cluster(idstudy)
boottest se_win, nograph
boottest _cons, nograph

eststo: ivreg2 rra_win se_win if tstat_win < -2.80 &  developing==1 | tstat_win > 2.80 &  developing==1, cluster(idstudy)
boottest se_win, nograph
boottest _cons, nograph

eststo: ivreg2 rra_win se_win if tstat_win < -2.80 & ogmls==1 | tstat_win > 2.80 & ogmls==1, cluster(idstudy)
boottest se_win, nograph
boottest _cons, nograph

eststo: ivreg2 rra_win se_win if tstat_win < -2.80 &  gmm==1 | tstat_win > 2.80 &  gmm==1, cluster(idstudy)
boottest se_win, nograph
boottest _cons, nograph

eststo: ivreg2 rra_win se_win if  tstat_win < -2.80 & quarterly==1 | tstat_win > 2.80 & quarterly==1, cluster(idstudy)
boottest se_win, nograph
boottest _cons, nograph

eststo: ivreg2 rra_win se_win if  tstat_win < -2.80 & annual==1 | tstat_win > 2.80 & annual==1, cluster(idstudy)
boottest se_win, nograph
boottest _cons, nograph


*saving PET tests
esttab using PETpval.tex, replace se title(Linear funnel asymmetry tests - PET /// \
	\label{tab: PET}) mtitles("All" "Econ" "Fin" "Top" "Implied" "Experimental" "N. America" "Developing" "OLS" "GMM"  "Quarterly" "Annual") /// \
	///addnote("Standard errors are clustered at the study level.") /// \
	star(\sym{*} 0.10 \sym{**} 0.05 \sym{***} 0.01) /// \
	label nonumber width(1\\hsize)
eststo clear
 
 
********************************************************************************
*DATA PREPARATION FOR BMA

*Baseline
preserve
keep  rra_win se_win lnpyear  lntimespan lnmidpoint  exp ez panel	csection  monthly	quarterly annual	us eu	asia developing others	sepdur	totalc	ndsothers  longrisk	fixed_ies implied	exact	second	gmm	ml	ogmls	simul	stockhold	nonstockhold	firstlag seclag	 instrument mreturn	consinclude	hcapital top	econjournal	 finjournal	 lnyearcits
order rra_win se_win  lntimespan lnmidpoint panel csection  monthly quarterly annual us eu asia developing others  ez longrisk fixed_ies  sepdur totalc ndsothers exact second hcapital stockhold nonstockhold exp implied gmm ml ogmls simul firstlag seclag  instrument mreturn consinclude  lnpyear top econjournal finjournal lnyearcits
saveold bma_base, replace
restore




* Now switch to the R-PART OF THE CODE: BMA


*************************FREQUENTIST CHECK OF BMA*******************************
********************************************************************************



// sum se_win  lntimespan lnmidpoint panel csection  monthly quarterly annual eu asia others ez longrisk fixed_ies  sepdur totalc exact hcapital stockhold nonstockhold  implied ml ogmls simul firstlag seclag mreturn consinclude  lnpyear top finjournal lnyearcits
// vif

* Regressors with pip > 50%
sum  se_win csection monthly annual us ez  sepdur  stockhold  finjournal 
correlate se_win csection monthly annual us ez  sepdur  stockhold  finjournal 
collin se_win csection monthly annual us ez  sepdur  stockhold  finjournal 


*UIP prior

eststo: reg rra_win se_win csection monthly annual  us ez  sepdur  stockhold  finjournal , cluster(idstudy)

estout, style(tex) cells("b se t p")

eststo clear 

* alternative
sum  se_win csection quarterly us ez  sepdur  stockhold  finjournal 
correlate se_win csection quarterly us ez  sepdur  stockhold  finjournal 
collin se_win csection quarterly us ez  sepdur  stockhold  finjournal 






********************************BEST PRACTICE***********************************
********************************************************************************


sum rra_win se_win lntimespan lnmidpoint panel csection  monthly quarterly annual us eu asia developing others ez longrisk fixed_ies  sepdur totalc ndsothers exact second hcapital stockhold nonstockhold exp implied gmm ogmls simul  seclag   mreturn consinclude  lnpyear top econjournal finjournal lnyearcits

ivreg2 rra_win se_win lntimespan lnmidpoint panel csection monthly quarterly  us eu asia developing  ez longrisk fixed_ies sepdur totalc exact  hcapital stockhold nonstockhold exp implied gmm simul seclag mreturn consinclude  lnpyear top  finjournal lnyearcits, cluster (idstudy)



***Subjective best practice***

*****Our subjective results


*base
lincom _cons + 0*se_win + 4.94*lntimespan + 4.5*lnmidpoint + 0.04*panel + 0.20*csection + 0.25*monthly + 0.51*quarterly + 0.74*us + 0.11*eu + 0.03*asia + 0.06*developing  + 0.90*ez + 0.32*longrisk + .25*fixed_ies + 0.13*sepdur + 0*totalc +0*exact + 1*hcapital + 0.12*stockhold + 0.05*nonstockhold + 0.03*exp + 0*implied + 0.59*gmm + 0.13*simul + 0.16*seclag  + 1*mreturn + 1*consinclude + 2.8*lnpyear + 1*top + 0.42*finjournal + 4.41*lnyearcits


*economics literature
lincom _cons + 0*se_win + 4.94*lntimespan + 4.5*lnmidpoint + 0.04*panel + 0.20*csection + 0.25*monthly + 0.51*quarterly + 0.74*us + 0.11*eu + 0.03*asia + 0.06*developing  + 0.90*ez + 0.32*longrisk + .25*fixed_ies + 0.13*sepdur + 0*totalc +0*exact + 1*hcapital + 0.12*stockhold + 0.05*nonstockhold + 0.03*exp + 0*implied + 0.59*gmm + 0.13*simul + 0.16*seclag  + 1*mreturn + 1*consinclude + 2.8*lnpyear + 1*top + 0*finjournal + 4.41*lnyearcits


*finance literature
lincom _cons + 0*se_win + 4.94*lntimespan + 4.5*lnmidpoint + 0.04*panel + 0.20*csection + 0.25*monthly + 0.51*quarterly + 0.74*us + 0.11*eu + 0.03*asia + 0.06*developing  + 0.90*ez + 0.32*longrisk + .25*fixed_ies + 0.13*sepdur + 0*totalc +0*exact + 1*hcapital + 0.12*stockhold + 0.05*nonstockhold + 0.03*exp + 0*implied + 0.59*gmm + 0.13*simul + 0.16*seclag  + 1*mreturn + 1*consinclude + 2.8*lnpyear + 1*top + 1*finjournal + 4.41*lnyearcits


*USA
lincom _cons + 0*se_win + 4.94*lntimespan + 4.5*lnmidpoint + 0.04*panel + 0.20*csection + 0.25*monthly + 0.51*quarterly + 1*us + 0*eu + 0*asia + 0*developing  + 0.90*ez + 0.32*longrisk + .25*fixed_ies + 0.13*sepdur + 0*totalc +0*exact + 1*hcapital + 0.12*stockhold + 0.05*nonstockhold + 0.03*exp + 0*implied + 0.59*gmm + 0.13*simul + 0.16*seclag  + 1*mreturn + 1*consinclude + 2.8*lnpyear + 1*top + 0.42*finjournal + 4.41*lnyearcits


*EU
lincom _cons + 0*se_win + 3.44*lntimespan + 4.5*lnmidpoint + 0.04*panel + 0.20*csection + 0.25*monthly + 0.51*quarterly + 0*us + 1*eu + 0*asia + 0*developing  + 0.90*ez + 0.32*longrisk + .25*fixed_ies + 0.13*sepdur + 0*totalc +0*exact + 1*hcapital + 0.12*stockhold + 0.05*nonstockhold + 0.03*exp + 0*implied + 0.59*gmm + 0.13*simul + 0.16*seclag  + 1*mreturn + 1*consinclude + 2.8*lnpyear + 1*top + 0.42*finjournal + 4.41*lnyearcits


*Stockholder
lincom _cons + 0*se_win + 3.44*lntimespan + 4.5*lnmidpoint + 0.04*panel + 0.20*csection + 0.25*monthly + 0.51*quarterly + 0.74*us + .11*eu + 0.03*asia + 0.06*developing  + 0.90*ez + 0.32*longrisk + .25*fixed_ies + 0.13*sepdur + 0*totalc +0*exact + 1*hcapital + 1*stockhold + 0*nonstockhold + 0.03*exp + 0*implied + 0.59*gmm + 0.13*simul + 0.16*seclag  + 0.32*mreturn + 0.35*consinclude + 2.8*lnpyear + 1*top + 0.42*finjournal + 4.41*lnyearcits


*GMM
lincom _cons + 0*se_win + 4.94*lntimespan + 4.5*lnmidpoint + 0.04*panel + 0.20*csection + 0.25*monthly + 0.51*quarterly + 0.74*us + .11*eu + 0.03*asia + 0.06*developing  + 0.90*ez + 0.32*longrisk + .25*fixed_ies + 0.13*sepdur + 0*totalc +0*exact + 1*hcapital + 0.12*stockhold + 0.05*nonstockhold + 0.03*exp + 0*implied + 1*gmm + 0*simul + 0.16*seclag  + 1*mreturn + 1*consinclude + 2.8*lnpyear + 1*top + 0.42*finjournal + 4.41*lnyearcits


*quarterly
lincom _cons + 0*se_win + 4.94*lntimespan + 4.5*lnmidpoint + 0.04*panel + 0.20*csection + 0*monthly + 1*quarterly + 0.74*us + .11*eu + 0.03*asia + 0.06*developing  + 0.90*ez + 0.32*longrisk + .25*fixed_ies + 0.13*sepdur + 0*totalc +0*exact + 1*hcapital + 0.12*stockhold + 0.05*nonstockhold + 0.03*exp + 0*implied + 0.59*gmm + 0.13*simul + 0.16*seclag  + 1*mreturn + 1*consinclude + 2.8*lnpyear + 1*top + 0.42*finjournal + 4.41*lnyearcits





*Revised subjective results based on frequentist check


ivreg2 rra_win10 se_win10 csection  quarterly  us   ez  sepdur  stockhold   finjournal, cluster (idstudy)

*base
lincom _cons + 0*se_win10 + 0.2*csection +  0.51*quarterly + 0.74*us  + 0.5*ez + 0.12*sepdur + 0.12*stockhold + 0.42*finjournal 
*economics literature
lincom _cons + 0*se_win10 + 0.2*csection + 0.51*quarterly + 0.74*us  + 0.5*ez + 0.12*sepdur + 0.12*stockhold + 0*finjournal 
*finance literature
lincom _cons + 0*se_win10 + 0.2*csection + 0.49*quarterly + 0.74*us  + 0.5*ez + 0.12*sepdur + 0.12*stockhold + 1*finjournal 
*USA
lincom _cons + 0*se_win10 + 0.2*csection + 0.49*quarterly + 1*us + 0.5*ez + 0.12*sepdur + 0.12*stockhold + 0.42*finjournal
*finance, US, annual
lincom _cons + 0*se_win10 + 0.2*csection   +0*quarterly  + 1*us  + 0.5*ez + 0.12*sepdur + 0.12*stockhold + 1*finjournal 
*quarterly
lincom _cons + 0*se_win10 + 0.2*csection + 1*quarterly + 0.74*us + 0.5*ez + 0.13*sepdur + 0.12*stockhold + 0.42*finjournal 
ivreg2 rra_win10 se_win10 csection   quarterly  us  eu ez  sepdur  stockhold   finjournal, cluster (idstudy)
*EU
lincom _cons + 0*se_win10 + 0.2*csection  + .5*quarterly + 0*us + 1*eu  + 0.9*ez + 0.13*sepdur + 0.12*stockhold + 0.42*finjournal 
ivreg2 rra_win10 se_win10 csection  quarterly  us  eu ez  sepdur  stockhold   finjournal, cluster (idstudy)
*economics, EU, quarterly
lincom _cons + 0*se_win10 + 0.2*csection + 1*quarterly + 0*us + 1*eu + 0.9*ez + 0.13*sepdur + 0.12*stockhold + 0*finjournal 










log close	
exit, clear
