* Replication file for: Betthaeuser, Bach-Mortensen, and Engzell 2022 
* A systematic review and meta-analysis of the impact of the COVID-19 pandemic on learning
* Date: 2022-10-026 / Version: Stata 17.0

* Required packages
* fre from http://fmwww.bc.edu/repec/bocode/f
* gtools from http://github.com/mcaceresb/stata-gtools
* R libraries: haven, ggplot2, estimatr
* labmask from http://www.stata-journal.com/software/sj8-2/
* missings from http://fmwww.bc.edu/repec/bocode/m
* rsource from http://fmwww.bc.edu/RePEc/bocode/r
* schemepack from http://fmwww.bc.edu/repec/bocode/s
* vioplot from http://fmwww.bc.edu/RePEc/bocode/v

* Set your working directory to the replication-package root before running.
*cd "[set directory]"
* (set the working directory to the replication-package root, e.g. cd "/path/to/luskova_et_al_2026")
set scheme gg_tableau

***************************************************************************
* Import estimates of learning deficit 
***************************************************************************

// Source: authors' own data extraction

clear
import excel "data/extraction_data.xlsx", sheet("Sheet1") firstrow clear
ren date strdate
gen date = date(strdate,"MY")
format %td date
destring es se n_study, force replace

missings dropobs _all, force // drop empty rows in data
missings dropvars _all, force // drop empty cols in data

save "data/main.dta", replace

***************************************************************************
* Figure 1: Study identification and selection process (PRISMA diagram)
***************************************************************************

//// THIS FIGURE COMPILED MANUALLY BY THE AUTHORS //// 

***************************************************************************
* Figure 2a: Risk of bias rating using ROBINS-I
***************************************************************************

//// THIS FIGURE COMPILED MANUALLY BY THE AUTHORS //// 

***************************************************************************
* Figure 2b: Distribution of z-scores across estimates
***************************************************************************

clear 
use "data/main.dta"

gen ln_z = ln(z)
sum ln_z

tw (hist ln_z, bin(25) start(-2.53) gap(15)) ///
	(function y = normalden(x,`r(mean)',`r(sd)'), range(-2.3025851 7.481556) lw(thick) lc(cranberry)) ///
	, ytit(Density, size(medsmall)) ylab(, notick) ///
	yscale(range(0 .35)) xlab(-2.3025851 "0.1" 0 "1" 2.3025851 "10" 4.6051702 "100" 6.9077553 "1000") ///
	xline(.67294447, lw(thick) lc(cranberry) lp(dash)) yline(0, lc(black) lp(solid)) /// 
	text(.27 -.2 "z = 1.96", size(medsmall) color(cranberry)) xtit("z-statistic (log scale)", size(medsmall)) ///
	graphr(margin(0 0 9.5 0)) plotr(margin(0 0 0 0) fc(white)) text(.32 -3.5 "B", size(huge)) ///
	legend(off) ysize(2.35) xsize(4) scale(1.8) name(zcurve, replace) 
	
*graph export "output/replication/zcurve.pdf", replace
graph export "output/figures/figA1_zscore_betthaeuser.pdf", replace

	
***************************************************************************
* Figure 3: Forest plot showing individual estimates by study
***************************************************************************

clear 
use "data/main.dta"

* average effect size and standard errors across grades
collapse es se (sum) n_study, by(study)

* set meta analysis variables
meta set es se, random studylab(study) studysize(n_study)

* forest plot
meta forest _id _plot _esci _weight, xline(0, lw(thin) lc(cranberry)) /// 
		sort(es) ciopts(lc(black) mlc(black) mfc(black) lw(medium)) ///
		markeropts(mc("31 119 180")) omarkeropts(mc(cranberry)) ///
		body(size(huge)) coltit(size(huge)) plotr(c(white) ic(white)) ///
		xlab(-.8(.2).2, labs(huge) notick) name(forest, replace) tdistribution

*graph export "output/replication/forest.pdf", replace
graph export "output/figures/figA2_forest.pdf", replace

***************************************************************************
* Figure 4: Estimates by date of measurement
***************************************************************************

// Note: this part calls R from within Stata using -rsource-

clear 
use "data/main.dta"

* set R options
clear
global Rterm_path "/usr/local/bin/R"
global Rterm_options `"--vanilla"'

* call R
rsource, terminator(rstop)

# Required packages
library(ggplot2)
library(estimatr)
library(haven)
set.seed(86753) 

# Read in data
# setwd("[set directory]")
# (set the working directory to the replication-package root, e.g. setwd("/path/to/luskova_et_al_2026"))


data <- read_dta("data/main.dta")

# Define colorpalette
mycolors <- c("#000000", "#FFFFFF", "#3CB44B", "#FF7F00", "#42D4F4", "#BFEF45", "#815375", "#FFC81D", "#CE8BAE", "#999999", "#BF862B", "#E41A1C", "#FFD8B1", "#BD6253", "#3A85A8")

# pdf("output/replication/timeline.pdf", height = 4.5, width = 10)
pdf("output/figures/figA3_temporal.pdf", height = 4.5, width = 10)

ggplot(data=data) + 
  geom_smooth(mapping = aes(date, es), color = "darkgrey", method = 'lm_robust', method.args = list(cluster = data$study)) +
  geom_jitter(mapping = aes(x=date, y=es, fill = country, size = n_study), 
              shape = 21, alpha = 1, position=position_jitter(width=5, height=0)) + 
  scale_fill_manual(values = mycolors) +
  scale_x_date(date_breaks = "2 months", date_labels =  "%b %Y") +
  scale_y_continuous(breaks = seq(-.8, .4, by = .2)) +
  geom_hline(yintercept=0, linetype="dashed") +
  xlab("Date") + ylab("Learning deficit (SD)") +
  guides(size = F, fill=guide_legend(title="", override.aes = list(size = 5))) +
  theme_bw()

dev.off()

rstop

***************************************************************************
* Figure 5: Harvest plot of evidence on educational inequality
***************************************************************************

//// THIS FIGURE COMPILED MANUALLY BY THE AUTHORS //// 

***************************************************************************
* Figure 6: Variation by individual- and country-level characteristics
***************************************************************************

global opts "plotr(fc(white)) yline(-.95, lc(black) lp(solid) lw(thin)) yline(0, lc(cranberry) lp(shortdash)) yscale(range(-.9 0.4)) ylab(-.75(.25).25, notick) ytit("Effect size ({it:d})") nodraw"

clear 
use "data/main.dta"

* additional variable construction
gen math = subject == "Math"
gen sec =  prim_sec == "Secondary"
gen midinc = 0	
foreach j in "Brazil" "Colombia" "Mexico" "South Africa" {
		replace midinc = 1 if country==`"`j'"'
	}

* plot
vioplot es, over(math) name(math, replace) ///
   xtit("Subject") xlab(1 "Reading" 2 "Math") text(.4 .45 "A", size(vlarge)) $opts

vioplot es, over(sec) name(sec, replace) ///
   xtit("Level of education") xlab(1 "Primary" 2 "Secondary") text(.4 .45 "B", size(vlarge)) $opts

vioplot es, over(midinc) name(midinc, replace) ///
   xtit("Country income level") xlab(1 "High income" 2 "Middle income") text(.4 .45 "C", size(vlarge)) $opts

graph combine math sec midinc, ysize(5) xsize(15) r(1) scale(1.8) imargin(zero) name(moderators, replace)
*graph export "output/replication/moderators.pdf", replace
graph export "output/figures/figA4_violin.pdf", replace

* significance tests 
reg es math, robust cl(study)
reg es sec, robust cl(study)
reg es midinc, robust cl(study)

mixed es math || study: 
mixed es sec || study: 
mixed es midinc || study: 

* box plots estimates
bysort math: sum es, det
bysort sec: sum es, det
bysort midinc: sum es, det

* estimate for trend line
reg es month, robust cl(study)
mixed es month || study: 

//// END OF MAIN ANALYSIS FILE //// 
