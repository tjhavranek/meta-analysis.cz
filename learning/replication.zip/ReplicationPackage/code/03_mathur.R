# ==============================================================================
# 03_mathur.R
# Publication bias and p-hacking in the effect of COVID-19 on learning
# Luskova, Buliskeria, Elminejad, Havranek, Irsova, Jurajda, Kapicka
#
# PRODUCES:
#   Table 4 Panel A: MAN, FE-SR4, RE-SR4
#            Panel B: s-values
#            output/tables/table4_panelA.txt
#            output/tables/table4_panelB.txt
#   Figure 6: Significance funnel plot
#            output/figures/fig06_significance_funnel.pdf
#
# NOTE: Affirmative results in this dataset are NEGATIVE and statistically
#       significant (learning deficits). We set favor_positive = FALSE
#       throughout. See notes/note_RTMA_sign.txt for details on the sign issue
#       in multibias_meta, and the custom multibias_new() fix used in
#       04_phacking.R.
# ==============================================================================

source(here::here("code", "00_setup.R")) 

dat <- dat %>%
  mutate(affirmative = es < 0 & p < 0.05)


# Panel A: Worst-case and selection-ratio-adjusted estimates ----

# MAN: meta-analysis of non-affirmative studies (worst-case benchmark)
# Extract the worst_case row from return_worst_meta = TRUE
man_res <- pubbias_meta(
  yi              = dat$es,
  vi              = dat$vi,
  cluster         = dat$study_id,
  favor_positive  = FALSE,
  selection_ratio = 2,           # selection ratio does not affect MAN row
  return_worst_meta = TRUE
)
cat("\n--- MAN (worst-case) ---\n")
print(man_res$stats)
# MAN estimate is the worst_case row
man_stats <- man_res$stats %>% filter(model == "worst_case")

# FE-SR4: fixed effects with 4-fold selection ratio
fe_sr4 <- pubbias_meta(
  yi              = dat$es,
  vi              = dat$vi,
  favor_positive  = FALSE,
  model_type      = "fixed",
  selection_ratio = 4,
  return_worst_meta = TRUE
)
cat("\n--- FE-SR4 ---\n")
print(fe_sr4$stats)
fe_sr4_stats <- fe_sr4$stats %>% filter(model == "pubbias")

# RE-SR4: robust random effects with 4-fold selection ratio
re_sr4 <- pubbias_meta(
  yi              = dat$es,
  vi              = dat$vi,
  cluster         = dat$study_id,
  favor_positive  = FALSE,
  selection_ratio = 4
)
cat("\n--- RE-SR4 ---\n")
print(re_sr4$stats)
re_sr4_stats <- re_sr4$stats %>% filter(model == "pubbias")



# Panel B: s-values ----

# coef = 0: how strong must bias be to shift estimate to zero?
sval_0 <- pubbias_svalue(
  yi             = dat$es,
  vi             = dat$vi,
  favor_positive = FALSE,
  cluster        = dat$study_id
)
cat("\n--- s-value (null = 0) ---\n")
print(sval_0$stats)

# coef = 0.01
sval_001 <- pubbias_svalue(
  yi             = dat$es,
  vi             = dat$vi,
  favor_positive = FALSE,
  cluster        = dat$study_id,
  q              = 0.01
)
cat("\n--- s-value (null = 0.01) ---\n")
print(sval_001$stats)

# coef = 0.05
sval_005 <- pubbias_svalue(
  yi             = dat$es,
  vi             = dat$vi,
  favor_positive = FALSE,
  cluster        = dat$study_id,
  q              = 0.05
)
cat("\n--- s-value (null = 0.05) ---\n")
print(sval_005$stats)


# Summary tables (Table 4 Panels A-B) ----

tab4_panelA <- tibble(
  Method   = c("MAN", "FE-SR4", "RE-SR4"),
  N        = c(sum(!dat$affirmative, na.rm = TRUE),  # MAN uses only non-affirmative
               nrow(dat),
               nrow(dat)),
  Estimate = c(man_stats$estimate,
               fe_sr4_stats$estimate,
               re_sr4_stats$estimate),
  SE       = c(man_stats$se,
               fe_sr4_stats$se,
               re_sr4_stats$se),
  p_value  = c(man_stats$p_value,
               fe_sr4_stats$p_value,
               re_sr4_stats$p_value)
) %>% mutate(across(where(is.numeric), ~ round(., 3)))

 
tab4_panelB <- tibble(
  Null_value   = c(0, 0.01, 0.05),
  N            = c(nrow(dat), nrow(dat), nrow(dat)),
  sval_est     = c(sval_0$stats$sval_est,
                   sval_001$stats$sval_est,
                   sval_005$stats$sval_est),
  sval_ci      = c(sval_0$stats$sval_ci,
                   sval_001$stats$sval_ci,
                   sval_005$stats$sval_ci)
) %>% mutate(across(where(is.numeric), ~ round(., 2)))

print(tab4_panelA)
print(tab4_panelB)

write_txt_table(
  tab4_panelA,
  file.path(table_path, "table4_panelA.txt")
)

write_txt_table(
  tab4_panelB,
  file.path(table_path, "table4_panelB.txt")
)

# Figure 6: Significance funnel plot ----
# (Mathur and VanderWeele 2020)

fig6 <- significance_funnel(
  yi             = dat$es,
  vi             = dat$vi,
  favor_positive = FALSE,
  plot_pooled    = TRUE
)

ggsave(file.path(fig_path, "fig06_significance_funnel.pdf"),
       fig6, width = 7, height = 5)


# ------------------------------------------------------------------------------
# End of 03_mathur.R
# ------------------------------------------------------------------------------
