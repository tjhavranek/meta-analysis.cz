# ==============================================================================
# 05_caliper_pcurve.R
# Publication bias and p-hacking in the effect of COVID-19 on learning
# Luskova, Buliskeria, Elminejad, Havranek, Irsova, Jurajda, Kapicka
#
# PRODUCES: Appendix C — Caliper Test and P-Curve Analysis
#
#   Figure C1: output/figures/figC1_caliper.pdf
#   Figure C2: output/figures/figC2_pcurve.pdf
#   Table C1:  see code/betthaeuser_caliper.do (Stata)
#
# NOTE: Table C1 (full caliper test across all caliper widths and thresholds)
#       is produced by the Stata script code/betthaeuser_caliper.do, which
#       requires Stata 15 or later and main.dta from the Betthäuser et al.
#       replication package (https://doi.org/10.17605/osf.io/u8gaz).
#
#       The R code here produces Figure C1 (caliper histogram at ±0.10 around
#       z = -1.96) and Figure C2 (p-curve distribution).
#
# REFERENCES:
#   Gerber & Malhotra (2008, QJPS) — caliper test
#   Simonsohn et al. (2014, JPSP)  — p-curve
#   Elliott et al. (2022b)         — power of p-hacking tests
# ==============================================================================

source(here::here("code", "00_setup.R")) 

# Signed z-statistic: es/se (negative for learning loss estimates)
dat <- dat %>%
  mutate(z_signed = es / se)

 
# Figure C1: Caliper test histogram -----
# Caliper width ±0.10 around z = -1.96

caliper   <- 0.10
threshold <- -1.96

n_inside  <- sum(dat$z_signed >= (threshold - caliper) &
                   dat$z_signed <  threshold, na.rm = TRUE)
n_outside <- sum(dat$z_signed >= threshold &
                   dat$z_signed <  (threshold + caliper), na.rm = TRUE)

cat(sprintf(
  "Caliper test (width = %.2f around z = %.2f):\n  Inside  [%.2f, %.2f): n = %d\n  Outside [%.2f, %.2f): n = %d\n  Ratio:  %.3f\n",
  caliper, threshold,
  threshold - caliper, threshold, n_inside,
  threshold, threshold + caliper, n_outside,
  n_inside / max(n_outside, 1)
))

# Build plot data
dat_caliper <- dat %>%
  filter(!is.na(z_signed),
         z_signed >= threshold - 0.5,
         z_signed <= threshold + 0.5) %>%
  mutate(side = if_else(z_signed < threshold, "Inside (significant)", "Outside (non-significant)"))

figC1 <- ggplot(dat_caliper, aes(x = z_signed, fill = side)) +
  geom_histogram(binwidth = 0.05, boundary = threshold,
                 color = "white", alpha = 0.85) +
  geom_vline(xintercept = threshold, linetype = "dashed",
             color = "grey30", linewidth = 0.7) +
  annotate("rect",
           xmin = threshold - caliper, xmax = threshold,
           ymin = -Inf, ymax = Inf,
           fill = "#e31a1c", alpha = 0.08) +
  annotate("rect",
           xmin = threshold, xmax = threshold + caliper,
           ymin = -Inf, ymax = Inf,
           fill = "#1f78b4", alpha = 0.08) +
  annotate("text", x = threshold - caliper / 2, y = Inf,
           label = paste0("Inside\nn = ", n_inside),
           vjust = 1.5, size = 3.5, color = "#e31a1c") +
  annotate("text", x = threshold + caliper / 2, y = Inf,
           label = paste0("Outside\nn = ", n_outside),
           vjust = 1.5, size = 3.5, color = "#1f78b4") +
  scale_fill_manual(values = c("Inside (significant)"     = "#e31a1c",
                                "Outside (non-significant)" = "#1f78b4")) +
  scale_x_continuous(name = "z-score",
                     breaks = c(-2.4, -2.2, -2.0, -1.8, -1.6)) +
  scale_y_continuous(name = "Count") +
  labs(title = paste0("Caliper Test (window: \u00b1", caliper,
                      " around z = ", threshold, ")")) +
  theme_classic(base_size = 11) +
  theme(legend.position = "none")

ggsave(file.path(fig_path, "figC1_caliper.pdf"),
       figC1, width = 6, height = 4)

 
# Figure C2: P-curve distribution ----- 

# Compute two-sided p-values from signed z-scores
dat <- dat %>%
  mutate(
    # Use pnorm(-abs(z)) for numerical precision with extreme z-values
    # (avoids catastrophic cancellation from 1 - pnorm(abs(z)))
    pval_twosided  = 2 * pnorm(-abs(z)),
    pval_underflow = pval_twosided == 0
  )

n_underflow <- sum(dat$pval_underflow, na.rm = TRUE)
cat(sprintf("\nP-curve: %d / %d p-values underflow to zero\n",
            n_underflow, nrow(dat)))
cat("Note: p-curve is structurally uninformative due to extreme statistical",
    "power\n(median n =", median(dat$n_study, na.rm = TRUE),
    "; max n =", max(dat$n_study, na.rm = TRUE), ")\n")

# Bin p-values for display
pval_bins <- dat %>%
  mutate(
    bin = case_when(
      pval_underflow              ~ "Underflow (= 0)",
      pval_twosided < 0.01        ~ "[.00, .01)",
      pval_twosided < 0.02        ~ "[.01, .02)",
      pval_twosided < 0.03        ~ "[.02, .03)",
      pval_twosided < 0.04        ~ "[.03, .04)",
      pval_twosided < 0.05        ~ "[.04, .05)",
      TRUE                        ~ "p \u2265 .05"
    ) %>% factor(levels = c("Underflow (= 0)", "[.00, .01)", "[.01, .02)",
                             "[.02, .03)", "[.03, .04)", "[.04, .05)",
                             "p \u2265 .05"))
  ) %>%
  count(bin) %>%
  mutate(fill_color = if_else(bin == "Underflow (= 0)", "underflow", "regular"))

figC2 <- ggplot(pval_bins, aes(x = bin, y = n, fill = fill_color)) +
  geom_col(color = "white", width = 0.8) +
  geom_hline(yintercept = 0, color = "#e31a1c", linetype = "dashed",
             linewidth = 0.5) +
  scale_fill_manual(values = c("underflow" = "grey60", "regular" = "#1f78b4")) +
  scale_x_discrete(name = "p-value bin") +
  scale_y_continuous(name = "Count") +
  labs(title = "P-Curve Distribution",
       subtitle = paste0(n_underflow, " / ", nrow(dat),
                         " p-values underflow to zero (grey bar)",
                         " \u2014 curve is uninformative")) +
  theme_classic(base_size = 11) +
  theme(legend.position  = "none",
        axis.text.x      = element_text(size = 9),
        plot.subtitle    = element_text(size = 8, color = "grey40"))

ggsave(file.path(fig_path, "figC2_pcurve.pdf"),
       figC2, width = 7, height = 4)


# ------------------------------------------------------------------------------
# End of 05_caliper_pcurve.R
# ------------------------------------------------------------------------------
