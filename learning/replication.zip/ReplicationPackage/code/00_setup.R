# ==============================================================================
# 00_setup.R
# Publication bias and p-hacking in the effect of COVID-19 on learning
# Luskova, Buliskeria, Elminejad, Havranek, Irsova, Jurajda, Kapicka
#
# PURPOSE: Load packages, import data, derive variables, define shared
#          plot settings. Source this file at the top of every other script.
#
# DATA:    data/learning_loss_data.xlsx
#          Base estimates from Betthäuser et al. (2023), OSF: osf.io/u8gaz
#          Study-level characteristics (school level, subject, grade,
#          source tier, country) coded by the authors.
# ==============================================================================


# ------------------------------------------------------------------------------
# 1. Packages
# ------------------------------------------------------------------------------

# Path management
# install.packages("here")
library(here)            # here() — robust relative paths 
here::i_am("code/00_setup.R")
setwd(here())
# Paths below are resolved by here() relative to the replication-package
# root (located via the .here marker file in the package root). Run the
# scripts with the working directory set anywhere inside the package; no
# manual setwd() is needed. (A hard-coded setwd() to a local path was removed.)

fig_path   <- here("output", "figures")
table_path <- here("output", "tables")

# Meta-analysis & bias correction
library(metafor)        # rma(), influence(), selmodel()
library(robumeta)       # robu() — robust variance estimation (RVE)
library(weightr)        # weightfunct() — 3PSM
# RoBMA results were obtained in JASP (see notes/note_RoBMA_JASP.txt);
# uncomment below only if re-running RoBMA natively in R
# library(RoBMA)
library(PublicationBias)# pubbias_meta(), pubbias_svalue() — Mathur sensitivity
library(phacking)       # phacking_meta() — RTMA
library(multibiasmeta)  # multibias_meta() — multi-bias sensitivity
library(metabias)       # shared infrastructure for Mathur packages

# Regression & inference
library(lmtest)         # coeftest()
library(sandwich)       # vcovCL() — cluster-robust SEs

# Data manipulation
library(dplyr)
library(tidyr)
library(readxl)

# Plotting
library(ggplot2)
library(ggrepel)        # geom_text_repel() — DFBETAS labels
library(patchwork)      # multi-panel figures

# Table output
library(xtable)
library(knitr)


# ------------------------------------------------------------------------------
# 2. Data loading
# ------------------------------------------------------------------------------

dat_raw <- read_excel(here("data", "learning_loss_data.xlsx"))
names(dat_raw) <- trimws(names(dat_raw))


# ------------------------------------------------------------------------------
# 3. Variable derivations
# ------------------------------------------------------------------------------

dat <- dat_raw %>%
  mutate(
    # -- ensure numeric types --
    es      = as.numeric(es),
    se      = as.numeric(se),
    n_study = as.numeric(n_study),
    vi      = se^2,

    # -- numeric study id for clustering --
    study_id = dense_rank(study),

    # -- grade: parse ranges to numeric midpoints --
    grade = gsub("\\.0$", "", as.character(grade)),
    grade_num = case_when(
      grade == "1-5"  ~ 3.0,  grade == "1-6"  ~ 3.5,
      grade == "2-5"  ~ 3.5,  grade == "3-6"  ~ 4.5,
      grade == "6-12" ~ 9.0,  grade == "7-11" ~ 9.0,
      grade == "7-9"  ~ 8.0,
      TRUE            ~ suppressWarnings(as.numeric(grade))
    ),

    # -- subject grouping --
    subject_group = case_when(
      subject == "Math"    ~ "Mathematics",
      subject == "Reading" ~ "Reading",
      TRUE                 ~ "Mixed"
    ),

    # -- school level --
    level_group = prim_sec,

    # -- statistical significance --
    sig_group = if_else(abs(z) >= 1.96,
                        "Significant (p<0.05)", "Not significant"),

    # -- sample size categories --
    size_group = case_when(
      n_study <  10000  ~ "Small (<10k)",
      n_study < 100000  ~ "Medium (10k\u2013100k)",
      TRUE              ~ "Large (>100k)"
    ) %>% factor(levels = c("Small (<10k)",
                             "Medium (10k\u2013100k)",
                             "Large (>100k)")),

    # -- grade groups --
    grade_group = case_when(
      grade_num <= 4 ~ "Early primary (1\u20134)",
      grade_num <= 8 ~ "Middle (5\u20138)",
      TRUE           ~ "Secondary (9+)"
    ),

    # -- country grouping --
    country_group = case_when(
      country == "United States"  ~ "United States",
      country == "United Kingdom" ~ "United Kingdom",
      country == "Netherlands"    ~ "Netherlands",
      TRUE                        ~ "Other countries"
    ),

    # -- source tier --
    source_tier = case_when(
      `Published in` %in% c(
        "International Journal of Educational Development",
        "European Societies", "BE Journal of Economic Analysis & Policy",
        "AERA Open", "Proceedings of the National Academy of Sciences USA",
        "Australian Educational Researcher", "PLOS ONE",
        "International Journal of Educational Research",
        "Nature Human Behaviour", "British Educational Research Journal",
        "School Effectiveness and School Improvement", "Frontiers in Education",
        "Scandinavian Journal of Educational Research",
        "International Journal of Psychology"
      ) ~ "Tier 1: Peer-reviewed",
      `Published in` %in% c(
        "EsadeEcPol Working Paper #1 / IEB Working Paper 2022/03",
        "FBK-IRVAPP Working Papers 2022-03", "SSRN",
        "PACE Working Paper (Policy Analysis for California Education)",
        "FEB Research Report, Department of Economics (KU Leuven)",
        "Ohio State University",
        "Maastricht University, Research Centre for Education and the Labour Market (ROA)",
        "Schule w\u00e4hrend der Corona-Pandemie (Waxmann)",
        "Institut f\u00fcr Schulentwicklungsforschung, University of Dortmund"
      ) ~ "Tier 2: Working paper",
      `Published in` %in% c(
        "UK Department for Education",
        "Institute of Education Sciences (IES), US Department of Education",
        "National Foundation for Educational Research (NFER) and Education Endowment Foundation (EEF)",
        "Center for Universal Education at Brookings",
        "Education Endowment Foundation",
        "The European Liberal Forum (ELF)-FORES"
      ) ~ "Tier 3: Gov't / institutional",
      `Published in` %in% c(
        "Illuminate Education",
        "RS Assessment from Hodder Education and SchoolDash",
        "GL Assessment", "NWEA", "Istation"
      ) ~ "Tier 4: Commercial",
      TRUE ~ NA_character_
    ) %>% factor(levels = c(
      "Tier 1: Peer-reviewed",
      "Tier 2: Working paper",
      "Tier 3: Gov't / institutional",
      "Tier 4: Commercial"
    ))
  ) %>%
  # -- within-study equal weight (1/k per study, for Table 2 weighted means) --
  group_by(study) %>%
  mutate(w = 1 / n()) %>%
  ungroup()


# ------------------------------------------------------------------------------
# 4. Derived scalars (used across scripts)
# ------------------------------------------------------------------------------

mean_es    <- mean(dat$es, na.rm = TRUE)          # unweighted mean: -0.126
insig_band <- 1.96 * mean(dat$se, na.rm = TRUE)   # ±1.96 × mean(SE)


# ------------------------------------------------------------------------------
# 5. Shared ggplot2 settings
# ------------------------------------------------------------------------------

x_lab     <- "Effect size estimate (Cohen's d)"
xlim_vals <- c(-1.2, 0.6)
bw_val    <- 0.08    # kernel bandwidth for density plots
bw_hist   <- 0.10   # binwidth for histograms

base_theme <- theme_classic(base_size = 10) +
  theme(
    legend.position  = "bottom",
    legend.title     = element_blank(),
    legend.key.size  = unit(0.4, "cm"),
    axis.title       = element_text(size = 9),
    plot.title       = element_text(size = 10, face = "plain"),
    plot.caption     = element_text(size = 6.5, color = "grey40")
  )

# ------------------------------------------------------------------------------
# 6. Shared table-output helpers
# ------------------------------------------------------------------------------

write_txt_table <- function(x, file) {
  txt_table <- knitr::kable(
    x,
    format = "pipe",
    align = c("l", rep("r", ncol(x) - 1))
  )
  
  writeLines(txt_table, file)
}
# ------------------------------------------------------------------------------
# End of 00_setup.R
# ------------------------------------------------------------------------------
