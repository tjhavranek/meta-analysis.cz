# ==============================================================================
# 02_bias_correction.R
# Publication bias and p-hacking in the effect of COVID-19 on learning
# Luskova, Buliskeria, Elminejad, Havranek, Irsova, Jurajda, Kapicka
#
# PRODUCES:
#   Table 3: Baseline and bias-corrected estimates
#            output/tables/table3_bias_correction.txt
#
# METHODS:
#   Panel A: FE (fixed effects), RVE (robust variance estimation)
#   Panel B: PET, PEESE, 3PSM, RoBMA
# ==============================================================================

source(here::here("code", "00_setup.R")) 

# Panel A: Baseline mean estimates ----

# Fixed effects (inverse-variance weighted mean)
fe_mod <- rma(yi = es, sei = se, data = dat, method = "FE")
cat("FE estimate:", round(fe_mod$b, 4),
    "(SE =", round(fe_mod$se, 4), ")\n")

# Robust variance estimation (RVE), clustering at study level
# Hedges et al. (2010) — this is the -0.140 estimate matching Betthäuser et al.
rve_mod <- robu(es ~ 1, data = dat,
                studynum = study,
                var.eff.size = vi)
print(rve_mod)


# Panel B: PET-PEESE ----
 
# PET: weighted regression of es on se, weights = 1/se^2
fit_PET <- lm(es ~ se, weights = 1/se^2, data = dat)
pet_res <- coeftest(fit_PET, vcov = vcovCL, type = "HC1", cluster = ~study_id)
print(pet_res)

# PEESE: weighted regression of es on se^2
fit_PEESE <- lm(es ~ I(se^2), weights = 1/se^2, data = dat)
peese_res <- coeftest(fit_PEESE, vcov = vcovCL, type = "HC1", cluster = ~study_id)
print(peese_res)
 
# Panel B: 3PSM (three-parameter selection model) ----

# Iyengar & Greenhouse (1988), Hedges (1992), Vevea & Hedges (1995)
# steps = c(0.025) corresponds to one-tailed alpha = 0.05
fit_3PSM <- weightfunct(effect = dat$es, v = dat$vi,
                        steps = c(0.025), table = TRUE)
print(fit_3PSM)

# Likelihood ratio test for publication bias
# H0: no publication bias (weight ratio = 1)
# p-value > 0.05 → cannot reject no publication bias



# Panel B: RoBMA ----
# Bartos et al. (2023), Maier et al. (2023)
#
# REQUIREMENTS: RoBMA requires JAGS to be installed separately.
# Download JAGS 4.x from: https://sourceforge.net/projects/mcmc-jags/
# Install the .pkg (macOS) or .exe (Windows) before running this block.
# Verify installation in R with: rjags::jags.version()
#
# Note: slow to run (~10-30 min). If it fails, see notes/note_RoBMA_JASP.txt
# for JASP instructions as an alternative.

library(RoBMA)

set.seed(1)
fit_RoBMA <- RoBMA(
  y                = dat$es,
  se               = dat$se,
  study_names      = dat$study,
  seed             = 1,
  effect_direction = "negative"
)

summary(fit_RoBMA)

# Extract model-averaged estimate for mu
robma_summary <- summary(fit_RoBMA)
robma_est     <- robma_summary$estimates["mu", "Mean"]
robma_lo      <- robma_summary$estimates["mu", "0.025"]
robma_hi      <- robma_summary$estimates["mu", "0.975"]

cat("RoBMA estimate:", round(robma_est, 3), "\n")
cat("95% CI: [", round(robma_lo, 3), ",", round(robma_hi, 4), "]\n")


# R result (seed = 1): mean = -0.120, 95% CI [-0.136, -0.100]
# JASP result (reported in paper): mean = -0.118, 95% CI [-0.135, -0.094]
# Small differences reflect MCMC sampling variability and minor differences
# in default priors between JASP and R implementations.
# See notes/note_RoBMA_JASP.txt for details.

# Results from JASP

# Robust Bayesian meta-analysis
# Model Summary:
#                Models      P(M)        P(M|data)    Inclusion BF
# Effect         18/36       0.500       1.000        6.783e7
# Heterogeneity  18/36       0.500       1.000        inf
# Bias           32/36       0.500       0.627        1.682

# Model Averaged Estimates      Mean        Median      Lower      Upper
# Effect size (muu)            -0.118      -0.119      -0.135     -0.094
# Heterogeneity (tau)           0.115       0.115       0.105      0.129


# Model Averaged PET-PEESE Estimates     Mean        Median      Lower      Upper
# PET                                    0.152       0.000       0.000      0.961
# PEESE                                  0.893       0.000       0.000      7.916


# Summary table (Table 3) ----

tab3 <- tibble(
  Method     = c("FE", "RVE", "PET", "PEESE", "3PSM", "RoBMA"),
  Panel      = c("A", "A", "B", "B", "B", "B"),
  Estimate   = c(
    round(fe_mod$b,              3),
    round(rve_mod$reg_table$b.r, 3),
    round(coef(fit_PET)[1],      3),
    round(coef(fit_PEESE)[1],    3),
    round(fit_3PSM$adj_est[2],   3),
    round(robma_est,             3)   # -0.120 from R; paper reports -0.118 from JASP
  ),
  SE = c(
    round(fe_mod$se,            3),
    round(rve_mod$reg_table$SE, 3),
    round(pet_res[1, 2],        3),
    round(peese_res[1, 2],      3),
    round(fit_3PSM$adj_se[2],   3),
    NA                              # RoBMA: CI reported instead of SE
  ),
  CI_lo = c(NA, NA, NA, NA, NA, round(robma_lo, 3)),  # -0.136 from R
  CI_hi = c(NA, NA, NA, NA, NA, round(robma_hi, 3))   # -0.100 from R
)

print(tab3)
write_txt_table(
  tab3,
  file.path(table_path, "table3_bias_correction.txt")
)

# ------------------------------------------------------------------------------
# End of 02_bias_correction.R
# ------------------------------------------------------------------------------
