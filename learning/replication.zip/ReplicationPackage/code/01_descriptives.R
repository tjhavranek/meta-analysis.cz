# ==============================================================================
# 01_descriptives.R
# Publication bias and p-hacking in the effect of COVID-19 on learning
# Luskova, Buliskeria, Elminejad, Havranek, Irsova, Jurajda, Kapicka
#
# PRODUCES:
#   Tables : output/tables/table1_descriptives.txt
#            output/tables/table2_subgroups.txt
#   Figures: output/figures/fig01_country.pdf
#            output/figures/fig02_subject_level.pdf
#            output/figures/fig03_grade.pdf
#            output/figures/fig04_funnel.pdf
#            output/figures/fig05_significance.pdf
# ==============================================================================

source(here::here("code", "00_setup.R")) 

# Table 1: Descriptive statistics ----

# Pooled RE mean (REML) — used as reference line in Figure 4
re_model  <- rma(yi = es, vi = vi, data = dat, method = "REML")
re_mean   <- as.numeric(re_model$b)   # -0.124

desc_cont <- tibble(
  Variable = c("Standardized mean difference",
               "Standard error",
               "Sample size (n)",
               "z-statistic"),
  N      = c(sum(!is.na(dat$es)), sum(!is.na(dat$se)),
             sum(!is.na(dat$n_study)), sum(!is.na(dat$z))),
  Mean   = c(mean(dat$es,      na.rm=TRUE), mean(dat$se,      na.rm=TRUE),
             mean(dat$n_study, na.rm=TRUE), mean(dat$z,       na.rm=TRUE)),
  SD     = c(sd(dat$es,        na.rm=TRUE), sd(dat$se,        na.rm=TRUE),
             sd(dat$n_study,   na.rm=TRUE),  sd(dat$z,        na.rm=TRUE)),
  Min    = c(min(dat$es,       na.rm=TRUE), min(dat$se,       na.rm=TRUE),
             min(dat$n_study,  na.rm=TRUE), min(dat$z,        na.rm=TRUE)),
  Median = c(median(dat$es,    na.rm=TRUE), median(dat$se,    na.rm=TRUE),
             median(dat$n_study, na.rm=TRUE), median(dat$z,   na.rm=TRUE)),
  Max    = c(max(dat$es,       na.rm=TRUE), max(dat$se,       na.rm=TRUE),
             max(dat$n_study,  na.rm=TRUE), max(dat$z,        na.rm=TRUE))
) %>%
  mutate(across(where(is.numeric), ~ round(., 3)))

desc_cont[3, c("SD")] <- NA

desc_comp <- tibble(
  Variable = c("Primary education", "Secondary education",
               "Mathematics", "Reading", "Mixed"),
  N        = c(
    sum(dat$prim_sec == "Primary",          na.rm=TRUE),
    sum(dat$prim_sec == "Secondary",        na.rm=TRUE),
    sum(dat$subject  == "Math",             na.rm=TRUE),
    sum(dat$subject  == "Reading",          na.rm=TRUE),
    sum(dat$subject  == "Math/Reading",     na.rm=TRUE)
  ),
  Share = c(
    mean(dat$prim_sec == "Primary",         na.rm=TRUE),
    mean(dat$prim_sec == "Secondary",       na.rm=TRUE),
    mean(dat$subject  == "Math",            na.rm=TRUE),
    mean(dat$subject  == "Reading",         na.rm=TRUE),
    mean(dat$subject  == "Math/Reading",    na.rm=TRUE)
  )
) %>% mutate(Share = paste0(round(Share * 100, 1), "%"))

print(desc_cont)
print(desc_comp)
 
separator <- tibble(Variable = "Composition", N = NA_character_, 
                    Mean = NA_character_, SD = NA_character_, 
                    Min = NA_character_, Median = NA_character_, 
                    Max = NA_character_)

desc_comp_aligned <- desc_comp %>%
  mutate(Mean = Share, SD = NA_character_, Min = NA_character_, 
         Median = NA_character_, Max = NA_character_) %>%
  select(-Share) %>%
  mutate(N = as.character(N))

table1 <- desc_cont %>%
  mutate(across(where(is.numeric), as.character)) %>%
  bind_rows(separator, desc_comp_aligned)

write.table(
  table1, file = "output/tables/table1_descriptives.txt", sep = "\t",
  row.names = FALSE, quote = FALSE, na = ""
)

write_txt_table(
  table1,
  file.path(table_path, "table1_descriptives.txt")
)


# Table 2: Summary statistics by subgroup ----

# Helper: compute unweighted and study-weighted means with 95% CIs. 
make_row <- function(df, label) {
  n     <- nrow(df)
  u_m   <- mean(df$es, na.rm = TRUE)
  u_se  <- sd(df$es, na.rm = TRUE) / sqrt(n)
  wts   <- df$w / sum(df$w, na.rm = TRUE)
  w_m   <- sum(wts * df$es, na.rm = TRUE)
  w_se  <- sqrt(sum(wts^2 * (df$es - w_m)^2, na.rm = TRUE))
  tibble(
    Subgroup = label, N = n,
    UW_mean  = round(u_m,            3),
    UW_lo    = round(u_m - 1.96 * u_se, 3),
    UW_hi    = round(u_m + 1.96 * u_se, 3),
    W_mean   = round(w_m,            3),
    W_lo     = round(w_m - 1.96 * w_se, 3),
    W_hi     = round(w_m + 1.96 * w_se, 3)
  )
}

section <- function(label) {
  tibble(Subgroup = paste0(label),
         N = NA_real_, UW_mean = NA_real_, UW_lo = NA_real_, UW_hi = NA_real_,
         W_mean = NA_real_, W_lo = NA_real_, W_hi = NA_real_)
}

tab2 <- bind_rows(
  section("Subject"),
  make_row(dat %>% filter(subject_group == "Mathematics"),  "Mathematics"),
  make_row(dat %>% filter(subject_group == "Reading"),      "Reading"),
  make_row(dat %>% filter(subject_group == "Mixed"),        "Mixed"),
  section("School level"),
  make_row(dat %>% filter(prim_sec == "Primary"),           "Primary"),
  make_row(dat %>% filter(prim_sec == "Secondary"),         "Secondary"),
  section("Grade group"),
  make_row(dat %>% filter(grade_group == "Early primary (1\u20134)"), "Early primary (1--4)"),
  make_row(dat %>% filter(grade_group == "Middle (5\u20138)"),        "Middle (5--8)"),
  make_row(dat %>% filter(grade_group == "Secondary (9+)"),           "Secondary (9+)"),
  section("Sample size"),
  make_row(dat %>% filter(size_group == "Small (<10k)"),              "Small (<10k)"),
  make_row(dat %>% filter(size_group == "Medium (10k\u2013100k)"),    "Medium (10k--100k)"),
  make_row(dat %>% filter(size_group == "Large (>100k)"),             "Large (>100k)"),
  section("Country"),
  make_row(dat %>% filter(country_group == "United States"),          "United States"),
  make_row(dat %>% filter(country_group == "United Kingdom"),         "United Kingdom"),
  make_row(dat %>% filter(country_group == "Netherlands"),            "Netherlands"),
  make_row(dat %>% filter(country_group == "Other countries"),        "Other countries"),
  section("Source tier"),
  make_row(dat %>% filter(source_tier == "Tier 1: Peer-reviewed"),        "Tier 1: Peer-reviewed"),
  make_row(dat %>% filter(source_tier == "Tier 2: Working paper"),         "Tier 2: Working paper"),
  make_row(dat %>% filter(source_tier == "Tier 3: Gov't / institutional"), "Tier 3: Gov't / institutional"),
  make_row(dat %>% filter(source_tier == "Tier 4: Commercial"),            "Tier 4: Commercial"),
  make_row(dat, "All estimates")
) %>%
  mutate(across(everything(), ~ ifelse(is.na(.), "", as.character(.))))

print(tab2) 
write_txt_table(
  tab2,
  file.path(table_path, "table2_subgroups.txt")
)


# Figure 1: Effect size estimates by country ----

country_order <- dat %>%
  group_by(country) %>%
  summarise(med = median(es, na.rm = TRUE), .groups = "drop") %>%
  arrange(med) %>%
  pull(country)

fig1 <- ggplot(
  dat %>% mutate(country = factor(country, levels = country_order)),
  aes(x = es, y = country)
) +
  geom_boxplot(outlier.size  = 0.9, outlier.alpha = 0.5,
               fill = "grey80", color = "grey30", linewidth = 0.4) +
  geom_vline(xintercept = mean_es, linetype = "dotted",
             color = "grey30", linewidth = 0.5) +
  geom_vline(xintercept = 0, linetype = "solid",
             color = "grey60", linewidth = 0.3) +
  coord_cartesian(xlim = xlim_vals) +
  labs(x = x_lab, y = NULL) +
   theme_classic(base_size = 10) +
  theme(axis.text.y  = element_text(size = 9),
        plot.caption = element_text(size = 7, color = "grey40"))

ggsave(file.path(fig_path, "fig01_country.pdf"),
       fig1, width = 6, height = 5.5)


# Figure 2: Distribution by subject area and school level ----

pal_subject <- c("Mathematics" = "#1f78b4", "Reading" = "#33a02c")
pal_level   <- c("Primary" = "#6a3d9a", "Secondary" = "#ff7f00")

p2a <- ggplot(dat %>% filter(subject_group != "Mixed"),
              aes(es, fill = subject_group, color = subject_group)) +
  geom_vline(xintercept = 0,       linetype = "solid",  color = "grey60", linewidth = 0.3) +
  geom_vline(xintercept = mean_es, linetype = "dotted", color = "grey30", linewidth = 0.6) +
  geom_histogram(aes(y = after_stat(density)), binwidth = bw_hist,
                 position = "identity", alpha = 0.25, linewidth = 0.2) +
  geom_density(bw = bw_val, linewidth = 0.75, fill = NA,
               aes(linetype = subject_group)) +
  scale_fill_manual(values = pal_subject) +
  scale_color_manual(values = pal_subject) +
  scale_linetype_manual(values = c("solid", "dashed")) +
  coord_cartesian(xlim = xlim_vals) +
  labs(title = "(a) Subject", x = x_lab, y = "Density") +
  base_theme +
  guides(fill     = guide_legend(override.aes = list(alpha = 0.4)),
         linetype = guide_legend(),
         color    = guide_legend())

p2b <- ggplot(dat %>% filter(!is.na(level_group)),
              aes(es, fill = level_group, color = level_group)) +
  geom_vline(xintercept = 0,       linetype = "solid",  color = "grey60", linewidth = 0.3) +
  geom_vline(xintercept = mean_es, linetype = "dotted", color = "grey30", linewidth = 0.6) +
  geom_histogram(aes(y = after_stat(density)), binwidth = bw_hist,
                 position = "identity", alpha = 0.25, linewidth = 0.2) +
  geom_density(bw = bw_val, linewidth = 0.75, fill = NA,
               aes(linetype = level_group)) +
  scale_fill_manual(values = pal_level) +
  scale_color_manual(values = pal_level) +
  scale_linetype_manual(values = c("solid", "dashed")) +
  coord_cartesian(xlim = xlim_vals) +
  labs(title = "(b) School level", x = x_lab, y = "Density") +
  base_theme +
  guides(fill     = guide_legend(override.aes = list(alpha = 0.4)),
         linetype = guide_legend(),
         color    = guide_legend())

fig2 <- p2a / p2b

ggsave(file.path(fig_path, "fig02_subject_level.pdf"),
       fig2, width = 6, height = 7)


 
# Figure 3: Effect size estimates by grade ----
# with loess smoother and 95% CI band 

fig3 <- ggplot(dat %>% filter(!is.na(grade_num)),
               aes(x = grade_num, y = es)) +
  geom_hline(yintercept = 0,       linetype = "dashed",
             color = "grey50", linewidth = 0.4) +
  geom_hline(yintercept = mean_es, linetype = "dotted",
             color = "grey30", linewidth = 0.5) +
  geom_jitter(width = 0.15, alpha = 0.35, size = 1.0, color = "#1f78b4") +
  geom_smooth(method = "loess", se = TRUE,
              color = "grey20", fill = "grey80", linewidth = 0.8) +
  scale_x_continuous(breaks = 1:13, name = "Grade") +
  scale_y_continuous(name = x_lab) +
  theme_classic(base_size = 10) +
  theme(plot.caption = element_text(size = 7, color = "grey40"))

ggsave(file.path(fig_path, "fig03_grade.pdf"),
       fig3, width = 6.5, height = 4)

 

# Figure 4: Conventional funnel plot ----
 
fig4 <- ggplot(dat, aes(x = es, y = se)) +
  geom_point(alpha = 0.5, size = 1.2, color = "#1f78b4") +
  geom_vline(xintercept = re_mean, linetype = "dotted",
             color = "grey30", linewidth = 0.5) +
  geom_vline(xintercept = 0,       linetype = "dashed",
             color = "grey50", linewidth = 0.4) +
  scale_x_continuous(name = x_lab) +
  scale_y_continuous(name = "Estimated Standard Error") +
  theme_classic(base_size = 10) +
  theme(plot.caption = element_text(size = 7, color = "grey40"))

ggsave(file.path(fig_path, "fig04_funnel.pdf"),
       fig4, width = 6, height = 5)


# Figure 5: Distribution by statistical significance ----

pal_sig <- c("Significant (p<0.05)" = "#1f78b4", "Not significant" = "#e31a1c")

fig5 <- ggplot(dat, aes(es, fill = sig_group, color = sig_group)) +
  geom_vline(xintercept = 0,       linetype = "solid",  color = "grey60", linewidth = 0.3) +
  geom_vline(xintercept = mean_es, linetype = "dotted", color = "grey30", linewidth = 0.6) +
  geom_histogram(aes(y = after_stat(density)), binwidth = bw_hist,
                 position = "identity", alpha = 0.25, linewidth = 0.2) +
  geom_density(bw = bw_val, linewidth = 0.75, fill = NA,
               aes(linetype = sig_group)) +
  scale_fill_manual(values = pal_sig) +
  scale_color_manual(values = pal_sig) +
  scale_linetype_manual(values = c("solid", "dashed")) +
  coord_cartesian(xlim = xlim_vals) +
  labs(x = x_lab, y = "Density") +
  base_theme +
  guides(fill     = guide_legend(override.aes = list(alpha = 0.4)),
         linetype = guide_legend(),
         color    = guide_legend())

ggsave(file.path(fig_path, "fig05_significance.pdf"),
       fig5, width = 6, height = 4)


# Figure 7: Distribution of z-scores ----

tcrit <- qnorm(1 - 0.05 / 2)   # 1.96

fig7 <- ggplot(dat, aes(x = es/se)) +
  geom_density(adjust = 0.3, linewidth = 0.8, color = "#1f78b4") +
  geom_vline(xintercept =  tcrit, linetype = "dashed",
             color = "grey40", linewidth = 0.5) +
  geom_vline(xintercept = -tcrit, linetype = "dashed",
             color = "grey40", linewidth = 0.5) +
  annotate("text", label = sprintf("Z = %.2f",  tcrit),
           x =  tcrit + 1.5, y = 0, hjust = 0,
           color = "grey40", angle = 90, size = 3) +
  annotate("text", label = sprintf("Z = %.2f", -tcrit),
           x = -tcrit - 1.5, y = 0, hjust = 0,
           color = "grey40", angle = 90, size = 3) +
  scale_x_continuous(breaks = seq(-100, 10, 10), name = "yi/sei",
                     limits = c(-100, 10)) +
  scale_y_continuous(name = "Density") +
  theme_classic(base_size = 11)

ggsave(file.path(fig_path, "fig07_zscore.pdf"), fig7, width = 7, height = 4)


# Figure 8: Absolute and log z-scores ----

abs_z <- abs(dat$es / dat$se)

# Panel (a): abs z-scores, full range
p8a <- ggplot(data.frame(abs_z = abs_z), aes(x = abs_z)) +
  geom_density(adjust = 0.3, color = "#1f78b4", linewidth = 0.8) +
  geom_vline(xintercept = tcrit, linetype = "dashed",
             color = "grey40", linewidth = 0.5) +
  annotate("text", label = sprintf("Z = %.2f", tcrit),
           x = tcrit + 1.5, y = 0, hjust = 0,
           color = "grey40", angle = 90, size = 3) +
  scale_x_continuous(breaks = seq(0, 100, 10), name = "Z-score",
                     limits = c(0, 100)) +
  scale_y_continuous(name = "Density") +
  theme_classic(base_size = 11) +
  theme(plot.margin = unit(c(1, 1, 1, 1), "cm"))

# Panel (b): abs z-scores, zoomed to (0, 20)
p8b <- ggplot(data.frame(abs_z = abs_z), aes(x = abs_z)) +
  geom_density(adjust = 0.3, color = "#1f78b4", linewidth = 0.8) +
  geom_vline(xintercept = tcrit, linetype = "dashed",
             color = "grey40", linewidth = 0.5) +
  annotate("text", label = sprintf("Z = %.2f", tcrit),
           x = tcrit + 1.5, y = 0, hjust = 0,
           color = "grey40", angle = 90, size = 3) +
  scale_x_continuous(breaks = seq(0, 20, 2), name = "Z-score",
                     limits = c(0, 20)) +
  scale_y_continuous(breaks = seq(0, 0.6, by = 0.05), name = "Density") +
  theme_classic(base_size = 11) +
  theme(plot.margin = unit(c(1, 1, 1, 1), "cm"))

# Panel (c): log abs z-scores
ln_z       <- log(abs(dat$z))
ln_z       <- ln_z[is.finite(ln_z)]
ln_z_df    <- data.frame(ln_z = ln_z)
mean_ln_z  <- mean(ln_z_df$ln_z)
sd_ln_z    <- sd(ln_z_df$ln_z)

p8c <- ggplot(ln_z_df, aes(x = ln_z)) +
  geom_histogram(aes(y = after_stat(density)), bins = 25,
                 fill = "#1f78b4", alpha = 0.4, color = "white") +
  stat_function(fun = dnorm,
                args = list(mean = mean_ln_z, sd = sd_ln_z),
                color = "#1f78b4", linewidth = 0.8) +
  geom_vline(xintercept = log(1.96), linetype = "dashed",
             color = "grey40", linewidth = 0.5) +
  annotate("text", x = log(1.96) + 0.2, y = 0.1,
           label = "z = 1.96", color = "grey40", size = 3.5) +
  scale_x_continuous(
    breaks = c(log(0.1), log(1), log(10), log(100), log(1000)),
    labels = c("0.1", "1", "10", "100", "1000"),
    name   = "z-statistic (log scale)"
  ) +
  scale_y_continuous(limits = c(0, 0.35), name = "Density") +
  theme_classic(base_size = 11) +
  theme(plot.margin = unit(c(1, 1, 1, 1), "cm"))

# Save panels separately (combined in LaTeX via subfigure)
ggsave(file.path(fig_path, "fig08a_absz.pdf"),      p8a, width = 7, height = 4)
ggsave(file.path(fig_path, "fig08b_absz_zoom.pdf"), p8b, width = 7, height = 4)
ggsave(file.path(fig_path, "fig08c_logz.pdf"),      p8c, width = 7, height = 4)


# Figure 9: DFBETAS influence diagnostics ----

#mod_dfb    <- rma(yi = es, sei = se, data = dat, method = "REML")
mod_dfb <- re_model
inf_obj    <- influence(mod_dfb)
dfbetas_df <- as.data.frame(inf_obj$dfbs)
colnames(dfbetas_df) <- "dfb"
dfbetas_df$idx <- seq_len(nrow(dfbetas_df))

threshold <- 2 / sqrt(nrow(dfbetas_df))   # 0.117

# Verification
influential <- dfbetas_df %>%
  filter(abs(dfb) > threshold) %>%
  mutate(study = dat$study[idx]) %>%
  arrange(desc(abs(dfb)))
print(influential)

mod_trimmed <- rma(yi = es, sei = se,
                   data = dat[-influential$idx, ], method = "REML")
cat("Full model:   ", round(mod_dfb$b,     4), "\n")
cat("Trimmed model:", round(mod_trimmed$b,  4), "\n")

fig9 <- ggplot(dfbetas_df) +
  geom_segment(aes(x = idx, xend = idx, y = 0, yend = dfb),
               color = "cornflowerblue") +
  geom_point(aes(x = idx, y = dfb)) +
  geom_hline(yintercept =  threshold, color = "salmon", linewidth = 0.4) +
  geom_hline(yintercept = -threshold, color = "salmon", linewidth = 0.4) +
  geom_text_repel(
    aes(x = idx, y = dfb,
        label = ifelse(abs(dfb) > threshold,
                       paste0(round(dfb, 2), " (", idx, ")"), "")),
    size = 3, max.overlaps = Inf,
    box.padding = 0.5, point.padding = 0.3,
    segment.color = "gray50", min.segment.length = 0.2
  ) +
  scale_x_continuous(name = "Observation index") +
  scale_y_continuous(name = "DFBETAS") +
  theme_classic(base_size = 10)
fig9

ggsave(file.path(fig_path, "fig09_dfbetas.pdf"), fig9, width = 10, height = 5)
 
# ------------------------------------------------------------------------------
# End of 01_descriptives.R
# ------------------------------------------------------------------------------
 
