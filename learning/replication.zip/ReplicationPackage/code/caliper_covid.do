/******************************************************************************************
  CALIPER TESTS – STATA
  Dataset: Betthäuser et al. (2023) – COVID-19 Learning Loss Meta-Analysis
  Based on: Gerber & Malhotra (2008) caliper test methodology

  Purpose:
    Apply caliper tests to the COVID-19 learning deficit estimates to detect
    potential publication bias / p-hacking around conventional significance
    thresholds.

  Context:
    In this setting, affirmative results are NEGATIVE and statistically
    significant (learning loss is measured as a negative Cohen's d).
    The signed t-statistic (es/se) is therefore negative for most estimates.

    We test around three thresholds:
      t = 0     : excess of negative vs. positive estimates
      t = -1.96 : bunching at the 5% significance level (negative side)
      t = -2.58 : bunching at the 1% significance level (negative side)

  Data requirements:
    - main.dta in the working directory

  Software requirements:
    - Stata 15 or later

  Output:
    - caliper_covid.log             – Stata log of all commands and results
    - caliper_tstat.gph             – histogram of t-statistics
    - caliper_tstat_zoom.gph        – zoomed histogram around [-5, 5]
    - table_caliper.tex             – LaTeX table of caliper test results
******************************************************************************************/

version 15
capture log close
clear all
set more off

* (set the working directory to the replication-package root, e.g. cd "/path/to/luskova_et_al_2026")

log using "output/tables/caliper_covid.log", replace

******************************************************************************************
* 1. DATA IMPORT & VARIABLE CONSTRUCTION
******************************************************************************************/

use "data/main.dta", clear

* Create numeric study identifier for clustering
encode study, gen(study_id)
xtset study_id

* Compute the signed t-statistic: es / se
gen tstat = es / se

summarize es se tstat, detail

******************************************************************************************
* 2. HISTOGRAM OF T-STATISTICS
******************************************************************************************/

twoway ///
    (histogram tstat if tstat > -50 & tstat < 10, ///
        bin(65) fcolor(gs14) lstyle(thin) ///
        xtitle("t-statistic of the effect size estimate (es/se)") ///
        ytitle("Density") ///
        xline(0, lcolor(gs12) lpattern(shortdash)) ///
        xline(-1.96 -2.58, lcolor(red)) ///
        xlabel(-50 -10 -2.58 -1.96 0 5 10) ///
        ylabel(, glcolor(ltbluishgray)) ///
        graphregion(color(ltbluishgray))) ///
    (kdensity tstat if tstat > -50 & tstat < 10, ///
        lcolor(navy)), ///
    legend(off) 
	*saving(caliper_tstat, replace)

twoway ///
    (histogram tstat if tstat > -5 & tstat < 5, ///
        bin(40) fcolor(gs14) lstyle(thin) ///
        xtitle("t-statistic of the effect size estimate (es/se)") ///
        ytitle("Density") ///
        xline(0, lcolor(gs12) lpattern(shortdash)) ///
        xline(-1.96 -2.58, lcolor(red)) ///
        xline(1.96, lcolor(red) lpattern(dash)) ///
        xlabel(-5 -2.58 -1.96 0 1.96 5) ///
        ylabel(, glcolor(ltbluishgray)) ///
        graphregion(color(ltbluishgray))) ///
    (kdensity tstat if tstat > -5 & tstat < 5, ///
        lcolor(navy)), ///
    legend(off) 
	*saving(caliper_tstat_zoom, replace)

******************************************************************************************
* 3. CALIPER TESTS
*    For each threshold and each caliper width:
*      - Define an indicator for being on one side of the threshold
*      - Regress the indicator on a constant, clustering at the study level
*      - Test H0: proportion = 0.5 using lincom _cons - 0.5
*      - Store the lincom coefficient, SE, p-value, and N
*
*    Thresholds tested:
*      t = 0     : significant = (tstat < 0), i.e. negative side
*      t = -1.96 : significant = (tstat < -1.96), i.e. below 5% threshold
*      t = -2.58 : significant = (tstat < -2.58), i.e. below 1% threshold
******************************************************************************************/

* --------------------------------------------------------------------------
* Prepare a results matrix: 10 caliper widths x 3 thresholds x 4 stats
* --------------------------------------------------------------------------

* Columns: [coef_0, se_0, p_0, N_0, coef_196, se_196, p_196, N_196,
*           coef_258, se_258, p_258, N_258]
matrix results = J(10, 12, .)
matrix colnames results = ///
    coef_0 se_0 p_0 N_0 ///
    coef_196 se_196 p_196 N_196 ///
    coef_258 se_258 p_258 N_258

local row = 0

forvalues w = 5(5)50 {
    local row = `row' + 1
    local bw = `w'/100

    * ------------------------------------------------------------------
    * Threshold t = 0
    * ------------------------------------------------------------------
    * significant = 1 if tstat < 0 (negative estimate)
    capture drop sig_temp
    gen sig_temp = (tstat < 0)

    local lo = -`bw'
    local hi =  `bw'
    quietly count if tstat > `lo' & tstat < `hi'
    local n0 = r(N)

    if `n0' >= 2 {
        quietly reg sig_temp if tstat > `lo' & tstat < `hi', ///
            vce(cluster study_id)
        quietly lincom _cons - 0.5
        matrix results[`row', 1] = r(estimate)
        matrix results[`row', 2] = r(se)
        matrix results[`row', 3] = r(p)
        matrix results[`row', 4] = `n0'
    }
    else {
        matrix results[`row', 4] = `n0'
    }

    * ------------------------------------------------------------------
    * Threshold t = -1.96
    * ------------------------------------------------------------------
    capture drop sig_temp
    gen sig_temp = (tstat < -1.96)

    local lo = -1.96 - `bw'
    local hi = -1.96 + `bw'
    quietly count if tstat > `lo' & tstat < `hi'
    local n196 = r(N)

    if `n196' >= 2 {
        quietly reg sig_temp if tstat > `lo' & tstat < `hi', ///
            vce(cluster study_id)
        quietly lincom _cons - 0.5
        matrix results[`row', 5] = r(estimate)
        matrix results[`row', 6] = r(se)
        matrix results[`row', 7] = r(p)
        matrix results[`row', 8] = `n196'
    }
    else {
        matrix results[`row', 8] = `n196'
    }

    * ------------------------------------------------------------------
    * Threshold t = -2.58
    * ------------------------------------------------------------------
    capture drop sig_temp
    gen sig_temp = (tstat < -2.58)

    local lo = -2.58 - `bw'
    local hi = -2.58 + `bw'
    quietly count if tstat > `lo' & tstat < `hi'
    local n258 = r(N)

    if `n258' >= 2 {
        quietly reg sig_temp if tstat > `lo' & tstat < `hi', ///
            vce(cluster study_id)
        quietly lincom _cons - 0.5
        matrix results[`row', 9]  = r(estimate)
        matrix results[`row', 10] = r(se)
        matrix results[`row', 11] = r(p)
        matrix results[`row', 12] = `n258'
    }
    else {
        matrix results[`row', 12] = `n258'
    }
}

capture drop sig_temp

* --------------------------------------------------------------------------
* Display results as a formatted table
* --------------------------------------------------------------------------

di " "
di "=================================================================="
di "  CALIPER TEST RESULTS"
di "  Gerber & Malhotra (2008)"
di "  Standard errors clustered at the study level"
di "=================================================================="
di " "
di "  Each cell reports:  lincom coefficient (proportion - 0.5)"
di "                      (clustered SE)"
di "                      N = number of observations in window"
di "  Stars: * p<0.10, ** p<0.05, *** p<0.01"
di " "
di _dup(70) "-"
di %20s " " %16s "t-stat = 0" %16s "t-stat = -1.96" %16s "t-stat = -2.58"
di _dup(70) "-"

local row = 0
forvalues w = 5(5)50 {
    local row = `row' + 1
    local bw = `w'/100

    foreach thresh in 0 196 258 {
        if "`thresh'" == "0" {
            local col_base = 1
        }
        else if "`thresh'" == "196" {
            local col_base = 5
        }
        else {
            local col_base = 9
        }

        local coef = results[`row', `col_base']
        local se_v = results[`row', `col_base' + 1]
        local pv   = results[`row', `col_base' + 2]
        local nobs = results[`row', `col_base' + 3]

        if `coef' == . {
            local str_`thresh' = "     .     "
            local ses_`thresh' = "           "
            local nos_`thresh' : di %11s "N = " %3.0f `nobs'
        }
        else {
            * Add stars
            local stars = ""
            if `pv' < 0.01 {
                local stars = "***"
            }
            else if `pv' < 0.05 {
                local stars = "**"
            }
            else if `pv' < 0.10 {
                local stars = "*"
            }
            local str_`thresh' : di %7.3f `coef' "`stars'"
            local ses_`thresh' : di "(" %5.3f `se_v' ")"
            local nos_`thresh' : di "N = " %3.0f `nobs'
        }
    }

    di %20s "Caliper `bw'" %16s "`str_0'" %16s "`str_196'" %16s "`str_258'"
    di %20s " "             %16s "`ses_0'" %16s "`ses_196'" %16s "`ses_258'"
    di %20s " "             %16s "`nos_0'" %16s "`nos_196'" %16s "`nos_258'"
    di " "
}

di _dup(70) "-"
di "  Notes: The table reports caliper tests (Gerber & Malhotra, 2008)."
di "  Each cell shows the deviation of the proportion from 0.5."
di "  A positive value at t = -1.96 means excess mass below the threshold"
di "  (more estimates just below -1.96 than just above)."
di "  Standard errors are clustered at the study level."
di _dup(70) "-"

* --------------------------------------------------------------------------
* Export as formatted text table
* --------------------------------------------------------------------------

capture file close fout
file open fout using "output/tables/tableC1_caliper.txt", write replace

file write fout "Table C1: Caliper Tests for Selection Around Significance Thresholds" _n
file write fout "======================================================================" _n
file write fout "Gerber & Malhotra (2008). SEs clustered at study level." _n
file write fout "======================================================================" _n
file write fout _col(20) "t = 0" _col(36) "t = -1.96" _col(52) "t = -2.58" _n
file write fout "----------------------------------------------------------------------" _n

local row = 0
forvalues w = 5(5)50 {
    local row = `row' + 1
    local bw = `w'/100
    
    local c0  = results[`row', 1]
    local s0  = results[`row', 2]
    local n0  = results[`row', 4]
    local c196 = results[`row', 5]
    local s196 = results[`row', 6]
    local n196 = results[`row', 8]
    local c258 = results[`row', 9]
    local s258 = results[`row', 10]
    local n258 = results[`row', 12]
    
    file write fout "Caliper `bw'" _n
    file write fout "  Coef" _col(20) %7.3f (`c0') _col(36) %7.3f (`c196') _col(52) %7.3f (`c258') _n
    file write fout "  (SE)" _col(20) "(" %5.3f (`s0') ")" _col(36) "(" %5.3f (`s196') ")" _col(52) "(" %5.3f (`s258') ")" _n
    file write fout "  N   " _col(20) %3.0f (`n0') _col(36) %3.0f (`n196') _col(52) %3.0f (`n258') _n
}

file write fout "======================================================================" _n
file write fout "* p<0.10, ** p<0.05, *** p<0.01" _n
file close fout

******************************************************************************************
* END
******************************************************************************************/
