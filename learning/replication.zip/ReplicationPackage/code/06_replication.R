# ==============================================================================
# 06_replication.R
# Publication bias and p-hacking in the effect of COVID-19 on learning
# Luskova, Buliskeria, Elminejad, Havranek, Irsova, Jurajda, Kapicka
#
# PRODUCES: Appendix A — Computational Reproducibility of Betthäuser et al.
#
#   Figure A1: output/figures/figA1_zscore_reproduction.pdf
#   Figure A3: output/figures/figA3_temporal.pdf
#   Table A2:  output/tables/tableA2_time_trend.txt
#   Table A3:  output/tables/tableA3_subgroups.txt
#
# NOTE: Figures A2 (forest plot) and A4 (violin plots) are reproduced using
#       the original Stata code by Betthäuser et al. (2023).
#       See code/betthaeuser_replication.do — requires Stata 17 and the
#       original replication package from https://doi.org/10.17605/osf.io/u8gaz
# ==============================================================================


source(here::here("code", "00_setup.R")) 

# Derive income group (World Bank classification)
# Brazil, Colombia, Mexico, South Africa = middle income; all others = high income
dat <- dat %>%
  mutate(
    income_group = if_else(
      country %in% c("Brazil", "Colombia", "Mexico", "South Africa"),
      "Middle income", "High income"
    ) %>% factor(levels = c("High income", "Middle income")),
    date_parsed = as.Date(paste("01", date), format = "%d %b %Y")
  )

 
# Figure A1: Distribution of z-scores (reproduction of Betthäuser Fig. 2b) -----

ln_z    <- log(abs(dat$z))
ln_z    <- ln_z[is.finite(ln_z)]
ln_z_df <- data.frame(ln_z = ln_z)

figA1 <- ggplot(ln_z_df, aes(x = ln_z)) +
  geom_histogram(aes(y = after_stat(density)), bins = 10,
                 fill = "#1f78b4", alpha = 0.6, color = "white") +
  stat_function(fun  = dnorm,
                args = list(mean = mean(ln_z), sd = sd(ln_z)),
                color = "#e31a1c", linewidth = 0.8, linetype = "dashed") +
  geom_vline(xintercept = log(1.96), linetype = "dashed",
             color = "grey40", linewidth = 0.5) +
  annotate("text", x = log(1.96) + 0.2, y = 0.27,
           label = "z = 1.96", color = "grey40", size = 3.5) +
  scale_x_continuous(
    breaks = c(log(0.1), log(1), log(10), log(100), log(1000)),
    labels = c("0.1", "1", "10", "100", "1000"),
    name   = "z-statistic (log scale)"
  ) +
  scale_y_continuous(limits = c(0, 0.35), name = "Density") +
  theme_classic(base_size = 11)

ggsave(file.path(fig_path, "figA1_zscore_reproduction.pdf"),
       figA1, width = 6, height = 4)

 
# Table A2: Estimates of learning deficits in time -----
# OLS with cluster-robust SEs at study level 

trend_mod <- lm(es ~ months, data = dat %>% filter(!is.na(months)))
trend_res <- coeftest(trend_mod,
                      vcov    = vcovCL,
                      cluster = ~study,
                      data    = dat %>% filter(!is.na(months)))
cat("\n--- Table A2: Time trend ---\n")
print(trend_res)

tabA2 <- tibble(
  Statistic    = c("Slope (months)", "p-value", "95% CI", "N", "Clusters"),
  Original     = c("-0.00", "0.097", "[-0.01, 0.00]", "291", "42"),
  Reproduction = c(
    round(trend_res[2, 1], 2),
    round(trend_res[2, 4], 3),
    paste0("[", round(confint(trend_mod)[2, 1], 2), ", ",
                round(confint(trend_mod)[2, 2], 2), "]"),
    nrow(dat %>% filter(!is.na(months))),
    n_distinct(dat$study[!is.na(dat$months)])
  )
)

print(tabA2)
write_txt_table(
  tabA2,
  file.path(table_path, "tableA2_time_trend.txt")
)
 
# Table A3: Variation in estimates by subgroup -----
# Medians and IQR matching Betthäuser et al. (2023) Table A3 

make_row_A3 <- function(df, label) {
  tibble(
    Subgroup = label,
    N        = nrow(df),
    Median   = round(median(df$es, na.rm = TRUE), 2),
    IQR_lo   = round(quantile(df$es, 0.25, na.rm = TRUE), 2),
    IQR_hi   = round(quantile(df$es, 0.75, na.rm = TRUE), 2)
  )
}

tabA3 <- bind_rows(
  make_row_A3(dat %>% filter(subject == "Reading"), "Reading"),
  make_row_A3(dat %>% filter(subject == "Math"),    "Mathematics"),
  make_row_A3(dat %>% filter(prim_sec == "Primary"),   "Primary"),
  make_row_A3(dat %>% filter(prim_sec == "Secondary"), "Secondary"),
  make_row_A3(dat %>% filter(income_group == "High income"),   "High income"),
  make_row_A3(dat %>% filter(income_group == "Middle income"), "Middle income")
)

print(tabA3)
write_txt_table(
  tabA3,
  file.path(table_path, "tableA3_subgroups.txt")
)

# Figure A3: Learning deficits in time (reproduction of Betthäuser Fig. 4) ----

library(estimatr)

mycolors <- c("#000000", "#FFFFFF", "#3CB44B", "#FF7F00", "#42D4F4",
              "#BFEF45", "#815375", "#FFC81D", "#CE8BAE", "#999999",
              "#BF862B", "#E41A1C", "#FFD8B1", "#BD6253", "#3A85A8")
set.seed(86753) 
figA3 <- ggplot(data = dat %>% filter(!is.na(date_parsed))) +
  geom_smooth(mapping = aes(date_parsed, es), color = "darkgrey",
              method = "lm_robust",
              method.args = list(cluster = dat %>%
                                   filter(!is.na(date_parsed)) %>%
                                   pull(study))) +
  geom_jitter(mapping = aes(x = date_parsed, y = es,
                            fill = country, size = n_study),
              shape = 21, alpha = 1,
              position = position_jitter(width = 5, height = 0)) +
  scale_fill_manual(values = mycolors) +
  scale_x_date(date_breaks = "2 months", date_labels = "%b %Y") +
  scale_y_continuous(breaks = seq(-.8, .4, by = .2)) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  xlab("Date") + ylab("Learning deficit (SD)") +
  guides(size  = "none",
         fill  = guide_legend(title = "",
                              override.aes = list(size = 5))) +
  theme_bw()

ggsave(file.path(fig_path, "figA3_temporal.pdf"),
       figA3, width = 10, height = 4.5)

# ------------------------------------------------------------------------------
# End of 06_replication.R
# ------------------------------------------------------------------------------
