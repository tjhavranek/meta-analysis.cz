# ==============================================================================
# 04_phacking.R
# Publication bias and p-hacking in the effect of COVID-19 on learning
# Luskova, Buliskeria, Elminejad, Havranek, Irsova, Jurajda, Kapicka
#
# PRODUCES:
#   Table 4 Panel C: MAIVE, RTMA, Multi0.05;0.01, Multi0.08;0.01
#            output/tables/table4_panelC.txt
#   Figure 10: RTMA diagnostic Q-Q plot
#            output/figures/fig10_rtma_qqplot.pdf
#
# NOTES:
#   MAIVE: Irsova et al. (2025). Uses maivefunction.R as a dependency.
#          Instrument: inverse sample size for squared SE.
#          Options: PEESE (method=2), no weights, clustered SEs, AR CI.
#
#   RTMA: Mathur (2024b). Affirmative = negative & significant.
#         phacking_meta() with favor_positive = FALSE internally reverses
#         sign of yi; the reported mu is positive, so we negate it.
#         tau is unaffected. See notes/note_RTMA_sign.txt for details.
#
#   Multibias: Mathur (2024c). The original multibias_meta() has a sign bug
#         when favor_positive = FALSE (returns inverted estimate). We use the
#         custom multibias_new() function defined below, which fixes this.
#         See notes/note_RTMA_sign.txt and the GitHub issue filed at:
#         https://github.com/mathurlabstanford/metabias-apps/issues/1
# ==============================================================================

source(here::here("code", "00_setup.R")) 

library(purrr)
library(rlang)

#---
# MAIVE ----
# Irsova et al. (2025) — Meta-Analysis Instrumental Variable Estimator
#---

# Prepare data in format required by maivefunction.R
# Columns must be: bs, sebs, Ns, studyid (in that order)
dat_maive <- dat %>%
  mutate(
    bs      = es,
    sebs    = se,
    Ns      = n_study,
    studyid = study_id
  ) %>%
  select(bs, sebs, Ns, studyid)

# Options (matching paper specification)
method     <- 3   # PET-PEESE
weight     <- 0   # no weights
instrument <- 1   # instrument SEs
studylevel <- 2   # cluster-robust SEs
AR         <- 1   # Anderson-Rubin CI

source("code/maivefunction.R")

MAIVE <- maive(dat        = dat_maive,
               method     = method,
               weight     = weight,
               instrument = instrument,
               studylevel = studylevel,
               AR         = AR)

cat("\f")
cat("MAIVE coefficient:     ", MAIVE$beta,        "\n")
cat("MAIVE SE:              ", MAIVE$SE,           "\n")
cat("AR 95% CI:             ", MAIVE$AR_CI,        "\n")
cat("Coefficient on fitted SE2:", MAIVE$beta_standard, "\n")
cat("SE (standard):            ", MAIVE$SE_standard,   "\n")
cat("First-stage F-stat:    ", MAIVE$`F-test`,     "\n")
cat("Hausman test:          ", MAIVE$Hausman,      "\n")
cat("Chi2(1) critical value:", MAIVE$Chi2,         "\n")

#---
# RTMA (Right-Truncated Meta-Analysis) ----
# Mathur (2024b) — phacking_meta()
#---

# Note: favor_positive = FALSE is needed because affirmative = negative & sig.
# The function internally reverses sign of yi, so the reported mode for mu is
# positive. We negate that mode estimate; tau is sign-invariant.

set.seed(1234)
phacking_res <- phacking_meta(
  yi             = dat$es,
  vi             = dat$vi,
  sei            = dat$se,
  favor_positive = FALSE,
  parallelize    = FALSE
)

cat("\n--- RTMA raw output ---\n")
print(phacking_res$stats)

# Corrected estimates (sign reversal)
# The table uses the RTMA posterior mode for mu, not the mean.
rtma_mu  <- -phacking_res$stats$mode[phacking_res$stats$param == "mu"]
rtma_tau <-  phacking_res$stats$mode[phacking_res$stats$param == "tau"]

cat("\nRTMA mu (sign-corrected):", round(rtma_mu,  3), "\n")
cat("RTMA tau:                 ", round(rtma_tau, 3), "\n")


# ---
# Custom multibias_new() function ----
# Fixes sign bug in multibias_meta() when favor_positive = FALSE
# Original issue: https://github.com/mathurlabstanford/metabias-apps/issues/1
#---

get_multibias <- function(yi, vi, sei, selection_ratio, bias_affirmative,
                          bias_nonaffirmative, cluster = 1:length(yi),
                          biased = TRUE, favor_positive = TRUE,
                          alpha_select = 0.05, ci_level = 0.95,
                          small = TRUE, model_label, ...) {
  vals <- list(
    selection_ratio      = selection_ratio,
    bias_affirmative     = bias_affirmative,
    bias_nonaffirmative  = bias_nonaffirmative,
    favor_positive       = favor_positive,
    alpha_select         = alpha_select,
    ci_level             = ci_level,
    small                = small
  )
  stopifnot(selection_ratio >= 1)
  stopifnot(length(bias_affirmative)    == 1)
  stopifnot(length(bias_nonaffirmative) == 1)
  stopifnot(length(cluster) == length(yi))
  stopifnot(length(biased)  == 1 || length(biased) == length(yi))
  if (missing(vi) && missing(sei))
    stop("Must specify 'vi' or 'sei' argument.")
  if (missing(vi))  vi  <- sei^2
  if (missing(sei)) sei <- sqrt(vi)
  if (length(sei) != length(yi))
    stop("Length of 'vi' or 'sei' must match that of 'yi'.")
  if (any(sei < 0))
    stop("vi or sei should never be negative.")
  stopifnot(length(vi)  == length(yi))
  stopifnot(length(sei) == length(yi))
  naive_pos <- metafor::rma(yi, vi, method = "FE")$beta > 0
  if (naive_pos != favor_positive)
    warning("Favored direction is opposite of the pooled estimate.")
  # Fix: use yif for affirmative determination, keep yi for estimation
  yif  <- if (favor_positive) yi else -yi
  pvals <- 2 * (1 - pnorm(abs(yif) / sqrt(vi)))
  dat_mb <- mutate(tibble(yi, yif, vi, sei, biased, cluster),
                   affirmative = (pvals < alpha_select) & (yif > 0))
  p_affirm_pub    <- mean(pull(filter(dat_mb, .data$biased), .data$affirmative))
  p_nonaffirm_pub <- 1 - p_affirm_pub
  denominator     <- p_affirm_pub + selection_ratio * p_nonaffirm_pub
  mhat_b <- (p_nonaffirm_pub * selection_ratio * bias_nonaffirmative +
               p_affirm_pub * bias_affirmative) / denominator
  dat_mb <- mutate(dat_mb, yi_adj = .data$yi - .data$biased * mhat_b)
  tau2   <- metafor::rma.uni(yi = dat_mb$yi_adj, vi = dat_mb$vi)$tau2
  dat_mb <- mutate(dat_mb,
                   weight     = if_else(.data$affirmative, 1, selection_ratio),
                   userweight = .data$weight / (.data$vi + tau2))
  meta_mb <- robumeta::robu(yi_adj ~ 1, data = dat_mb,
                            studynum   = cluster,
                            var.eff.size = dat_mb$vi,
                            userweights  = dat_mb$userweight,
                            small        = small)
  stats <- mutate(
    select(metabias::robu_ci(meta_mb, ci_level), -.data$param),
    model = model_label, .before = everything()
  )
  fit <- list()
  fit[[model_label]] <- meta_mb
  metabias::metabias(data = dat_mb, values = vals, stats = stats, fits = fit)
}

multibias_new <- function(yi, vi, sei, cluster = 1:length(yi), biased = TRUE,
                          selection_ratio, bias_affirmative, bias_nonaffirmative,
                          favor_positive = TRUE, alpha_select = 0.05,
                          ci_level = 0.95, small = TRUE,
                          return_worst_meta = FALSE,
                          return_pubbias_meta = FALSE) {
  args      <- as.list(environment())
  args      <- discard(args, function(a) class(a) == "name")
  meta_mb   <- exec(get_multibias, !!!args, model_label = "multibias")
  if (return_pubbias_meta) {
    pub_args <- args
    pub_args[c("bias_affirmative", "bias_nonaffirmative")] <- 0
    meta_pub <- exec(get_multibias, !!!pub_args, model_label = "pubbias")
    meta_mb$stats <- bind_rows(meta_mb$stats, meta_pub$stats)
    meta_mb$fits  <- append(meta_mb$fits, meta_pub$fits)
  }
  if (return_worst_meta) {
    dat_mb    <- meta_mb$data
    meta_worst <- robumeta::robu(yi ~ 1,
                                 data         = filter(dat_mb, !.data$affirmative),
                                 studynum     = cluster,
                                 var.eff.size = vi,
                                 small        = small)
    worst_stats <- mutate(
      select(metabias::robu_ci(meta_worst, ci_level), -.data$param),
      model = "worst_case", .before = everything()
    )
    meta_mb$stats          <- bind_rows(meta_mb$stats, worst_stats)
    meta_mb$fits[["worst_case"]] <- meta_worst
  }
  return(meta_mb)
}


#---
# Multi-bias sensitivity analysis ----
# Mathur (2024c) — using corrected multibias_new()
#---

# Multi0.05;0.01: affirmative bias = 0.05, non-affirmative bias = 0.01
multi_51 <- multibias_new(
  yi                  = dat$es,
  vi                  = dat$vi,
  cluster             = dat$study_id,
  selection_ratio     = 4,
  bias_affirmative    = 0.05,
  bias_nonaffirmative = 0.01,
  alpha_select        = 0.05,
  ci_level            = 0.95,
  favor_positive      = FALSE
)
cat("\n--- Multi0.05;0.01 ---\n")
print(multi_51$stats)

# Multi0.08;0.01: affirmative bias = 0.08, non-affirmative bias = 0.01
multi_81 <- multibias_new(
  yi                  = dat$es,
  vi                  = dat$vi,
  cluster             = dat$study_id,
  selection_ratio     = 4,
  bias_affirmative    = 0.08,
  bias_nonaffirmative = 0.01,
  alpha_select        = 0.05,
  ci_level            = 0.95,
  favor_positive      = FALSE
)
cat("\n--- Multi0.08;0.01 ---\n")
print(multi_81$stats)


#---
# Summary table (Table 4 Panel C) ----
#---

tab4_panelC <- tibble(
  Method   = c("MAIVE", "RTMA", "Multi0.05;0.01", "Multi0.08;0.01"),
  N        = rep(nrow(dat), 4),
  Estimate = c(
    MAIVE$beta,
    round(rtma_mu,  3),
    round(multi_51$stats$estimate, 3),
    round(multi_81$stats$estimate, 3)
  ),
  SE = c(
    MAIVE$SE,
    round(phacking_res$stats$se[phacking_res$stats$param == "mu"], 3),
    round(multi_51$stats$se, 3),
    round(multi_81$stats$se, 3)
  ),
  AR_CI_lo = c(MAIVE$AR_CI[1], NA, NA, NA),
  AR_CI_hi = c(MAIVE$AR_CI[2], NA, NA, NA),
  Coef_fitted_SE2     = c(MAIVE$beta_standard, NA, NA, NA),
  se_Coef_fitted_SE2 = c(MAIVE$SE_standard, NA, NA, NA),
  F_stat   = c(MAIVE$`F-test`,  NA, NA, NA),
  tau      = c(NA, round(rtma_tau, 3), NA, NA)
)


print(tab4_panelC)
write_txt_table(
  tab4_panelC,
  file.path(table_path, "table4_panelC.txt")
)

#---
# Figure 10: RTMA diagnostic Q-Q plot ----
#---

fig10 <- phacking::rtma_qqplot(phacking_res)

ggsave(file.path(fig_path, "fig10_rtma_qqplot.pdf"),
       fig10, width = 5, height = 5)


# ------------------------------------------------------------------------------
# End of 04_phacking.R
# ------------------------------------------------------------------------------
